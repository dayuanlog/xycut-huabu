(() => {
  'use strict';
  const clamp = n => Math.max(0, Math.min(1, n));
  const ease = n => { n = clamp(n); return 1 - Math.pow(1 - n, 3); };
  const backOut = n => {
    n = clamp(n);
    const c1 = 1.65, c3 = c1 + 1;
    return 1 + c3 * Math.pow(n - 1, 3) + c1 * Math.pow(n - 1, 2);
  };

  const html = {
    'opening-hook': `
      <div class="v-poster-card">
        <div class="v-badge-row"><span class="v-kicker">🎣 晴空湖畔绘本</span><span style="font-size:26px;font-weight:900;color:#1d78f2">故事开场</span></div>
        <h2 class="v-big-title">男性之间的交友方式，<br>有时候<em>简单得让人佩服</em></h2>
        <div class="v-sub-bar"><span>🐟 一根鱼竿 · 一整年周末 · 零负担友谊</span></div>
      </div>`,
    'comments-bridge': `
      <div class="v-poster-card">
        <div class="v-badge-row"><span class="v-kicker">🌊 评论区鱼群来袭</span><span style="font-size:26px;font-weight:900;color:#27b376">同款经历</span></div>
        <h2 class="v-big-title">结果评论区更精彩，<br>全都是<em>同款钓鱼搭子</em>！</h2>
        <div class="v-sub-bar"><span>🎣 十年网名</span><span>🍺 老张王胖</span><span style="color:#1d78f2">🔍 压轴神评</span></div>
      </div>`,
    'pure-turn': `
      <div class="v-poster-card">
        <div class="v-badge-row"><span class="v-kicker">☀️ 湖畔感悟</span><span style="font-size:26px;font-weight:900;color:#27b376">简单纯粹</span></div>
        <h2 class="v-big-title">笑完其实挺感慨，<br>大家羡慕它<em>足够纯粹</em></h2>
        <div class="v-sub-bar"><span>不查户口 · 有事说事 · 轻装上阵</span></div>
      </div>`,
    'closing-cta': `
      <div class="v-poster-card">
        <div class="v-badge-row"><span class="v-kicker">💬 湖畔夜话</span><span style="font-size:26px;font-weight:900;color:#1d78f2">互动提问</span></div>
        <h2 class="v-big-title">你身边有没有这种<br><em>处得特别轻松</em>的搭子？</h2>
        <div class="v-cta-btn">🎣 评论区说说你们怎么认识的</div>
      </div>`,
    'year-buddy': `
      <div class="il-card">
        <div class="il-head">
          <span class="il-tag is-green">湖畔绘本 #01</span>
          <h2>并肩钓了<em>整整一年</em></h2>
        </div>
        <div class="lake-scene-box">
          <svg class="lake-svg" viewBox="0 0 640 365" aria-hidden="true">
            <!-- Bright sky sun & fluffy clouds -->
            <circle cx="562" cy="54" r="30" fill="#ffd84d" stroke="#163a5f" stroke-width="3"/>
            <g fill="#ffffff" stroke="#163a5f" stroke-width="2.6">
              <path d="M58 64 C58 48,80 42,94 50 C106 36,136 40,142 56 C156 58,158 74,142 76 L68 76 C54 76,52 66,58 64 Z"/>
              <path d="M352 54 C352 42,372 36,384 44 C396 32,422 36,426 50 C438 52,438 66,424 68 L362 68 C350 68,348 58,352 54 Z"/>
            </g>
            <!-- Distant green mountains -->
            <path d="M0 186 Q115 126 240 186 T500 182 T640 174 L640 194 L0 194 Z" fill="#9ae0c4" stroke="#163a5f" stroke-width="2.6"/>
            <!-- Grassy bank & cute reeds -->
            <path d="M0 182 L262 182 Q284 182 284 206 L284 365 L0 365 Z" fill="#5fd194" stroke="#163a5f" stroke-width="3.2"/>
            <!-- Reeds & fishing bucket on bank -->
            <path d="M26 184 Q20 144 34 128 M42 184 Q48 152 38 134" fill="none" stroke="#163a5f" stroke-width="3" stroke-linecap="round"/>
            <ellipse cx="34" cy="128" rx="4" ry="11" fill="#8b5a2b" stroke="#163a5f" stroke-width="2.2"/>
            <path d="M224 238 L230 272 L262 272 L268 238 Z" fill="#ffd84d" stroke="#163a5f" stroke-width="2.8" stroke-linejoin="round"/>
            <path d="M226 238 Q246 220 266 238" fill="none" stroke="#163a5f" stroke-width="2.6"/>
            <!-- Two cute fishing buddies in bucket hats -->
            <g transform="translate(68,142)">
              <rect x="6" y="54" width="30" height="26" rx="5" fill="#d99b66" stroke="#163a5f" stroke-width="3"/>
              <path d="M4 38 Q20 24 38 38 L42 64 L0 64 Z" fill="#1d78f2" stroke="#163a5f" stroke-width="3"/>
              <circle cx="21" cy="20" r="14" fill="#ffe1c6" stroke="#163a5f" stroke-width="3"/>
              <path d="M3 15 Q21 0 39 15 Z" fill="#7ce8ff" stroke="#163a5f" stroke-width="3"/>
              <line x1="-4" y1="15" x2="46" y2="15" stroke="#163a5f" stroke-width="3.2" stroke-linecap="round"/>
            </g>
            <g transform="translate(154,148)">
              <rect x="6" y="54" width="30" height="26" rx="5" fill="#d99b66" stroke="#163a5f" stroke-width="3"/>
              <path d="M4 38 Q20 24 38 38 L42 64 L0 64 Z" fill="#ff8c32" stroke="#163a5f" stroke-width="3"/>
              <circle cx="21" cy="20" r="14" fill="#ffe1c6" stroke="#163a5f" stroke-width="3"/>
              <path d="M3 15 Q21 0 39 15 Z" fill="#ffffff" stroke="#163a5f" stroke-width="3"/>
              <line x1="-4" y1="15" x2="46" y2="15" stroke="#163a5f" stroke-width="3.2" stroke-linecap="round"/>
            </g>
            <!-- Fishing rods & lines -->
            <path d="M108 186 Q256 84 416 106" fill="none" stroke="#163a5f" stroke-width="3.8" stroke-linecap="round"/>
            <path d="M194 192 Q346 102 512 122" fill="none" stroke="#163a5f" stroke-width="3.8" stroke-linecap="round"/>
            <line x1="416" y1="106" x2="416" y2="236" stroke="#163a5f" stroke-width="2" stroke-dasharray="5 5"/>
            <line x1="512" y1="122" x2="512" y2="256" stroke="#163a5f" stroke-width="2" stroke-dasharray="5 5"/>
            <!-- Bobbers & ripples -->
            <g class="bobber-1" transform="translate(416,236)">
              <ellipse cx="0" cy="14" rx="30" ry="8" fill="none" stroke="#ffffff" stroke-width="2.8" opacity="0.9"/>
              <circle cx="0" cy="0" r="9" fill="#ff8c32" stroke="#163a5f" stroke-width="2.6"/>
              <path d="M-9 0 A9 9 0 0 0 9 0 Z" fill="#ffffff" stroke="#163a5f" stroke-width="2.6"/>
            </g>
            <g class="bobber-2" transform="translate(512,256)">
              <ellipse cx="0" cy="14" rx="34" ry="9" fill="none" stroke="#ffffff" stroke-width="2.8" opacity="0.9"/>
              <circle cx="0" cy="0" r="9" fill="#27b376" stroke="#163a5f" stroke-width="2.6"/>
              <path d="M-9 0 A9 9 0 0 0 9 0 Z" fill="#ffffff" stroke="#163a5f" stroke-width="2.6"/>
            </g>
            <!-- Underwater swimming fish -->
            <g class="jump-fish" transform="translate(566,220)">
              <path d="M-20 0 Q-4 -16 16 -5 Q28 0 16 7 Q-4 16 -20 0 Z" fill="#ff8c32" stroke="#163a5f" stroke-width="2.6"/>
              <polygon points="-18,0 -30,-10 -30,10" fill="#ff8c32" stroke="#163a5f" stroke-width="2.6"/>
              <circle cx="8" cy="-2" r="2.5" fill="#163a5f"/>
            </g>
            <g transform="translate(362,318)">
              <ellipse cx="0" cy="0" rx="22" ry="12" fill="#7ce8ff" stroke="#163a5f" stroke-width="2.5"/>
              <polygon points="-20,0 -34,-10 -34,10" fill="#7ce8ff" stroke="#163a5f" stroke-width="2.5"/>
              <circle cx="10" cy="-2" r="2.5" fill="#163a5f"/>
            </g>
            <!-- Sky tag -->
            <g transform="translate(182,22)">
              <rect x="0" y="0" width="212" height="48" rx="14" fill="#ffffff" stroke="#163a5f" stroke-width="3"/>
              <text x="106" y="32" text-anchor="middle" font-size="23" font-weight="900" fill="#1d78f2">放假必约 × 365天</text>
            </g>
          </svg>
          <div class="lake-progress-strip">
            <span>作钓进度</span>
            <div class="lake-bar"><div class="lake-bar-fill"></div></div>
            <span style="color:#1d78f2">整整 1 年</span>
          </div>
          <div class="lake-caption-bar">
            <span class="lake-pill">每次放假一起钓</span>
            <div class="lake-thought">
              <span class="glint-target">老婆以为：铁哥们吧？</span>
              <i class="beat-ripple"></i>
            </div>
          </div>
        </div>
      </div>`,

    'no-name': `
      <div class="il-card">
        <div class="il-head">
          <span class="il-tag is-orange">大型反转</span>
          <h2>认识一年，<em>真名未知</em></h2>
        </div>
        <div class="hook-twist-box">
          <div class="twist-dialog">
            <div class="il-bubble is-q">
              <small>老婆随口一问</small>
              「你那位钓鱼搭子，到底叫啥名字？」
            </div>
            <div class="il-bubble is-a">
              <small>老公淡定回答</small>
              「……不知道！」
            </div>
          </div>
          <svg class="hook-svg-wide" viewBox="0 0 620 235" aria-hidden="true">
            <!-- Rod casting from left -->
            <path d="M24 38 Q220 4 310 42" fill="none" stroke="#163a5f" stroke-width="4.5" stroke-linecap="round"/>
            <line x1="310" y1="42" x2="310" y2="86" stroke="#163a5f" stroke-width="2.6" stroke-dasharray="5 5"/>
            <!-- Hook lifting Giant Question Mark -->
            <g class="hook-q">
              <path d="M310 86 L310 108 Q310 124 294 124 Q282 124 282 112" fill="none" stroke="#163a5f" stroke-width="3.8" stroke-linecap="round"/>
              <circle cx="310" cy="134" r="44" fill="#ff8c32" stroke="#163a5f" stroke-width="3.8"/>
              <text x="310" y="152" text-anchor="middle" font-size="60" font-weight="900" fill="#ffffff">?</text>
            </g>
            <!-- Water surface waves -->
            <path d="M0 144 Q45 130 90 144 T180 144 T270 144 T360 144 T450 144 T540 144 T620 144" fill="none" stroke="#ffffff" stroke-width="4" stroke-linecap="round"/>
            <!-- Two cute confused fish watching -->
            <g transform="translate(115,192)">
              <ellipse cx="0" cy="0" rx="26" ry="15" fill="#7ce8ff" stroke="#163a5f" stroke-width="2.8"/>
              <polygon points="-24,0 -40,-11 -40,11" fill="#7ce8ff" stroke="#163a5f" stroke-width="2.8"/>
              <circle cx="12" cy="-3" r="4.5" fill="#ffffff" stroke="#163a5f" stroke-width="2"/>
              <circle cx="13" cy="-3" r="2" fill="#163a5f"/>
            </g>
            <g transform="translate(505,192) scale(-1,1)">
              <ellipse cx="0" cy="0" rx="26" ry="15" fill="#5fd194" stroke="#163a5f" stroke-width="2.8"/>
              <polygon points="-24,0 -40,-11 -40,11" fill="#5fd194" stroke="#163a5f" stroke-width="2.8"/>
              <circle cx="12" cy="-3" r="4.5" fill="#ffffff" stroke="#163a5f" stroke-width="2"/>
              <circle cx="13" cy="-3" r="2" fill="#163a5f"/>
            </g>
            <text x="165" y="182" font-size="22" font-weight="900" fill="#ffffff">？？？</text>
            <text x="415" y="182" font-size="22" font-weight="900" fill="#ffffff">笑死</text>
          </svg>
          <div class="bro-wave-row">
            <div class="fish-stamp">
              <span class="glint-target">真名：不知道！</span>
              <i class="beat-ripple"></i>
            </div>
            <div class="bro-pill">
              <span>见面照样喊：兄弟！</span>
              <i class="beat-ripple"></i>
            </div>
          </div>
        </div>
      </div>`,

    'comment-1': `
      <div class="il-card">
        <div class="il-head">
          <span class="il-tag">同款 #01</span>
          <h2><em>十年鱼友</em>只知网名</h2>
        </div>
        <div class="il-comment-wrap">
          <svg class="hook-hanger" viewBox="0 0 560 76" aria-hidden="true">
            <path d="M24 18 Q200 2 280 22" fill="none" stroke="#163a5f" stroke-width="4.5" stroke-linecap="round"/>
            <line x1="280" y1="22" x2="280" y2="58" stroke="#163a5f" stroke-width="2.8"/>
            <path d="M280 58 Q280 68 269 68 Q260 68 260 60" fill="none" stroke="#ff8c32" stroke-width="4" stroke-linecap="round"/>
            <circle cx="280" cy="22" r="6" fill="#7ce8ff" stroke="#163a5f" stroke-width="2.5"/>
          </svg>
          <div class="il-comment-frame c1-frame">
            <img src="assets/comments/01-ten-years.png" alt="评论区原图：认识十多年的鱼友，转账才知道叫啥">
          </div>
          <div class="il-comment-footer c1-note">
            <svg class="mini-illust-icon" viewBox="0 0 64 46" aria-hidden="true">
              <ellipse cx="36" cy="23" rx="20" ry="13" fill="#ff8c32" stroke="#163a5f" stroke-width="2.6"/>
              <polygon points="18,23 5,11 5,35" fill="#ff8c32" stroke="#163a5f" stroke-width="2.6"/>
              <circle cx="44" cy="20" r="5" fill="#ffffff" stroke="#163a5f" stroke-width="2.2"/>
              <circle cx="45" cy="20" r="2" fill="#163a5f"/>
            </svg>
            <span class="glint-target">直到<em>转账打名字</em>，才知真名！</span>
            <i class="beat-ripple"></i>
          </div>
          <svg class="il-water-ribbon" viewBox="0 0 560 74" aria-hidden="true">
            <path d="M0 32 Q70 16 140 32 T280 32 T420 32 T560 32 L560 74 L0 74 Z" fill="#2f9de0" opacity="0.45"/>
            <g transform="translate(115,44)">
              <ellipse cx="0" cy="0" rx="18" ry="10" fill="#ffffff" stroke="#163a5f" stroke-width="2.4"/>
              <polygon points="-16,0 -27,-8 -27,8" fill="#ffffff" stroke="#163a5f" stroke-width="2.4"/>
              <circle cx="8" cy="-2" r="2" fill="#163a5f"/>
            </g>
            <text x="280" y="48" text-anchor="middle" font-size="22" font-weight="900" fill="#163a5f">十多年鱼友 · 全靠网名相认</text>
          </svg>
        </div>
      </div>`,

    'comment-2': `
      <div class="il-card">
        <div class="il-head">
          <span class="il-tag is-green">同款 #02</span>
          <h2>丈人的<em>老张与王胖</em></h2>
        </div>
        <div class="il-comment-wrap">
          <div class="il-comment-frame c2-frame">
            <img src="assets/comments/02-laozhang-wangpang.png" alt="评论区原图：丈人钓鱼几十年，老张王胖招呼，干净单纯">
          </div>
          <div class="il-comment-footer is-green c2-note">
            <svg class="mini-illust-icon" viewBox="0 0 64 46" aria-hidden="true">
              <g transform="rotate(-10 22 26)">
                <rect x="10" y="14" width="18" height="24" rx="4" fill="#ffd84d" stroke="#163a5f" stroke-width="2.5"/>
                <path d="M10 15 Q14 7 20 11 Q25 7 28 15 Z" fill="#ffffff" stroke="#163a5f" stroke-width="2.2"/>
              </g>
              <g transform="rotate(10 44 26)">
                <rect x="34" y="14" width="18" height="24" rx="4" fill="#ffd84d" stroke="#163a5f" stroke-width="2.5"/>
                <path d="M34 15 Q38 7 44 11 Q49 7 52 15 Z" fill="#ffffff" stroke="#163a5f" stroke-width="2.2"/>
              </g>
              <path d="M31 4 L31 10 M24 6 L27 11 M38 6 L35 11" stroke="#1d78f2" stroke-width="2.4" stroke-linecap="round"/>
            </svg>
            <span class="glint-target">99赞：<em>干净单纯</em>，不高兴不联系</span>
            <i class="beat-ripple"></i>
          </div>
          <svg class="il-water-ribbon" viewBox="0 0 560 74" aria-hidden="true">
            <path d="M0 32 Q70 16 140 32 T280 32 T420 32 T560 32 L560 74 L0 74 Z" fill="#27b376" opacity="0.32"/>
            <text x="280" y="48" text-anchor="middle" font-size="22" font-weight="900" fill="#163a5f">酒没少喝 · 平时全靠老张、王胖招呼</text>
          </svg>
        </div>
      </div>`,

    'comment-3': `
      <div class="il-card">
        <div class="il-head">
          <span class="il-tag is-orange">压轴神评</span>
          <h2>文艺开场，<em>极限反转</em></h2>
        </div>
        <div class="il-comment-wrap">
          <div class="c3-badges">
            <span class="c3-chip c3-art">⛵ 同一时空 · 最好陪伴</span>
            <span class="c3-chip is-warn c3-alert">🔍 查微信转账 · 红红花花不行</span>
          </div>
          <div class="il-comment-frame c3-frame">
            <img src="assets/comments/03-serious-hobby.png" alt="评论区原图：神评补刀是正经爱好吗">
          </div>
          <div class="c3-shock-bar c3-punch">
            <svg class="mini-illust-icon" viewBox="0 0 64 46" aria-hidden="true">
              <ellipse cx="36" cy="24" rx="20" ry="14" fill="#1d78f2" stroke="#163a5f" stroke-width="2.6"/>
              <polygon points="18,24 5,13 5,35" fill="#1d78f2" stroke="#163a5f" stroke-width="2.6"/>
              <circle cx="44" cy="20" r="6" fill="#ffffff" stroke="#163a5f" stroke-width="2.2"/>
              <circle cx="45" cy="20" r="2.2" fill="#163a5f"/>
              <ellipse cx="52" cy="29" rx="3.5" ry="4.5" fill="#ff8c32" stroke="#163a5f" stroke-width="2"/>
            </svg>
            <span class="glint-target">网友补刀：你这真是<em>正经爱好吗？</em></span>
            <i class="beat-ripple"></i>
          </div>
        </div>
      </div>`,

    'pure-reasons': `
      <div class="il-card">
        <div class="il-head">
          <span class="il-tag">为什么羡慕</span>
          <h2>因为足够<em>纯粹</em></h2>
        </div>
        <div class="fish-reason-list">
          <div class="fish-reason-row r1">
            <svg class="swim-fish-svg" viewBox="0 0 88 58" aria-hidden="true">
              <ellipse cx="52" cy="29" rx="27" ry="18" fill="#1d78f2" stroke="#163a5f" stroke-width="3"/>
              <polygon points="27,29 9,14 9,44" fill="#1d78f2" stroke="#163a5f" stroke-width="3"/>
              <circle cx="64" cy="24" r="5" fill="#ffffff" stroke="#163a5f" stroke-width="2.2"/>
              <circle cx="65" cy="24" r="2.2" fill="#163a5f"/>
              <text x="45" y="35" text-anchor="middle" font-size="18" font-weight="900" fill="#ffffff">01</text>
            </svg>
            <div class="fish-reason-text">
              <strong>不查户口 · 不讲人情世故</strong>
              <small>没有繁琐寒暄，零社交压力</small>
            </div>
            <i class="beat-ripple"></i>
          </div>
          <div class="fish-reason-row r2">
            <svg class="swim-fish-svg" viewBox="0 0 88 58" aria-hidden="true">
              <ellipse cx="52" cy="29" rx="27" ry="18" fill="#27b376" stroke="#163a5f" stroke-width="3"/>
              <polygon points="27,29 9,14 9,44" fill="#27b376" stroke="#163a5f" stroke-width="3"/>
              <circle cx="64" cy="24" r="5" fill="#ffffff" stroke="#163a5f" stroke-width="2.2"/>
              <circle cx="65" cy="24" r="2.2" fill="#163a5f"/>
              <text x="45" y="35" text-anchor="middle" font-size="18" font-weight="900" fill="#ffffff">02</text>
            </svg>
            <div class="fish-reason-text">
              <strong>有事说事 · 简单明了</strong>
              <small>约好时间地点，直奔共同热爱</small>
            </div>
            <i class="beat-ripple"></i>
          </div>
          <div class="fish-reason-row r3">
            <svg class="swim-fish-svg" viewBox="0 0 88 58" aria-hidden="true">
              <ellipse cx="52" cy="29" rx="27" ry="18" fill="#ff8c32" stroke="#163a5f" stroke-width="3"/>
              <polygon points="27,29 9,14 9,44" fill="#ff8c32" stroke="#163a5f" stroke-width="3"/>
              <circle cx="64" cy="24" r="5" fill="#ffffff" stroke="#163a5f" stroke-width="2.2"/>
              <circle cx="65" cy="24" r="2.2" fill="#163a5f"/>
              <text x="45" y="35" text-anchor="middle" font-size="18" font-weight="900" fill="#ffffff">03</text>
            </svg>
            <div class="fish-reason-text">
              <strong>合得来开心 · 不合不内耗</strong>
              <small>进退自如，全凭自在舒服</small>
            </div>
            <i class="beat-ripple"></i>
          </div>
        </div>
      </div>`,

    'light-ending': `
      <div class="il-card">
        <div class="il-head">
          <span class="il-tag is-green">成年人处关系</span>
          <h2>最舒服的<em>边界感</em></h2>
        </div>
        <div class="sunset-card">
          <svg class="sunset-svg" viewBox="0 0 640 310" aria-hidden="true">
            <defs>
              <linearGradient id="skyLakeGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stop-color="#bfe7ff"/>
                <stop offset="56%" stop-color="#e3f6ff"/>
                <stop offset="100%" stop-color="#7ce8ff"/>
              </linearGradient>
            </defs>
            <rect width="640" height="310" fill="url(#skyLakeGrad)"/>
            <!-- Soft clouds -->
            <g fill="#ffffff" stroke="#163a5f" stroke-width="2.6">
              <path d="M90 66 C90 50,114 44,128 52 C142 38,172 42,178 58 C192 60,194 76,178 78 L100 78 C86 78,84 68,90 66 Z"/>
              <path d="M440 58 C440 45,460 40,472 47 C484 35,510 39,514 52 C526 54,526 68,512 70 L450 70 C438 70,436 60,440 58 Z"/>
            </g>
            <!-- Sun over calm blue lake -->
            <circle cx="320" cy="186" r="56" fill="#ffd84d" stroke="#163a5f" stroke-width="3.2"/>
            <rect x="0" y="186" width="640" height="124" fill="#42b0eb" stroke="#163a5f" stroke-width="2.8"/>
            <line x1="242" y1="214" x2="398" y2="214" stroke="#ffffff" stroke-width="6" stroke-linecap="round"/>
            <line x1="268" y1="238" x2="372" y2="238" stroke="#ffffff" stroke-width="5" stroke-linecap="round"/>
            <line x1="292" y1="260" x2="348" y2="260" stroke="#ffffff" stroke-width="4" stroke-linecap="round"/>
            <!-- Grass bank, bucket & packed fishing rod -->
            <path d="M0 198 L184 198 Q206 198 214 310 L0 310 Z" fill="#5fd194" stroke="#163a5f" stroke-width="3.2"/>
            <path d="M58 194 L68 252 L116 252 L126 194 Z" fill="#ffd84d" stroke="#163a5f" stroke-width="3.2" stroke-linejoin="round"/>
            <path d="M60 194 Q92 164 124 194" fill="none" stroke="#163a5f" stroke-width="3.2"/>
            <line x1="142" y1="248" x2="218" y2="108" stroke="#163a5f" stroke-width="4.5" stroke-linecap="round"/>
            <!-- Birds -->
            <path d="M428 118 Q442 104 456 118 Q470 104 484 118" fill="none" stroke="#163a5f" stroke-width="3" stroke-linecap="round"/>
            <path d="M510 144 Q520 134 530 144 Q540 134 550 144" fill="none" stroke="#163a5f" stroke-width="2.6" stroke-linecap="round"/>
          </svg>
          <div class="sunset-bottom">
            <div class="sunset-quote">
              成年人处关系，<br>像这样 <em class="glint-target">轻装上阵</em>
            </div>
            <div class="sunset-stamp">
              <span>其实挺舒服</span>
              <i class="beat-ripple"></i>
            </div>
          </div>
        </div>
      </div>`
  };

  function setRipple(el, t, at, duration = 0.65, all = false) {
    if (!el) return;
    if (all || t < at || t > at + duration) {
      el.style.opacity = '0';
      el.style.transform = 'translate(-50%,-50%) scale(.4)';
      return;
    }
    const u = clamp((t - at) / duration);
    el.style.opacity = String(0.8 * (1 - u));
    el.style.transform = `translate(-50%,-50%) scale(${0.45 + 1.55 * ease(u)})`;
  }

  function setGlint(el, t, at, duration = 0.72, all = false) {
    if (!el) return;
    if (all || t < at || t > at + duration) {
      el.style.setProperty('--glint-pos', '-30%');
      el.style.setProperty('--glint-alpha', '0');
      return;
    }
    const u = clamp((t - at) / duration);
    el.style.setProperty('--glint-pos', (-30 + 160 * ease(u)) + '%');
    el.style.setProperty('--glint-alpha', String(Math.sin(Math.PI * u)));
  }

  function render(t, { all = false } = {}) {
    const within = (at, dur = 0.34) => all ? 1 : ease((t - at) / dur);
    const show = (el, at, dx = 0, dy = 18, dur = 0.34, floor = 0) => {
      if (!el) return;
      const u = within(at, dur);
      el.style.opacity = String(floor + (1 - floor) * u);
      el.style.transform = `translate(${dx * (1 - u)}px,${dy * (1 - u)}px)`;
    };
    const pop = (el, at, rot = 0, floor = 0) => {
      if (!el) return;
      const u = all ? 1 : backOut((t - at) / 0.34);
      const vis = all ? 1 : clamp((t - at) / 0.14);
      el.style.opacity = String(floor + (1 - floor) * vis);
      el.style.transform = `rotate(${rot}deg) scale(${0.82 + 0.18 * u})`;
    };
    const root = id => document.querySelector(`#world [data-component="${id}"]`);

    // 1. year-buddy
    let r = root('year-buddy');
    if (r) {
      show(r.querySelector('.il-head'), 3.0, 0, 12, 0.34, 0.78);
      const bob1 = r.querySelector('.bobber-1');
      const bob2 = r.querySelector('.bobber-2');
      const dy1 = all ? 0 : Math.sin(t * 4.2) * 6;
      const dy2 = all ? 0 : Math.cos(t * 3.6) * 6;
      if (bob1) bob1.setAttribute('transform', `translate(416,${(236 + dy1).toFixed(1)})`);
      if (bob2) bob2.setAttribute('transform', `translate(512,${(256 + dy2).toFixed(1)})`);
      const fish = r.querySelector('.jump-fish');
      if (fish) {
        const fy = all ? 0 : -Math.abs(Math.sin(t * 3.2)) * 20;
        fish.setAttribute('transform', `translate(566,${(220 + fy).toFixed(1)}) rotate(${(fy * 0.8).toFixed(1)})`);
      }
      const fill = r.querySelector('.lake-bar-fill');
      if (fill) fill.style.width = (within(6.75, 0.95) * 100).toFixed(1) + '%';
      show(r.querySelector('.lake-thought'), 8.05, 0, 14, 0.36, 0.35);
      setGlint(r.querySelector('.lake-thought .glint-target'), t, 8.2, 0.75, all);
      setRipple(r.querySelector('.lake-thought .beat-ripple'), t, 8.25, 0.65, all);
    }

    // 2. no-name
    r = root('no-name');
    if (r) {
      show(r.querySelector('.il-head'), 9.9, 0, 12, 0.34, 0.78);
      show(r.querySelector('.il-bubble.is-q'), 11.4, -20, 0, 0.34, 0.6);
      show(r.querySelector('.il-bubble.is-a'), 13.35, 20, 0, 0.34, 0.4);
      const hq = r.querySelector('.hook-q');
      if (hq) {
        const lift = within(13.5, 0.45);
        const sway = all ? 0 : Math.sin(t * 4.5) * 4;
        hq.setAttribute('transform', `translate(0,${((1 - lift) * 28).toFixed(1)}) rotate(${sway.toFixed(1)} 310 86)`);
      }
      pop(r.querySelector('.fish-stamp'), 13.7, -2.5, 0.2);
      setGlint(r.querySelector('.fish-stamp .glint-target'), t, 14.0, 0.75, all);
      setRipple(r.querySelector('.fish-stamp .beat-ripple'), t, 13.78, 0.7, all);
      pop(r.querySelector('.bro-pill'), 16.65, 2, 0.2);
      setRipple(r.querySelector('.bro-pill .beat-ripple'), t, 16.8, 0.7, all);
    }

    // 3. comment-1
    r = root('comment-1');
    if (r) {
      show(r.querySelector('.il-head'), 22.85, 0, 12, 0.34, 0.78);
      const frame = r.querySelector('.c1-frame');
      if (frame) {
        const u = within(23.1, 0.4);
        frame.style.opacity = String(0.7 + 0.3 * u);
        frame.style.transform = `rotate(-1deg) translateY(${(1 - u) * 14}px)`;
      }
      pop(r.querySelector('.c1-note'), 27.34, 0, 0.3);
      setGlint(r.querySelector('.c1-note .glint-target'), t, 27.6, 0.75, all);
      setRipple(r.querySelector('.c1-note .beat-ripple'), t, 27.45, 0.7, all);
    }

    // 4. comment-2
    r = root('comment-2');
    if (r) {
      show(r.querySelector('.il-head'), 30.1, 0, 12, 0.34, 0.78);
      const frame = r.querySelector('.c2-frame');
      if (frame) {
        const u = within(30.4, 0.4);
        frame.style.opacity = String(0.7 + 0.3 * u);
        frame.style.transform = `rotate(1deg) translateY(${(1 - u) * 14}px)`;
      }
      pop(r.querySelector('.c2-note'), 36.65, 0, 0.3);
      setGlint(r.querySelector('.c2-note .glint-target'), t, 38.2, 0.75, all);
      setRipple(r.querySelector('.c2-note .beat-ripple'), t, 36.75, 0.7, all);
    }

    // 5. comment-3
    r = root('comment-3');
    if (r) {
      show(r.querySelector('.il-head'), 41.8, 0, 12, 0.34, 0.78);
      show(r.querySelector('.c3-art'), 43.8, -14, 0, 0.34, 0.5);
      show(r.querySelector('.c3-alert'), 49.0, 14, 0, 0.34, 0.25);
      const frame = r.querySelector('.c3-frame');
      if (frame) {
        const u = within(42.1, 0.4);
        frame.style.opacity = String(0.7 + 0.3 * u);
        frame.style.transform = `translateY(${(1 - u) * 12}px)`;
      }
      pop(r.querySelector('.c3-punch'), 53.25, -1, 0.2);
      setGlint(r.querySelector('.c3-punch .glint-target'), t, 54.4, 0.78, all);
      setRipple(r.querySelector('.c3-punch .beat-ripple'), t, 54.35, 0.75, all);
    }

    // 6. pure-reasons
    r = root('pure-reasons');
    if (r) {
      show(r.querySelector('.il-head'), 59.8, 0, 12, 0.34, 0.78);
      const rows = [['.r1', 59.85], ['.r2', 61.60], ['.r3', 63.16]];
      for (const [sel, at] of rows) {
        const item = r.querySelector(sel);
        if (!item) continue;
        show(item, at, -24, 0, 0.36, 0.38);
        setRipple(item.querySelector('.beat-ripple'), t, at + 0.08, 0.6, all);
      }
    }

    // 7. light-ending
    r = root('light-ending');
    if (r) {
      show(r.querySelector('.il-head'), 65.6, 0, 12, 0.34, 0.78);
      show(r.querySelector('.sunset-quote'), 66.1, 0, 14, 0.36, 0.68);
      setGlint(r.querySelector('.sunset-quote .glint-target'), t, 67.2, 0.75, all);
      pop(r.querySelector('.sunset-stamp'), 68.3, -3, 0.28);
      setRipple(r.querySelector('.sunset-stamp .beat-ripple'), t, 68.38, 0.7, all);
    }
  }

  window.FishingDiagrams = { html, render };
})();
