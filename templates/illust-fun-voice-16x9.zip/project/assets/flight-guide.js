(() => {
  'use strict';
  const P = window.CANVAS_PLAN;
  const C = window.CanvasCamera;
  if (!P || !C) return;

  const clamp = x => Math.max(0, Math.min(1, x));
  const ease = x => { x = clamp(x); return x * x * (3 - 2 * x); };
  const rect = P.framing?.content_rect || { x: 0, y: 0, width: P.output.width, height: P.output.height };
  const ns = 'http://www.w3.org/2000/svg';

  const svg = document.createElementNS(ns, 'svg');
  svg.id = 'camera-flight-guide';
  svg.setAttribute('viewBox', `0 0 ${P.output.width} ${P.output.height}`);
  svg.setAttribute('aria-hidden', 'true');
  Object.assign(svg.style, {
    position: 'absolute',
    inset: '0',
    width: '100%',
    height: '100%',
    zIndex: '36',
    pointerEvents: 'none',
    display: 'none'
  });

  svg.innerHTML = `<defs>
    <clipPath id="flight-safe-clip"><rect x="${rect.x}" y="${rect.y - 40}" width="${rect.width}" height="${rect.height + 80}"/></clipPath>
    <filter id="flight-soft-glow" x="-40%" y="-40%" width="180%" height="180%"><feGaussianBlur stdDeviation="2.6"/></filter>
    <linearGradient id="flight-tail-grad" gradientUnits="userSpaceOnUse">
      <stop offset="0" stop-color="var(--flight-tail,#e4b46d)" stop-opacity="0"/>
      <stop offset="0.55" stop-color="var(--flight-main,#b54432)" stop-opacity="0.58"/>
      <stop offset="1" stop-color="var(--flight-main,#b54432)" stop-opacity="0.96"/>
    </linearGradient>
  </defs>
  <g class="flight-layer">
    <path class="flight-trail-halo" fill="none" stroke="var(--flight-tail,#e4b46d)" stroke-width="6.5" opacity=".32" stroke-linecap="round" filter="url(#flight-soft-glow)"/>
    <path class="flight-trail" fill="none" stroke="url(#flight-tail-grad)" stroke-width="3" stroke-dasharray="8 9" stroke-linecap="round"/>
    <circle class="flight-ripple-outer" fill="none" stroke="var(--flight-main,#b54432)" stroke-width="2"/>
    <circle class="flight-ripple-inner" fill="none" stroke="var(--flight-tail,#e4b46d)" stroke-width="2.2"/>
    <g class="flight-plane">
      <path d="M22 0 L-14 -12 L-8 0 L-14 12 Z" fill="var(--flight-main,#b54432)" stroke="#fffaf0" stroke-width="1.3" stroke-linejoin="round"/>
      <path d="M22 0 L-8 0 L-11 5.5 Z" fill="#82291b" opacity=".55"/>
    </g>
  </g>`;

  document.querySelector('#stage').append(svg);

  const layer = svg.querySelector('.flight-layer');
  const trail = svg.querySelector('.flight-trail');
  const halo = svg.querySelector('.flight-trail-halo');
  const plane = svg.querySelector('.flight-plane');
  const rippleOuter = svg.querySelector('.flight-ripple-outer');
  const rippleInner = svg.querySelector('.flight-ripple-inner');
  const grad = svg.querySelector('#flight-tail-grad');

  const finalCam = shot => {
    const b = C.bounds(P, shot.target);
    const pad = shot.padding ?? 0.08;
    return {
      cx: b.x + b.width / 2,
      cy: b.y + b.height / 2,
      screen_cx: rect.x + rect.width / 2,
      screen_cy: rect.y + rect.height / 2,
      scale: Math.min(rect.width * (1 - 2 * pad) / b.width, rect.height * (1 - 2 * pad) / b.height) * (shot.context_scale ?? 1)
    };
  };

  // Glide events: ONLY across different 16:9 boards (never cluttering close neighbors on the same board)
  const moveEvents = P.shots.flatMap((shot, i) => {
    if (!i || !shot.move || shot.move < 0.4 || shot.flight?.enabled === false) return [];
    const prevShot = P.shots[i - 1];
    const prevComp = P.components.find(c => c.id === prevShot.target.split('/')[0]);
    const nextComp = P.components.find(c => c.id === shot.target.split('/')[0]);
    const crossBoard = prevComp && nextComp && prevComp.board_id !== nextComp.board_id;
    if (!crossBoard && shot.flight?.enabled !== true) return [];
    const from = finalCam(prevShot);
    const to = finalCam(shot);
    if (Math.hypot(to.cx - from.cx, to.cy - from.cy) < 40) return [];
    return [{
      kind: 'glide',
      id: shot.id,
      start: shot.at,
      arrive: shot.at + shot.move,
      shot, from, to
    }];
  });

  // Entry swoops: opening hook + landing onto each canvas entry
  const swoops = (P.flight_guides?.swoops || [
    { id: 'opening-swoop', start: 0.24, arrive: 1.02, p0: [95, 1340], p1: [270, 1080], p2: [730, 1020], p3: [910, 1140], dark: true },
    { id: 'enter-task', start: 9.52, arrive: 10.18, p0: [780, 560], p1: [560, 480], p2: [340, 560], p3: [235, 650], dark: false },
    { id: 'enter-step1', start: 19.62, arrive: 20.22, p0: [780, 560], p1: [540, 490], p2: [350, 560], p3: [220, 645], dark: false },
    { id: 'enter-rev', start: 44.48, arrive: 45.06, p0: [780, 560], p1: [560, 500], p2: [340, 570], p3: [230, 655], dark: false },
    { id: 'enter-small', start: 49.68, arrive: 50.26, p0: [780, 560], p1: [560, 500], p2: [340, 570], p3: [230, 655], dark: false }
  ]);

  const project = (p, cam) => {
    const reserve = window.CanvasSubtitles?.reserve?.(P.output) || 0;
    const scx = cam.screen_cx ?? (P.output.width / 2);
    const scy = cam.screen_cy ?? ((P.output.height - reserve) / 2);
    return {
      x: scx + (p.cx - cam.cx) * cam.scale,
      y: scy + (p.cy - cam.cy) * cam.scale
    };
  };

  function cubic(ev, u) {
    const pts = ev.points
      ? ev.points.map(p => Array.isArray(p) ? p : [p.x, p.y])
      : [ev.p0, ev.p1, ev.p2, ev.p3];
    const [a, b, c, d] = pts;
    const v = 1 - u;
    return {
      x: v * v * v * a[0] + 3 * v * v * u * b[0] + 3 * v * u * u * c[0] + u * u * u * d[0],
      y: v * v * v * a[1] + 3 * v * v * u * b[1] + 3 * v * u * u * c[1] + u * u * u * d[1]
    };
  }

  function hide() {
    svg.style.display = 'none';
    svg.dataset.event = '';
  }

  function render(t, { browsing = false, cover = false, small = 0 } = {}) {
    if (browsing || cover) { hide(); return; }
    const hold = 0.06, fade = 0.36, release = hold + fade;
    const swoop = swoops.find(e => t >= e.start && t <= e.arrive + release);
    const glide = !swoop && small > 0.55 ? moveEvents.find(e => t >= e.start && t <= e.arrive + release) : null;
    const ev = swoop || glide;
    if (!ev) { hide(); return; }
    const isDark = ev.dark ?? (ev.requires_canvas === false);
    if (swoop && !isDark && small < 0.55) { hide(); return; }

    svg.style.setProperty('--flight-main', isDark ? '#f6d28b' : 'var(--video-accent,#b54432)');
    svg.style.setProperty('--flight-tail', isDark ? '#e49a6d' : 'var(--video-marker,#e4b46d)');
    layer.setAttribute('clip-path', isDark ? '' : 'url(#flight-safe-clip)');

    const u = clamp((t - ev.start) / (ev.arrive - ev.start));
    const cam = C.at(P, t);
    let progress = ev.kind === 'glide' ? Math.min(1, u + 0.14 * Math.sin(Math.PI * u)) : ease(u);

    let pointAt;
    if (ev.kind === 'glide') {
      const dx = ev.to.cx - ev.from.cx, dy = ev.to.cy - ev.from.cy;
      const dist = Math.hypot(dx, dy) || 1;
      const bend = (ev.shot.curve >= 0 ? 1 : -1) * Math.min(54, Math.max(28, dist * cam.scale * 0.06));
      pointAt = p => {
        p = clamp(p);
        const pt = project(C.at(P, ev.start + (ev.arrive - ev.start) * p), cam);
        const arc = bend * Math.sin(Math.PI * p) ** 2;
        return { x: pt.x - dy / dist * arc, y: pt.y + dx / dist * arc };
      };
    } else {
      pointAt = p => cubic(ev, clamp(p));
    }

    const head = pointAt(progress);
    const tailFrac = 0.42;
    const tailStart = Math.max(0, progress - tailFrac);
    const pts = [];
    for (let i = 0; i <= 26; i++) pts.push(pointAt(tailStart + (progress - tailStart) * i / 26));
    const d = pts.map((p, i) => `${i ? 'L' : 'M'}${p.x.toFixed(2)} ${p.y.toFixed(2)}`).join(' ');
    trail.setAttribute('d', d);
    halo.setAttribute('d', d);
    trail.style.strokeDashoffset = String(-(t - ev.start) * 28);
    grad.setAttribute('x1', pts[0].x); grad.setAttribute('y1', pts[0].y);
    grad.setAttribute('x2', head.x); grad.setAttribute('y2', head.y);

    const a = pointAt(Math.max(0, progress - 0.015));
    const b = pointAt(Math.min(1, progress + 0.015));
    const angle = Math.atan2(b.y - a.y, b.x - a.x) * 180 / Math.PI;
    const planeScale = ev.dark ? 1.15 : 1.05;
    plane.setAttribute('transform', `translate(${head.x.toFixed(2)} ${head.y.toFixed(2)}) rotate(${angle.toFixed(2)}) scale(${planeScale})`);

    const fadeOut = 1 - ease((t - ev.arrive - hold) / fade);
    const fadeIn = ease((t - ev.start) / 0.1);
    svg.style.display = 'block';
    svg.style.opacity = String((fadeIn * fadeOut * (ev.dark ? 0.88 : 0.92)).toFixed(3));

    // Concentric expanding arrival ripples
    const land = clamp((t - ev.arrive + 0.03) / release);
    const rAlpha = land > 0 ? Math.sin(Math.PI * land) : 0;
    rippleOuter.setAttribute('cx', head.x); rippleOuter.setAttribute('cy', head.y);
    rippleOuter.setAttribute('r', (12 + 34 * ease(land)).toFixed(2));
    rippleOuter.style.opacity = (rAlpha * 0.65).toFixed(3);
    rippleInner.setAttribute('cx', head.x); rippleInner.setAttribute('cy', head.y);
    rippleInner.setAttribute('r', (7 + 20 * ease(land)).toFixed(2));
    rippleInner.style.opacity = (rAlpha * 0.85).toFixed(3);

    svg.dataset.event = ev.id;
  }

  window.CameraFlightGuide = { render, root: svg };
})();
