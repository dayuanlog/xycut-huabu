(() => {
  'use strict';
  const P = window.CANVAS_PLAN, C = P.cues, $ = s => document.querySelector(s);
  const stage = $('#stage'), world = $('#world'), video = $('#presenter-video'), voice = $('#voice');
  const renderMode = new URLSearchParams(location.search).get('render') === '1';
  if (renderMode) document.body.classList.add('render-mode');
  const clamp = x => Math.max(0, Math.min(1, x));
  const smooth = x => { x = clamp(x); return x * x * (3 - 2 * x); };
  const mix = (a, b, u) => a + (b - a) * u;
  const originalLead = P.intro?.duration || 0;
  let time = 0, lead = originalLead, coverEnabled = true, mode = 'demo', playing = false, freeCamera = null, frame = 0, lastSync = 0, seekQueue = Promise.resolve();
  let viewport = { ...P.output }, browseTarget = 'overview', segment = null, selected = '', tool = 'select', drag = null, spaceDown = false, lastTapTarget = null;
  const duration = () => P.content_duration + lead, audioOffset = () => originalLead - lead, bodyTime = () => Math.max(0, time - lead);

  world.style.width = P.world.width + 'px';
  world.style.height = P.world.height + 'px';

  for (const b of P.boards) {
    const boardEl = document.createElement('div');
    boardEl.className = 'board-frame';
    boardEl.dataset.board = b.id;
    Object.assign(boardEl.style, { left: b.x + 'px', top: b.y + 'px', width: b.width + 'px', height: b.height + 'px' });
    const label = document.createElement('div');
    label.className = 'board-frame-label';
    label.textContent = b.name || b.id;
    boardEl.append(label);
    world.append(boardEl);
  }

  const shirt = '<svg class="shirt" viewBox="0 0 110 120" fill="none"><path d="M35 12 12 25 3 51 24 61 29 47v62h52V47l5 14 21-10-10-26-23-13c-3 20-35 20-39 0Z" fill="currentColor" fill-opacity=".12" stroke="currentColor" stroke-width="4"/><path d="M37 13c3 19 32 19 36 0" stroke="currentColor" stroke-width="4"/></svg>';
  const html = {
    'cost-comparison': `<h2 class="serif">把次数也算进去<small>价格 ÷ 使用次数</small></h2><div class="cost-card a" data-at="shirtA">${shirt}<div class="calc"><div class="meta">第一件衣服</div><div class="equation"><span>100</span><span class="operator" data-at="usesA">÷</span><span data-at="usesA">2</span><span class="operator" data-at="resultA">＝</span><span class="result" data-count="50" data-at="resultA">50</span><span class="unit" data-at="resultA">元/次</span></div></div></div><div class="cost-card b" data-at="shirtB">${shirt}<div class="calc"><div class="meta">另一件衣服</div><div class="equation"><span>300</span><span class="operator" data-at="usesB">÷</span><span data-at="usesB">30</span><span class="operator" data-at="resultB">＝</span><span class="result" data-count="10" data-at="resultB">10</span><span class="unit" data-at="resultB">元/次</span></div></div></div><div class="cost-foot" data-at="cost">每次使用的成本<span class="pink">更低</span><small>同样是衣服，使用次数改变了答案</small></div>`,
    'idle-equipment': `<h2 class="serif">折扣很大，<span class="pink">然后呢？</span><small>买到，不等于用到</small></h2><div class="idle-stage"><div class="sale-badge" data-at="sale">打折</div><div class="equipment" data-at="equipment"><svg viewBox="0 0 360 330" fill="none"><rect x="30" y="115" width="30" height="122" rx="12" fill="white"/><rect x="74" y="140" width="25" height="73" rx="8" fill="white"/><rect x="44" y="163" width="200" height="25" rx="10" fill="var(--accent)"/><rect x="231" y="140" width="25" height="73" rx="8" fill="white"/><rect x="270" y="115" width="30" height="122" rx="12" fill="white"/><path d="M65 282h193c31 0 42-24 19-35l-59-27-21-35-29 39-64 12-39 46Z" fill="var(--accent)"/><path d="m132 231 50 15m-17-32 43 17" stroke="white" stroke-width="6" stroke-linecap="round"/></svg></div><div class="idle-arrow">→</div><div class="closet"><div class="shelf"></div><div class="door left"></div><div class="door right"></div></div></div><div class="idle-foot serif" data-at="waste">闲置，<span class="pink">没有价值</span><small>折扣再大，也要真正用起来</small></div>`,
    'buying-questions': `<h2 class="serif">买之前问自己<small>给冲动一次停顿</small></h2><div class="question q1" data-at="q1"><div class="number">01</div><strong>用在哪？<small>有没有明确的使用场景</small></strong></div><div class="question q2" data-at="q2"><div class="number">02</div><strong>已有替代吗？<small>家里是不是已经有同类东西</small></strong></div><div class="question q3" data-at="q3"><div class="number">03</div><strong>没有促销，还买吗？<small>分清需要，还是被折扣吸引</small></strong></div><div class="q-summary" data-at="budget">再比较：价格 · 质量 · 预算</div>`,
    'value-conclusion': `<h2 class="serif">买得便宜，也要买得值<small>把价值带回生活</small></h2><div class="verdict"><div data-at="cheap">看起来便宜<small>标价低，未必经常用</small></div><div class="worth" data-at="worth">买回来值得<small>适合自己，也真正用得上</small></div></div>`
  };

  const elements = new Map();
  for (const c of P.components) {
    const el = document.createElement('section');
    el.className = 'component';
    el.dataset.component = c.id;
    const b = P.boards.find(x => x.id === c.board_id);
    Object.assign(el.style, { left: (b.x + c.bounds.x) + 'px', top: (b.y + c.bounds.y) + 'px', width: c.bounds.width + 'px', height: c.bounds.height + 'px' });
    el.innerHTML = html[c.id];
    world.append(el);
    elements.set(c.id, el);
  }
  window.CanvasScene = { elements, render: t => draw(t + lead) };
  const captions = window.CanvasSubtitles = CanvasSubtitleTrack.create({ stage, timeline: FINAL_TIMELINE, output: P.output, config: P.subtitle_settings, isBrowsing: () => mode === 'browse', requestRender: () => draw(time) });
  const animated = [...world.querySelectorAll('[data-at]')];

  function reveal(el, t, at, all, floor = 0.28) {
    const u = all ? 1 : smooth((t - at) / 0.28);
    el.style.opacity = String(floor + (1 - floor) * u);
    el.style.transform = `translateY(${(1 - u) * 14}px)`;
    return u;
  }
  function smallAmount(t) {
    let value = 0;
    for (const [start, end] of P.presenter_layout.canvas_intervals) {
      if (t >= start && t < end + 0.34) value = Math.max(value, smooth((t - start) / 0.38) * (1 - smooth((t - end) / 0.34)));
    }
    return value;
  }
  function cameraAt(t) {
    if (segment && P.components.some(c => c.id === segment.target)) {
      const f = CanvasCamera.fit(CanvasCamera.bounds(P, segment.target), P.output, 0.08);
      f.scale *= 0.88;
      return { ...f, shot: { target: segment.target }, index: 0, u: 1 };
    }
    return CanvasCamera.at(P, t);
  }
  function draw(presentationTime) {
    time = Math.max(0, Math.min(duration(), presentationTime));
    const t = bodyTime(), browsing = mode === 'browse', all = browsing, small = smallAmount(t), cam = browsing ? freeCamera : cameraAt(t);
    world.style.transform = CanvasCamera.matrix(cam, browsing ? viewport : P.output);
    const current = cam.shot?.target;
    const canvasMix = browsing ? 1 : smooth((small - 0.16) / 0.32);
    stage.style.setProperty('--canvas-mix', canvasMix.toFixed(4));
    stage.classList.toggle('canvas-active', canvasMix > 0.5);

    const idx = cam.index ?? 0, prior = P.shots[Math.max(0, idx - 1)], uCam = browsing ? 1 : smooth(cam.u ?? 1);
    const priorId = prior?.target?.split('/')[0], targetId = current?.split('/')[0];
    const pixelScale = browsing ? 1 : Math.max(0.4, cam.scale || 1);
    for (const c of P.components) {
      const el = elements.get(c.id);
      if (browsing) { el.style.filter = 'none'; continue; }
      const weight = Math.min(1, (c.id === priorId ? 1 - uCam : 0) + (c.id === targetId ? uCam : 0));
      const blur = (5.0 / pixelScale) * (1 - weight);
      el.style.filter = weight > 0.995 ? 'none' : `brightness(${(0.32 + 0.68 * weight).toFixed(3)}) blur(${blur.toFixed(2)}px)`;
    }

    for (const el of animated) {
      reveal(el, t, C[el.dataset.at], all);
      if (el.dataset.count) {
        const u = all ? 1 : smooth((t - C[el.dataset.at]) / 0.32);
        el.textContent = String(Math.round(Number(el.dataset.count) * u));
        el.style.minWidth = '2ch';
      }
    }
    const equipment = $('.equipment'), store = all ? 1 : smooth((t - C.closet) / 0.65);
    equipment.style.transform = `translate(${store * 330}px,${store * -14}px) scale(${1 - store * 0.55})`;
    equipment.style.opacity = String((all ? 1 : smooth((t - C.equipment) / 0.25)) * (1 - store * 0.78));
    const doors = all ? 1 : smooth((t - C.closet - 0.4) / 0.36);
    $('.door.left').style.transform = `perspective(700px) rotateY(${-100 * (1 - doors)}deg)`;
    $('.door.right').style.transform = `perspective(700px) rotateY(${100 * (1 - doors)}deg)`;
    $('.idle-arrow').style.opacity = String(all ? 0 : 1 - store);
    $('.sale-badge').style.opacity = String((all ? 0 : smooth((t - C.sale) / 0.2)) * (1 - smooth((t - C.waste) / 0.3)));
    for (const [i, key] of ['q1', 'q2', 'q3'].entries()) {
      const el = $('.question.' + key), active = all || (t >= C[key] && (i === 2 || t < C[['q2', 'q3'][i]]));
      el.classList.toggle('is-current', active);
    }

    const pin = P.presenter_layout.window;
    const w = mix(1080, pin.width, small), h = mix(1920, pin.height, small);
    const x = mix(0, pin.x, small), y = mix(0, pin.y, Math.pow(small, 0.68));
    const box = $('#presenter');
    Object.assign(box.style, {
      left: x + 'px', top: y + 'px', width: w + 'px', height: h + 'px',
      borderRadius: (small * pin.width / 2) + 'px',
      boxShadow: small > 0.85 ? `0 0 0 3px ${P.theme.accent}, 0 12px 28px rgba(0,0,0,${(0.35 * small).toFixed(3)})` : 'none'
    });
    const vw = mix(1200, 336, small), vh = vw * 1920 / 1080;
    Object.assign(video.style, { width: vw + 'px', height: vh + 'px', left: mix(-60, -68, small) + 'px', top: mix(0, -104, small) + 'px' });

    $('#full-shade').style.opacity = String(1 - smooth(small / 0.65));
    $('#film-title').style.opacity = '1';
    $('#cover').style.display = (!browsing && coverEnabled && time < lead) ? 'flex' : 'none';
    window.CameraFlightGuide?.render(t, { browsing, cover: time < lead, small });

    captions.render(t);
    captions.root.style.display = time < lead || browsing || captions.getMode() === 'off' ? 'none' : 'block';
    const line = FINAL_TIMELINE.lines.find(l => l.line_id === captions.root.dataset.lineId), entry = line ? smooth((t - line.target_start_ms / 1000) / 0.16) : 1;
    captions.root.dataset.editorial = (P.subtitle_settings.strong_lines || []).includes(line?.line_id) ? 'strong' : 'normal';
    captions.root.querySelector('.canvas-caption-line').style.transform = `translateY(${(1 - entry) * 8}px)`;
    window.CaptionDirector?.render(t, { browsing, cover: time < lead });
    for (const el of stage.querySelectorAll('[id^="canvas-subtitles-"]')) el.style.visibility = time < lead ? 'hidden' : 'visible';

    if (!renderMode) {
      $('#seek').min = segment?.start || 0; $('#seek').max = segment?.end ?? duration(); $('#seek').value = time;
      $('#time-label').textContent = segment ? (time - segment.start).toFixed(2) + ' / ' + (segment.end - segment.start).toFixed(2) + ' 秒' : time.toFixed(2) + ' / ' + duration().toFixed(2) + ' 秒';
      const activeCh = P.chapters.filter(c => c.at <= t).at(-1);
      $('#current-chapter').textContent = segment ? '局部播放 · ' + segment.label : activeCh?.label || '';
      for (const b of document.querySelectorAll('.phases button')) b.classList.toggle('current', Number(b.dataset.at) === activeCh?.at);
      $('#zoom-label').textContent = Math.round(cam.scale * 100) + '%';
      window.dispatchEvent(new CustomEvent('canvas-render', { detail: { time, bodyTime: t, mode: browsing ? 'resource' : 'demo', playing, segment } }));
    }
    return { time, contentTime: t, small, sourceTime: video.currentTime, shot: current };
  }
  function pause(){playing=false;voice.pause();video.pause();cancelAnimationFrame(frame);$('#play').textContent='播放';if(!renderMode)window.dispatchEvent(new CustomEvent('canvas-render',{detail:{time,bodyTime:bodyTime(),mode:mode==='browse'?'resource':'demo',playing,segment}}))}
  async function mediaSeek(target){const t=Math.max(0,Math.min(P.content_duration-.001,target));if(Math.abs(video.currentTime-t)<.018&&video.readyState>=2)return;await new Promise((resolve,reject)=>{const timeout=setTimeout(()=>{cleanup();reject(Error('人物源帧定位超时：'+t))},9000);function cleanup(){clearTimeout(timeout);video.removeEventListener('seeked',done);video.removeEventListener('error',fail)}function done(){cleanup();resolve()}function fail(){cleanup();reject(Error('人物素材加载失败'))}video.addEventListener('seeked',done,{once:true});video.addEventListener('error',fail,{once:true});video.currentTime=t});if(video.requestVideoFrameCallback)await new Promise(resolve=>{const timer=setTimeout(resolve,120);video.requestVideoFrameCallback(()=>{clearTimeout(timer);resolve()})})}
  function setMode(next){const changed=next!==mode;mode=next;document.body.classList.toggle('resource-mode',mode==='browse');document.body.classList.toggle('demo-mode',mode==='demo');resize();if(changed)window.dispatchEvent(new CustomEvent('canvas-mode-change',{detail:{mode:mode==='browse'?'resource':'demo'}}))}
  async function position(target,{keepSegment=false}={}){pause();if(!keepSegment)segment=null;setMode('demo');time=Math.max(0,Math.min(duration(),target));await mediaSeek(bodyTime());voice.currentTime=time+audioOffset();return draw(time)}
  function seek(target,options){seekQueue=seekQueue.catch(()=>{}).then(()=>position(target,options));return seekQueue}
  window.END=duration();window.renderAt=target=>seek(target);
  function tick(){if(!playing)return;draw(voice.currentTime-audioOffset());if(time>=lead&&video.paused)video.play().catch(report);if(time>=lead&&performance.now()-lastSync>900&&Math.abs(video.currentTime-bodyTime())>.14){video.currentTime=bodyTime();lastSync=performance.now()}const end=segment?.end??duration();if(voice.ended||time>=end-.01){pause();draw(end);return}frame=requestAnimationFrame(tick)}
  function report(e){$('#review-status').textContent=e.message;console.error(e)}
  async function play(){if(playing){pause();return}const end=segment?.end??duration(),start=segment?.start||0;await seek(time>=end-.01?start:Math.max(start,time),{keepSegment:true});await voice.play();if(time>=lead)await video.play();playing=true;$('#play').textContent='暂停';frame=requestAnimationFrame(tick)}
  function resize(){const work=$('.workspace'),w=renderMode?P.output.width:work.clientWidth,h=renderMode?P.output.height:work.clientHeight;if(w<=0||h<=0)return;viewport=mode==='browse'&&!renderMode?{width:w,height:h}:{...P.output};const scale=Math.min(w/viewport.width,h/viewport.height);Object.assign($('#screen').style,{width:w+'px',height:h+'px'});Object.assign(stage.style,{width:viewport.width+'px',height:viewport.height+'px',transform:`translate(${(w-viewport.width*scale)/2}px,${(h-viewport.height*scale)/2}px) scale(${scale})`})}
  function fitBrowse(target,padding=.06){return CanvasCamera.fit(CanvasCamera.bounds(P,target),viewport,padding)}
  function browse(){pause();segment=null;const entering=mode!=='browse';setMode('browse');if(entering||!freeCamera){browseTarget='overview';freeCamera=fitBrowse('overview',.05)}draw(time)}
  function focus(id){browse();browseTarget=id;select(elements.has(id)?id:'');freeCamera=fitBrowse(id,id==='overview'?.05:.08);draw(time)}
  function select(id){if(id&&!elements.has(id))return;selected=id;for(const [key,el] of elements)el.classList.toggle('selected',key===id);window.dispatchEvent(new CustomEvent('canvas-selection',{detail:{id}}))}
  function setTool(next){tool=next==='pan'?'pan':'select';document.body.classList.toggle('tool-pan',tool==='pan');window.dispatchEvent(new CustomEvent('canvas-tool-change',{detail:{tool}}))}
  async function preview(target){const members=P.components.filter(c=>c.id===target||c.board_id===target||target==='overview'),ranges=members.map(c=>c.preview_range).filter(Boolean);if(!ranges.length)return;pause();segment={target,label:members.length===1?members[0].content.title:P.boards.find(b=>b.id===target)?.name||'完整项目',start:lead+Math.min(...ranges.map(r=>r.start)),end:lead+Math.max(...ranges.map(r=>r.end))};await seek(segment.start,{keepSegment:true});return play()}
  async function setCoverEnabled(enabled){pause();const t=bodyTime();coverEnabled=!!enabled;lead=coverEnabled?originalLead:0;window.END=duration();segment=null;const result=await seek(t+lead);window.dispatchEvent(new CustomEvent('canvas-timing-change',{detail:{lead,audioOffset:audioOffset()}}));return result}
  window.CanvasExplorer={getMode:()=>mode==='browse'?'resource':'demo',getTime:()=>time,getBodyTime:bodyTime,getView:()=>({...mode==='browse'?freeCamera:cameraAt(bodyTime())}),getSelected:()=>selected,getTool:()=>tool,getSegment:()=>segment?{...segment}:null,getLead:()=>lead,getAudioOffset:audioOffset,getCoverEnabled:()=>coverEnabled,setCoverEnabled,pause,seek,focus,select,setTool,preview,play,browse,overview:()=>focus('overview')};
  $('#play').onclick=()=>play().catch(report);$('#replay').onclick=()=>seek(segment?.start||0,{keepSegment:true}).then(play).catch(report);$('#browse').onclick=browse;$('#overview').onclick=()=>focus('overview');
  let requestedTime=null,uiSeeking=false;
  $('#seek').oninput=async()=>{requestedTime=Number($('#seek').value);pause();if(uiSeeking)return;uiSeeking=true;try{while(requestedTime!==null){const target=requestedTime;requestedTime=null;await seek(target,{keepSegment:true})}}catch(e){report(e)}finally{uiSeeking=false}};
  $('#subtitle-mode').onchange=()=>window.CaptionDirector?window.CaptionDirector.setMode($('#subtitle-mode').value).catch(report):captions.setMode($('#subtitle-mode').value);
  $('#voice-only').onchange=async()=>{if(window.CaptionDirector)return window.CaptionDirector.syncAudio({resume:false}).catch(report);pause();const at=time;const loaded=new Promise(resolve=>voice.addEventListener('loadedmetadata',resolve,{once:true}));voice.src=$('#voice-only').checked?'assets/preview-mix.m4a':'assets/preview-mix.m4a';await loaded;voice.currentTime=at+audioOffset()};
  for(const c of P.chapters){const b=document.createElement('button');b.dataset.at=c.at;b.innerHTML=`<span>${c.at.toFixed(1)}s</span>${c.label}`;b.onclick=()=>seek(c.at+lead).catch(report);$('.phases').append(b)}
  function zoom(factor,point){if(mode!=='browse')browse();browseTarget=null;const old=freeCamera.scale,next=Math.max(.065,Math.min(6,old*factor)),p=point||{x:viewport.width/2,y:viewport.height/2};freeCamera.cx+=(p.x-viewport.width/2)*(1/old-1/next);freeCamera.cy+=(p.y-viewport.height/2)*(1/old-1/next);freeCamera.scale=next;draw(time)}$('#zoom-in').onclick=()=>zoom(1.3);$('#zoom-out').onclick=()=>zoom(1/1.3);
  const screen=$('#screen');
  screen.addEventListener('pointerdown',e=>{if(renderMode||![0,1].includes(e.button))return;pause();const pan=tool==='pan'||e.button===1;if(pan&&mode!=='browse')browse();drag={id:e.pointerId,x:e.clientX,y:e.clientY,camera:{...freeCamera||cameraAt(bodyTime())},target:e.target,moved:false,pan};screen.setPointerCapture(e.pointerId);if(pan)screen.classList.add('dragging')});
  screen.addEventListener('pointermove',e=>{if(!drag||drag.id!==e.pointerId)return;const dx=e.clientX-drag.x,dy=e.clientY-drag.y;if(Math.hypot(dx,dy)>6)drag.moved=true;if(!drag.pan)return;browseTarget=null;freeCamera={...drag.camera,cx:drag.camera.cx-dx/drag.camera.scale,cy:drag.camera.cy-dy/drag.camera.scale};draw(time)});
  function endDrag(e,cancelled=false){if(!drag||drag.id!==e.pointerId)return;const previous=drag;drag=null;screen.classList.remove('dragging');lastTapTarget=!cancelled&&!previous.pan&&!previous.moved?previous.target:null;if(lastTapTarget){const el=lastTapTarget.closest('[data-component]');if(el){select(el.dataset.component);window.dispatchEvent(new CustomEvent('canvas-review-request',{detail:{id:el.dataset.component,point:{x:e.clientX,y:e.clientY}}}))}}}
  screen.addEventListener('pointerup',e=>endDrag(e));screen.addEventListener('pointercancel',e=>endDrag(e,true));screen.addEventListener('lostpointercapture',e=>endDrag(e,true));
  screen.addEventListener('wheel',e=>{if(renderMode)return;e.preventDefault();if(mode!=='browse')browse();const r=screen.getBoundingClientRect();zoom(Math.exp(-e.deltaY*.0013),{x:e.clientX-r.left,y:e.clientY-r.top})},{passive:false});
  screen.addEventListener('dblclick',e=>{if(renderMode)return;const el=e.target.closest('[data-component]')||lastTapTarget?.closest('[data-component]');if(el)focus(el.dataset.component)});
  const isEditing=e=>e.target.closest('input,textarea,select,[contenteditable="true"],[role="dialog"]');
  document.addEventListener('keydown',e=>{if(renderMode||isEditing(e))return;if(e.code==='Space'){e.preventDefault();spaceDown=true;setTool('pan')}else if(e.key.toLowerCase()==='f'){e.preventDefault();focus('overview')}});
  document.addEventListener('keyup',e=>{if(e.code==='Space'&&spaceDown){e.preventDefault();spaceDown=false;setTool('select')}});
  window.addEventListener('blur',()=>{spaceDown=false;setTool('select');if(drag)endDrag({pointerId:drag.id},true)});
  voice.addEventListener('ended',()=>{pause();draw(segment?.end??duration())});window.addEventListener('resize',()=>{resize();if(mode==='browse'&&browseTarget)freeCamera=fitBrowse(browseTarget,browseTarget==='overview'?.05:.08);draw(time)});
  const loaded=el=>el.readyState>=2?Promise.resolve():new Promise((resolve,reject)=>{el.addEventListener('loadeddata',resolve,{once:true});el.addEventListener('error',()=>reject(Error('媒体加载失败：'+el.src)),{once:true})});
  window.READY=Promise.all([loaded(video),loaded(voice),document.fonts.ready]).then(()=>{setMode('demo');return seek(0)});
  window.PREVIEW_STATE=()=>({time,bodyTime:bodyTime(),lead,audioOffset:audioOffset(),mode,playing,segment,viewport:{...viewport},videoTime:video.currentTime,audioTime:voice.currentTime,videoReady:video.readyState,audioReady:voice.readyState});
})();
