# 活力娱乐 · 人物主导（`pop-fun-presenter-9x16`）模板指南

- **形态与规格**：`presenter-led` ｜ `presenter: true` ｜ `1080×1920` @ 25fps ｜ 浅色系（`light`）
- **视觉定位**：活力娱乐吃瓜风（`pop-fun`）：暖奶杏波点底 `#fff8eb` + 深靛黑粗描边 `#1e2436` + 珊瑚橘红 `#ff5733` + 热梗明黄 `#ffe14d` + 湖水青 `#1fb6aa`，系统无衬线粗黑体。
- **字体**：系统无衬线粗黑体（`'PingFang SC', 'Microsoft YaHei UI', 'Microsoft YaHei', sans-serif`），无需额外中文字体包，离线即开即用。
- **核心规范**：
  1. 浅色画布非当前组件采用 `opacity + saturate + blur` 柔和虚化，禁用 `brightness(.4)`；
  2. 纸飞机引导仅在开场入画与跨画板转场触发，同画板内仅做丝滑弧线运镜；
  3. 评论/截图类组件支持真实 PNG 嵌入装裱（见 `assets/comments/`），横屏版采用通栏大原图保证阅读清晰；
  4. 横屏版片内不加顶部固定标题，保留前 5 帧 16:9 双栏海报封面；
  5. 新任务复用时请根据新文案与最终 ASR 重排组件、台词、时间锚点与字幕关键词。
