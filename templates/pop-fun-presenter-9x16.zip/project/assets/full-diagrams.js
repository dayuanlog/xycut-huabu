(() => {
  'use strict';
  const clamp = n => Math.max(0, Math.min(1, n));
  const ease = n => { n = clamp(n); return 1 - Math.pow(1 - n, 3); };
  const backOut = n => {
    n = clamp(n);
    const c1 = 1.65, c3 = c1 + 1;
    return 1 + c3 * Math.pow(n - 1, 3) + c1 * Math.pow(n - 1, 2);
  };

  const html = {
    'year-buddy': `
      <div class="fun-card">
        <div class="fun-head">
          <span class="fun-pill is-teal">网友投稿</span>
          <h2>老公的<em>钓鱼搭子</em></h2>
        </div>
        <div class="buddy-panel">
          <div class="buddy-row">
            <div class="cal-chip chip-freq">
              <span class="tag">出勤频率</span>
              <strong>每次放假必约</strong>
            </div>
            <div class="cal-chip chip-act">
              <span class="tag">共同爱好</span>
              <strong>一起去钓鱼</strong>
            </div>
          </div>
          <div class="year-meter">
            <div class="meter-top">
              <span>并肩作钓时长</span>
              <b class="glint-target">整整 1 年</b>
            </div>
            <div class="meter-track"><div class="meter-fill"></div></div>
          </div>
          <div class="wife-thought">
            <span>老婆以为：这肯定是铁哥们吧？</span>
            <i class="beat-ripple"></i>
          </div>
        </div>
      </div>`,

    'no-name': `
      <div class="fun-card">
        <div class="fun-head">
          <span class="fun-pill is-coral">大型反转</span>
          <h2>认识一年，<em>真名未知</em></h2>
        </div>
        <div class="chat-stage">
          <div class="chat-bubble wife">
            <small>老婆随口一问</small>
            「你那位钓鱼搭子，叫什么名字呀？」
          </div>
          <div class="chat-bubble husband">
            <small>老公淡定回答</small>
            「……不知道。」
          </div>
          <div class="twist-row">
            <div class="comedy-stamp">
              <span>实名认证失败</span>
              <strong class="glint-target">真名：不知道！</strong>
              <i class="beat-ripple"></i>
            </div>
            <div class="bro-shout">
              <span>见面：兄弟！走！</span>
              <i class="beat-ripple"></i>
            </div>
          </div>
        </div>
      </div>`,

    'comment-1': `
      <div class="fun-card">
        <div class="fun-head">
          <span class="fun-pill">同款 #01</span>
          <h2><em>十年鱼友</em>只知网名</h2>
        </div>
        <div class="comment-showcase">
          <div class="comment-frame tilt-left">
            <img src="assets/comments/01-ten-years.png" alt="评论区原图：认识十多年的鱼友，转账才知道叫啥">
          </div>
          <div class="comment-note c1-note">
            <span class="glint-target">直到<em>转账打名字</em>，才知道对方叫啥</span>
            <i class="beat-ripple"></i>
          </div>
        </div>
      </div>`,

    'comment-2': `
      <div class="fun-card">
        <div class="fun-head">
          <span class="fun-pill is-teal">同款 #02</span>
          <h2>老丈人的<em>老张与王胖</em></h2>
        </div>
        <div class="comment-showcase">
          <div class="comment-frame tilt-right">
            <img src="assets/comments/02-laozhang-wangpang.png" alt="评论区原图：丈人钓鱼几十年，老张王胖招呼，干净单纯">
          </div>
          <div class="comment-note is-teal c2-note">
            <span class="glint-target">99赞热评：<em>干净单纯</em>，不高兴就不联系</span>
            <i class="beat-ripple"></i>
          </div>
        </div>
      </div>`,

    'comment-3': `
      <div class="fun-card">
        <div class="fun-head">
          <span class="fun-pill is-coral">压轴神评</span>
          <h2>文艺开场，<em>极限反转</em></h2>
        </div>
        <div class="comment-showcase">
          <div class="comment-tags">
            <span class="mini-sticker is-art c3-art">文艺：同一时空 · 最好陪伴</span>
            <span class="mini-sticker is-alert c3-alert">反转：查微信转账 · 红红花花不行</span>
          </div>
          <div class="comment-frame">
            <img src="assets/comments/03-serious-hobby.png" alt="评论区原图：神评补刀是正经爱好吗">
          </div>
          <div class="punchline-banner c3-punch">
            <span class="glint-target">网友补刀：你这真是<em>正经爱好吗？</em></span>
            <i class="beat-ripple"></i>
          </div>
        </div>
      </div>`,

    'pure-reasons': `
      <div class="fun-card">
        <div class="fun-head">
          <span class="fun-pill">为什么羡慕</span>
          <h2>因为足够<em>纯粹</em></h2>
        </div>
        <div class="reason-list">
          <div class="reason-item r1">
            <span class="reason-idx">01</span>
            <div class="reason-text">
              <strong>不查户口 · 不讲人情世故</strong>
              <small>没有繁琐寒暄，零社交压力</small>
            </div>
            <i class="beat-ripple"></i>
          </div>
          <div class="reason-item r2">
            <span class="reason-idx">02</span>
            <div class="reason-text">
              <strong>有事说事 · 简单明了</strong>
              <small>约好时间地点，直奔共同热爱</small>
            </div>
            <i class="beat-ripple"></i>
          </div>
          <div class="reason-item r3">
            <span class="reason-idx">03</span>
            <div class="reason-text">
              <strong>合得来开心 · 不合不内耗</strong>
              <small>进退自如，全凭自在舒服</small>
            </div>
            <i class="beat-ripple"></i>
          </div>
        </div>
      </div>`,

    'light-ending': `
      <div class="fun-card">
        <div class="fun-head">
          <span class="fun-pill is-teal">成年人处关系</span>
          <h2>最舒服的<em>边界感</em></h2>
        </div>
        <div class="ending-panel">
          <div class="ending-quote">
            如果成年人处关系，<br>都能像这样 <em class="glint-target">轻装上阵</em>
          </div>
          <div class="ending-stamp-row">
            <span class="ending-pill">简单 · 纯粹 · 不内耗</span>
            <div class="ending-stamp">
              <span>其实挺舒服</span>
              <i class="beat-ripple"></i>
            </div>
          </div>
        </div>
      </div>`
  };

  function setRipple(el, t, at, duration = 0.65, all = false) {
    if (!el) return;
    if (all || t < at || t > at + duration) {
      el.style.opacity = '0';
      el.style.transform = 'translate(-50%,-50%) scale(.4)';
      return;
    }
    const u = clamp((t - at) / duration);
    el.style.opacity = String(0.8 * (1 - u));
    el.style.transform = `translate(-50%,-50%) scale(${0.45 + 1.55 * ease(u)})`;
  }

  function setGlint(el, t, at, duration = 0.72, all = false) {
    if (!el) return;
    if (all || t < at || t > at + duration) {
      el.style.setProperty('--glint-pos', '-30%');
      el.style.setProperty('--glint-alpha', '0');
      return;
    }
    const u = clamp((t - at) / duration);
    el.style.setProperty('--glint-pos', (-30 + 160 * ease(u)) + '%');
    el.style.setProperty('--glint-alpha', String(Math.sin(Math.PI * u)));
  }

  function render(t, { all = false } = {}) {
    const within = (at, dur = 0.34) => all ? 1 : ease((t - at) / dur);
    const show = (el, at, dx = 0, dy = 18, dur = 0.34, floor = 0) => {
      if (!el) return;
      const u = within(at, dur);
      el.style.opacity = String(floor + (1 - floor) * u);
      el.style.transform = `translate(${dx * (1 - u)}px,${dy * (1 - u)}px)`;
    };
    const pop = (el, at, rot = 0, floor = 0) => {
      if (!el) return;
      const u = all ? 1 : backOut((t - at) / 0.34);
      const vis = all ? 1 : clamp((t - at) / 0.14);
      el.style.opacity = String(floor + (1 - floor) * vis);
      el.style.transform = `rotate(${rot}deg) scale(${0.82 + 0.18 * u})`;
    };
    const root = id => document.querySelector(`#world [data-component="${id}"]`);

    // 1. year-buddy (2.94 -> 9.84s)
    let r = root('year-buddy');
    if (r) {
      show(r.querySelector('.fun-head'), 3.0, 0, 12, 0.34, 0.75);
      show(r.querySelector('.chip-freq'), 5.1, -18, 0, 0.34, 0.55);
      show(r.querySelector('.chip-act'), 5.7, 18, 0, 0.34, 0.55);
      const fill = r.querySelector('.meter-fill');
      if (fill) fill.style.width = (within(6.75, 0.95) * 100).toFixed(1) + '%';
      setGlint(r.querySelector('.meter-top .glint-target'), t, 7.1, 0.72, all);
      show(r.querySelector('.wife-thought'), 8.05, 0, 18, 0.36, 0.2);
      setRipple(r.querySelector('.wife-thought .beat-ripple'), t, 8.2, 0.65, all);
    }

    // 2. no-name (9.84 -> 20.28s)
    r = root('no-name');
    if (r) {
      show(r.querySelector('.fun-head'), 9.9, 0, 12, 0.34, 0.75);
      show(r.querySelector('.chat-bubble.wife'), 11.4, -22, 0, 0.34, 0.55);
      show(r.querySelector('.chat-bubble.husband'), 13.35, 22, 0, 0.34, 0.35);
      pop(r.querySelector('.comedy-stamp'), 13.7, -5, 0.15);
      setGlint(r.querySelector('.comedy-stamp .glint-target'), t, 14.0, 0.75, all);
      setRipple(r.querySelector('.comedy-stamp .beat-ripple'), t, 13.78, 0.7, all);
      pop(r.querySelector('.bro-shout'), 16.65, 3, 0.12);
      setRipple(r.querySelector('.bro-shout .beat-ripple'), t, 16.8, 0.7, all);
    }

    // 3. comment-1 (22.74 -> 29.98s)
    r = root('comment-1');
    if (r) {
      show(r.querySelector('.fun-head'), 22.85, 0, 12, 0.34, 0.78);
      const frame = r.querySelector('.comment-frame');
      if (frame) {
        const u = within(23.1, 0.4);
        frame.style.opacity = String(0.68 + 0.32 * u);
        frame.style.transform = `rotate(-1.2deg) translateY(${(1 - u) * 16}px)`;
      }
      pop(r.querySelector('.c1-note'), 27.34, 0, 0.25);
      setGlint(r.querySelector('.c1-note .glint-target'), t, 27.6, 0.75, all);
      setRipple(r.querySelector('.c1-note .beat-ripple'), t, 27.45, 0.7, all);
    }

    // 4. comment-2 (29.98 -> 41.68s)
    r = root('comment-2');
    if (r) {
      show(r.querySelector('.fun-head'), 30.1, 0, 12, 0.34, 0.78);
      const frame = r.querySelector('.comment-frame');
      if (frame) {
        const u = within(30.4, 0.4);
        frame.style.opacity = String(0.68 + 0.32 * u);
        frame.style.transform = `rotate(1.1deg) translateY(${(1 - u) * 16}px)`;
      }
      pop(r.querySelector('.c2-note'), 36.65, 0, 0.25);
      setGlint(r.querySelector('.c2-note .glint-target'), t, 38.2, 0.75, all);
      setRipple(r.querySelector('.c2-note .beat-ripple'), t, 36.75, 0.7, all);
    }

    // 5. comment-3 (41.68 -> 55.78s)
    r = root('comment-3');
    if (r) {
      show(r.querySelector('.fun-head'), 41.8, 0, 12, 0.34, 0.78);
      show(r.querySelector('.c3-art'), 43.8, -16, 0, 0.34, 0.45);
      show(r.querySelector('.c3-alert'), 49.0, 16, 0, 0.34, 0.2);
      const frame = r.querySelector('.comment-frame');
      if (frame) {
        const u = within(42.1, 0.4);
        frame.style.opacity = String(0.68 + 0.32 * u);
        frame.style.transform = `translateY(${(1 - u) * 14}px)`;
      }
      pop(r.querySelector('.c3-punch'), 53.25, -1, 0.15);
      setGlint(r.querySelector('.c3-punch .glint-target'), t, 54.4, 0.78, all);
      setRipple(r.querySelector('.c3-punch .beat-ripple'), t, 54.35, 0.75, all);
    }

    // 6. pure-reasons (59.74 -> 65.50s)
    r = root('pure-reasons');
    if (r) {
      show(r.querySelector('.fun-head'), 59.8, 0, 12, 0.34, 0.78);
      const rows = [
        ['.r1', 59.85],
        ['.r2', 61.60],
        ['.r3', 63.16]
      ];
      for (const [sel, at] of rows) {
        const item = r.querySelector(sel);
        if (!item) continue;
        show(item, at, -22, 0, 0.34, 0.35);
        setRipple(item.querySelector('.beat-ripple'), t, at + 0.08, 0.6, all);
      }
    }

    // 7. light-ending (65.50 -> 69.28s)
    r = root('light-ending');
    if (r) {
      show(r.querySelector('.fun-head'), 65.6, 0, 12, 0.34, 0.78);
      show(r.querySelector('.ending-quote'), 66.1, 0, 16, 0.36, 0.65);
      setGlint(r.querySelector('.ending-quote .glint-target'), t, 67.2, 0.75, all);
      show(r.querySelector('.ending-pill'), 67.6, -16, 0, 0.32, 0.45);
      pop(r.querySelector('.ending-stamp'), 68.3, -4, 0.25);
      setRipple(r.querySelector('.ending-stamp .beat-ripple'), t, 68.38, 0.7, all);
    }
  }

  window.FishingDiagrams = { html, render };
})();
