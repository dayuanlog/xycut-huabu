(() => {
  const cues = [{"start": 6.0, "end": 7.35, "text": "免费", "effect": "pop", "asr_phrase": "免费", "line_id": "line_003"}, {"start": 45.45, "end": 47.25, "text": "画布", "effect": "shine", "asr_phrase": "画布", "line_id": "line_027"}, {"start": 113.04, "end": 114.84, "text": "时间", "effect": "reveal", "asr_phrase": "音频时间", "line_id": "line_062"}, {"start": 123.76, "end": 125.56, "text": "渲染", "effect": "pop", "asr_phrase": "渲染", "line_id": "line_068"}];
  const node = document.createElement('div');
  node.id = 'presenter-top-keyword';
  node.setAttribute('aria-hidden', 'true');
  document.querySelector('#stage').append(node);
  const style = document.createElement('style');
  style.textContent = `
    @font-face{font-family:PresenterSong;src:url('assets/fonts/SourceHanSerifCN-Bold.woff2') format('woff2');font-weight:700;font-style:normal;font-display:block}
    #presenter-top-keyword{position:absolute;z-index:34;left:100px;right:100px;top:140px;justify-content:center;gap:72px;text-align:center;pointer-events:none;color:#fff9e9;font-family:PresenterSong,serif;font-size:290px;line-height:1;font-weight:700;letter-spacing:0;text-shadow:0 3px 12px #000b;transform-origin:50% 65%;white-space:nowrap}
    #presenter-top-keyword span{display:inline-block;color:#fff9e9;-webkit-text-fill-color:currentColor;text-shadow:0 3px 8px #0008,0 0 12px #7ceae133}
    body.resource-mode #presenter-top-keyword,body.intro-on #presenter-top-keyword{display:none!important}
  `;
  document.head.append(style);
  const clamp = q => Math.max(0,Math.min(1,q));
  const ease = q => 1-Math.pow(1-clamp(q),3);
  function render(t){
    const cue = cues.find(c=>t>=c.start&&t<c.end);
    const full = document.body.classList.contains('presenter-fullscreen');
    node.style.display = cue&&full?'flex':'none';
    document.querySelector('.canvas-presenter-words h2').style.opacity=cue&&full?'0':'1';
    if(!cue||!full)return;
    if(node.dataset.cue!==cue.text){node.dataset.cue=cue.text;node.replaceChildren(...Array.from(cue.text,ch=>{const s=document.createElement('span');s.textContent=ch;return s;}));}
    const age=t-cue.start,exit=clamp((cue.end-t)/.17),q=ease(age/.23);
    const scale=cue.effect==='pop'?.87+.13*q+.025*Math.exp(-age*13)*Math.sin(age*24):.96+.04*q;
    node.style.opacity=String(exit);
    node.style.transform=`translateY(${7*(1-q)}px) scale(${scale})`;
    node.style.fontSize=cue.text.length>2?'210px':'290px';
    [...node.children].forEach((s,i)=>{
      const v=cue.effect==='reveal'?ease((age-i*.045)/.17):q;
      s.style.opacity=String(v);s.style.transform=`translateY(${5*(1-v)}px)`;
      const sweep=Math.max(0,1-Math.abs((age-.1)/.65-i/Math.max(1,node.children.length-1))*3);
      s.style.color='#fff9e9';
      s.style.textShadow=`0 3px 8px #0008,0 0 ${10+16*sweep}px #7ceae166`;
    });
  }
  const original=CanvasScene.render;
  CanvasScene.render=function(t){const r=original.call(this,t);render(t);return r;};
  window.PresenterKeywords={cues,node,render};
  window.READY=Promise.all([window.READY,document.fonts.load('700 290px PresenterSong')]).then(()=>{render(CanvasExplorer.getBodyTime());return true;});
  render(CanvasExplorer.getBodyTime());
})();
