(()=>{
 const stage=document.querySelector('#stage'),world=document.querySelector('#world');
 const win=document.createElement('div');win.className='film-window';world.before(win);win.append(world);
 const series=CANVAS_PLAN.series,escape=InfoKit.esc;
 const label=document.createElement('div');label.className='film-series';label.innerHTML=`<b data-preview-text="title-heading">${escape(series.title)}${series.episode_label?` <span>· ${escape(series.episode_label)}</span>`:''}</b><i data-preview-text="title-description">${escape(series.subtitle)}</i>`;stage.append(label);
 const cover=document.createElement('div');cover.className='film-cover';cover.innerHTML=`<div class="series-cover-content"><div class="series-cover-heading"><span class="series-cover-name">${escape(series.title)}</span><span class="series-cover-day">${escape(series.episode_label)}</span></div><div class="series-cover-divider"></div><h1 class="series-cover-subtitle">${series.cover_lines.map((line,i)=>`<span class="cover-line-${i}">${escape(line).replace(/(\d+)/g,'<em>$1</em>')}</span>`).join('')}</h1></div>`;stage.append(cover);
 const guides=document.createElement('div');guides.className='film-guides';guides.innerHTML='<span>中央 1:1 · 当前重点与邻近内容</span>';stage.append(guides);
 const style=document.createElement('style');style.textContent=`
 .stage{background-color:#0c141c;background-image:radial-gradient(ellipse at 25% 40%,#143c4733,transparent 68%),radial-gradient(#8ca8b638 1px,transparent 1.6px),linear-gradient(#89a2b30e 1px,transparent 1px),linear-gradient(90deg,#89a2b30e 1px,transparent 1px);background-size:100% 100%,40px 40px,180px 180px,180px 180px}.film-window{position:absolute;inset:0;clip-path:inset(410px 0 410px);overflow:hidden}.resource-mode .film-window{clip-path:none}.demo-mode .world{background:none}.demo-mode .world:before{display:none}.demo-mode .board:before,.demo-mode .board:after{display:none}
 .film-series{position:absolute;left:90px;right:90px;top:160px;z-index:32;display:flex;flex-direction:column;gap:20px;pointer-events:none}.film-series span{font:19px 'Segoe UI',sans-serif;letter-spacing:4px;color:#6892a5}.film-series b{font-size:37px;letter-spacing:0;color:#d4e5ec}.film-series i{font-size:26px;font-style:normal;color:#739aaa}.resource-mode .film-series{display:none}.film-guides{display:none;position:absolute;left:0;top:420px;width:1080px;height:1080px;border:2px dashed #ffc67699;pointer-events:none;z-index:50}.film-guides span{position:absolute;left:15px;top:10px;font-size:22px;color:#ffc676}.show-guides .film-guides{display:block}.resource-mode .film-guides,.render .film-guides{display:none!important}.guide-toggle{font-size:11px;color:#abc7d3;display:flex;align-items:center;gap:7px}.guide-toggle input{width:14px!important;margin:0!important}.sidebar .phases{grid-template-columns:1fr 1fr}
 .demo-mode .film-window{mask-image:linear-gradient(transparent 410px,#000 450px,#000 1470px,transparent 1510px)}
 .film-series{top:220px;gap:25px}.film-series b{font-size:52px;font-weight:750;line-height:1.2;letter-spacing:-1px;white-space:nowrap;color:#bdd9e3}.film-series b span{font:inherit;letter-spacing:inherit;color:#ffce86}.film-series i{font-size:66px;font-weight:850;line-height:1.2;color:#f4f9fb;letter-spacing:-2px}
 .film-cover{position:absolute;inset:0;z-index:100;overflow:hidden;pointer-events:none;background-color:#0c141c;background-image:radial-gradient(ellipse at 35% 48%,#14546844,transparent 68%),radial-gradient(#8ca8b638 1px,transparent 1.6px),linear-gradient(#89a2b30e 1px,transparent 1px),linear-gradient(90deg,#89a2b30e 1px,transparent 1px);background-size:100% 100%,40px 40px,180px 180px,180px 180px}.film-cover[hidden]{display:none}.series-cover-name{position:absolute;left:100px;right:100px;top:472px;font-size:48px;font-weight:700;letter-spacing:1px;color:#b8d7e2}.series-cover-day{position:absolute;left:100px;top:558px;padding-left:19px;border-left:4px solid #00c8d6;font-size:42px;font-weight:650;color:#ffce86}.series-cover-watermark{position:absolute;left:540px;top:528px;font:900 480px/1.2 'Segoe UI',sans-serif;letter-spacing:-30px;color:transparent;-webkit-text-stroke:2px #476e7a;opacity:.15}.series-cover-subtitle{position:absolute;left:92px;right:80px;top:710px;margin:0;font-size:132px;line-height:1.35;letter-spacing:-5px;font-weight:900;color:#f4fafb}.series-cover-subtitle>span{display:block;white-space:nowrap;position:relative}.series-cover-subtitle em{font:900 165px/1 'Segoe UI',sans-serif;color:#ffce86;font-style:normal;letter-spacing:-7px}.series-cover-subtitle .cover-line-1{color:#00c8d6;margin-top:18px}.series-cover-rule{position:absolute;left:100px;right:100px;top:1158px;height:3px;background:linear-gradient(90deg,#00c8d6,#456c7a88,transparent)}.series-cover-foot{position:absolute;left:100px;top:1210px;margin:0;font-size:32px;letter-spacing:2px;color:#7298aa}
 .intro-on .film-window,.intro-on .film-series,.intro-on [id^="canvas-subtitles-"]{visibility:hidden}.resource-mode .film-cover{display:none!important}.resource-mode .film-window{visibility:visible!important}
 .series-cover-content{position:absolute;left:120px;right:120px;top:50%;transform:translateY(-50%);display:flex;flex-direction:column;text-align:left}.series-cover-heading{position:static;display:flex;justify-content:flex-start;align-items:baseline;gap:26px;white-space:nowrap;font-size:64px;line-height:1.25;font-weight:750;letter-spacing:-1px}.series-cover-name,.series-cover-day{position:static;padding:0;border:0;font:inherit;letter-spacing:inherit}.series-cover-name{color:#b8d7e2}.series-cover-day{color:#ffce86}.series-cover-divider{height:2px;width:680px;align-self:flex-start;margin:24px 0;background:#62848d}.series-cover-subtitle{position:static;margin:0;font-size:136px;line-height:1.15;letter-spacing:-5px}.series-cover-subtitle em{font-size:170px}.series-cover-subtitle .cover-line-1{margin-top:12px}
 .series-cover-subtitle{font-size:120px}
 `;document.head.append(style);
 document.querySelector('#guides').onchange=e=>document.body.classList.toggle('show-guides',e.target.checked);
 function render(t){const visible=Number.isFinite(t)&&t<(CANVAS_PLAN.intro?.duration||0)-1e-9;cover.hidden=!visible;document.body.classList.toggle('intro-on',visible)}
 function fitTitles(){if(cover.querySelector('.v2-cover'))return;
  const restoreDisplay=cover.style.display;cover.style.setProperty('display','block','important');
  const heading=cover.querySelector('.series-cover-heading'),rule=cover.querySelector('.series-cover-divider'),range=document.createRange();
  range.selectNodeContents(heading);rule.style.width=Math.ceil(range.getBoundingClientRect().width)+'px';
  const subtitle=label.querySelector('i');subtitle.style.whiteSpace='nowrap';
  let size=66;subtitle.style.fontSize=size+'px';
  while(subtitle.scrollWidth>subtitle.clientWidth&&size>45){size-=.5;subtitle.style.fontSize=size+'px'}
  const title=cover.querySelector('.series-cover-subtitle');let coverSize=120;
  const apply=()=>{title.style.fontSize=coverSize+'px';title.querySelectorAll('em').forEach(n=>n.style.fontSize=coverSize*1.22+'px')};apply();
  while([...title.children].some(n=>n.scrollWidth>840)&&coverSize>90){coverSize-=.5;apply()}
  if(restoreDisplay)cover.style.display=restoreDisplay;else cover.style.removeProperty('display');
 }
 document.fonts.ready.then(fitTitles);
 window.FilmSeries={render,cover,config:series,fitTitles};render(window.CanvasExplorer?.getTime()||0);
})();

// === V2 COVER UPGRADE: light_portrait_presenter ===
(()=>{
 const cover=document.querySelector('.film-cover');
 if(!cover)return;
 const s=CANVAS_PLAN.series||{},esc=InfoKit.esc;
 const lines=s.cover_lines||['配音讲到哪','画面就到哪'];
 cover.innerHTML=`
  <div class="v2-cover v2-lp-pres">
   <img src="assets/media/person-poster.jpg" alt="" class="v2-bg-photo">
   <div class="v2-scrim"></div>
   <div class="v2-frame-border"></div>
   <div class="v2-safe">
    <div class="v2-top-kicker"><span class="v2-k-pill">人物主导 · 暖白板</span><b data-preview-text="cover-heading">${esc(s.title||'XYCUT 画布视频 Skill')}</b></div>
    <div class="v2-bottom-block">
     <h1 class="v2-hero">
      <span class="v2-l0" data-preview-text="cover-line-0">${esc(lines[0]||'')}</span>
      <span class="v2-l1" data-preview-text="cover-line-1">${esc(lines[1]||'')}</span>
     </h1>
     <div class="v2-caption-bar">
      <span>人物全屏开讲</span><i>·</i><span>大字关键词强调</span><i>·</i><span>关键处切入白板</span>
     </div>
    </div>
   </div>
  </div>`;
 const st=document.createElement('style');
 st.textContent=`
  .v2-lp-pres{position:absolute;inset:0;overflow:hidden;background:#1a2224}
  .v2-lp-pres .v2-bg-photo{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;object-position:50% 16%;transform:scale(1.18);transform-origin:56% 22%}
  .v2-lp-pres .v2-scrim{position:absolute;inset:0;background:linear-gradient(180deg,#122428aa 0%,#12242822 24%,transparent 48%,#13262bcc 74%,#0d1b1ff2 100%)}
  .v2-lp-pres .v2-frame-border{position:absolute;inset:36px;border:2px solid #f3efe544;border-radius:28px;pointer-events:none}
  .v2-lp-pres .v2-safe{position:absolute;left:116px;right:116px;top:290px;bottom:290px;display:flex;flex-direction:column;justify-content:space-between;align-items:center;text-align:center}
  .v2-lp-pres .v2-top-kicker{display:inline-flex;align-items:center;gap:14px;padding:12px 26px 12px 14px;border-radius:999px;background:#f3efe5ee;border:1.5px solid #ffffff;box-shadow:0 12px 32px #0005}
  .v2-lp-pres .v2-k-pill{padding:7px 18px;border-radius:999px;background:#008793;color:#ffffff;font-size:25px;font-weight:800}
  .v2-lp-pres .v2-top-kicker b{color:#203c42;font-size:28px;font-weight:800}
  .v2-lp-pres .v2-bottom-block{width:100%;display:flex;flex-direction:column;align-items:center;gap:28px}
  .v2-lp-pres .v2-hero{margin:0;display:flex;flex-direction:column;gap:10px;font-size:122px;line-height:1.12;font-weight:900;letter-spacing:-4px}
  .v2-lp-pres .v2-l0{color:#fffdf8;text-shadow:0 6px 26px #000b}
  .v2-lp-pres .v2-l1{color:#7ceae1;text-shadow:0 6px 28px #000b}
  .v2-lp-pres .v2-caption-bar{width:100%;padding:20px 28px;border-radius:20px;background:#f3efe5eb;border:1.5px solid #ffffff;color:#203c42;font-size:27px;font-weight:800;display:flex;justify-content:center;align-items:center;gap:16px;box-shadow:0 14px 36px #0006}
  .v2-lp-pres .v2-caption-bar i{font-style:normal;color:#008793}
 `;
 document.head.append(st);
 if(window.FilmSeries){window.FilmSeries.fitTitles=()=>{};}
})();
