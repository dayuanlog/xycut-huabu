(()=>{
 const $=s=>document.querySelector(s),cover=FilmSeries.cover,title=$('.film-series');
 // Each marked node is an independently designed text block, regardless of wrapping.
 const collect=root=>[...root.querySelectorAll('[data-preview-text]')].map(node=>({id:node.dataset.previewText,node,initial:node.textContent}));
 const coverBlocks=collect(cover),titleBlocks=collect(title);
 const ids=[...coverBlocks,...titleBlocks].map(b=>b.id);
 if(new Set(ids).size!==ids.length)throw Error('封面与标题的文字块 ID 必须唯一');
 const panel=document.createElement('details');panel.className='preview-settings edit-packaging';
 panel.innerHTML='<summary>封面、标题与字幕</summary><label><input type="checkbox" id="edit-cover-on" checked> 显示封面（前5帧）</label><div data-fields="cover"></div><button type="button" id="edit-cover-preview">查看封面</button><label><input type="checkbox" id="edit-title-on" checked> 显示片内标题</label><div data-fields="title"></div><p>编辑项按本项目的独立文字块生成，自动换行不另拆项。仅调整当前预览，刷新后恢复。</p>';
 $('.timeline').after(panel);
 $('#edit-cover-on').checked=(CANVAS_PLAN.intro?.duration||0)>0;
 $('#edit-title-on').checked=CANVAS_PLAN.series.title_enabled!==false;
 const subtitleControl=$('#subtitle-mode').closest('label');
 panel.insertBefore(subtitleControl,panel.querySelector('p'));
 for(const [kind,blocks] of [['cover',coverBlocks],['title',titleBlocks]]){
  const fields=panel.querySelector('[data-fields="'+kind+'"]');
  blocks.forEach((block,i)=>{
   const label=document.createElement('label');label.textContent=(kind==='cover'?'封面文字 ':'片内标题文字 ')+(i+1);
   const input=document.createElement('textarea');input.rows=block.initial.includes('\n')?2:1;input.value=block.initial;
   input.dataset.blockId=block.id;input.id='edit-'+block.id;label.append(input);fields.append(label);block.input=input;
  });
  if(!blocks.length){const p=document.createElement('p');p.textContent='当前项目没有可编辑的文字块。';fields.append(p)}
 }
 const notice=document.createElement('section');notice.className='preview-change-notice';notice.hidden=true;
 notice.innerHTML='<p>当前设置已修改，仅用于预览。请复制修改提示词发送给 AI，更新项目后再渲染。</p><button type="button">复制修改提示词</button><p class="copy-state" role="status"></p>';panel.after(notice);
 const values=blocks=>blocks.map(b=>({id:b.id,text:b.input.value}));
 const settings=()=>({cover:{enabled:$('#edit-cover-on').checked,blocks:values(coverBlocks)},title:{enabled:$('#edit-title-on').checked,blocks:values(titleBlocks)},subtitles:$('#subtitle-mode').value});
 const baseline=settings(),initial=JSON.stringify(baseline);
 function changed(){notice.hidden=JSON.stringify(settings())===initial;notice.querySelector('.copy-state').textContent=''}
 panel.addEventListener('input',e=>{
  if(e.target.id==='edit-cover-on')CanvasExplorer.setCoverEnabled(e.target.checked);
  const block=[...coverBlocks,...titleBlocks].find(b=>b.input===e.target);
  if(block){
   if(block.node.matches('.series-cover-subtitle > span'))block.node.innerHTML=InfoKit.esc(block.input.value).replace(/(\d+)/g,'<em>$1</em>');
   else block.node.textContent=block.input.value;
   block.node.style.whiteSpace='pre-wrap';
  }
  document.body.classList.toggle('preview-title-off',!$('#edit-title-on').checked);
  FilmSeries.fitTitles();changed();
  if((e.target.id==='edit-cover-on'||coverBlocks.includes(block))&&$('#edit-cover-on').checked)CanvasExplorer.seek(0);
 });
 $('#edit-cover-preview').onclick=()=>{if($('#edit-cover-on').checked)CanvasExplorer.seek(0)};
 $('#subtitle-mode').addEventListener('change',changed);
 notice.querySelector('button').onclick=async()=>{
  const current=settings(),changes=[];
  if(current.cover.enabled!==baseline.cover.enabled)changes.push(current.cover.enabled?'启用开头封面（前5帧），同步处理音轨、字幕和章节的时间偏移。':'取消开头封面及其占用的5帧，同步处理音轨、字幕和章节的时间偏移，正文 ASR 时间保持不变。');
  if(current.title.enabled!==baseline.title.enabled)changes.push(current.title.enabled?'显示视频顶部的片内标题。':'隐藏视频顶部的片内标题，保持正文取景不变。');
  for(const [kind,name] of [['cover','封面'],['title','片内标题']]){
   current[kind].blocks.forEach((block,index)=>{
    const previous=baseline[kind].blocks.find(b=>b.id===block.id);
    if(previous&&block.text!==previous.text)changes.push('将'+name+'第 '+(index+1)+' 块文字从'+JSON.stringify(previous.text)+'改为'+JSON.stringify(block.text)+'。（文字块 ID：'+block.id+'）');
   });
  }
  const modes={emphasis:'白字＋关键词强调',normal:'普通白字',off:'关闭字幕'};
  if(current.subtitles!==baseline.subtitles)changes.push(current.subtitles==='off'?'关闭画面字幕。':'将画面字幕改为“'+modes[current.subtitles]+'”。');
  if(!changes.length){notice.querySelector('.copy-state').textContent='当前没有需要提交的修改。';return}
  const text='请修改以下画布视频项目。以下是我在浏览器中的试调意见，尚未保存到工程：\n项目入口：'+location.href+'\n\n'+changes.map((line,i)=>(i+1)+'. '+line).join('\n')+'\n\n按文字块 ID 定位源码修改，不要按截图坐标调整。封面与片内标题分别处理，其余内容保持不变。修改后先提供 HTML 预览，等我确认后再渲染。';
  try{await navigator.clipboard.writeText(text);notice.querySelector('.copy-state').textContent='已复制，请发送给 AI。'}
  catch{let area=notice.querySelector('textarea');if(!area){area=document.createElement('textarea');notice.append(area)}area.value=text;area.focus();area.select();notice.querySelector('.copy-state').textContent='请手动复制下方提示词。'}
 };
})();
