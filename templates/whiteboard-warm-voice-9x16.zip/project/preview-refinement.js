(()=>{
 const $=s=>document.querySelector(s),P=CANVAS_PLAN;
 $('#overview').hidden=true;
 $('#check-caption').onchange=e=>{$('#spoken-line').hidden=!e.target.checked};
 function update(){
  const t=(window.CanvasExplorer?.getTime()||0)-(P.intro?.duration||0);
  let shot=P.shots[0];for(const s of P.shots)if(t>=s.at)shot=s;
  const c=P.components.find(c=>c.id===shot.target.split('/')[0]);
  const b=P.boards.find(b=>b.id===(c?.board_id||shot.target));
  $('#current-chapter').textContent=b?.short_name||b?.name||'';
  $('#review-copy-all').hidden=$('#review-copy-all').disabled;
 }
 new MutationObserver(update).observe($('#shot-label'),{childList:true,characterData:true,subtree:true});
 new MutationObserver(update).observe($('#review-count'),{childList:true});
 update();
})();
