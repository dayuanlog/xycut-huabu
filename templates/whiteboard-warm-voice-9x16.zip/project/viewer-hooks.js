(()=>{
 const audio=document.querySelector('#voice'),plan=window.CANVAS_PLAN,label=document.querySelector('#spoken-line'),phases=document.querySelector('.phases');
 const update=()=>{const t=window.CanvasExplorer?.getTime()||0,bodyTime=t-(plan.intro?.duration||0);label.textContent=(window.CAPTION_TIMELINE||window.FINAL_TIMELINE).lines.find(line=>bodyTime>=line.target_start_ms/1000&&bodyTime<=line.target_end_ms/1000)?.text||'';document.querySelectorAll('[data-time]').forEach((button,index,buttons)=>button.classList.toggle('current',t>=Number(button.dataset.time)&&t<Number(buttons[index+1]?.dataset.time??Infinity)))};
 for(const [index,board] of plan.boards.entries()){
  const components=plan.components.filter(c=>c.board_id===board.id),start=(plan.intro?.duration||0)+Number(board.start??Math.min(...components.map(c=>c.motion?.start??0))),button=document.createElement('button');button.dataset.time=String(start);button.title=board.name;
  const number=document.createElement('span');number.textContent=String(index+1).padStart(2,'0');button.append(number,board.short_name||board.name);phases.append(button);
  button.onclick=()=>{const playing=!audio.paused;window.CanvasExplorer.seek(Number(button.dataset.time));update();if(playing)document.querySelector('#play').click()};
  const originalLead=plan.intro?.duration||0;
  addEventListener('canvas-timing-change',()=>{button.dataset.time=String(start-originalLead+(plan.intro?.duration||0));update()});
 }
 const voiceOnly=document.querySelector('#voice-only');
 if(voiceOnly)voiceOnly.onchange=e=>{const t=audio.currentTime,playing=!audio.paused;audio.src=e.target.checked?'assets/voice.wav':'assets/preview-mix.m4a';audio.currentTime=t;if(playing)audio.play().catch(()=>{})};
 audio.addEventListener('timeupdate',update);document.querySelector('#seek').addEventListener('input',()=>requestAnimationFrame(update));
 addEventListener('load',()=>window.READY.then(()=>{document.querySelector('#shot-label').textContent=plan.boards.length+'页 · '+plan.duration.toFixed(2)+'秒 · 先预览，再确认渲染';update()}));
 const style=document.createElement('style');style.textContent='.phases button{overflow:hidden;text-overflow:ellipsis}.phases button.current{border-color:#00c1cd;color:#f4fdff;background:#16303b}';document.head.append(style);
})();
