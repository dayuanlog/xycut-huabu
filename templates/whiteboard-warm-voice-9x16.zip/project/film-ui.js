(()=>{
 const stage=document.querySelector('#stage'),world=document.querySelector('#world');
 const win=document.createElement('div');win.className='film-window';world.before(win);win.append(world);
 const series=CANVAS_PLAN.series,escape=InfoKit.esc;
 const label=document.createElement('div');label.className='film-series';label.innerHTML=`<b data-preview-text="title-heading">${escape(series.title)}${series.episode_label?` <span>· ${escape(series.episode_label)}</span>`:''}</b><i data-preview-text="title-description">${escape(series.subtitle)}</i>`;stage.append(label);
 const cover=document.createElement('div');cover.className='film-cover';cover.innerHTML=`<div class="series-cover-content"><div class="series-cover-heading"><span class="series-cover-name">${escape(series.title)}</span><span class="series-cover-day">${escape(series.episode_label)}</span></div><div class="series-cover-divider"></div><h1 class="series-cover-subtitle">${series.cover_lines.map((line,i)=>`<span class="cover-line-${i}">${escape(line).replace(/(\d+)/g,'<em>$1</em>')}</span>`).join('')}</h1></div>`;stage.append(cover);
 const guides=document.createElement('div');guides.className='film-guides';guides.innerHTML='<span>中央 1:1 · 当前重点与邻近内容</span>';stage.append(guides);
 const style=document.createElement('style');style.textContent=`
 .stage{background-color:#0c141c;background-image:radial-gradient(ellipse at 25% 40%,#143c4733,transparent 68%),radial-gradient(#8ca8b638 1px,transparent 1.6px),linear-gradient(#89a2b30e 1px,transparent 1px),linear-gradient(90deg,#89a2b30e 1px,transparent 1px);background-size:100% 100%,40px 40px,180px 180px,180px 180px}.film-window{position:absolute;inset:0;clip-path:inset(410px 0 410px);overflow:hidden}.resource-mode .film-window{clip-path:none}.demo-mode .world{background:none}.demo-mode .world:before{display:none}.demo-mode .board:before,.demo-mode .board:after{display:none}
 .film-series{position:absolute;left:90px;right:90px;top:160px;z-index:32;display:flex;flex-direction:column;gap:20px;pointer-events:none}.film-series span{font:19px 'Segoe UI',sans-serif;letter-spacing:4px;color:#6892a5}.film-series b{font-size:37px;letter-spacing:0;color:#d4e5ec}.film-series i{font-size:26px;font-style:normal;color:#739aaa}.resource-mode .film-series{display:none}.film-guides{display:none;position:absolute;left:0;top:420px;width:1080px;height:1080px;border:2px dashed #ffc67699;pointer-events:none;z-index:50}.film-guides span{position:absolute;left:15px;top:10px;font-size:22px;color:#ffc676}.show-guides .film-guides{display:block}.resource-mode .film-guides,.render .film-guides{display:none!important}.guide-toggle{font-size:11px;color:#abc7d3;display:flex;align-items:center;gap:7px}.guide-toggle input{width:14px!important;margin:0!important}.sidebar .phases{grid-template-columns:1fr 1fr}
 .demo-mode .film-window{mask-image:linear-gradient(transparent 410px,#000 450px,#000 1470px,transparent 1510px)}
 .film-series{top:220px;gap:25px}.film-series b{font-size:52px;font-weight:750;line-height:1.2;letter-spacing:-1px;white-space:nowrap;color:#bdd9e3}.film-series b span{font:inherit;letter-spacing:inherit;color:#ffce86}.film-series i{font-size:66px;font-weight:850;line-height:1.2;color:#f4f9fb;letter-spacing:-2px}
 .film-cover{position:absolute;inset:0;z-index:100;overflow:hidden;pointer-events:none;background-color:#0c141c;background-image:radial-gradient(ellipse at 35% 48%,#14546844,transparent 68%),radial-gradient(#8ca8b638 1px,transparent 1.6px),linear-gradient(#89a2b30e 1px,transparent 1px),linear-gradient(90deg,#89a2b30e 1px,transparent 1px);background-size:100% 100%,40px 40px,180px 180px,180px 180px}.film-cover[hidden]{display:none}.series-cover-name{position:absolute;left:100px;right:100px;top:472px;font-size:48px;font-weight:700;letter-spacing:1px;color:#b8d7e2}.series-cover-day{position:absolute;left:100px;top:558px;padding-left:19px;border-left:4px solid #00c8d6;font-size:42px;font-weight:650;color:#ffce86}.series-cover-watermark{position:absolute;left:540px;top:528px;font:900 480px/1.2 'Segoe UI',sans-serif;letter-spacing:-30px;color:transparent;-webkit-text-stroke:2px #476e7a;opacity:.15}.series-cover-subtitle{position:absolute;left:92px;right:80px;top:710px;margin:0;font-size:132px;line-height:1.35;letter-spacing:-5px;font-weight:900;color:#f4fafb}.series-cover-subtitle>span{display:block;white-space:nowrap;position:relative}.series-cover-subtitle em{font:900 165px/1 'Segoe UI',sans-serif;color:#ffce86;font-style:normal;letter-spacing:-7px}.series-cover-subtitle .cover-line-1{color:#00c8d6;margin-top:18px}.series-cover-rule{position:absolute;left:100px;right:100px;top:1158px;height:3px;background:linear-gradient(90deg,#00c8d6,#456c7a88,transparent)}.series-cover-foot{position:absolute;left:100px;top:1210px;margin:0;font-size:32px;letter-spacing:2px;color:#7298aa}
 .intro-on .film-window,.intro-on .film-series,.intro-on [id^="canvas-subtitles-"]{visibility:hidden}.resource-mode .film-cover{display:none!important}.resource-mode .film-window{visibility:visible!important}
 .series-cover-content{position:absolute;left:120px;right:120px;top:50%;transform:translateY(-50%);display:flex;flex-direction:column;text-align:left}.series-cover-heading{position:static;display:flex;justify-content:flex-start;align-items:baseline;gap:26px;white-space:nowrap;font-size:64px;line-height:1.25;font-weight:750;letter-spacing:-1px}.series-cover-name,.series-cover-day{position:static;padding:0;border:0;font:inherit;letter-spacing:inherit}.series-cover-name{color:#b8d7e2}.series-cover-day{color:#ffce86}.series-cover-divider{height:2px;width:680px;align-self:flex-start;margin:24px 0;background:#62848d}.series-cover-subtitle{position:static;margin:0;font-size:136px;line-height:1.15;letter-spacing:-5px}.series-cover-subtitle em{font-size:170px}.series-cover-subtitle .cover-line-1{margin-top:12px}
 .series-cover-subtitle{font-size:120px}
 `;document.head.append(style);
 document.querySelector('#guides').onchange=e=>document.body.classList.toggle('show-guides',e.target.checked);
 function render(t){const visible=Number.isFinite(t)&&t<(CANVAS_PLAN.intro?.duration||0)-1e-9;cover.hidden=!visible;document.body.classList.toggle('intro-on',visible)}
 function fitTitles(){if(cover.querySelector('.v2-cover'))return;
  const restoreDisplay=cover.style.display;cover.style.setProperty('display','block','important');
  const heading=cover.querySelector('.series-cover-heading'),rule=cover.querySelector('.series-cover-divider'),range=document.createRange();
  range.selectNodeContents(heading);rule.style.width=Math.ceil(range.getBoundingClientRect().width)+'px';
  const subtitle=label.querySelector('i');subtitle.style.whiteSpace='nowrap';
  let size=66;subtitle.style.fontSize=size+'px';
  while(subtitle.scrollWidth>subtitle.clientWidth&&size>45){size-=.5;subtitle.style.fontSize=size+'px'}
  const title=cover.querySelector('.series-cover-subtitle');let coverSize=120;
  const apply=()=>{title.style.fontSize=coverSize+'px';title.querySelectorAll('em').forEach(n=>n.style.fontSize=coverSize*1.22+'px')};apply();
  while([...title.children].some(n=>n.scrollWidth>840)&&coverSize>90){coverSize-=.5;apply()}
  if(restoreDisplay)cover.style.display=restoreDisplay;else cover.style.removeProperty('display');
 }
 document.fonts.ready.then(fitTitles);
 window.FilmSeries={render,cover,config:series,fitTitles};render(window.CanvasExplorer?.getTime()||0);
})();

// === V2 COVER UPGRADE: light_portrait_voice ===
(()=>{
 const cover=document.querySelector('.film-cover');
 if(!cover)return;
 const s=CANVAS_PLAN.series||{},esc=InfoKit.esc;
 const lines=s.cover_lines||['配音讲到哪','画面就到哪'];
 cover.innerHTML=`
  <div class="v2-cover v2-lp-voice">
   <div class="v2-safe">
    <div class="v2-top-badge"><span>WARM WHITEBOARD</span><i>·</i><b data-preview-text="cover-heading">${esc(s.title||'XYCUT 画布视频 Skill')}</b></div>
    <h1 class="v2-hero">
     <span class="v2-l0" data-preview-text="cover-line-0">${esc(lines[0]||'')}</span>
     <span class="v2-l1" data-preview-text="cover-line-1">${esc(lines[1]||'')}</span>
    </h1>
    <svg class="v2-underline" viewBox="0 0 420 22" fill="none" aria-hidden="true">
     <path d="M12 14 C120 4, 290 4, 408 14" stroke="#008793" stroke-width="7" stroke-linecap="round"/>
    </svg>
    <div class="v2-wb-board">
     <div class="v2-wb-row">
      <div class="v2-wb-chip"><b>01</b><span>无限画布</span><em>9 块结构化画板</em></div>
      <div class="v2-wb-chip active"><b>02</b><span>字词对齐</span><em>音频驱动镜头</em></div>
      <div class="v2-wb-chip"><b>03</b><span>一键成片</span><em>清爽暖白板风</em></div>
     </div>
     <div class="v2-wb-bar">
      <span class="v2-wb-dot"></span>
      <span class="v2-wb-track"><i class="v2-wb-fill"></i></span>
      <span class="v2-wb-label">纯配音白板版 · 20 模块</span>
     </div>
    </div>
   </div>
  </div>`;
 const st=document.createElement('style');
 st.textContent=`
  .v2-lp-voice{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;background:radial-gradient(ellipse at 50% 25%,#ffffff88,transparent 60%)}
  .v2-lp-voice .v2-safe{width:848px;display:flex;flex-direction:column;align-items:center;text-align:center;gap:28px}
  .v2-lp-voice .v2-top-badge{display:inline-flex;align-items:center;gap:14px;padding:14px 30px;border-radius:999px;background:#ffffffcc;border:2px solid #9ab8b0;color:#203c42;font-size:30px;font-weight:700;box-shadow:0 8px 24px #203c4212}
  .v2-lp-voice .v2-top-badge span{color:#aa6229;letter-spacing:1.5px;font-size:24px}
  .v2-lp-voice .v2-top-badge i{font-style:normal;color:#8da8a0}
  .v2-lp-voice .v2-top-badge b{font-weight:800;color:#203c42}
  .v2-lp-voice .v2-hero{margin:0;display:flex;flex-direction:column;gap:12px;font-size:126px;line-height:1.12;font-weight:900;letter-spacing:-4px}
  .v2-lp-voice .v2-l0{color:#1d3940}
  .v2-lp-voice .v2-l1{color:#008793}
  .v2-lp-voice .v2-underline{width:420px;height:22px;margin-top:-10px}
  .v2-lp-voice .v2-wb-board{width:100%;padding:30px;border-radius:28px;background:#faf8f2ee;border:2px solid #9db7ad;box-shadow:0 20px 50px #203c4218;display:flex;flex-direction:column;gap:24px}
  .v2-lp-voice .v2-wb-row{display:grid;grid-template-columns:repeat(3,1fr);gap:18px}
  .v2-lp-voice .v2-wb-chip{padding:24px 16px;border-radius:20px;background:#f1ede2;border:1.5px solid #c3d2c9;display:flex;flex-direction:column;align-items:center;gap:8px;text-align:center}
  .v2-lp-voice .v2-wb-chip.active{background:#e4f2f1;border:2px solid #008793;box-shadow:0 10px 24px #0087931a}
  .v2-lp-voice .v2-wb-chip b{font-size:32px;font-weight:900;color:#aa6229;line-height:1}
  .v2-lp-voice .v2-wb-chip.active b{color:#008793}
  .v2-lp-voice .v2-wb-chip span{font-size:32px;font-weight:800;color:#203c42}
  .v2-lp-voice .v2-wb-chip em{font-style:normal;font-size:22px;color:#5a7577;font-weight:600}
  .v2-lp-voice .v2-wb-bar{display:flex;align-items:center;gap:16px;padding:14px 20px;border-radius:14px;background:#edf2ea;border:1px solid #c0d2c7}
  .v2-lp-voice .v2-wb-dot{width:14px;height:14px;border-radius:50%;background:#008793;flex:none}
  .v2-lp-voice .v2-wb-track{flex:1;height:10px;border-radius:999px;background:#d3dfd8;overflow:hidden}
  .v2-lp-voice .v2-wb-fill{display:block;width:68%;height:100%;border-radius:999px;background:linear-gradient(90deg,#008793,#2aa89d)}
  .v2-lp-voice .v2-wb-label{font-size:24px;font-weight:700;color:#34595f;white-space:nowrap}
 `;
 document.head.append(st);
 if(window.FilmSeries){window.FilmSeries.fitTitles=()=>{};}
})();
