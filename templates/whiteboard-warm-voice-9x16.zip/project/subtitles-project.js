(()=>{
 const params=new URLSearchParams(location.search),plan=window.CANVAS_PLAN;
 const config={mode:'emphasis',reveal:'typewriter',font_size:54,line_height:1.45,bottom:54,safe_bottom:216,margin_x:120,color:'#f7fafc',accent:'#00c1cd',keywords:{},strong_lines:[],display_aliases:{},...plan.subtitle_settings};
 if(window.CAPTION_KEYWORDS){config.keywords=window.CAPTION_KEYWORDS;config.display_aliases={}}
 const track=window.CanvasSubtitleTrack.create({stage:document.querySelector('#stage'),timeline:window.CAPTION_TIMELINE||window.FINAL_TIMELINE,output:plan.output,config,mode:params.get('subtitles')||config.mode,requestRender:()=>window.CanvasExplorer?.getMode()==='demo'?window.renderAt(window.CanvasExplorer.getTime()):undefined});
 window.CanvasSubtitles=track;plan.subtitle_settings=track.settings;
 const render=window.CanvasScene.render;window.CanvasScene.render=t=>{render(t);track.render(t);if((plan.insertions||[]).some(x=>t>=x.body_start&&t<x.body_end))track.root.style.opacity='0'};
 const select=document.querySelector('#subtitle-mode');select.value=track.getMode();
 select.addEventListener('change',async()=>{select.disabled=true;try{await track.setMode(select.value)}finally{select.disabled=false}});
 const style=document.createElement('style');style.textContent='.subtitle-control{display:flex;align-items:center;justify-content:space-between;color:#a8bdce;font-size:11px;gap:8px}.subtitle-control select{font:11px inherit;color:#e8f5f7;background:#111c27;border:1px solid #3b5465;border-radius:6px;padding:5px 7px;max-width:180px}';document.head.append(style);
})();
