(()=>{
 const style=document.createElement('style');style.textContent='.motion-glint{position:absolute;inset:0;display:block;pointer-events:none;user-select:none;font:inherit!important;letter-spacing:inherit!important;line-height:inherit!important;white-space:inherit!important;color:#efffff!important;--glint:-20%;mask-image:linear-gradient(105deg,transparent calc(var(--glint) - 13%),#000 var(--glint),transparent calc(var(--glint) + 13%));filter:drop-shadow(0 0 13px #75eaff);opacity:0}.motion-glint *{color:inherit!important}.resource-mode .motion-glint{display:none!important}';document.head.append(style);
 function sweep(tl,element,{at,duration=.65}={}){
  if(getComputedStyle(element).position==='static')element.style.position='relative';
  const glint=document.createElement('span');glint.className='motion-glint';glint.setAttribute('aria-hidden','true');glint.innerHTML=element.innerHTML;element.append(glint);
  gsap.set(glint,{opacity:0,'--glint':'-20%'});tl.set(glint,{opacity:1},at).to(glint,{'--glint':'120%',duration,ease:'power2.inOut'},at).to(glint,{opacity:0,duration:.12},at+duration-.05);
  return glint;
 }
 function type(tl,line,groups){
  const text=line.querySelector('.typed-text'),cursor=line.querySelector('.type-cursor');
  text.innerHTML=groups.flatMap(g=>Array.from(g.text).map((ch,i)=>`<span data-at="${g.start+(g.end-g.start)*i/Math.max(1,g.text.length)}">${ch===' '?'&nbsp;':ch}</span>`)).join('');
  const sheen=document.createElement('i');sheen.className='type-sheen';line.append(sheen);
  const chars=[...text.children];gsap.set(chars,{opacity:0,y:10,rotationX:28,filter:'blur(4px)',textShadow:'0 0 0px rgba(95,210,255,0)',transformOrigin:'50% 100%'});gsap.set([cursor,sheen],{opacity:0});
  chars.forEach(ch=>{const t=Number(ch.dataset.at);
   tl.to(ch,{opacity:1,y:0,rotationX:0,filter:'blur(0px)',textShadow:'0 0 28px rgba(95,210,255,.6)',duration:.18,ease:'power3.out'},t);
   tl.to(ch,{textShadow:'0 0 0px rgba(95,210,255,0)',duration:.24},t+.16);
   tl.set(cursor,{opacity:1},t);tl.to(cursor,{x:()=>ch.offsetLeft+ch.offsetWidth+8,duration:.065,ease:'none'},t);
   tl.to(sheen,{x:()=>ch.offsetLeft+ch.offsetWidth-10,opacity:.7,duration:.08,ease:'none'},t);
  });
  tl.to(cursor,{opacity:0,duration:.16},groups.at(-1).end+.1).to(sheen,{opacity:0,duration:.2},groups.at(-1).end+.04);
 }
 const cursor='<svg class="demo-cursor" viewBox="0 0 17 22" aria-hidden="true"><path d="M1.5 1.5L1.5 18.6 6.4 13.9 9.1 20.3 11.9 19.1 9.2 12.8 14.5 12.8Z"/></svg>';
 window.MotionInk={type,cursor,sweep};
})();
