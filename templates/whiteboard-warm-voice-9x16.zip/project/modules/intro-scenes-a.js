(()=>{
 const R=IntroScenes.register;
 const line=(d,c='#008793',w=2,extra='')=>`<path d="${d}" fill="none" stroke="${c}" stroke-width="${w}" stroke-linecap="round" ${extra}/>`;
 const dot=(x,y,r=5,c='#008793')=>`<circle cx="${x}" cy="${y}" r="${r}" fill="${c}"/>`;
 const tx=(x,y,t,cl='')=>`<text x="${x}" y="${y}" class="${cl}">${t}</text>`;
 const rect=(x,y,w,h,fill='#e2e9e1',stroke='#8da59e',rx=5)=>`<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="${rx}" fill="${fill}" stroke="${stroke}"/>`;
 const arrows=(x,y)=>line(`M${x} ${y}h32m-8-7 8 7-8 7`);
 const mini=(x,y,w=110,h=70,label='画面')=>`<g transform="translate(${x} ${y})">${rect(0,0,w,h)}${tx(9,22,label,'i-small')}${rect(9,32,w*.55,7,'#008793','none',1)}${rect(9,46,w*.75,5,'#8fa9a2','none',1)}</g>`;
 R('brand',{
  build:H=>H.over('把声音，做成看得见的讲解。')+
   `<div style="position:absolute;left:16px;top:49px;font-size:43px;font-weight:850;line-height:1.2">${H.word('用代码制作','code')}<br>${H.word('讲解视频','code','i-accent')}</div>
    <div style="position:absolute;left:16px;top:177px;font:900 112px/1 'Segoe UI',sans-serif;letter-spacing:-7px">${H.word('XYCut','brand','i-accent')}</div>
    <div style="position:absolute;left:20px;top:293px;font-size:40px;font-weight:850">${H.word('画布视频 Skill','name')}</div>
    ${H.on('name','xycut-canvas-video-skill','skill-full-name')}
    ${H.on('free','<span style="color:#aa6229">✓</span> 免费分享','brand-free')}
    <svg class="brand-code" style="position:absolute;left:430px;top:78px;width:130px;height:184px" viewBox="0 0 130 184">${line('M42 38 10 80l32 42','#708d8c',5)}${line('m85 38 32 42-32 42','#008793',5)}${line('m76 20-25 125','#78659d',4)}<path class="brand-orbit" d="M2 161H128" fill="none" stroke="#008793" stroke-width="3"/></svg>`+
   H.foot('音频时间 → AI设计 → 画布与镜头'),
  render:C=>{const q=C.q('code',1.2);C.draw('.brand-orbit',q);C.one('.brand-code').style.transform=`translateY(${(1-q)*18}px) scale(${.9+.1*q})`}
 });
 R('code-to-video',{
  build:H=>H.head('你现在看到的这条视频','根据录好的配音','设计画面和动画','voice','design',{firstSize:43,secondSize:50})+
   H.art(`${tx(0,25,'你的配音','i-small')}<g transform="translate(0 47)">${H.waveBars(7.48,10.7,122,54,22)}</g>
    ${arrows(132,80)}<g class="code-frame">${rect(180,10,200,176,'#e4eae3','#8ba39d')}${line('M180 42h200','#8da59e',1)}${tx(194,32,'SCENE / CODE','i-small')}
    ${tx(196,72,'&lt;canvas&gt;','i-code')}${tx(209,103,'voice.time','i-code')}${tx(209,134,'animate(t)','i-code')}${tx(196,163,'&lt;/canvas&gt;','i-code')}</g>
    ${arrows(392,80)}<g class="mini-output">${rect(438,10,126,176,'#fcf9f0','#91b6b9')}
    <text x="450" y="45" style="fill:#17424b;font-weight:850">会动的</text><text x="450" y="71" style="fill:#008c9b;font-weight:850">讲解</text>
    <path class="output-graph" d="M450 149 470 132 487 139 508 102 546 94" fill="none" stroke="#008c9b" stroke-width="4"/>
    ${line('M450 167h98','#6d939f',2)}<circle class="out-head" cy="167" r="4" fill="#008c9b"/></g>`)+
    H.on('made','✓ 本片也是用它制作','made-proof')+H.foot('声音和画面，使用同一条时间轴。'),
  render:C=>{C.draw('.output-graph',C.q('design',1.8));C.one('.out-head').setAttribute('cx',450+98*C.q('self',1.2));C.one('.code-frame').style.opacity=String(.6+.4*C.q('ai',.5))}
 });
 R('audio-inputs',{
  build:H=>H.head('整个过程，从这里开始','先确定','音频的时间','start','clock')+
    H.art(`<g class="tts-input">${rect(0,20,176,125)}<text x="88" y="52" text-anchor="middle" style="font-size:23px;font-weight:800">AI 自动配音</text><g transform="translate(24 67)">${H.waveBars(16.8,18.4,128,40,26)}</g></g>
    <g class="oral-input">${rect(392,20,176,125)}<text x="480" y="52" text-anchor="middle" style="font-size:23px;font-weight:800">你的口播视频</text>${line('M412 71h135v48H412z','#8da59e',2)}${line('m469 82 18 12-18 12z','#008793',2)}</g>
    ${line('M176 83H206Q232 83 232 109v47M392 83H362Q336 83 336 109v47','#6e9794',2,'class="input-merge"')}
    ${rect(176,156,216,53,'#d9e9df','#008793',26)}<text x="284" y="190" text-anchor="middle" style="font-size:23px;font-weight:800">同一条主时间轴</text>`)+H.foot('输入可以不同，时间依据始终来自声音。'),
  render:C=>{C.one('.tts-input').style.opacity=String(.45+.55*C.q('tts',.45));C.one('.oral-input').style.opacity=String(.45+.55*C.q('oral',.45));C.draw('.input-merge',C.q('clock',1.2))}
 });
 R('asr-clock',{
  build:H=>H.head('声音先变成可定位的时间','识别音频','带时间的字幕','recognize','caption',{firstSize:52,secondSize:51})+
   H.art(`${rect(0,0,568,204,'#faf7ef','#8ba39d',6)}
    <g transform="translate(18 17)">${H.waveBars(20.04,25.21,532,42,100)}</g>
    ${line('M18 68h532','#34515f',1)}
    ${[12,13,14].map((n,i)=>{const l=FINAL_TIMELINE.lines[n-1];return `<g class="asr-row row-${i}">${tx(18,98+i*36,H.fmt(l.target_start_ms/1000),'i-code')}${tx(127,98+i*36,H.esc(l.text),'i-small')}</g>`}).join('')}
    <g class="asr-scanner">${line('M18 10v53','#008793',2)}${dot(18,10,4)}</g>
    ${tx(18,192,'ASR · 字词级时间','i-small')}`)+H.foot('真实音频识别结果，不按平均时长猜字幕。'),
  render:C=>{const q=C.qTime(C.at('recognize'),4.7);C.move('.asr-scanner',q*532,0);C.all('.asr-row').forEach((n,i)=>n.style.opacity=String(.25+.75*C.qTime(FINAL_TIMELINE.lines[11+i].target_start_ms/1000,.3)))}
 });
 R('beat-sync',{
  build:H=>H.head('不只是字幕，还是画面时钟','哪句话、哪个词','都能精准定位','sentence','keyword',{firstSize:46,secondSize:49})+
   H.art(`${tx(0,34,'文字','i-small')}${tx(0,104,'图形','i-small')}${tx(0,174,'动画','i-small')}
    ${line('M82 54H560M82 125H560M82 194H560','#c2d1c7',1)}
    ${rect(88,8,174,40,'#dcebe3','#6e9b95')}${tx(108,35,'句子开始','i-label')}
    ${rect(304,8,218,40,'#c9e4db','#008793')}${tx(328,35,'重点词出现','i-label')}
    <g class="sync-graph">${[18,29,23,41,32,47].map((h,i)=>`<rect class="sync-bar" data-height="${h}" x="${108+i*72}" y="${121-h}" width="38" height="${h}" rx="2" fill="#008793"/>`).join('')}</g>
    <g class="sync-nodes">${line('M130 165h141m38 0h165','#6e9794',3)}${[114,290,490].map((x,i)=>`${dot(x,165,16,'#dce6de')}<text x="${x}" y="171" text-anchor="middle" class="i-small">${i+1}</text>`).join('')}</g>
    <g class="sync-head i-lens-frame">${line('M88 0V197','#007d87',2)}${dot(88,197,4,'#aa6229')}</g>`,568,220)+H.foot('文字、图形和动画，对齐同一条实际时间轴。'),
  render:C=>{const progress=C.preview?1:C.clamp((C.t-C.content.activation)/(C.content.end-C.content.activation));C.move('.sync-head',progress*466,0);C.all('.sync-bar').forEach((n,i)=>{const h=Number(n.dataset.height)*(.15+.85*C.q('visuals',.85,i*.08));n.setAttribute('height',h);n.setAttribute('y',121-h)});C.all('.sync-nodes circle').forEach((n,i)=>n.setAttribute('fill',C.qTime(C.at('follow')+i*.18,.2)>.2?'#b5d8cb':'#dce6de'))}
 });
 const canvasObjects=(H)=>`<g class="world-title"><text x="20" y="46" style="font-size:28px;font-weight:850">把内容</text><text x="20" y="91" style="font-size:28px;font-weight:850">组织起来</text>${line('M20 109h126','#008793',3)}</g>
  <g class="world-number"><text x="238" y="81" class="i-number" style="font-size:68px">99</text>${tx(238,120,'数字示例','i-small')}</g>
  <g class="world-flow">${[414,466,518].map(x=>dot(x,54,16,'#c7dfd5')).join('')}${line('M430 54h20m32 0h20','#008793',3)}${tx(423,106,'流程推进','i-small')}</g>
  <g class="world-extra">${line('M20 135H548','#385b69',1)}${rect(20,151,528,45)}${tx(36,181,'操作组件','i-small')}${line('M199 174h320','#527b89',4)}${dot(426,174,9)}</g>`;
 R('world-build',{
  build:H=>H.head('不是一页一页堆起来','按内容关系','铺开一张大画布','elements','relation',{firstSize:51,secondSize:47})+
   H.art(`<rect class="world-boundary" x="0" y="0" width="568" height="210" fill="none" stroke="#476471" stroke-dasharray="5 7"/>${canvasObjects(H)}`)+H.foot('画布继续延展，内容之间的关系仍然清楚。'),
  render:C=>{const q=C.q('extend',1);C.one('.world-extra').style.opacity=String(.45+.55*q);C.one('.world-extra circle').setAttribute('cx',340+86*C.q('relation',1.3));C.all('.world-flow circle').forEach((n,i)=>n.setAttribute('fill',C.q('elements',1,i*.15)>.8?'#b5d8cb':'#c7dfd5'));C.one('.world-boundary').setAttribute('stroke',C.q('canvas',.7)>.3?'#5e9ca8':'#476471')}
 });
 R('visual-vocabulary',{
  build:H=>H.over('根据讲解内容，选择表现方式')+
   `<h2 style="position:absolute;left:16px;top:43px;font-size:49px;line-height:1.12;font-weight:900">${H.word('有些内容','title')}<br>${H.word('就是一句大标题','title','i-accent')}</h2>`+
   H.art(`<g class="vocab-count"><text x="2" y="92" class="i-number" style="font-size:82px">0</text>${tx(5,144,'数字','i-small')}</g>
    <g class="vocab-flow">${[235,300,365].map((x,i)=>`${dot(x,58,20,'#c8dfd1')}${tx(x-6,65,i+1)}`).join('')}${line('M255 58h25m40 0h25','#008793',3)}${tx(251,129,'流程图','i-small')}</g>
    <g class="vocab-slider">${line('M431 57h130','#527c89',6)}${dot(480,57,11)}${tx(442,129,'操作组件','i-small')}</g>
    <g class="vocab-expand">${line('M4 171h531m-12-8 12 8-12 8','#7aa0ae',2)}${tx(5,208,'内容多了，沿着画布继续扩展。','i-small')}</g>`)+H.foot('不用把每一句话，都塞进相同的卡片。'),
  render:C=>{C.one('.vocab-count text').textContent=Math.round(99*C.q('types',1.2));C.draw('.vocab-flow path',C.q('types',1));C.one('.vocab-slider circle').setAttribute('cx',440+112*C.q('controls',1.1));C.draw('.vocab-expand path',C.q('extend',1.1))}
 });
 const layoutPreview=(x,y,s=1)=>`<g transform="translate(${x} ${y}) scale(${s})">${rect(0,0,228,148,'#faf7ef','#507180')}
   ${rect(13,16,85,11,'#008793','none',1)}${rect(13,36,114,8,'#85a4b2','none',1)}
   ${mini(13,66,78,60,'标题')}${mini(126,20,82,50,'数字')}${mini(126,89,82,43,'流程')}${line('M91 95H108V47h18M91 95h35','#5c8c99',2)}</g>`;
 R('snapshot',{
  build:H=>H.head('大画布的另一个好处','方便AI','检查和修改','layout','ai',{firstSize:58,secondSize:58})+
    H.art(`${layoutPreview(0,20)}
    <g class="capture-corners">${line('M-5 48V14h33m177 0h29v34M-5 140v33h33m177 0h29v-33','#008793',3)}</g>
    ${arrows(244,94)}
    <g class="snapshot-result">${rect(300,0,264,207,'#e3eae2','#6f8d9d')}
     ${tx(315,29,'AI · 截图查看','i-small')}${layoutPreview(316,44,.99)}
     ${tx(316,197,'整体排版 / 检查示意','i-small')}</g>
    <rect class="scan-beam" x="0" y="20" width="228" height="3" fill="#008793"/></svg>`.replace('</svg>',''))+
    H.foot('先看整体是否正确，再看实际播放是否合适。'),
  render:C=>{const q=C.q('capture',1);C.one('.scan-beam').setAttribute('y',20+148*q);C.one('.scan-beam').style.opacity=String(Math.sin(q*Math.PI));C.one('.snapshot-result').style.opacity=String(.25+.75*q);C.draw('.capture-corners path',C.q('benefit',1))}
 });
 R('layout-audit',{
  build:H=>H.head('检查的重点，是具体问题','重叠？越界？','关系清不清楚？','check','relation',{firstSize:53,secondSize:48})+
    H.art(`${rect(0,0,350,205,'#faf7ef','#64818e',1)}${tx(13,27,'布局检查示意','i-small')}
    ${rect(20,52,145,56,'#dde8df','#497581')}${tx(30,86,'文字 A','i-label')}
    ${rect(112,76,135,54,'#e4e5e2','#73828b')}${tx(128,110,'文字 B','i-label')}
    ${rect(281,45,65,102,'#e0e8df','#63808b')}
    <rect class="audit-overlap" x="105" y="69" width="65" height="46" fill="none" stroke="#aa6229" stroke-width="3"/>
    <rect class="audit-overflow" x="275" y="39" width="83" height="114" fill="none" stroke="#aa6229" stroke-width="3"/>
    ${line('M27 171h260m-10-7 10 7-10 7','#7197a3',2)}
    <g class="audit-relation">${dot(42,171,8)}${dot(286,171,8)}</g>
    ${[['重叠',60],['越界',115],['关系',170]].map(([s,y],i)=>`<g class="audit-check check-${i}">${dot(395,y-6,12,'#163846')}${tx(420,y,s,'i-label')}</g>`).join('')}`)+H.foot('静态排版检查：文字、范围、图形关系。'),
  render:C=>{['overlap','overflow','relation'].forEach((k,i)=>{const q=C.q(k,.3);C.one('.audit-check.check-'+i).style.opacity=String(.3+.7*q);C.one('.audit-check.check-'+i+' circle').setAttribute('fill',q>.2?'#008793':'#163846');C.one('.audit-'+k).style.opacity=String(q)})}
 });
 R('keyframe-repair',{
  build:H=>H.head('再检查实际播放中的画面','截取关键画面','回到代码调整','keyframes','adjust',{firstSize:50,secondSize:51})+
    H.art(`${[0,1,2].map(i=>`<g transform="translate(${i*112} 0)">${rect(0,0,98,61)}${tx(9,25,'镜头 0'+(i+1),'i-small')}${line('M10 42h76','#008793',3)}</g>`).join('')}
    ${rect(0,84,252,125,'#e4ebe3','#60808e')}${tx(13,111,'CODE / 调整布局','i-small')}
    ${tx(15,143,'x:','i-code')}${tx(54,143,'120 → 24','i-code')}${tx(15,180,'renderAt(t)','i-code')}
    ${arrows(269,145)}${rect(320,84,244,125,'#fcf9f0','#74959c')}
    <g class="repair-object">${rect(335,103,179,38,'#bad7c8','#008c9a')}${tx(346,129,'对齐后的重点','i-label')}${rect(335,154,200,8,'#6b979f','none',0)}${rect(335,174,145,8,'#6b979f','none',0)}</g>
    <rect class="repair-focus" x="328" y="95" width="226" height="105" fill="none" stroke="#008793" stroke-width="2"/>`)+H.foot('排版和播放，两次检查都回到同一份代码。'),
  render:C=>{const q=C.q('adjust',.7);C.move('.repair-object',38*(1-q),0);C.one('.repair-focus').style.opacity=String(C.q('camera',.6));C.all('g[transform^="translate("]').slice(0,3).forEach((n,i)=>n.style.opacity=String(.35+.65*C.qTime(C.at('keyframes')+i*.22,.3)))}
 });
 const style=document.createElement('style');style.textContent=`
 .brand-free{position:absolute;left:420px;top:308px;font-size:23px;font-weight:750;white-space:nowrap}.skill-full-name{position:absolute;left:20px;top:351px;font:23px/1.3 Consolas,'Segoe UI',sans-serif;letter-spacing:-.6px;color:#526f72}.made-proof{position:absolute;left:16px;top:347px;font-size:23px;font-weight:750;color:#aa6229}.intro-code-to-video .i-art{height:175px!important;top:168px!important}.intro-brand .i-foot{top:397px}.intro-visual-vocabulary .i-title{font-size:50px}`;
 document.head.append(style);
})();
