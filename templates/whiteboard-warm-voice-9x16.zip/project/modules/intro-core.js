(()=>{
 const clamp=x=>Math.max(0,Math.min(1,x)),ease=x=>1-Math.pow(1-clamp(x),3),lerp=(a,b,q)=>a+(b-a)*q;
 const esc=InfoKit.esc,norm=s=>String(s).replace(/[\s\p{P}\p{S}]/gu,'').toLowerCase();
 function register(id,definition){CanvasModules.register({id:'intro/'+id,name:id,create(root,{content}){
  const cue=key=>{if(!content.anchors[key])throw Error('Missing real ASR cue: '+id+'/'+key);return content.anchors[key]};
  const H={content,esc,uid:s=>'intro-'+id+'-'+s,anchor:key=>cue(key).start,icon:name=>CanvasIcons[name]||CanvasIcons.file,
   word(text,key,cls=''){
    const a=cue(key),source=norm(a.text),target=norm(text),offset=source.indexOf(target),owners=[];
    for(const token of a.tokens)for(const c of norm(token.text))owners.push(token.target_start_ms/1000);
    let i=0,last=a.start;const glyphs=Array.from(text).map(c=>{if(norm(c)){last=offset>=0?(owners[offset+i]??a.start):a.start;i++}return `<span class="i-glyph" data-at="${last}">${esc(c)}</span>`}).join('');
    return `<span class="i-word ${esc(cls)}" data-label="${esc(text)}" data-at="${a.start}" data-end="${a.end}">${glyphs}</span>`;
   },
   on(key,html,cls=''){return `<div class="i-atom ${esc(cls)}" data-at="${cue(key).start}">${html}</div>`},
   over:text=>`<p class="i-over">${esc(text)}</p>`,
   head(over,first,second,k1,k2,options={}){return this.over(over)+`<h2 class="i-title" style="font-size:${options.firstSize??54}px">${this.word(first,k1)}<br><span style="font-size:${options.secondSize??54}px">${this.word(second,k2,'i-accent')}</span></h2>`},
   art:(body,w=568,h=220,x=16,y=176)=>`<svg class="i-art" style="left:${x}px;top:${y}px;width:${w}px;height:${h}px" viewBox="0 0 ${w} ${h}" aria-hidden="true">${body}</svg>`,
   foot:text=>`<p class="i-foot">${esc(text)}</p>`,
   fmt:t=>`${String(Math.floor(t/60)).padStart(2,'0')}:${(t%60).toFixed(2).padStart(5,'0')}`,
   waveBars(start,end,w=530,h=45,count=80){const wave=CANVAS_PLAN.audio_waveform||{rate:25,values:[]};return Array.from({length:count},(_,i)=>{const sample=wave.values[Math.floor((start+(end-start)*i/count)*wave.rate)]??.08,height=Math.max(3,sample*h);return `<rect x="${i*w/count}" y="${(h-height)/2}" width="${Math.max(2,w/count-2)}" height="${height}" rx="1" fill="#6f9894"/>`}).join('')}
  };
  root.innerHTML=`<section class="intro-scene intro-${id}" data-variant="${id}">${definition.build(H)}</section>`;const scene=root.firstElementChild,words=[...scene.querySelectorAll('.i-word')],glyphs=[...scene.querySelectorAll('.i-glyph')],atoms=[...scene.querySelectorAll('.i-atom')];
  return{render(local){const t=Number.isFinite(window.FILM_TIME)?FILM_TIME:content.start+local,preview=document.body.classList.contains('resource-mode')||t<(content.reveal_start??content.activation);
   scene.dataset.preview=String(preview);
   for(const n of atoms){const age=t-Number(n.dataset.at);n.style.opacity=preview?'1':String(ease(age/.16));n.style.transform='none'}
   for(const n of glyphs){const age=t-Number(n.dataset.at);n.style.opacity=preview?'1':String(ease(age/.065));n.style.transform='none'}
   for(const n of words){const age=t-Number(n.dataset.at);n.style.transform='none';n.style.opacity=preview||age>=0?'1':'0';const sheen=preview?1:clamp((t-Number(n.dataset.end)+.12)/.7),accent=n.classList.contains('i-accent');n.style.setProperty('--shine',(-20+140*sheen)+'%');n.style.setProperty('--shine-opacity',!preview&&accent?String(.42*Math.sin(Math.PI*sheen)):'0')}
   const one=s=>scene.querySelector(s),all=s=>[...scene.querySelectorAll(s)],qTime=(s,d=.5)=>preview?1:ease((t-s)/Math.max(.04,d));
   const ctx={scene,t,preview,content,anchors:content.anchors,one,all,clamp,ease,lerp,at:key=>cue(key).start,q:(key,d=.5,delay=0)=>qTime(cue(key).start+delay,d),qTime,
    show:(s,visible)=>all(s).forEach(n=>n.style.opacity=visible?'1':'0'),
    move:(s,x,y)=>all(s).forEach(n=>n.setAttribute('transform',`translate(${x} ${y})`)),
    draw:(s,q)=>all(s).flatMap(n=>typeof n.getTotalLength==='function'?[n]:[...n.querySelectorAll('path,rect,circle')]).forEach(n=>{const len=n.getTotalLength();n.style.strokeDasharray=String(len);n.style.strokeDashoffset=String(len*(1-q))})};
   definition.render(ctx);
   const frameAt=content.anchors.lens?.start??content.anchors.zoom?.start??content.anchors.move?.start??content.activation;
   const fq=preview?1:clamp((t-frameAt)/1.7),flare=preview?0:Math.sin(Math.PI*fq);
   all('.i-lens-frame').forEach(n=>{n.style.filter=`drop-shadow(0 0 ${2.2+flare*3.5}px #00dfeb${preview?'45':'99'})`});
   all('.lens-sweep').forEach(n=>{const len=n.getTotalLength();n.style.strokeDasharray=`${len*.16} ${len}`;n.style.strokeDashoffset=String(-len*fq);n.style.opacity=String(flare*.95)});
   scene.dataset.processVersion='intro-2';
  }};
 }});}
 const css=document.createElement('style');css.textContent=`
 .intro-scene{position:relative;width:600px;height:420px;color:#203c42;font-family:'XYCut Noto','Microsoft YaHei UI',sans-serif}.intro-scene *{box-sizing:border-box}.intro-scene h1,.intro-scene h2,.intro-scene p{margin:0}.i-over{position:absolute;left:16px;top:1px;font-size:19px;line-height:1.4;letter-spacing:1px;color:#617879}.i-title{position:absolute;left:16px;top:39px;line-height:1.13;font-weight:900;letter-spacing:-1.6px}.i-word{display:inline-block;position:relative;white-space:nowrap;vertical-align:baseline;transform-origin:left center}.i-glyph{display:inline-block;white-space:pre;vertical-align:baseline}.i-word:after{content:attr(data-label);position:absolute;inset:0;white-space:pre;pointer-events:none;color:#007d87;text-shadow:0 0 12px #008793;opacity:var(--shine-opacity,0);mask-image:linear-gradient(110deg,transparent calc(var(--shine,-20%) - 12%),#000 var(--shine,-20%),transparent calc(var(--shine,-20%) + 12%))}.i-accent{color:#008793}.i-warm{color:#aa6229}.i-purple{color:#78659d}.i-foot{position:absolute;left:16px;top:397px;font-size:17px;line-height:1.2;color:#617879;white-space:nowrap}.i-art{position:absolute;overflow:visible}.i-art text{font:20px 'XYCut Noto','Microsoft YaHei UI',sans-serif;fill:#203c42}.i-art .i-label{font-size:25px;font-weight:800}.i-art .i-big{font-size:33px;font-weight:850}.i-art .i-number{font:900 96px 'Segoe UI',sans-serif;fill:#008793}.i-art .i-small{font-size:16px;fill:#617879}.i-art .i-code{font:19px Consolas,monospace;fill:#715391}.i-art .i-ink{fill:#dce7df}.i-art .i-cyan{fill:#008793}.i-art .i-gold{fill:#aa6229}.i-art .i-mute{fill:#617879}.i-art .i-white{fill:#203c42}.intro-scene .ui-icon{width:32px;height:32px;fill:currentColor}.intro-scene .i-atom{transform-origin:center}.intro-scene *{animation:none!important}
 `;document.head.append(css);window.IntroScenes={register};
})();
