(()=>{
 const P=CANVAS_PLAN,S=CanvasScene,C=CanvasCamera,old=S.render;
 const smooth=x=>{x=Math.max(0,Math.min(1,x));return x*x*(3-2*x)};
 function render(t){
  const browse=document.body.classList.contains('resource-mode');
  let index=0;for(let i=1;i<P.shots.length;i++)if(t>=P.shots[i].at)index=i;
  const shot=P.shots[index],previous=P.shots[Math.max(0,index-1)],u=shot.move?smooth((t-shot.at)/shot.move):1,target=shot.target.split('/')[0],prior=previous.target.split('/')[0];
  const owner=P.components.find(c=>c.id===target),board=P.boards.find(b=>b.id===target),activeBoard=owner?.board_id??board?.id;
  const anchor=FILM_ANCHORS[owner?.id]?.start??shot.at,ready=smooth((t-anchor+.1)/.35),pixelScale=browse?1:C.at(P,t).scale;
  const matches=(c,id)=>id==='overview'||c.id===id||c.board_id===id;
  P.components.forEach(c=>{const weight=browse?1:(matches(c,prior)?1-u:0)+(matches(c,target)?u:0),node=S.elements.get(c.id),same=c.board_id===activeBoard,base=same?.34+.1*ready:.2,blur=(same?5.5-ready:7)/pixelScale;node.style.opacity=String(base+(1-base)*Math.min(1,weight));node.style.filter=`saturate(${.65+.35*Math.min(1,weight)}) blur(${(1-Math.min(1,weight))*blur}px)`;node.dataset.attentionState=browse?'browse':matches(c,target)?'active':t<c.content.activation?'preview':'retained'});
  document.body.classList.toggle('board-overview',!browse&&!!board);
  document.querySelectorAll('.board').forEach(n=>n.classList.toggle('active-overview',!!board&&n.dataset.board===board.id));
 }
 S.render=t=>{window.FILM_TIME=t;old(t);render(t)};
 window.CanvasAttention={has:()=>true,render,parts:[]};
 window.VideoMedia={render(){},pause(){},settle:()=>Promise.resolve(),ready:Promise.resolve(),items:[]};
 const style=document.createElement('style');style.textContent='.demo-mode.board-overview .board.active-overview:before{display:block;border:2px solid #4f9eac;box-shadow:0 0 14px #00c8d622}.demo-mode.board-overview .board.active-overview .board-label{display:flex;font-size:28px;color:#98c5d0}.demo-mode.board-overview .board.active-overview:after{display:block}';document.head.append(style);
})();
