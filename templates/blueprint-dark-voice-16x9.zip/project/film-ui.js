(()=>{
 const P=CANVAS_PLAN,$=s=>document.querySelector(s),stage=$('#stage'),world=$('#world'),series=P.series,esc=InfoKit.esc;
 const win=document.createElement('div');win.className='film-window';world.before(win);win.append(world);
 const label=document.createElement('div');label.className='film-series';
 label.innerHTML='<b data-preview-text="title-heading">'+esc(series.title)+'</b><i data-preview-text="title-description">'+esc(series.subtitle)+'</i>';stage.append(label);
 document.body.classList.toggle('preview-title-off',series.title_enabled===false);
 const cover=document.createElement('div');cover.className='film-cover';
 cover.innerHTML='<div class="series-cover-content"><div class="series-cover-heading"><span class="series-cover-name" data-preview-text="cover-heading">'+esc(series.title)+'</span><span class="series-cover-day"></span></div><div class="series-cover-divider"></div><h1 class="series-cover-subtitle">'+series.cover_lines.map((line,i)=>'<span class="cover-line-'+i+'" data-preview-text="cover-line-'+i+'">'+esc(line)+'</span>').join('')+'</h1></div>';stage.append(cover);
 const guides=document.createElement('div');guides.className='film-guides';guides.innerHTML='<span>横屏正文安全范围 · 字幕位于下方</span>';stage.append(guides);
 $('#guides').closest('label').lastChild.textContent=' 横屏构图参考线';
 $('#guides').onchange=e=>document.body.classList.toggle('show-guides',e.target.checked);
 function render(t){const visible=Number.isFinite(t)&&t<(P.intro?.duration||0)-1e-9;cover.hidden=!visible;document.body.classList.toggle('intro-on',visible)}
 function fitTitles(){if(cover.querySelector('.v2-cover'))return;
  const prev=cover.style.display;cover.style.setProperty('display','block','important');
  const head=cover.querySelector('.series-cover-heading');
  cover.querySelector('.series-cover-divider').style.width=Math.min(1500,head.scrollWidth)+'px';
  const text=cover.querySelector('.series-cover-subtitle');let size=118;text.style.fontSize=size+'px';
  while(text.scrollWidth>1550&&size>70){size-=1;text.style.fontSize=size+'px'}
  if(prev)cover.style.display=prev;else cover.style.removeProperty('display');
 }
 document.fonts.ready.then(fitTitles);
 window.FilmSeries={render,cover,config:series,fitTitles};render(CanvasExplorer.getTime());
})();

// === V2 COVER UPGRADE: dark_landscape_voice ===
(()=>{
 const cover=document.querySelector('.film-cover');
 if(!cover)return;
 const s=CANVAS_PLAN.series||{},esc=InfoKit.esc;
 const lines=s.cover_lines||['配音讲到哪','画面就到哪'];
 cover.innerHTML=`
  <div class="v2-cover v2-dl-voice">
   <div class="v2-dl-grid">
    <div class="v2-dl-left">
     <div class="v2-eyebrow"><span class="v2-dot"></span><span data-preview-text="cover-heading">${esc(s.title||'XYCUT 画布视频 Skill')}</span></div>
     <h1 class="v2-hero">
      <span class="v2-l0" data-preview-text="cover-line-0">${esc(lines[0]||'')}</span>
      <span class="v2-l1" data-preview-text="cover-line-1">${esc(lines[1]||'')}</span>
     </h1>
     <div class="v2-rule"></div>
     <div class="v2-chips">
      <span>16:9 横屏蓝图</span><span>9 画板 · 20 模块</span><span>跨画板纸飞机运镜</span>
     </div>
    </div>
    <div class="v2-dl-right">
     <div class="v2-preview-box">
      <div class="v2-pb-bar"><i></i><i></i><i></i><span>INFINITE CANVAS PREVIEW</span></div>
      <svg class="v2-pb-svg" viewBox="0 0 640 420" fill="none" aria-hidden="true">
       <rect x="26" y="42" width="240" height="150" rx="16" fill="#10202c" stroke="#2c5b6b" stroke-width="2"/>
       <rect x="50" y="70" width="118" height="16" rx="8" fill="#00c8d6"/>
       <rect x="50" y="102" width="176" height="10" rx="5" fill="#7da4b5" opacity=".48"/>
       <rect x="50" y="124" width="144" height="10" rx="5" fill="#7da4b5" opacity=".32"/>
       <rect x="356" y="28" width="256" height="164" rx="16" fill="#132c3a" stroke="#00d8e6" stroke-width="2.6"/>
       <circle cx="406" cy="84" r="24" fill="#00c8d624" stroke="#00d8e6" stroke-width="2.2"/>
       <path d="M397 84l7 7 14-15" stroke="#a6ffff" stroke-width="2.8" stroke-linecap="round" stroke-linejoin="round"/>
       <rect x="444" y="68" width="136" height="16" rx="8" fill="#f0fbff"/>
       <rect x="444" y="96" width="110" height="10" rx="5" fill="#7fdce3" opacity=".6"/>
       <rect x="382" y="134" width="204" height="32" rx="10" fill="#0c1923" stroke="#2d5f70" stroke-width="1.5"/>
       <rect x="396" y="146" width="128" height="8" rx="4" fill="#00d8e6"/>
       <rect x="190" y="236" width="276" height="150" rx="16" fill="#10202c" stroke="#ffce86aa" stroke-width="2"/>
       <rect x="216" y="264" width="140" height="16" rx="8" fill="#ffce86"/>
       <rect x="216" y="296" width="212" height="10" rx="5" fill="#8fb3c4" opacity=".48"/>
       <rect x="216" y="318" width="170" height="10" rx="5" fill="#8fb3c4" opacity=".32"/>
       <path d="M266 116 C306 116, 316 106, 356 106" stroke="#00d8e6" stroke-width="3" stroke-dasharray="7 7"/>
       <path d="M484 192 C484 244, 512 290, 466 306" stroke="#00d8e6" stroke-width="3" stroke-dasharray="7 7"/>
       <g transform="translate(314 111) rotate(-6) scale(1.25)">
        <path d="M16 0 4-3.5-4-14h-4l4 11.5-10-1.5-3.5-4h-2.5l2.5 8-2.5 8h2.5l3.5-4 10-1.5-4 11.5h4L4 3.5Z" fill="#a5f0f4" stroke="#ffffff" stroke-width="1"/>
       </g>
      </svg>
     </div>
    </div>
   </div>
  </div>`;
 const st=document.createElement('style');
 st.textContent=`
  .v2-dl-voice{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;padding:0 110px;background:radial-gradient(ellipse at 25% 45%,#15536655,transparent 62%),radial-gradient(ellipse at 78% 55%,#1b2c4e44,transparent 58%)}
  .v2-dl-voice .v2-dl-grid{width:100%;display:grid;grid-template-columns:1.05fr 0.95fr;gap:72px;align-items:center}
  .v2-dl-voice .v2-dl-left{display:flex;flex-direction:column;align-items:flex-start;gap:28px}
  .v2-dl-voice .v2-eyebrow{display:inline-flex;align-items:center;gap:14px;padding:12px 26px;border-radius:999px;background:#102331;border:1.5px solid #2b697a;color:#bee6f0;font-size:32px;font-weight:700}
  .v2-dl-voice .v2-dot{width:13px;height:13px;border-radius:50%;background:#00e5f2;box-shadow:0 0 14px #00e5f2}
  .v2-dl-voice .v2-hero{margin:0;display:flex;flex-direction:column;gap:12px;font-size:122px;line-height:1.12;font-weight:900;letter-spacing:-4px}
  .v2-dl-voice .v2-l0{color:#f4fafb}
  .v2-dl-voice .v2-l1{color:#00dce8;text-shadow:0 0 36px #00c8d644}
  .v2-dl-voice .v2-rule{width:280px;height:4px;border-radius:4px;background:linear-gradient(90deg,#00d4e2,#ffce86,transparent)}
  .v2-dl-voice .v2-chips{display:flex;flex-wrap:wrap;gap:14px}
  .v2-dl-voice .v2-chips span{padding:12px 22px;border-radius:14px;background:#101f2b;border:1px solid #2a5566;color:#b8d7e2;font-size:25px;font-weight:700}
  .v2-dl-voice .v2-preview-box{border-radius:28px;background:linear-gradient(160deg,#0f1e2aef,#09121aef);border:1.5px solid #2a5d6f;box-shadow:0 28px 70px #0009;overflow:hidden}
  .v2-dl-voice .v2-pb-bar{display:flex;align-items:center;gap:10px;padding:18px 24px;border-bottom:1px solid #204050;background:#0c1722}
  .v2-dl-voice .v2-pb-bar i{width:12px;height:12px;border-radius:50%;background:#2e5c6e}
  .v2-dl-voice .v2-pb-bar i:first-child{background:#00d8e6}
  .v2-dl-voice .v2-pb-bar span{margin-left:auto;font-size:20px;font-weight:700;letter-spacing:2px;color:#7ca8b8}
  .v2-dl-voice .v2-pb-svg{width:100%;height:auto;display:block;padding:16px}
 `;
 document.head.append(st);
 if(window.FilmSeries){window.FilmSeries.fitTitles=()=>{};}
})();
