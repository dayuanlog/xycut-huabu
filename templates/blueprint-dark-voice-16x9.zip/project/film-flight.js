(()=>{
 const P=CANVAS_PLAN,C=CanvasCamera,S=CanvasScene,F=P.flight_guides;
 if(!F)return;
 const clamp=x=>Math.max(0,Math.min(1,x)),ease=x=>{x=clamp(x);return x*x*(3-2*x)};
 const rect=P.framing.content_rect,ns='http://www.w3.org/2000/svg';
 const svg=document.createElementNS(ns,'svg');
 svg.id='camera-flight-guide';svg.setAttribute('viewBox',`0 0 ${P.output.width} ${P.output.height}`);
 svg.setAttribute('aria-hidden','true');
 Object.assign(svg.style,{position:'absolute',inset:'0',width:'100%',height:'100%',zIndex:'35',pointerEvents:'none',display:'none'});
 svg.innerHTML=`<defs>
  <clipPath id="flight-safe-clip"><rect x="${rect.x}" y="${rect.y+10}" width="${rect.width}" height="${rect.height-20}"/></clipPath>
  <filter id="flight-trail-glow" filterUnits="userSpaceOnUse" x="0" y="0" width="1920" height="1080"><feGaussianBlur stdDeviation="3.3"/></filter>
  <filter id="flight-head-glow" x="-70%" y="-70%" width="240%" height="240%"><feGaussianBlur stdDeviation="3"/></filter>
  <linearGradient id="flight-tail-fade" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#00cfdf" stop-opacity="0"/><stop offset=".55" stop-color="#37e9ed" stop-opacity=".65"/><stop offset="1" stop-color="#ddffff"/></linearGradient>
 </defs><g clip-path="url(#flight-safe-clip)">
  <path class="flight-trail-glow" fill="none" stroke="#00dfea" stroke-width="7" opacity=".3" filter="url(#flight-trail-glow)"/>
  <path class="flight-trail" fill="none" stroke="url(#flight-tail-fade)" stroke-width="2.4" stroke-dasharray="7 9" stroke-linecap="round"/>
  <circle class="flight-arrival" fill="none" stroke="#9effff" stroke-width="1.8"/>
  <g class="flight-plane">
   <path class="flight-plane-halo" d="M19 0 5-4-5-17h-5l5 14-12-2-4-5h-3l3 10-3 10h3l4-5 12-2-5 14h5L5 4Z" fill="#00ecf5" opacity=".65" filter="url(#flight-head-glow)"/>
   <path d="M19 0 5-4-5-17h-5l5 14-12-2-4-5h-3l3 10-3 10h3l4-5 12-2-5 14h5L5 4Z" fill="#a5f0f4" stroke="#edffff" stroke-width="1.2" stroke-linejoin="round"/>
  </g></g>`;
 document.querySelector('#stage').append(svg);
 const trail=svg.querySelector('.flight-trail'),halo=svg.querySelector('.flight-trail-glow'),plane=svg.querySelector('.flight-plane'),arrival=svg.querySelector('.flight-arrival'),gradient=svg.querySelector('linearGradient');
 const finalCamera=shot=>{
  const b=C.bounds(P,shot.target),padding=shot.padding??.12;
  return{cx:b.x+b.width/2,cy:b.y+b.height/2,
   screen_cx:rect.x+rect.width/2,screen_cy:rect.y+rect.height/2,
   scale:Math.min(rect.width*(1-2*padding)/b.width,rect.height*(1-2*padding)/b.height)*(shot.context_scale??1)};
 };
 const boardOf=t=>{
  const id=String(t||'').split('/')[0];
  return P.components.find(c=>c.id===id)?.board_id||(P.boards.some(b=>b.id===id)?id:null);
 };
 const events=P.shots.flatMap((shot,i)=>{
  if(!i||!shot.move||!P.components.some(c=>c.id===shot.target.split('/')[0]))return[];
  if(shot.flight?.enabled===false)return[];
  const prevBoard=boardOf(P.shots[i-1].target),nextBoard=boardOf(shot.target);
  if(!prevBoard||!nextBoard||prevBoard===nextBoard)return[];
  const from=finalCamera(P.shots[i-1]),to=finalCamera(shot);
  if(Math.hypot(to.cx-from.cx,to.cy-from.cy)*Math.min(from.scale,to.scale)<45)return[];
  return[{id:shot.id,start:shot.at,arrive:shot.at+shot.move,target:shot.target,shot,from,to}];
 });
 const project=(p,c)=>({x:c.screen_cx+(p.cx-c.cx)*c.scale,y:c.screen_cy+(p.cy-c.cy)*c.scale});
 const openingCamera=finalCamera(P.shots[0]),openingBox=C.bounds(P,F.opening.target);
 const entryEnd=project({cx:openingBox.x+F.opening.local_x,cy:openingBox.y+F.opening.local_y},openingCamera);
 const entryStart={x:24,y:Math.min(rect.y+rect.height-80,entryEnd.y+270)};
 function entryPoint(u){
  const a=entryStart,b={x:180,y:entryStart.y-40},c={x:entryEnd.x-100,y:entryEnd.y+80},d=entryEnd,v=1-u;
  return{x:v*v*v*a.x+3*v*v*u*b.x+3*v*u*u*c.x+u*u*u*d.x,y:v*v*v*a.y+3*v*v*u*b.y+3*v*u*u*c.y+u*u*u*d.y};
 }
 function hide(){svg.style.display='none';svg.dataset.event='';}
 function render(t){
  if(document.body.classList.contains('resource-mode')||Number(document.querySelector('#seek').min)>0){hide();return}
  const release=(F.landing_hold??0)+F.landing_fade;
  const opening=t>=F.opening.start&&t<=F.opening.arrive+release;
  const event=opening?{...F.opening,id:'opening-focus'}:events.find(e=>t>=e.start&&t<=e.arrive+release);
  if(!event){hide();return}
  const u=clamp((t-event.start)/(event.arrive-event.start)),camera=C.at(P,t);
  let progress=opening?ease(u):Math.min(1,u+F.lead*Math.sin(Math.PI*u));
  const dx=opening?0:event.to.cx-event.from.cx,dy=opening?0:event.to.cy-event.from.cy;
  const distance=Math.hypot(dx,dy)||1,bend=(event.shot?.curve>=0?1:-1)*Math.min(44,Math.max(24,distance*camera.scale*.055));
  const pointAt=opening?entryPoint:p=>{
   p=clamp(p);
   const point=project(C.at(P,event.start+(event.arrive-event.start)*p),camera),arc=bend*Math.sin(Math.PI*p)**2;
   return{x:point.x-dy/distance*arc,y:point.y+dx/distance*arc};
  };
  if(!opening){
   for(let tries=0;tries<5;tries++){
    const p=pointAt(progress);
    if(p.x>=rect.x+35&&p.x<=rect.x+rect.width-35&&p.y>=rect.y+50&&p.y<=rect.y+rect.height-50)break;
    progress=(progress+u)/2;
   }
  }
  const head=pointAt(progress),tailStart=Math.max(0,progress-F.trail_fraction),points=[];
  for(let i=0;i<=26;i++)points.push(pointAt(tailStart+(progress-tailStart)*i/26));
  const path=points.map((p,i)=>`${i?'L':'M'}${p.x.toFixed(3)} ${p.y.toFixed(3)}`).join(' ');
  trail.setAttribute('d',path);halo.setAttribute('d',path);
  trail.style.strokeDashoffset=String(-(t-event.start)*24);
  gradient.setAttribute('x1',points[0].x);gradient.setAttribute('y1',points[0].y);
  gradient.setAttribute('x2',head.x);gradient.setAttribute('y2',head.y);
  const a=pointAt(Math.max(0,progress-.012)),b=pointAt(Math.min(1,progress+.012));
  const angle=Math.atan2(b.y-a.y,b.x-a.x)*180/Math.PI;
  plane.setAttribute('transform',`translate(${head.x} ${head.y}) rotate(${angle}) scale(${F.plane_size})`);
  const opacity=ease((t-event.start)/.12)*(1-ease((t-event.arrive-(F.landing_hold??0))/F.landing_fade));
  svg.style.display='block';svg.style.opacity=String(opacity*.94);
  const land=clamp((t-event.arrive+.025)/release);
  arrival.setAttribute('cx',head.x);arrival.setAttribute('cy',head.y);arrival.setAttribute('r',11+13*land);
  arrival.style.opacity=land>0?String(.6*Math.sin(Math.PI*land)):'0';
  svg.dataset.event=event.id;svg.dataset.target=event.target;svg.dataset.progress=String(progress);
 }
 const old=S.render;S.render=t=>{old(t);render(t)};
 window.CameraFlightGuide={render,root:svg,events,opening:F.opening};
 render(0);
})();
