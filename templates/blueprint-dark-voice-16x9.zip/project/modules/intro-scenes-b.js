(()=>{
 const R=IntroScenes.register;
 const line=(d,c='#00c8d6',w=2,extra='')=>`<path d="${d}" fill="none" stroke="${c}" stroke-width="${w}" stroke-linecap="round" ${extra}/>`;
 const dot=(x,y,r=5,c='#00c8d6')=>`<circle cx="${x}" cy="${y}" r="${r}" fill="${c}"/>`;
 const tx=(x,y,t,cl='')=>`<text x="${x}" y="${y}" class="${cl}">${t}</text>`;
 const rect=(x,y,w,h,fill='#162b35',stroke='#547885',rx=5)=>`<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="${rx}" fill="${fill}" stroke="${stroke}"/>`;
 const smallWorld=()=>`${tx(19,38,'内容','i-label')}${rect(18,50,88,6,'#00c8d6','none',0)}
   ${tx(170,42,'99','i-big')}${tx(244,42,'流程','i-small')}
   ${[28,73,117].map(x=>dot(x,121,11,'#1f5660')).join('')}${line('M39 121h23m22 0h22','#00c8d6',2)}
   ${rect(170,98,133,53)}${line('M186 124h100','#759ca9',4)}${dot(231,124,7)}
   ${line('M111 42Q137 42 137 79v42h22','#577f8b',2)}`;
 R('viewfinder',{
  build:H=>H.head('这张大画布，怎样变成视频？','内容在画布上','通过镜头取景','question','lens',{firstSize:51,secondSize:53})+
   H.art(`${rect(0,0,345,211,'none','#446876',1)}<g transform="translate(3 23)">${smallWorld()}</g>
    <g class="finder-window i-lens-frame"><rect x="7" y="29" width="140" height="129" rx="1" fill="#00c8d60a" stroke="#00e8ef" stroke-width="3"/>
    <rect class="lens-sweep" x="7" y="29" width="140" height="129" rx="1" fill="none" stroke="#edffff" stroke-width="3.5"/>
    ${line('M7 52V29h23m94 0h23v23M7 135v23h23m94 0h23v-23','#bcffff',4)}</g>
    ${line('M361 98h28m-8-7 8 7-8 7','#7398a6',2)}
    ${rect(407,0,157,211,'#e5eadf','#8eacb1',9)}
    <text x="425" y="55" style="fill:#17404c;font-size:28px;font-weight:850">视频</text>
    <text x="425" y="98" style="fill:#008b99;font-size:26px;font-weight:850">取景窗口</text>
    ${rect(424,119,121,63,'#19404b','none',1)}${line('M437 143h83m-83 18h56','#00c8d6',5)}
    ${tx(9,205,'画布 · 持续存在','i-small')}`)+H.foot('视频，是镜头此刻看到的一部分。'),
  render:C=>{const q=C.q('lens',1.1);C.move('.finder-window',151*q,0);C.one('.finder-window').style.opacity=String(.35+.65*q)}
 });
 R('follow-focus',{
  build:H=>H.head('说到哪里，镜头就去哪里','移动 · 放大','让这里动起来','speak','animate',{firstSize:56,secondSize:53})+
   H.art(`${rect(0,0,348,210,'#10222c','#456879',1)}
    <g transform="translate(0 19)">${smallWorld()}</g>
    <rect class="follow-window i-lens-frame" x="8" y="33" width="140" height="142" fill="#00c8d60c" stroke="#00e8ef" stroke-width="3"/>
    ${line('M362 101h28m-9-7 9 7-9 7','#7698a4',2)}
    <g class="zoom-preview" transform="translate(409 21)">${rect(0,0,155,167,'#142d38','#00c8d6')}${tx(15,34,'当前焦点','i-small')}
    <path class="focus-chart" d="M15 137 41 124 65 129 91 94 122 79 141 51" fill="none" stroke="#00c8d6" stroke-width="4"/>
    ${line('M15 148h126','#6d8c9b',1)}</g>`)+H.foot('镜头负责突出位置，组件负责解释过程。'),
  render:C=>{C.one('.follow-window').setAttribute('x',8+155*C.q('move',.9));const z=C.q('zoom',.8);C.one('.follow-window').setAttribute('width',140-20*z);C.one('.follow-window').setAttribute('height',142-48*z);C.draw('.focus-chart',C.q('animate',1.6));C.one('.zoom-preview').style.opacity=String(.4+.6*z)}
 });
 R('numbers-flow',{
  build:H=>H.head('动画，表达正在发生的过程','数字逐步增长','流程依次推进','number','flow',{firstSize:54,secondSize:54})+
   H.art(`${tx(2,101,'0','i-number count-value')}${tx(8,154,'示例数值 / 0 → 100','i-small')}
    ${line('M275 12v187','#466574',1)}
    ${[0,1,2].map((i)=>`<g class="process-node n-${i}">${dot(326+i*99,74,27,'#183d49')}${tx(318+i*99,82,i+1,'i-label')}${tx(307+i*99,132,['输入','处理','完成'][i],'i-small')}</g>`).join('')}
    ${line('M354 74h43m56 0h43','#00c8d6',3,'class="node-route"')}
    ${rect(5,177,236,10,'#243e49','none',2)}<rect class="count-meter" x="5" y="177" width="0" height="10" fill="#00c8d6" rx="2"/>`)+H.foot('动画有起点、有变化，也有明确的完成状态。'),
  render:C=>{const q=C.q('count',1.35);C.one('.count-value').textContent=Math.round(q*100);C.one('.count-meter').setAttribute('width',q*236);const f=C.q('advance',1.15);C.draw('.node-route',f);C.all('.process-node').forEach((n,i)=>{const active=f>i*.36;n.querySelector('circle').setAttribute('fill',active?'#00a9b8':'#183d49');n.style.transform=`translateY(${active?-3*Math.sin(Math.min(1,f*3-i)*Math.PI):0}px)`})}
 });
 R('slider-demo',{
  build:H=>H.head('操作和结果，连在一起','拖动滑块','结果跟着变化','operation','response',{firstSize:59,secondSize:54})+
   H.art(`${tx(0,28,'文字大小','i-small')}${tx(185,28,'24','i-label slider-value')}
    ${line('M12 83h232','#4c7280',7)}<path class="slider-fill" d="M12 83H12" stroke="#00c8d6" stroke-width="7" stroke-linecap="round"/>
    <g class="slider-knob">${dot(12,83,14,'#00e1ed')}${dot(12,83,5,'#122b35')}</g>
    ${tx(3,127,'小','i-small')}${tx(228,127,'大','i-small')}
    ${line('M260 83h32m-10-7 10 7-10 7','#668f9d',2)}
    ${rect(318,0,246,193,'#e7eadd','#82a4aa')}
    <text class="slider-result" x="441" y="111" text-anchor="middle" style="fill:#008c9a;font-weight:900;font-size:28px">重点</text>
    <text x="332" y="174" style="fill:#4a6f79;font-size:16px">预览随操作实时变化</text>
    ${tx(1,200,'参数变化 → 画面响应','i-small')}`)+H.foot('不只让组件入场，还让组件真正工作。'),
  render:C=>{const q=C.q('drag',1.4),x=q*220;C.move('.slider-knob',x,0);C.one('.slider-fill').setAttribute('d',`M12 83H${12+x}`);C.one('.slider-value').textContent=Math.round(24+40*q);C.one('.slider-result').style.fontSize=24+40*q+'px'}
 });
 const contextContents=(x,label,value)=>`<g transform="translate(${x} 30)">${rect(0,0,168,162,'#162d37','#567a88')}${tx(14,31,label,'i-small')}${tx(14,91,value,'i-big')}${rect(14,115,128,6,'#00c8d6','none',1)}${rect(14,133,90,5,'#789ca9','none',1)}</g>`;
 R('context-focus',{
  build:H=>H.head('内容还在，只是焦点不同','周围内容保留','让注意力集中','context','focus',{firstSize:52,secondSize:53})+
   H.art(`<defs><filter id="${H.uid('blur')}"><feGaussianBlur stdDeviation="0"/></filter></defs>
    <g class="context-side" filter="url(#${H.uid('blur')})">${contextContents(0,'上一个组件','内容 A')}${contextContents(396,'下一个组件','内容 C')}</g>
    <g class="context-main">${contextContents(198,'当前正在讲解','重点 B')}</g>
    <rect class="context-focus-ring" x="197" y="29" width="170" height="164" rx="6" fill="none" stroke="#00e4ec" stroke-width="3"/>`)+H.foot('虚化与降亮度，不会删除旁边的内容。'),
  render:C=>{const b=C.q('blur',1);C.one('feGaussianBlur').setAttribute('stdDeviation',4*b);C.one('.context-side').style.opacity=String(1-.7*C.q('dim',.8));C.one('.context-focus-ring').style.opacity=String(C.q('focus',.6));C.one('.context-main').style.filter=`brightness(${.75+.25*C.q('focus',.7)})`}
 });
 R('focus-handoff',{
  build:H=>H.head('不是换掉内容，而是移动镜头','讲到下一段','焦点顺着画布走','next','move',{firstSize:54,secondSize:48})+
   H.art(`<defs><clipPath id="${H.uid('crop')}"><rect width="568" height="133"/></clipPath></defs>
    ${rect(0,0,568,133,'#10222c','#486a79',1)}
    <g clip-path="url(#${H.uid('crop')})">${[0,1,2,3].map((i)=>`<g transform="translate(${18+i*148} 15)">${rect(0,0,128,100,'#1a3541','#5a808e')}${tx(12,28,'组件 '+String.fromCharCode(65+i),'i-small')}${tx(12,73,['标题','数字','流程','操作'][i],'i-big')}</g>`).join('')}
    <rect class="handoff-window" x="10" y="7" width="145" height="117" fill="#00d5dc0c" stroke="#00e3ea" stroke-width="3"/></g>
    ${tx(0,181,'画布','i-label')}${tx(69,181,'组织内容','i-small')}
    ${tx(318,181,'镜头','i-label')}${tx(387,181,'决定看哪里','i-small')}
    ${line('M1 202h205M318 202h244','#00c8d6',2,'class="handoff-rule"')}`)+H.foot('一张画布，连续取景，讲解有清楚的路线。'),
  render:C=>{C.one('.handoff-window').setAttribute('x',10+296*C.q('move',1.4));C.all('.handoff-rule').forEach((n,i)=>C.draw(i===0?'.handoff-rule:first-of-type':'.handoff-rule:last-of-type',C.q(i?'lens':'canvas',.65)))}
 });
 R('aspect-switch',{
  build:H=>H.head('内容相同，取景与排版可以调整','横屏，还是竖屏？','镜头都能适配','window','adjust',{firstSize:48,secondSize:52})+
   H.art(`${rect(0,0,326,210,'#10212b','#476a79',1)}
    <g class="aspect-world" transform="translate(0 17)">${smallWorld()}</g>
    <rect class="aspect-crop i-lens-frame" x="18" y="34" width="284" height="160" fill="#00c8d609" stroke="#00e8ef" stroke-width="3"/>
    ${tx(17,24,'大画布','i-small')}
    <g class="aspect-wide">${rect(366,24,198,112,'#e6e9de','#91a8b0',4)}
     <text x="378" y="56" style="fill:#18454e;font-size:24px;font-weight:850">横屏 16:9</text>
     ${rect(378,69,80,8,'#008d9b','none',1)}${rect(469,69,80,8,'#72959e','none',1)}</g>
    <g class="aspect-tall">${rect(418,6,108,192,'#e6e9de','#8da7af',6)}
     <text x="432" y="46" style="fill:#18454e;font-size:20px;font-weight:850">竖屏</text>
     <text x="432" y="81" style="fill:#008d9b;font-size:22px;font-weight:850">9:16</text>
     ${rect(431,96,81,8,'#008d9b','none',1)}${rect(431,118,65,6,'#71969e','none',1)}${rect(431,151,81,6,'#71969e','none',1)}</g>
    ${tx(366,219,'取景 · 字号 · 重排','i-small')}`)+H.foot('比例改变时，重新检查构图与可读性。'),
  render:C=>{const q=C.q('portrait',.8),crop=C.one('.aspect-crop');crop.setAttribute('x',18+99*q);crop.setAttribute('width',284-194*q);crop.setAttribute('y',34-13*q);crop.setAttribute('height',160+28*q);C.one('.aspect-wide').style.opacity=String(1-q);C.one('.aspect-tall').style.opacity=String(q)}
 });
 const themeExample=(x,light)=>`<g transform="translate(${x} 0)">${rect(0,0,270,208,light?'#f0eee5':'#122734',light?'#b8c5c3':'#567a88')}
    <text x="16" y="30" style="fill:${light?'#1c424a':'#edf8fa'};font-size:27px;font-weight:850">同一份内容</text>
    <text x="16" y="76" style="fill:${light?'#007e8c':'#00c8d6'};font-size:32px;font-weight:850">不同的表达</text>
    ${line('M18 153 61 134 99 144 141 109 188 115 243 91',light?'#008a99':'#00c8d6',3)}
    <text x="16" y="192" style="fill:${light?'#50737b':'#97b8c6'};font-size:18px">${light?'简洁白板风':'深色科技风'}</text></g>`;
 R('theme-switch',{
  build:H=>H.head('画面的风格，同样可以变化','深色科技风','或简洁白板风','dark','light',{firstSize:54,secondSize:54})+
    H.art(`${themeExample(0,false)}${themeExample(294,true)}
     <rect class="theme-select" x="-2" y="-2" width="274" height="212" fill="none" stroke="#00e1ea" stroke-width="3"/>`)+H.foot('主题可以更换，音频与动画的对应关系不变。'),
  render:C=>{C.one('.theme-select').setAttribute('x',-2+294*C.q('light',.65));C.one('.theme-select').style.opacity=String(.3+.7*C.q('dark',.5))}
 });
 R('recap',{
  build:H=>H.over('这就是，它的基本思路')+
   `<div style="position:absolute;left:16px;top:42px;font:900 92px/1 'Segoe UI',sans-serif;letter-spacing:-4px">${H.word('XYCut','brand','i-accent')}</div>
    <h2 style="position:absolute;left:19px;top:140px;font-size:39px;font-weight:850">${H.word('画布视频 Skill','name')}</h2>
    ${H.on('name','xycut-canvas-video-skill','recap-full-name')}`+
    H.art(`${[0,1,2,3].map((i)=>`<g class="recap-step step-${i}" transform="translate(${i*148} 15)">${dot(32,29,24,'#1b3c48')}${tx(24,37,i+1,'i-label')}${tx(0,88,['音频时间','AI设计','画布镜头','组织成片'][i],'i-label')}${tx(0,119,['建立依据','设计画面','聚焦重点','连续讲解'][i],'i-small')}</g>`).join('')}
    ${line('M57 44h91m57 0h91m57 0h91','#00c8d6',2,'class="recap-route"')}`,568,150,16,244)+
    H.foot('时间是依据，AI做设计，画布和镜头组织讲解。'),
  render:C=>{const keys=['basis','design','camera','video'];C.all('.recap-step').forEach((n,i)=>{const q=C.q(keys[i],.5);n.querySelector('circle').setAttribute('fill',q>.1?'#008f9e':'#1b3c48');n.style.opacity=String(.35+.65*q)});C.draw('.recap-route',C.q('design',3.6))}
 });
 R('make-your-own',{
  build:H=>H.head('现在，换成你自己的内容','自己的文案和配音','做成自己的视频','input','try',{firstSize:47,secondSize:49})+
    H.art(`${rect(0,0,149,146,'#e4e7dd','#83a4a9')}
     <text x="13" y="32" style="fill:#17444d;font-size:24px;font-weight:850">你的文案</text>
     ${line('M13 55h121m-121 16h97m-97 16h108','#6a939f',4)}
     <g transform="translate(12 103)">${H.waveBars(118.96,123.6,122,28,27)}</g>
     ${line('M164 73h30m-9-7 9 7-9 7','#7295a4',2)}
     ${[0,1,2].map(i=>`<g class="make-stage make-${i}" transform="translate(${210+i*122} 11)">${dot(34,36,30,'#173c49')}${tx(26,44,i+1,'i-label')}${tx(9,104,['设计','组装','渲染'][i],'i-label')}</g>`).join('')}
     ${line('M276 47h21m99 0h21','#00c8d6',3)}
     <g class="make-complete">${rect(209,161,355,49,'#0c3e48','#00c8d6',4)}${tx(225,193,'✓  完全由代码制作视频','i-label')}</g>`)+
    H.on('independent','不再需要经过剪映','closing-note')+H.foot('xycut-canvas-video-skill · 画布视频 Skill'),
  render:C=>{['code','assemble','render'].forEach((key,i)=>{const q=C.q(key,.35);C.one('.make-'+i+' circle').setAttribute('fill',q>.1?'#0099a9':'#173c49');C.one('.make-'+i).style.opacity=String(.35+.65*q)});C.one('.make-complete').style.opacity=String(C.q('render',.5))}
 });
 const style=document.createElement('style');style.textContent=`
 .intro-make-your-own .i-art{top:174px!important;height:195px!important}.intro-make-your-own .i-foot{top:397px;font-size:16px}.closing-note{position:absolute;left:16px;top:370px;color:#ffce86;font-size:20px;font-weight:750}.intro-recap .i-foot{font-size:16px}.recap-full-name{position:absolute;left:20px;top:196px;font:23px/1.3 Consolas,'Segoe UI',sans-serif;letter-spacing:-.6px;color:#98c1cc}`;
 document.head.append(style);
})();
