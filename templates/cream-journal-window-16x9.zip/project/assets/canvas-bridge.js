(()=>{
const content={
'opening-question':`<div class="bridge"><h2>越想做好</h2><strong data-time="2.49">越难开始？</strong><div class="bridge-line" data-time="1.13"></div></div>`,
'example-start':`<div class="bridge"><h2>今天要做完</h2><strong data-time="5.41">一条视频</strong><p data-time="7.89">却不知道<br><em>从哪下手</em></p></div>`,
'three-intro':`<div class="bridge"><h2>试着把它缩小</h2><strong data-time="18.33">先做三步</strong><div class="three-numbers" data-time="18.33">01 → 02 → 03</div></div>`,
'first-version':`<div class="bridge"><h2>有了第一版</h2><strong data-time="41.16">问题就具体了</strong><p data-time="42.48">不再对着<br><em>空白文档发愁</em></p></div>`,
'keep-breaking':`<div class="bridge"><h2>还是不想动？</h2><strong data-time="48.68">就继续拆</strong><div class="bridge-line" data-time="48.68"></div></div>`,
'closing':`<div class="bridge"><h2 data-time="53.92">先让事情有个开头</h2><p data-time="55.12">再一点点把它做好</p><div class="final-action" data-time="59.2"><b>五分钟</b><strong data-time="60.12">先做一个小动作</strong></div></div>`};
window.CanvasBridge={html:content,render(t,{all=false}={}){for(const el of document.querySelectorAll('#world [data-time]')){const u=all?1:Math.max(0,Math.min(1,(t-Number(el.dataset.time))/.4));el.style.opacity=u;el.style.transform=el.classList.contains('bridge-line')?`scaleX(${u})`:`translateY(${(1-u)*20}px)`}}};})();