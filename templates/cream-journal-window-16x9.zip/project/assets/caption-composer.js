(() => {
  'use strict';
  const P = window.CANVAS_PLAN;
  const track = window.CanvasSubtitles;
  const E = window.CanvasExplorer;
  const stage = document.querySelector('#stage');
  const voice = document.querySelector('#voice');
  const selector = document.querySelector('#subtitle-mode');
  const originalVoice = document.querySelector('#voice-only');
  if (!P || !stage || !voice || !track || !E) throw Error('Caption composer must load after the scene and subtitle track.');
  const exporting = new URLSearchParams(location.search).get('render') === '1';
  const clamp = n => Math.max(0, Math.min(1, n));
  const smooth = n => { n = clamp(n); return n * n * (3 - 2 * n); };
  const ease = n => 1 - Math.pow(1 - clamp(n), 3);
  const finite = n => typeof n === 'number' && Number.isFinite(n);
  const modes = new Set(['emphasis', 'normal', 'off']);
  const layouts = new Set(['comparison', 'stack', 'stagger', 'poster']);
  const lineIds = new Set((window.FINAL_TIMELINE?.lines || []).map(line => line.line_id));
  const groups = JSON.parse(JSON.stringify(P.caption_groups || [])).sort((a, b) => a.start - b.start);
  const nodes = new Map();
  const root = document.createElement('div');
  root.id = 'caption-composer';
  root.setAttribute('aria-hidden', 'true');
  root.style.setProperty('--caption-accent', P.theme?.accent || '#b54432');
  root.style.setProperty('--caption-paper', '#fffaf0');
  root.style.setProperty('--caption-ink', P.caption_settings?.marker_color || '#f5d38c');
  root.hidden = true;
  stage.append(root);
  const legacyHeadline = document.querySelector('#headline');
  if (legacyHeadline) {
    legacyHeadline.hidden = true;
    legacyHeadline.style.setProperty('display', 'none', 'important');
    legacyHeadline.setAttribute('aria-hidden', 'true');
  }
  if (selector) {
    const automatic = [...selector.options].find(option => option.value === 'emphasis');
    if (automatic) automatic.textContent = '自动字幕包装';
  }
  let lastTime = 0;
  let lastOptions = { browsing: false, cover: false };
  let state = { mode: track.getMode(), groupId: null, visibleRows: 0, suppressesNormal: false, sourceLineIds: [] };
  let generation = 0;
  let switchQueue = Promise.resolve();
  let pendingResume = null;

  function report(error) {
    const status = document.querySelector('#review-status');
    if (status) status.textContent = error?.message || String(error);
    console.error(error);
  }

  function keywordRanges(text, words) {
    const result = [];
    for (const candidate of words || []) {
      const word = String(candidate);
      if (!word) continue;
      let offset = 0;
      while (offset < text.length) {
        const start = text.indexOf(word, offset);
        if (start < 0) break;
        result.push({ start, end: start + word.length });
        offset = start + word.length;
      }
    }
    return result;
  }

  function fillText(node, text, accentWords, markerWords) {
    const accents = keywordRanges(text, accentWords);
    const markers = keywordRanges(text, markerWords);
    const edges = [...new Set([0, text.length, ...accents.flatMap(r => [r.start, r.end]), ...markers.flatMap(r => [r.start, r.end])])].sort((a, b) => a - b);
    for (let index = 0; index < edges.length - 1; index++) {
      const start = edges[index], end = edges[index + 1];
      const span = document.createElement('span');
      span.textContent = text.slice(start, end);
      if (accents.some(r => start < r.end && end > r.start)) span.classList.add('caption-accent');
      if (markers.some(r => start < r.end && end > r.start)) span.classList.add('caption-marked');
      node.append(span);
    }
  }

  const usedIds = new Set();
  for (const [index, group] of groups.entries()) {
    if (!group.id || usedIds.has(group.id)) throw Error('Caption group ID must be unique: ' + group.id);
    usedIds.add(group.id);
    if (!finite(group.start) || !finite(group.end) || group.start < 0 || group.end <= group.start || group.end > P.content_duration + .001) throw Error('Invalid caption group interval: ' + group.id);
    if (index && group.start < groups[index - 1].end) throw Error('Caption groups must not overlap: ' + group.id);
    if (!Array.isArray(group.rows) || !group.rows.length || group.rows.length > 3) throw Error('Caption groups require one to three rows: ' + group.id);
    if ((group.source_line_ids || []).some(id => !lineIds.has(id))) throw Error('Unknown ASR line in caption group: ' + group.id);
    const section = document.createElement('section');
    const layout = layouts.has(group.layout) ? group.layout : 'stack';
    section.className = 'caption-composer-group layout-' + layout;
    section.dataset.groupId = group.id;
    section.dataset.sourceLineIds = (group.source_line_ids || []).join(' ');
    const top = finite(group.top) ? group.top : 1140;
    const left = finite(group.left) ? group.left : 110;
    const right = finite(group.right) ? group.right : 110;
    const maxHeight = finite(group.max_height) ? Math.min(400, group.max_height) : 340;
    if (top < 960 || top + maxHeight > 1525 || left < 80 || right < 80 || left + right >= P.output.width) throw Error('Caption group exceeds the presenter safe area: ' + group.id);
    Object.assign(section.style, { top: top + 'px', left: left + 'px', right: right + 'px' });
    const rows = [];
    for (const [rowIndex, row] of group.rows.entries()) {
      if (typeof row.text !== 'string' || !row.text.trim() || !finite(row.at) || row.at < group.start || row.at >= group.end) throw Error('Invalid caption row: ' + group.id + '/' + rowIndex);
      if (rowIndex && row.at < group.rows[rowIndex - 1].at) throw Error('Caption rows must follow speech order: ' + group.id);
      const element = document.createElement('div');
      element.className = 'caption-composer-row';
      element.dataset.at = String(row.at);
      const align = ['left', 'center', 'right'].includes(row.align) ? row.align : (layout === 'stagger' || layout === 'comparison' ? ['left', 'center', 'right'][rowIndex] : 'center');
      element.style.textAlign = align;
      const inner = document.createElement('div');
      inner.className = 'caption-composer-row-inner';
      const size = finite(row.size) ? Math.max(44, Math.min(128, row.size)) : [64, 90, 100][rowIndex];
      inner.style.fontSize = size + 'px';
      inner.style.fontWeight = String(row.weight || 900);
      fillText(inner, row.text, row.accent_words, row.marker_words);
      let ripple = null;
      if (row.enter === 'stamp' || row.enter === 'pop') {
        ripple = document.createElement('i');
        ripple.className = 'caption-row-ripple';
        ripple.setAttribute('aria-hidden', 'true');
        element.append(ripple);
      }
      element.append(inner);
      section.append(element);
      rows.push({ config: row, element, inner, ripple, size, align, index: rowIndex });
    }
    section.hidden = true;
    root.append(section);
    nodes.set(group.id, { group, section, rows, maxHeight, fitted: false });
  }

  function fit(node) {
    const width = P.output.width - parseFloat(node.section.style.left) - parseFloat(node.section.style.right);
    for (const row of node.rows) {
      row.inner.style.fontSize = row.size + 'px';
      const used = row.inner.scrollWidth;
      if (used > width - 8) row.inner.style.fontSize = Math.max(36, Math.floor(row.size * (width - 8) / used)) + 'px';
    }
    let height = node.section.scrollHeight;
    if (height > node.maxHeight) {
      const factor = (node.maxHeight - 8) / height;
      for (const row of node.rows) row.inner.style.fontSize = Math.max(36, Math.floor(parseFloat(row.inner.style.fontSize) * factor)) + 'px';
      height = node.section.scrollHeight;
    }
    if (height > node.maxHeight + 2 || node.rows.some(row => row.inner.scrollWidth > width + 2)) throw Error('Caption composition cannot fit its safe area: ' + node.group.id);
    node.fitted = true;
  }

  function rowMotion(row, group, t) {
    const duration = finite(row.config.duration) ? Math.max(.1, row.config.duration) : .38;
    const u = clamp((t - row.config.at) / duration);
    const q = ease(u);
    const entered = smooth((t - row.config.at) / .11);
    let x = 0, y = (1 - q) * 28, scale = .98 + .02 * q, rotation = 0;
    if (row.config.enter === 'pop') { y = (1 - q) * 12; scale = .84 + .16 * q + .04 * Math.sin(Math.PI * u); }
    if (row.config.enter === 'slide') { x = (row.align === 'right' ? -1 : 1) * 34 * (1 - q); y = (1 - q) * 8; }
    if (row.config.enter === 'stamp') { y = 0; scale = 1.12 - .12 * q; rotation = -2.4 * (1 - q); }
    if (group.layout === 'stagger') rotation += [-1.4, .7, -.5][row.index];
    row.element.style.opacity = String(entered);
    row.element.style.visibility = t >= row.config.at ? 'visible' : 'hidden';
    row.element.dataset.visible = t >= row.config.at ? 'true' : 'false';
    row.inner.style.transform = `translate(${x}px,${y}px) rotate(${rotation}deg) scale(${scale})`;
    row.inner.style.setProperty('--mark-progress', String(ease((t - row.config.at - .06) / .34)));
    const sheenU = clamp((t - row.config.at - .12) / .62);
    row.inner.style.setProperty('--sheen-pos', (-30 + 160 * ease(sheenU)) + '%');
    row.inner.style.setProperty('--sheen-alpha', sheenU > 0 && sheenU < 1 ? String(Math.sin(Math.PI * sheenU)) : '0');
    if (row.ripple) {
      const ru = clamp((t - row.config.at - .04) / .65);
      row.ripple.style.opacity = ru > 0 && ru < 1 ? String(0.65 * (1 - ru)) : '0';
      row.ripple.style.transform = `translate(-50%,-50%) scale(${0.45 + 1.45 * ease(ru)})`;
    }
  }

  function render(t, options = {}) {
    if (!finite(t)) throw Error('Caption composer requires absolute body time');
    lastTime = t;
    lastOptions = { browsing: !!options.browsing, cover: !!options.cover };
    const mode = track.getMode();
    const blocked = lastOptions.browsing || lastOptions.cover;
    const active = !blocked && mode === 'emphasis' ? groups.find(group => t >= group.start && t < group.end) : null;
    const ownedTail = !blocked && mode === 'emphasis'
      ? groups.find(group => t >= group.end && (group.source_line_ids || []).includes(track.root.dataset.lineId))
      : null;
    const suppressesNormal = !!(active || ownedTail);
    root.hidden = !active;
    root.dataset.mode = mode;
    root.dataset.activeGroup = active?.id || '';
    if (legacyHeadline) legacyHeadline.hidden = true;
    track.root.style.display = blocked || mode === 'off' || suppressesNormal ? 'none' : 'block';
    track.root.style.visibility = blocked ? 'hidden' : 'visible';
    let visibleRows = 0;
    for (const node of nodes.values()) {
      const visible = node.group === active;
      node.section.hidden = !visible;
      if (!visible) continue;
      if (!node.fitted) fit(node);
      const fade = finite(node.group.exit_duration) ? Math.max(.04, node.group.exit_duration) : .14;
      node.section.style.opacity = String(1 - smooth((t - node.group.end + fade) / fade));
      node.section.style.transform = `translateY(${-8 * smooth((t - node.group.end + fade) / fade)}px)`;
      for (const row of node.rows) { rowMotion(row, node.group, t); if (t >= row.config.at) visibleRows++; }
    }
    state = { mode, groupId: active?.id || null, tailGroupId: ownedTail?.id || null, visibleRows, suppressesNormal, sourceLineIds: (active || ownedTail)?.source_line_ids || [] };
    return { ...state, sourceLineIds: [...state.sourceLineIds] };
  }

  function sourceForMode() {
    const profiles = P.caption_audio || {};
    if (originalVoice?.checked) return profiles.voice || 'assets/voice-aligned.wav';
    return profiles[track.getMode()] || profiles.emphasis || voice.getAttribute('src');
  }

  function loadTrack(source) {
    const absolute = new URL(source, document.baseURI).href;
    if (voice.src === absolute && voice.readyState >= 2) return Promise.resolve();
    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => { cleanup(); reject(Error('字幕试听音轨加载超时')); }, 12000);
      function cleanup() { clearTimeout(timeout); voice.removeEventListener('loadedmetadata', ready); voice.removeEventListener('loadeddata', ready); voice.removeEventListener('canplay', ready); voice.removeEventListener('error', failed); }
      function ready() { if (voice.readyState >= 2) { cleanup(); resolve(); } }
      function failed() { cleanup(); reject(Error('字幕试听音轨加载失败：' + source)); }
      voice.addEventListener('loadedmetadata', ready);
      voice.addEventListener('loadeddata', ready);
      voice.addEventListener('canplay', ready);
      voice.addEventListener('error', failed);
      voice.src = source;
      voice.load();
      ready();
    });
  }

  function syncAudio(options = {}) {
    const request = ++generation;
    const resume = typeof options.resume === 'boolean' ? options.resume : (pendingResume ?? !voice.paused);
    pendingResume = resume;
    E.pause();
    switchQueue = switchQueue.catch(() => {}).then(async () => {
      if (request !== generation) return;
      const source = sourceForMode();
      if (!source) throw Error('字幕试听音轨未配置');
      await loadTrack(source);
      if (request !== generation) return;
      const at = E.getTime();
      if (E.getMode() !== 'resource') await E.seek(at, { keepSegment: true });
      if (request !== generation) return;
      voice.currentTime = E.getTime() + E.getAudioOffset();
      render(E.getBodyTime(), { browsing: E.getMode() === 'resource', cover: E.getTime() < E.getLead() });
      if (resume && !exporting) await E.play();
      else E.pause();
      if (request === generation) pendingResume = null;
      return { source: voice.src, resumed: resume && !exporting };
    });
    return switchQueue.catch(error => { if (request === generation) pendingResume = null; report(error); throw error; });
  }

  async function setMode(value) {
    if (!modes.has(value)) throw Error('字幕模式无效：' + value);
    const wasPlaying = pendingResume ?? !voice.paused;
    if (selector) selector.value = value;
    await track.setMode(value);
    render(lastTime, lastOptions);
    return syncAudio({ resume: wasPlaying });
  }

  window.CaptionDirector = { root, render, setMode, syncAudio, getMode: () => track.getMode(), getState: () => ({ ...state, sourceLineIds: [...state.sourceLineIds] }), getAudioSource: sourceForMode, groups };
  const baseReady = window.READY;
  window.READY = Promise.resolve(baseReady).then(async () => {
    await document.fonts.ready;
    await syncAudio({ resume: false });
    render(E.getBodyTime(), { browsing: E.getMode() === 'resource', cover: E.getTime() < E.getLead() });
    return true;
  }).catch(error => { report(error); throw error; });
})();
