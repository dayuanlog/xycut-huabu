(() => {
  'use strict';
  const clamp = n => Math.max(0, Math.min(1, n));
  const ease = n => { n = clamp(n); return 1 - Math.pow(1 - n, 3); };
  const backOut = n => { n = clamp(n); const c1 = 1.6, c3 = c1 + 1; return 1 + c3 * Math.pow(n - 1, 3) + c1 * Math.pow(n - 1, 2); };

  const html = {
    // 1. Unboxed editorial opening: asymmetric typography + stuck 0% progress bar metaphor
    'opening-question': `
      <div class="canvas-unit u-opening">
        <div class="u-eyebrow"><span class="u-dot"></span>痛点拆解 · 01</div>
        <h2 class="open-l1">越想把一件事<em>做好</em></h2>
        <div class="open-punch-wrap">
          <strong class="open-l2 glint-target">越容易迟迟不开始</strong>
          <svg class="open-underline" viewBox="0 0 420 18" aria-hidden="true"><path pathLength="1" d="M4 11 Q210 2 416 12"/></svg>
          <i class="beat-ripple"></i>
        </div>
        <div class="stuck-meter">
          <div class="meter-head"><span>心理预期</span><b>100% 完美</b></div>
          <div class="meter-track"><div class="meter-fill high-fill"></div></div>
          <div class="meter-head" style="margin-top:14px"><span>实际进度</span><b class="accent-num">0% 未开始</b></div>
          <div class="meter-track"><div class="meter-fill zero-fill"></div><i class="meter-pulse"></i></div>
        </div>
      </div>`,

    // 2. Real mini video-editor UI metaphor (stuck at 00:00)
    'example-start': `
      <div class="canvas-unit u-example">
        <div class="step-head"><span class="step-num">例</span><h2>今天要做完<em>一条视频</em></h2></div>
        <div class="editor-mock">
          <div class="editor-bar"><i></i><i></i><i></i><span>新项目.proj</span><em>00:00</em></div>
          <div class="editor-tracks">
            <div class="e-track"><span>文案</span><div class="e-empty">空白草稿<i class="pen-cursor blink-cursor"></i></div></div>
            <div class="e-track"><span>剪辑</span><div class="e-empty dashed">等待素材…</div></div>
          </div>
          <div class="playhead-pin"></div>
        </div>
        <div class="hesitate-line">
          <span>坐到电脑前，却不知道</span><strong class="glint-target">从哪下手</strong>
          <i class="beat-ripple"></i>
        </div>
      </div>`,

    // 3. Structured branching task web (tight, zero wasted margin)
    'task-chain': `
      <div class="canvas-unit task-board compact-task">
        <div class="task-head">
          <span class="step-badge">藏着一整串任务</span>
          <h2>做完<em>一条视频</em></h2>
        </div>
        <svg class="task-links" viewBox="0 0 600 480" aria-hidden="true">
          <path data-branch="0" pathLength="1" d="M168 118 C168 156, 108 156, 108 186"/>
          <path data-branch="1" pathLength="1" d="M214 118 C248 156, 336 156, 352 186"/>
          <path data-branch="2" pathLength="1" d="M108 248 C108 274, 178 274, 184 296"/>
          <path data-branch="3" pathLength="1" d="M352 248 C362 274, 434 274, 442 296"/>
          <path data-branch="4" pathLength="1" d="M184 358 C176 378, 134 382, 126 402"/>
          <path data-branch="5" pathLength="1" d="M442 358 C436 378, 388 382, 380 402"/>
        </svg>
        <div class="task-nodes">
          <div class="task-node" data-task-index="0" style="left:36px;top:186px"><b>01</b><span>选题</span><i class="node-ripple"></i></div>
          <div class="task-node is-accent" data-task-index="1" style="left:278px;top:186px"><b>02</b><span>写稿</span><i class="node-ripple"></i></div>
          <div class="task-node" data-task-index="2" style="left:112px;top:296px"><b>03</b><span>录音</span><i class="node-ripple"></i></div>
          <div class="task-node is-accent" data-task-index="3" style="left:368px;top:296px"><b>04</b><span>剪辑</span><i class="node-ripple"></i></div>
          <div class="task-node" data-task-index="4" style="left:54px;top:402px"><b>05</b><span>字幕</span><i class="node-ripple"></i></div>
          <div class="task-node is-accent" data-task-index="5" style="left:308px;top:402px"><b>06</b><span>封面</span><i class="node-ripple"></i></div>
        </div>
      </div>`,

    // 4. Unboxed 3-step sightline roadmap with animated connecting spine
    'three-intro': `
      <div class="canvas-unit u-roadmap">
        <div class="u-eyebrow"><span class="u-dot"></span>破局方法</div>
        <div class="roadmap-title">试着把它缩小，<strong class="glint-target">先做三步</strong><i class="beat-ripple"></i></div>
        <div class="roadmap-track">
          <svg class="roadmap-spine" viewBox="0 0 560 40" aria-hidden="true"><path pathLength="1" d="M60 20 L500 20"/></svg>
          <div class="rm-node sp1"><em>01</em><strong>写观点</strong><small>只写一句</small></div>
          <div class="rm-node sp2"><em>02</em><strong>找例子</strong><small>听得明白</small></div>
          <div class="rm-node sp3"><em>03</em><strong>第一版</strong><small>先录出来</small></div>
        </div>
      </div>`,

    // 5. Step 01: lined manuscript strip + typewriter + hand-drawn oval
    'step-one': `
      <div class="canvas-unit step-one">
        <div class="step-head"><span class="step-num">01</span><h2>只写<em>一个观点</em></h2></div>
        <div class="note-slip">
          <div class="note-slip-label">核心句 · 先不纠结开头</div>
          <div class="type-line"><span class="typed-chars" data-type="一句话" data-start="20.25" data-end="21.05"></span><i class="pen-cursor"></i></div>
          <span class="note-rule"></span>
        </div>
        <div class="remember-block">
          <p>这条视频，最想让别人</p>
          <div class="circle-emphasis">
            <strong class="glint-target">记住什么？</strong>
            <svg class="hand-oval" viewBox="0 0 320 112" aria-hidden="true">
              <path pathLength="1" d="M24 58 C20 18, 128 8, 224 14 C298 18, 314 54, 294 84 C272 108, 134 108, 52 94 C14 86, 10 56, 36 44"/>
            </svg>
            <i class="beat-ripple"></i>
          </div>
        </div>
      </div>`,

    // 6. Step 02: A/B split comparison + converging sightline
    'step-two': `
      <div class="canvas-unit step-two">
        <div class="step-head"><span class="step-num">02</span><h2>找一个<em>具体例子</em></h2></div>
        <div class="example-grid">
          <div class="example-card own">
            <span class="card-tag">方式 A</span>
            <strong>自己的经历</strong>
            <small>真实踩坑或体会</small>
            <svg viewBox="0 0 220 20" aria-hidden="true"><path pathLength="1" d="M6 12 Q110 3 214 13"/></svg>
          </div>
          <span class="example-or">或</span>
          <div class="example-card compare">
            <span class="card-tag">方式 B</span>
            <strong>两种做法对比</strong>
            <small>好与坏一眼看懂</small>
            <svg viewBox="0 0 220 20" aria-hidden="true"><path pathLength="1" d="M6 13 Q110 18 214 6"/></svg>
          </div>
        </div>
        <svg class="converge-lines" viewBox="0 0 560 52" aria-hidden="true">
          <path pathLength="1" d="M130 4 C130 34, 260 22, 280 48 M430 4 C430 34, 300 22, 280 48"/>
        </svg>
        <div class="clear-result">
          <span class="glint-target">让别人<em>听得明白</em></span>
          <i class="beat-ripple"></i>
        </div>
      </div>`,

    // 7. Step 03: pill merge + live waveform + seal stamp
    'step-three': `
      <div class="canvas-unit step-three">
        <div class="step-head"><span class="step-num">03</span><h2>录成<em>第一版</em></h2></div>
        <div class="combine-row">
          <span class="paper-pill pill-view">观点</span>
          <b class="combine-plus">＋</b>
          <span class="paper-pill pill-example">例子</span>
        </div>
        <div class="record-flow">
          <svg class="record-arrow" viewBox="0 0 120 74" aria-hidden="true">
            <path pathLength="1" d="M60 4 C64 28, 60 44, 60 64 M44 48 L60 66 L76 48"/>
          </svg>
          <div class="record-wave-box">
            <div class="record-wave">${Array.from({ length: 19 }, (_, i) => `<i data-wave-index="${i}"></i>`).join('')}</div>
          </div>
          <div class="stamp-wrap">
            <div class="vermilion-stamp">
              <span>初稿完成</span>
              <strong>第一版</strong>
            </div>
            <i class="beat-ripple"></i>
          </div>
        </div>
      </div>`,

    // 8. Unboxed state-shift diagram (blank fog -> concrete target)
    'first-version': `
      <div class="canvas-unit first-version-card">
        <div class="step-head"><span class="step-num">转</span><h2>有了<em>第一版</em></h2></div>
        <div class="fv-compare">
          <div class="fv-before"><span>对着空白发愁</span></div>
          <i class="fv-arrow">→</i>
          <div class="fv-after"><strong class="glint-target">问题就具体了</strong><i class="beat-ripple"></i></div>
        </div>
        <div class="fv-checklist">
          <span class="fv-chip">✓ 看得见哪里卡壳</span>
          <span class="fv-chip">✓ 知道下一步怎么改</span>
        </div>
      </div>`,

    // 9. Manuscript proofreading sheet
    'revision': `
      <div class="canvas-unit revision">
        <div class="step-head"><span class="step-num">改</span><h2>具体修改<em>两件事</em></h2></div>
        <div class="proof-sheet">
          <div class="proof-row proof-short">
            <span class="proof-old">这句话太长要缩短<svg class="strike-svg" viewBox="0 0 320 24" preserveAspectRatio="none" aria-hidden="true"><path pathLength="1" d="M2 13 Q160 8 318 14"/></svg></span>
            <span class="proof-arrow">→</span>
            <strong class="proof-new glint-target">缩短这句话</strong>
          </div>
          <div class="proof-row proof-expand">
            <span class="proof-base">例子</span>
            <span class="proof-caret">
              <svg viewBox="0 0 42 36" aria-hidden="true"><path pathLength="1" d="M6 30 L21 6 L36 30"/></svg>
            </span>
            <strong class="proof-insert">补充一个例子<svg class="insert-line" viewBox="0 0 260 18" preserveAspectRatio="none" aria-hidden="true"><path pathLength="1" d="M4 11 Q130 4 256 12"/></svg></strong>
            <i class="beat-ripple"></i>
          </div>
        </div>
      </div>`,

    // 10. Visual block-splitting metaphor
    'keep-breaking': `
      <div class="canvas-unit keep-breaking-card">
        <div class="step-head"><span class="step-num">拆</span><h2>还是<em>不想动？</em></h2></div>
        <div class="split-visual">
          <div class="split-half left-half">大任务</div>
          <span class="split-cut"></span>
          <div class="split-half right-half">再拆半</div>
        </div>
        <div class="kb-punch"><strong class="glint-target">就继续拆小</strong><i class="beat-ripple"></i></div>
      </div>`,

    // 11. Size-reduction bar comparison
    'make-smaller': `
      <div class="canvas-unit make-smaller">
        <div class="step-head"><span class="step-num">小</span><h2>把动作<em>降到最轻</em></h2></div>
        <div class="shrink-list">
          <div class="shrink-row writing">
            <div class="big-block"><span>写一段</span></div>
            <i class="shrink-arrow">→</i>
            <div class="mini-block">
              <strong class="glint-target">写一句</strong>
              <i class="beat-ripple"></i>
            </div>
          </div>
          <div class="shrink-row recording">
            <div class="big-block"><span>录完整条</span></div>
            <i class="shrink-arrow">→</i>
            <div class="mini-block">
              <strong class="glint-target">录个开头</strong>
              <i class="beat-ripple"></i>
            </div>
          </div>
        </div>
      </div>`,

    // 12. Editorial closing CTA (leaves clean space on top-left for larger presenter portrait!)
    'closing': `
      <div class="canvas-unit closing-card">
        <div class="closing-motto">
          <p class="cm-1">先让事情有个<em>开头</em></p>
          <p class="cm-2">再一点点把它做好</p>
        </div>
        <div class="closing-cta">
          <div class="vermilion-stamp cta-stamp">
            <span>接下来的 5 分钟</span>
            <strong class="glint-target">先做一个小动作</strong>
          </div>
          <i class="beat-ripple"></i>
        </div>
      </div>`
  };

  function setRipple(el, t, at, duration = 0.65, all = false) {
    if (!el) return;
    if (all || t < at || t > at + duration) {
      el.style.opacity = '0';
      el.style.transform = 'translate(-50%,-50%) scale(.4)';
      return;
    }
    const u = clamp((t - at) / duration);
    el.style.opacity = String(0.75 * (1 - u));
    el.style.transform = `translate(-50%,-50%) scale(${0.45 + 1.45 * ease(u)})`;
  }

  function setGlint(el, t, at, duration = 0.72, all = false) {
    if (!el) return;
    if (all || t < at || t > at + duration) {
      el.style.setProperty('--glint-pos', '-30%');
      el.style.setProperty('--glint-alpha', '0');
      return;
    }
    const u = clamp((t - at) / duration);
    el.style.setProperty('--glint-pos', (-30 + 160 * ease(u)) + '%');
    el.style.setProperty('--glint-alpha', String(Math.sin(Math.PI * u)));
  }

  function setDraw(path, u) {
    if (!path) return;
    path.style.strokeDasharray = '1';
    path.style.strokeDashoffset = String(1 - clamp(u));
  }

  function render(t, { all = false } = {}) {
    const within = (at, dur = 0.34) => all ? 1 : ease((t - at) / dur);
    const show = (el, at, dx = 0, dy = 18, dur = 0.34, floor = 0) => {
      if (!el) return;
      const u = within(at, dur);
      el.style.opacity = String(floor + (1 - floor) * u);
      el.style.transform = `translate(${dx * (1 - u)}px,${dy * (1 - u)}px)`;
    };
    const root = id => document.querySelector(`#world [data-component="${id}"]`);

    // 1. opening-question
    let r = root('opening-question');
    if (r) {
      show(r.querySelector('.open-l1'), 0.33, 0, 14, 0.36, 0.7);
      show(r.querySelector('.open-l2'), 2.49, 0, 16, 0.36, 0.45);
      setDraw(r.querySelector('.open-underline path'), within(2.75, 0.52));
      setGlint(r.querySelector('.open-l2'), t, 2.75, 0.75, all);
      setRipple(r.querySelector('.beat-ripple'), t, 2.65, 0.7, all);
      const hf = r.querySelector('.high-fill');
      if (hf) hf.style.transform = `scaleX(${within(1.13, 0.65)})`;
      const mp = r.querySelector('.meter-pulse');
      if (mp) mp.style.opacity = all ? '0.6' : String(0.35 + 0.65 * Math.abs(Math.sin(t * 5)));
    }

    // 2. example-start
    r = root('example-start');
    if (r) {
      show(r.querySelector('.step-head'), 4.4, 0, 12, 0.34, 0.72);
      show(r.querySelector('.editor-mock'), 5.4, 0, 14, 0.36, 0.58);
      const cur = r.querySelector('.blink-cursor');
      if (cur) cur.style.opacity = all ? '0.6' : String(0.35 + 0.65 * Math.abs(Math.cos(t * 7)));
      show(r.querySelector('.hesitate-line'), 7.89, 0, 14, 0.34, 0.25);
      setGlint(r.querySelector('.hesitate-line .glint-target'), t, 8.2, 0.7, all);
      setRipple(r.querySelector('.hesitate-line .beat-ripple'), t, 8.1, 0.65, all);
    }

    // 3. task-chain
    r = root('task-chain');
    if (r) {
      show(r.querySelector('.task-head'), 9.45, 0, 12, 0.34, 0.65);
      const taskTimes = [10.61, 11.09, 11.65, 12.09, 13.01, 13.61];
      r.querySelectorAll('[data-branch]').forEach((path, i) => setDraw(path, within(taskTimes[i] - 0.14, 0.28)));
      r.querySelectorAll('[data-task-index]').forEach((node, i) => {
        const at = taskTimes[i];
        const u = all ? 1 : backOut((t - at) / 0.3);
        const vis = all ? 1 : clamp((t - at) / 0.14);
        node.style.opacity = String(0.22 + 0.78 * vis);
        node.style.transform = `translateY(${(1 - Math.min(1, u)) * 16}px) scale(${0.88 + 0.12 * u})`;
        node.classList.toggle('is-active', !all && t >= at && t < at + 0.55);
        setRipple(node.querySelector('.node-ripple'), t, at, 0.55, all);
      });
    }

    // 4. three-intro
    r = root('three-intro');
    if (r) {
      show(r.querySelector('.roadmap-title'), 17.35, 0, 12, 0.32, 0.7);
      setGlint(r.querySelector('.roadmap-title .glint-target'), t, 18.35, 0.7, all);
      setRipple(r.querySelector('.roadmap-title .beat-ripple'), t, 18.3, 0.65, all);
      setDraw(r.querySelector('.roadmap-spine path'), within(18.3, 0.55));
      show(r.querySelector('.sp1'), 18.35, 0, 12, 0.26, 0.45);
      show(r.querySelector('.sp2'), 18.62, 0, 12, 0.26, 0.45);
      show(r.querySelector('.sp3'), 18.88, 0, 12, 0.26, 0.45);
    }

    // 5. step-one
    r = root('step-one');
    if (r) {
      show(r.querySelector('.step-head'), 19.62, 0, 12, 0.34, 0.72);
      show(r.querySelector('.note-slip'), 20.15, 0, 14, 0.34, 0.65);
      const typed = r.querySelector('.typed-chars');
      const cursor = r.querySelector('.pen-cursor');
      if (typed) {
        const full = typed.dataset.type || '一句话';
        const s = Number(typed.dataset.start), e = Number(typed.dataset.end);
        const count = all ? full.length : Math.floor(clamp((t - s) / Math.max(0.05, e - s)) * full.length + 0.999);
        const shown = t < s && !all ? 0 : Math.min(full.length, count);
        typed.textContent = full.slice(0, shown);
        if (cursor) {
          const active = !all && t >= s && t < e + 0.45;
          cursor.style.opacity = active ? String(0.5 + 0.5 * Math.cos((t - s) * 14)) : '0';
        }
      }
      const rule = r.querySelector('.note-rule');
      if (rule) rule.style.transform = `scaleX(${within(20.25, 0.55)})`;
      show(r.querySelector('.remember-block'), 23.6, 0, 16, 0.34, 0.2);
      setDraw(r.querySelector('.hand-oval path'), within(24.85, 0.62));
      setGlint(r.querySelector('.remember-block .glint-target'), t, 24.95, 0.72, all);
      setRipple(r.querySelector('.remember-block .beat-ripple'), t, 24.95, 0.65, all);
    }

    // 6. step-two
    r = root('step-two');
    if (r) {
      show(r.querySelector('.step-head'), 26.6, 0, 12, 0.34, 0.75);
      show(r.querySelector('.example-card.own'), 28.55, -18, 0, 0.34, 0.55);
      show(r.querySelector('.example-or'), 29.45, 0, 8, 0.25, 0.4);
      show(r.querySelector('.example-card.compare'), 29.7, 18, 0, 0.34, 0.55);
      setDraw(r.querySelector('.example-card.own path'), within(28.75, 0.45));
      setDraw(r.querySelector('.example-card.compare path'), within(29.9, 0.45));
      setDraw(r.querySelector('.converge-lines path'), within(31.25, 0.4));
      show(r.querySelector('.clear-result'), 31.53, 0, 16, 0.34, 0.2);
      setGlint(r.querySelector('.clear-result .glint-target'), t, 31.68, 0.72, all);
      setRipple(r.querySelector('.clear-result .beat-ripple'), t, 31.6, 0.65, all);
    }

    // 7. step-three
    r = root('step-three');
    if (r) {
      show(r.querySelector('.step-head'), 33.0, 0, 12, 0.34, 0.75);
      show(r.querySelector('.combine-row'), 33.65, 0, 10, 0.34, 0.55);
      const merge = within(33.75, 0.65);
      const pv = r.querySelector('.pill-view'), pe = r.querySelector('.pill-example');
      if (pv) pv.style.transform = `translateX(${-42 * (1 - merge)}px)`;
      if (pe) pe.style.transform = `translateX(${42 * (1 - merge)}px)`;
      show(r.querySelector('.record-flow'), 35.15, 0, 12, 0.34, 0.35);
      setDraw(r.querySelector('.record-arrow path'), within(35.15, 0.4));
      r.querySelectorAll('[data-wave-index]').forEach(bar => {
        const i = Number(bar.dataset.waveIndex);
        const u = within(35.2, 0.22);
        const active = all ? 0.58 : (t >= 35.2 && t < 37.2 ? (0.32 + 0.68 * Math.abs(Math.sin(t * 9 + i * 0.75))) : 0.14);
        bar.style.height = (10 + u * active * (26 + Math.sin(i * 2.1) ** 2 * 40)) + 'px';
      });
      const stamp = r.querySelector('.vermilion-stamp');
      if (stamp) {
        const su = all ? 1 : backOut((t - 35.8) / 0.34);
        const vis = all ? 1 : clamp((t - 35.8) / 0.12);
        stamp.style.opacity = String(0.25 + 0.75 * vis);
        stamp.style.transform = `rotate(${-6 + 3 * Math.min(1, su)}deg) scale(${1.32 - 0.32 * su})`;
      }
      setRipple(r.querySelector('.stamp-wrap .beat-ripple'), t, 35.84, 0.72, all);
    }

    // 8. first-version
    r = root('first-version');
    if (r) {
      show(r.querySelector('.step-head'), 40.4, 0, 12, 0.32, 0.72);
      show(r.querySelector('.fv-before'), 40.6, 0, 10, 0.32, 0.55);
      show(r.querySelector('.fv-after'), 41.16, -18, 0, 0.34, 0.35);
      setGlint(r.querySelector('.fv-after .glint-target'), t, 41.3, 0.7, all);
      setRipple(r.querySelector('.fv-after .beat-ripple'), t, 41.24, 0.65, all);
      show(r.querySelector('.fv-checklist'), 42.45, 0, 12, 0.34, 0.25);
    }

    // 9. revision
    r = root('revision');
    if (r) {
      show(r.querySelector('.step-head'), 44.36, 0, 12, 0.34, 0.75);
      show(r.querySelector('.proof-short'), 45.05, 0, 12, 0.34, 0.55);
      const shortened = within(45.12, 0.52);
      const oldEl = r.querySelector('.proof-old');
      if (oldEl) oldEl.style.opacity = String(1 - 0.42 * shortened);
      setDraw(r.querySelector('.strike-svg path'), within(45.18, 0.36));
      show(r.querySelector('.proof-arrow'), 45.32, -12, 0, 0.26, 0.3);
      show(r.querySelector('.proof-new'), 45.4, -18, 0, 0.32, 0.3);
      setGlint(r.querySelector('.proof-new'), t, 45.5, 0.65, all);
      show(r.querySelector('.proof-expand'), 46.18, 0, 14, 0.34, 0.45);
      setDraw(r.querySelector('.proof-caret path'), within(46.28, 0.3));
      show(r.querySelector('.proof-insert'), 46.36, -16, 0, 0.32, 0.3);
      setDraw(r.querySelector('.insert-line path'), within(46.46, 0.4));
      setRipple(r.querySelector('.proof-expand .beat-ripple'), t, 46.42, 0.65, all);
    }

    // 10. keep-breaking
    r = root('keep-breaking');
    if (r) {
      show(r.querySelector('.step-head'), 47.64, 0, 12, 0.32, 0.72);
      const sp = within(48.55, 0.45);
      const lh = r.querySelector('.left-half'), rh = r.querySelector('.right-half');
      if (lh) lh.style.transform = `translateX(${-16 * sp}px) rotate(${-2.5 * sp}deg)`;
      if (rh) rh.style.transform = `translateX(${16 * sp}px) rotate(${2.5 * sp}deg)`;
      show(r.querySelector('.kb-punch'), 48.68, 0, 14, 0.34, 0.35);
      setGlint(r.querySelector('.kb-punch .glint-target'), t, 48.8, 0.65, all);
      setRipple(r.querySelector('.kb-punch .beat-ripple'), t, 48.72, 0.65, all);
    }

    // 11. make-smaller
    r = root('make-smaller');
    if (r) {
      show(r.querySelector('.step-head'), 49.56, 0, 12, 0.34, 0.75);
      const pairs = [['.writing', 49.65, 50.48], ['.recording', 51.5, 52.55]];
      for (const [sel, rowAt, hitAt] of pairs) {
        const row = r.querySelector(sel);
        if (!row) continue;
        show(row, rowAt, 0, 14, 0.34, 0.55);
        const u = within(hitAt, 0.42);
        const big = row.querySelector('.big-block');
        if (big) {
          big.style.opacity = String(1 - 0.48 * u);
          big.style.transform = `scale(${1 - 0.06 * u})`;
        }
        show(row.querySelector('.shrink-arrow'), hitAt - 0.05, -14, 0, 0.24, 0.35);
        const mini = row.querySelector('.mini-block');
        if (mini) {
          const mu = all ? 1 : backOut((t - hitAt) / 0.34);
          const vis = all ? 1 : clamp((t - hitAt) / 0.14);
          mini.style.opacity = String(0.45 + 0.55 * vis);
          mini.style.transform = `translateX(${-20 * (1 - Math.min(1, mu))}px) scale(${0.88 + 0.12 * mu})`;
        }
        setGlint(row.querySelector('.glint-target'), t, hitAt + 0.08, 0.68, all);
        setRipple(row.querySelector('.beat-ripple'), t, hitAt + 0.04, 0.65, all);
      }
    }

    // 12. closing
    r = root('closing');
    if (r) {
      show(r.querySelector('.cm-1'), 53.95, 0, 14, 0.34, 0.65);
      show(r.querySelector('.cm-2'), 55.12, 0, 14, 0.34, 0.55);
      const cta = r.querySelector('.cta-stamp');
      if (cta) {
        const su = all ? 1 : backOut((t - 59.2) / 0.38);
        const vis = all ? 1 : clamp((t - 59.2) / 0.16);
        cta.style.opacity = String(0.3 + 0.7 * vis);
        cta.style.transform = `rotate(${-3 + 2 * Math.min(1, su)}deg) scale(${1.18 - 0.18 * su})`;
      }
      setGlint(r.querySelector('.closing-cta .glint-target'), t, 60.15, 0.75, all);
      setRipple(r.querySelector('.closing-cta .beat-ripple'), t, 59.35, 0.72, all);
    }
  }

  window.SmallStepDiagrams = { html, render };
})();
