(() => {
  'use strict';
  const plan = window.CANVAS_PLAN || {};
  const design = plan.title_design || {};
  const root = document.querySelector('#film-title');
  if (!root) return;

  const defaults = {
    lines: ['买东西别只看标价', '使用次数才是关键'],
    keywords: [['标价'], ['使用次数']],
    marker_words: [['只看标价'], ['使用次数']],
    font_size: 84,
    top: 200
  };
  const lines = [0, 1].map(index => String(design.lines?.[index] ?? defaults.lines[index]));
  const keywords = [0, 1].map(index => design.keywords?.[index] ?? defaults.keywords[index]);
  const markers = [0, 1].map(index => design.marker_words?.[index] ?? defaults.marker_words[index]);
  const top = Number.isFinite(design.top) ? design.top : defaults.top;
  const maximum = Number.isFinite(design.font_size) ? design.font_size : defaults.font_size;
  const margin = Number.isFinite(design.margin_x) ? design.margin_x : 130;
  const theme = plan.theme || {};
  const accent = theme.accent || '#FF3D8B';
  const foreground = theme.foreground || '#FFFFFF';
  const observed = [];
  let scheduled = 0;
  let observer;

  root.classList.add('title-pack');
  root.style.setProperty('--title-pack-top', top + 'px');
  root.style.setProperty('--title-pack-margin', margin + 'px');
  root.style.setProperty('--title-pack-accent', accent);
  root.style.setProperty('--title-pack-foreground', foreground);
  root.style.setProperty('--title-pack-warm', '#F2CB61');

  function ranges(text, words) {
    const found = [];
    for (const raw of Array.isArray(words) ? words : []) {
      const word = String(raw);
      if (!word) continue;
      let cursor = 0;
      while (cursor < text.length) {
        const at = text.indexOf(word, cursor);
        if (at < 0) break;
        found.push({ start: at, end: at + word.length });
        cursor = at + word.length;
      }
    }
    found.sort((a, b) => a.start - b.start || a.end - b.end);
    return found.reduce((merged, range) => {
      const previous = merged[merged.length - 1];
      if (previous && range.start <= previous.end) previous.end = Math.max(previous.end, range.end);
      else merged.push({ ...range });
      return merged;
    }, []);
  }

  function appendWords(parent, text, from, to, highlights) {
    const cuts = [...new Set([from, to, ...highlights.flatMap(range => [range.start, range.end]).filter(at => at > from && at < to)])].sort((a, b) => a - b);
    for (let index = 0; index < cuts.length - 1; index++) {
      const start = cuts[index];
      const end = cuts[index + 1];
      const value = text.slice(start, end);
      if (!value) continue;
      if (highlights.some(range => start < range.end && end > range.start)) {
        const span = document.createElement('span');
        span.className = 'title-pack-keyword';
        span.textContent = value;
        parent.append(span);
      } else parent.append(document.createTextNode(value));
    }
  }

  function decorate(node, index) {
    const text = node.textContent;
    const highlights = ranges(text, keywords[index]);
    const strokes = ranges(text, markers[index]);
    const copy = document.createElement('span');
    copy.className = 'title-pack-copy';
    let cursor = 0;
    for (const range of strokes) {
      appendWords(copy, text, cursor, range.start, highlights);
      const mark = document.createElement('span');
      mark.className = 'title-pack-marker ' + (index === 0 ? 'title-pack-marker-brand' : 'title-pack-marker-warm');
      appendWords(mark, text, range.start, range.end, highlights);
      copy.append(mark);
      cursor = range.end;
    }
    appendWords(copy, text, cursor, text.length, highlights);
    node.replaceChildren(copy);
    node.dataset.titlePackLine = String(index + 1);
  }

  for (const [index, id] of ['title-opening', 'title-subtitle'].entries()) {
    let node = root.querySelector('[data-preview-text="' + id + '"]');
    if (!node) {
      node = root.children[index] || document.createElement(index ? 'strong' : 'div');
      node.dataset.previewText = id;
      if (!node.parentElement) root.append(node);
    }
    node.textContent = lines[index];
    observed.push(node);
  }

  function watch() {
    for (const node of observed) observer.observe(node, { childList: true, subtree: true, characterData: true });
  }

  function fit() {
    const width = root.clientWidth;
    if (!width) return { fontSize: maximum, hidden: true };
    const heightMaximum = Math.floor((405 - top - 10 - 7) / 2.16);
    let size = Math.min(maximum, heightMaximum);
    size = Math.max(64, size);
    root.style.setProperty('--title-pack-font-size', size + 'px');
    let textWidth = Math.max(...observed.map(node => node.querySelector('.title-pack-copy')?.scrollWidth || 0));
    if (textWidth > width) {
      size = Math.max(64, Math.floor(size * (width - 8) / textWidth));
      root.style.setProperty('--title-pack-font-size', size + 'px');
      textWidth = Math.max(...observed.map(node => node.querySelector('.title-pack-copy')?.scrollWidth || 0));
    }
    root.dataset.titlePackOverflow = String(textWidth > width + 1);
    return { fontSize: size, textWidth, availableWidth: width, overflow: textWidth > width + 1 };
  }

  function refresh() {
    observer?.disconnect();
    try {
      observed.forEach(decorate);
      return fit();
    } finally {
      if (observer) watch();
    }
  }

  function scheduleFit() {
    cancelAnimationFrame(scheduled);
    scheduled = requestAnimationFrame(() => { scheduled = 0; fit(); });
  }

  observer = new MutationObserver(() => refresh());
  refresh();
  if (document.fonts?.ready) document.fonts.ready.then(fit);
  addEventListener('resize', scheduleFit);
  addEventListener('canvas-mode-change', scheduleFit);
  window.CanvasTitlePack = { refresh, fit, getLines: () => observed.map(node => node.textContent) };
})();
