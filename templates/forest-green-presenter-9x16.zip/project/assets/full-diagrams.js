(() => {
  'use strict';
  const clamp = n => Math.max(0, Math.min(1, n));
  const ease = n => { n = clamp(n); return 1 - Math.pow(1 - n, 3); };
  const backOut = n => { n = clamp(n); const c1 = 1.6, c3 = c1 + 1; return 1 + c3 * Math.pow(n - 1, 3) + c1 * Math.pow(n - 1, 2); };

  const html = {
    'opening-question': `
      <div class="paper-card opening-card">
        <span class="margin-rule"></span>
        <div class="card-kicker">痛点起点</div>
        <h2>越想把一件事做好</h2>
        <strong>越容易<br>迟迟不开始</strong>
        <div class="opening-dots"><i></i><i></i><i></i></div>
      </div>`,

    'task-chain': `
      <div class="paper-card task-board">
        <div class="task-head">
          <span class="step-badge">拆解前</span>
          <h2>做完<em>一条视频</em></h2>
        </div>
        <svg class="task-links" viewBox="0 0 800 560" aria-hidden="true">
          <path data-branch="0" pathLength="1" d="M225 148 C225 198, 128 200, 128 242"/>
          <path data-branch="1" pathLength="1" d="M265 148 C305 198, 392 198, 412 242"/>
          <path data-branch="2" pathLength="1" d="M128 310 C128 345, 222 345, 228 370"/>
          <path data-branch="3" pathLength="1" d="M412 310 C425 345, 530 340, 540 370"/>
          <path data-branch="4" pathLength="1" d="M228 438 C220 462, 170 465, 160 486"/>
          <path data-branch="5" pathLength="1" d="M540 438 C535 462, 475 465, 465 486"/>
        </svg>
        <div class="task-nodes">
          <div class="task-node" data-task-index="0" style="left:48px;top:242px"><b>01</b><span>选题</span><i class="node-ripple"></i></div>
          <div class="task-node is-accent" data-task-index="1" style="left:332px;top:242px"><b>02</b><span>写稿</span><i class="node-ripple"></i></div>
          <div class="task-node" data-task-index="2" style="left:148px;top:370px"><b>03</b><span>录音</span><i class="node-ripple"></i></div>
          <div class="task-node is-accent" data-task-index="3" style="left:460px;top:370px"><b>04</b><span>剪辑</span><i class="node-ripple"></i></div>
          <div class="task-node" data-task-index="4" style="left:80px;top:486px"><b>05</b><span>字幕</span><i class="node-ripple"></i></div>
          <div class="task-node is-accent" data-task-index="5" style="left:385px;top:486px"><b>06</b><span>封面</span><i class="node-ripple"></i></div>
        </div>
      </div>`,

    'step-one': `
      <div class="paper-card step-one">
        <div class="step-head"><span class="step-num">01</span><h2>只写<em>一个观点</em></h2></div>
        <div class="note-slip">
          <div class="note-slip-label">核心句</div>
          <div class="type-line"><span class="typed-chars" data-type="一句话" data-start="20.25" data-end="21.05"></span><i class="pen-cursor"></i></div>
          <span class="note-rule"></span>
        </div>
        <div class="remember-block">
          <p>这条视频，最想让别人</p>
          <div class="circle-emphasis">
            <strong class="glint-target">记住什么？</strong>
            <svg class="hand-oval" viewBox="0 0 320 112" aria-hidden="true">
              <path pathLength="1" d="M24 58 C20 18, 128 8, 224 14 C298 18, 314 54, 294 84 C272 108, 134 108, 52 94 C14 86, 10 56, 36 44"/>
            </svg>
            <i class="beat-ripple"></i>
          </div>
        </div>
      </div>`,

    'step-two': `
      <div class="paper-card step-two">
        <div class="step-head"><span class="step-num">02</span><h2>找一个<em>具体例子</em></h2></div>
        <div class="example-grid">
          <div class="example-card own">
            <span class="card-tag">方式 A</span>
            <strong>自己的经历</strong>
            <small>真实踩坑或体会</small>
            <svg viewBox="0 0 220 20" aria-hidden="true"><path pathLength="1" d="M6 12 Q110 3 214 13"/></svg>
          </div>
          <span class="example-or">或</span>
          <div class="example-card compare">
            <span class="card-tag">方式 B</span>
            <strong>两种做法对比</strong>
            <small>好与坏一眼看懂</small>
            <svg viewBox="0 0 220 20" aria-hidden="true"><path pathLength="1" d="M6 13 Q110 18 214 6"/></svg>
          </div>
        </div>
        <svg class="converge-lines" viewBox="0 0 560 52" aria-hidden="true">
          <path pathLength="1" d="M130 4 C130 34, 260 22, 280 48 M430 4 C430 34, 300 22, 280 48"/>
        </svg>
        <div class="clear-result">
          <span class="glint-target">让别人<em>听得明白</em></span>
          <i class="beat-ripple"></i>
        </div>
      </div>`,

    'step-three': `
      <div class="paper-card step-three">
        <div class="step-head"><span class="step-num">03</span><h2>录成<em>第一版</em></h2></div>
        <div class="combine-row">
          <span class="paper-pill pill-view">观点</span>
          <b class="combine-plus">＋</b>
          <span class="paper-pill pill-example">例子</span>
        </div>
        <div class="record-flow">
          <svg class="record-arrow" viewBox="0 0 120 74" aria-hidden="true">
            <path pathLength="1" d="M60 4 C64 28, 60 44, 60 64 M44 48 L60 66 L76 48"/>
          </svg>
          <div class="record-wave-box">
            <div class="record-wave">${Array.from({ length: 19 }, (_, i) => `<i data-wave-index="${i}"></i>`).join('')}</div>
          </div>
          <div class="stamp-wrap">
            <div class="vermilion-stamp">
              <span>初稿完成</span>
              <strong>第一版</strong>
            </div>
            <i class="beat-ripple"></i>
          </div>
        </div>
      </div>`,

    'revision': `
      <div class="paper-card revision">
        <div class="step-head"><span class="step-num">改</span><h2>有了第一版，<em>问题就具体了</em></h2></div>
        <div class="proof-sheet">
          <div class="proof-row proof-short">
            <span class="proof-old">这句话太长要缩短<svg class="strike-svg" viewBox="0 0 320 24" preserveAspectRatio="none" aria-hidden="true"><path pathLength="1" d="M2 13 Q160 8 318 14"/></svg></span>
            <span class="proof-arrow">→</span>
            <strong class="proof-new glint-target">缩短这句话</strong>
          </div>
          <div class="proof-row proof-expand">
            <span class="proof-base">例子</span>
            <span class="proof-caret">
              <svg viewBox="0 0 42 36" aria-hidden="true"><path pathLength="1" d="M6 30 L21 6 L36 30"/></svg>
            </span>
            <strong class="proof-insert">补充一个例子<svg class="insert-line" viewBox="0 0 260 18" preserveAspectRatio="none" aria-hidden="true"><path pathLength="1" d="M4 11 Q130 4 256 12"/></svg></strong>
            <i class="beat-ripple"></i>
          </div>
        </div>
      </div>`,

    'make-smaller': `
      <div class="paper-card make-smaller">
        <div class="step-head"><span class="step-num">拆</span><h2>还是太难？<em>继续拆小</em></h2></div>
        <div class="shrink-list">
          <div class="shrink-row writing">
            <div class="big-block"><span>写一段</span></div>
            <i class="shrink-arrow">→</i>
            <div class="mini-block">
              <strong class="glint-target">写一句</strong>
              <i class="beat-ripple"></i>
            </div>
          </div>
          <div class="shrink-row recording">
            <div class="big-block"><span>录完整条</span></div>
            <i class="shrink-arrow">→</i>
            <div class="mini-block">
              <strong class="glint-target">录个开头</strong>
              <i class="beat-ripple"></i>
            </div>
          </div>
        </div>
      </div>`
  };

  function setRipple(el, t, at, duration = 0.65, all = false) {
    if (!el) return;
    if (all || t < at || t > at + duration) {
      el.style.opacity = '0';
      el.style.transform = 'translate(-50%,-50%) scale(.4)';
      return;
    }
    const u = clamp((t - at) / duration);
    el.style.opacity = String(0.75 * (1 - u));
    el.style.transform = `translate(-50%,-50%) scale(${0.45 + 1.45 * ease(u)})`;
  }

  function setGlint(el, t, at, duration = 0.72, all = false) {
    if (!el) return;
    if (all || t < at || t > at + duration) {
      el.style.setProperty('--glint-pos', '-30%');
      el.style.setProperty('--glint-alpha', '0');
      return;
    }
    const u = clamp((t - at) / duration);
    el.style.setProperty('--glint-pos', (-30 + 160 * ease(u)) + '%');
    el.style.setProperty('--glint-alpha', String(Math.sin(Math.PI * u)));
  }

  function setDraw(path, u) {
    if (!path) return;
    path.style.strokeDasharray = '1';
    path.style.strokeDashoffset = String(1 - clamp(u));
  }

  function render(t, { all = false } = {}) {
    const within = (at, dur = 0.34) => all ? 1 : ease((t - at) / dur);
    const show = (el, at, dx = 0, dy = 20, dur = 0.34, floor = 0) => {
      if (!el) return;
      const u = within(at, dur);
      el.style.opacity = String(floor + (1 - floor) * u);
      el.style.transform = `translate(${dx * (1 - u)}px,${dy * (1 - u)}px)`;
    };
    const root = id => document.querySelector(`#world [data-component="${id}"]`);

    // 0. task-chain
    let r = root('task-chain');
    if (r) {
      const headU = all ? 1 : ease((t - 9.48) / 0.36);
      const head = r.querySelector('.task-head');
      if (head) {
        head.style.opacity = String(0.55 + 0.45 * headU);
        head.style.transform = `translateY(${(1 - headU) * 14}px)`;
      }
      const taskTimes = [10.61, 11.09, 11.65, 12.09, 13.01, 13.61];
      r.querySelectorAll('[data-branch]').forEach((path, i) => {
        setDraw(path, within(taskTimes[i] - 0.14, 0.28));
      });
      r.querySelectorAll('[data-task-index]').forEach((node, i) => {
        const at = taskTimes[i];
        const u = all ? 1 : backOut((t - at) / 0.3);
        const vis = all ? 1 : clamp((t - at) / 0.14);
        node.style.opacity = String(vis);
        node.style.transform = `translateY(${(1 - Math.min(1, u)) * 18}px) scale(${0.86 + 0.14 * u})`;
        node.classList.toggle('is-active', !all && t >= at && t < at + 0.55);
        setRipple(node.querySelector('.node-ripple'), t, at, 0.55, all);
      });
    }

    // 1. step-one
    r = root('step-one');
    if (r) {
      show(r.querySelector('.step-head'), 19.62, 0, 12, 0.34, 0.72);
      const slip = r.querySelector('.note-slip');
      show(slip, 20.15, 0, 14, 0.34, 0.65);
      const typed = r.querySelector('.typed-chars');
      const cursor = r.querySelector('.pen-cursor');
      if (typed) {
        const full = typed.dataset.type || '一句话';
        const s = Number(typed.dataset.start), e = Number(typed.dataset.end);
        const count = all ? full.length : Math.floor(clamp((t - s) / Math.max(0.05, e - s)) * full.length + 0.999);
        const shown = t < s && !all ? 0 : Math.min(full.length, count);
        typed.textContent = full.slice(0, shown);
        if (cursor) {
          const active = !all && t >= s && t < e + 0.45;
          cursor.style.opacity = active ? String(0.5 + 0.5 * Math.cos((t - s) * 14)) : '0';
        }
      }
      const rule = r.querySelector('.note-rule');
      if (rule) rule.style.transform = `scaleX(${within(20.25, 0.55)})`;
      show(r.querySelector('.remember-block'), 23.6, 0, 16, 0.34, 0);
      setDraw(r.querySelector('.hand-oval path'), within(24.85, 0.62));
      setGlint(r.querySelector('.remember-block .glint-target'), t, 24.95, 0.72, all);
      setRipple(r.querySelector('.remember-block .beat-ripple'), t, 24.95, 0.65, all);
    }

    // 2. step-two
    r = root('step-two');
    if (r) {
      show(r.querySelector('.step-head'), 26.6, 0, 12, 0.34, 0.75);
      show(r.querySelector('.example-card.own'), 28.55, -18, 0, 0.34, 0.55);
      show(r.querySelector('.example-or'), 29.45, 0, 8, 0.25, 0.4);
      show(r.querySelector('.example-card.compare'), 29.7, 18, 0, 0.34, 0.55);
      setDraw(r.querySelector('.example-card.own path'), within(28.75, 0.45));
      setDraw(r.querySelector('.example-card.compare path'), within(29.9, 0.45));
      setDraw(r.querySelector('.converge-lines path'), within(31.25, 0.4));
      show(r.querySelector('.clear-result'), 31.53, 0, 16, 0.34, 0);
      setGlint(r.querySelector('.clear-result .glint-target'), t, 31.68, 0.72, all);
      setRipple(r.querySelector('.clear-result .beat-ripple'), t, 31.6, 0.65, all);
    }

    // 3. step-three
    r = root('step-three');
    if (r) {
      show(r.querySelector('.step-head'), 33.0, 0, 12, 0.34, 0.75);
      show(r.querySelector('.combine-row'), 33.65, 0, 10, 0.34, 0.55);
      const merge = within(33.75, 0.65);
      const pv = r.querySelector('.pill-view');
      const pe = r.querySelector('.pill-example');
      if (pv) pv.style.transform = `translateX(${-42 * (1 - merge)}px)`;
      if (pe) pe.style.transform = `translateX(${42 * (1 - merge)}px)`;
      show(r.querySelector('.record-flow'), 35.15, 0, 12, 0.34, 0.35);
      setDraw(r.querySelector('.record-arrow path'), within(35.15, 0.4));
      r.querySelectorAll('[data-wave-index]').forEach(bar => {
        const i = Number(bar.dataset.waveIndex);
        const u = within(35.2, 0.22);
        const active = all ? 0.58 : (t >= 35.2 && t < 37.2 ? (0.32 + 0.68 * Math.abs(Math.sin(t * 9 + i * 0.75))) : 0.14);
        bar.style.height = (10 + u * active * (26 + Math.sin(i * 2.1) ** 2 * 40)) + 'px';
      });
      const stamp = r.querySelector('.vermilion-stamp');
      if (stamp) {
        const su = all ? 1 : backOut((t - 35.8) / 0.34);
        const vis = all ? 1 : clamp((t - 35.8) / 0.12);
        stamp.style.opacity = String(vis);
        stamp.style.transform = `rotate(${-6 + 3 * Math.min(1, su)}deg) scale(${1.35 - 0.35 * su})`;
      }
      setRipple(r.querySelector('.stamp-wrap .beat-ripple'), t, 35.84, 0.72, all);
    }

    // 4. revision
    r = root('revision');
    if (r) {
      show(r.querySelector('.step-head'), 44.36, 0, 12, 0.34, 0.75);
      show(r.querySelector('.proof-short'), 45.05, 0, 12, 0.34, 0.55);
      const shortened = within(45.12, 0.52);
      const oldEl = r.querySelector('.proof-old');
      if (oldEl) oldEl.style.opacity = String(1 - 0.42 * shortened);
      setDraw(r.querySelector('.strike-svg path'), within(45.18, 0.36));
      show(r.querySelector('.proof-arrow'), 45.32, -12, 0, 0.26);
      show(r.querySelector('.proof-new'), 45.4, -18, 0, 0.32);
      setGlint(r.querySelector('.proof-new'), t, 45.5, 0.65, all);
      show(r.querySelector('.proof-expand'), 46.18, 0, 14, 0.34, 0.45);
      setDraw(r.querySelector('.proof-caret path'), within(46.28, 0.3));
      show(r.querySelector('.proof-insert'), 46.36, -16, 0, 0.32);
      setDraw(r.querySelector('.insert-line path'), within(46.46, 0.4));
      setRipple(r.querySelector('.proof-expand .beat-ripple'), t, 46.42, 0.65, all);
    }

    // 5. make-smaller
    r = root('make-smaller');
    if (r) {
      show(r.querySelector('.step-head'), 49.56, 0, 12, 0.34, 0.75);
      const pairs = [['.writing', 49.65, 50.48], ['.recording', 51.5, 52.55]];
      for (const [sel, rowAt, hitAt] of pairs) {
        const row = r.querySelector(sel);
        if (!row) continue;
        show(row, rowAt, 0, 14, 0.34, 0.55);
        const u = within(hitAt, 0.42);
        const big = row.querySelector('.big-block');
        if (big) {
          big.style.opacity = String(1 - 0.48 * u);
          big.style.transform = `scale(${1 - 0.06 * u})`;
        }
        show(row.querySelector('.shrink-arrow'), hitAt - 0.05, -14, 0, 0.24, 0.35);
        const mini = row.querySelector('.mini-block');
        if (mini) {
          const mu = all ? 1 : backOut((t - hitAt) / 0.34);
          const vis = all ? 1 : clamp((t - hitAt) / 0.14);
          mini.style.opacity = String(0.45 + 0.55 * vis);
          mini.style.transform = `translateX(${-20 * (1 - Math.min(1, mu))}px) scale(${0.88 + 0.12 * mu})`;
        }
        setGlint(row.querySelector('.glint-target'), t, hitAt + 0.08, 0.68, all);
        setRipple(row.querySelector('.beat-ripple'), t, hitAt + 0.04, 0.65, all);
      }
    }
  }

  window.SmallStepDiagrams = { html, render };
})();
