# 字体与图标的原协议

| 资源 | 来源 | 原协议 |
|---|---|---|
| 思源宋体（Source Han Serif CN） | Adobe | [SIL OFL 1.1](SourceHanSerif-OFL.txt) |
| 康康体 | 素材集市 | 原包未附完整许可文本；本项目不额外授予使用权 |
| Ant Design Icons | Ant UED | [MIT](Ant-Design-MIT.txt) |

原有字体、图标及其许可文件继续保留。字体文件主要为精简子集，仍遵循原权利人的许可，不因模板代码采用 MIT 而改变。
