(() => {
  'use strict';
  const clamp = n => Math.max(0, Math.min(1, n));
  const ease = n => { n = clamp(n); return 1 - Math.pow(1 - n, 3); };
  const expoOut = n => { n = clamp(n); return n <= 0 ? 0 : n >= 1 ? 1 : 1 - Math.pow(2, -10 * n); };
  const backOut = n => { n = clamp(n); const c1 = 2.15, c3 = c1 + 1; return 1 + c3 * Math.pow(n - 1, 3) + c1 * Math.pow(n - 1, 2); };

  const html = {
    'opening-question': `
      <div class="wb-card">
        <div class="wb-head">
          <div class="wb-head-left"><span class="wb-pill">01 痛点切片</span><h2>完美主义<em>拖延症</em></h2></div>
          <span class="wb-badge-right">AI 拆解工作流</span>
        </div>
        <div class="op-hero-title">越想把一件事<em>做到满分</em></div>
        <div class="op-sub-line">为什么明明很想做好，却迟迟动不了手？</div>
        <div class="op-bottom-row">
          <div class="op-mini-flow">
            <span class="op-flow-node fn1">01 观点</span><span class="op-flow-arrow">→</span>
            <span class="op-flow-node fn2">02 例子</span><span class="op-flow-arrow">→</span>
            <span class="op-flow-node fn3">03 第一版</span>
          </div>
          <div class="op-stickies">
            <div class="sticky-note is-red st-delay">越容易迟迟不开始</div>
            <div class="sticky-note is-yellow st-stay">先别划走！</div>
          </div>
        </div>
      </div>`,

    'task-chain': `
      <div class="wb-card tc-card">
        <div class="tc-intro">
          <div class="tc-intro-tag">常见困局 · 模糊大目标</div>
          <div class="tc-intro-title">今天要做完<em>一条视频</em></div>
          <div class="tc-intro-row">
            <span class="tc-scene-chip">💻 坐到电脑前</span>
            <span class="tc-scene-arrow">→</span>
            <span class="tc-stuck-chip">不知道从哪下手？</span>
          </div>
          <div class="tc-intro-lead">因为这句话里面，其实藏着 <em>6 项隐形任务</em> →</div>
        </div>
        <div class="tc-list-stage">
          <div class="wb-head">
            <div class="wb-head-left"><span class="wb-pill">拆解前</span><h2>做完一条视频 = <em>6 项隐形任务</em></h2></div>
            <span class="wb-badge-right">大脑超载警告</span>
          </div>
          <div class="tc-grid">
            <div class="tc-node" data-task-index="0"><b>01</b><span>选题</span><i class="beat-ripple"></i></div>
            <div class="tc-node is-accent" data-task-index="1"><b>02</b><span>写稿</span><i class="beat-ripple"></i></div>
            <div class="tc-node" data-task-index="2"><b>03</b><span>录音</span><i class="beat-ripple"></i></div>
            <div class="tc-node is-accent" data-task-index="3"><b>04</b><span>剪辑</span><i class="beat-ripple"></i></div>
            <div class="tc-node" data-task-index="4"><b>05</b><span>字幕</span><i class="beat-ripple"></i></div>
            <div class="tc-node is-accent" data-task-index="5"><b>06</b><span>封面</span><i class="beat-ripple"></i></div>
          </div>
          <div class="tc-stress-bar">
            <span>脑内待办负荷</span>
            <div class="tc-track"><div class="tc-fill"></div></div>
            <span>100% 卡死</span>
          </div>
        </div>
      </div>`,

    'step-one': `
      <div class="wb-card">
        <div class="wb-head">
          <div class="wb-head-left"><span class="wb-pill">STEP 01</span><h2>只写<em>一个观点</em></h2></div>
          <span class="wb-badge-right">先缩小第一步</span>
        </div>
        <div class="s1-split">
          <div class="s1-left">
            <div style="font-size:22px;color:#64748b;font-weight:800">核心输出区</div>
            <div class="type-line"><span class="typed-chars" data-type="一句话" data-start="20.25" data-end="21.05"></span><i class="pen-cursor"></i></div>
            <div class="s1-strike-badge">先不用纠结开头</div>
          </div>
          <div class="s1-right">
            <div style="font-size:32px;font-weight:800;color:#475569">只回答：这条视频最想让别人</div>
            <div class="circle-emphasis">
              <strong>记住什么？</strong>
              <svg class="hand-oval" viewBox="0 0 320 112" aria-hidden="true">
                <path pathLength="1" d="M24 58 C20 18, 128 8, 224 14 C298 18, 314 54, 294 84 C272 108, 134 108, 52 94 C14 86, 10 56, 36 44"/>
              </svg>
              <i class="beat-ripple"></i>
            </div>
          </div>
        </div>
      </div>`,

    'step-two': `
      <div class="wb-card">
        <div class="wb-head">
          <div class="wb-head-left"><span class="wb-pill is-green">STEP 02</span><h2>找一个<em>具体例子</em></h2></div>
          <span class="wb-badge-right">二选一即可</span>
        </div>
        <div class="s2-grid">
          <div class="s2-card own">
            <span style="color:#1d5eff;font-weight:900;font-size:22px">方式 A · 真实感</span>
            <strong>自己的经历</strong>
            <small>亲自踩过的坑或真实体会</small>
          </div>
          <div class="s2-card compare">
            <span style="color:#1d5eff;font-weight:900;font-size:22px">方式 B · 直观感</span>
            <strong>两种做法对比</strong>
            <small>好做法 VS 坏做法一眼看懂</small>
          </div>
        </div>
        <div class="s2-footer">
          <span>目标：让别人听得明白</span>
          <i class="beat-ripple"></i>
        </div>
      </div>`,

    'step-three': `
      <div class="wb-card">
        <div class="wb-head">
          <div class="wb-head-left"><span class="wb-pill is-orange">STEP 03</span><h2>录成<em>第一版</em></h2></div>
          <div class="s3-timer">00:00</div>
        </div>
        <div class="s3-top-row">
          <div class="s3-pills">
            <span class="s3-pill">观点</span>
            <b style="font-size:40px;color:#1d5eff">＋</b>
            <span class="s3-pill">例子</span>
            <b style="font-size:40px;color:#1d5eff">＝</b>
            <span class="s3-pill" style="background:#fef08a">读出来</span>
          </div>
        </div>
        <div class="record-wave">${Array.from({ length: 28 }, (_, i) => `<i data-wave-index="${i}"></i>`).join('')}</div>
        <div class="s3-bottom-row">
          <div class="vermilion-stamp"><span>初稿完成 · 第一版</span><i class="beat-ripple"></i></div>
          <div class="op-stickies">
            <div class="sticky-note is-red s3-fix1">不顺就改哪里</div>
            <div class="sticky-note is-yellow s3-fix2">没讲清补一句</div>
          </div>
        </div>
      </div>`,

    'revision': `
      <div class="wb-card">
        <div class="wb-head">
          <div class="wb-head-left"><span class="wb-pill is-orange">迭代修改</span><h2>有了第一版，问题就<em>具体了</em></h2></div>
          <span class="wb-badge-right">告别空白焦虑</span>
        </div>
        <div class="rev-grid">
          <div class="rev-blank">
            <span style="font-size:52px">📄</span>
            <span style="text-decoration:line-through;text-decoration-color:#ff6b35;text-decoration-thickness:4px">对着空白文档发愁</span>
          </div>
          <div class="rev-diff">
            <div class="proof-row">
              <span class="proof-old">这句话太长要缩短<svg class="strike-svg" viewBox="0 0 320 24" preserveAspectRatio="none"><path pathLength="1" d="M2 13 Q160 8 318 14"/></svg></span>
              <span>→</span>
              <strong class="proof-new">缩短这句话</strong>
            </div>
            <div class="proof-row">
              <span>例子</span>
              <span style="color:#10b981;font-size:38px">∧</span>
              <strong class="proof-new" style="color:#047857">补充一个例子</strong>
              <i class="beat-ripple"></i>
            </div>
          </div>
        </div>
      </div>`,

    'make-smaller': `
      <div class="wb-card">
        <div class="wb-head">
          <div class="wb-head-left"><span class="wb-pill is-green">继续拆小</span><h2>如果还是不想动？<em>继续拆</em></h2></div>
          <span class="wb-badge-right">最小可行动作</span>
        </div>
        <div class="shrink-list">
          <div class="shrink-row writing">
            <div class="big-block">写一段太难</div>
            <span style="font-size:40px;font-weight:900;color:#1d5eff">→</span>
            <div class="mini-block"><span>✓ 先写一句</span><i class="beat-ripple"></i></div>
          </div>
          <div class="shrink-row recording">
            <div class="big-block">录完整条太难</div>
            <span style="font-size:40px;font-weight:900;color:#1d5eff">→</span>
            <div class="mini-block"><span>✓ 先录开头</span><i class="beat-ripple"></i></div>
          </div>
        </div>
      </div>`
  };

  function setRipple(el, t, at, duration = 0.65, all = false) {
    if (!el) return;
    if (all || t < at || t > at + duration) {
      el.style.opacity = '0';
      el.style.transform = 'translate(-50%,-50%) scale(.4)';
      return;
    }
    const u = clamp((t - at) / duration);
    el.style.opacity = String(0.78 * (1 - u));
    el.style.transform = `translate(-50%,-50%) scale(${0.45 + 1.5 * ease(u)})`;
  }

  function setDraw(path, u) {
    if (!path) return;
    path.style.strokeDasharray = '1';
    path.style.strokeDashoffset = String(1 - clamp(u));
  }

  function render(t, { all = false } = {}) {
    const within = (at, dur = 0.15) => all ? 1 : expoOut((t - at) / dur);
    const show = (el, at, dx = 0, dy = 16, dur = 0.16, floor = 0) => {
      if (!el) return;
      const u = within(at, dur);
      el.style.opacity = String(floor + (1 - floor) * u);
      el.style.transform = `translate(${dx * (1 - u)}px,${dy * (1 - u)}px)`;
    };
    const pop = (el, at, rot = 0, floor = 0) => {
      if (!el) return;
      const u = all ? 1 : backOut((t - at) / 0.17);
      const vis = all ? 1 : clamp((t - at) / 0.06);
      el.style.opacity = String(floor + (1 - floor) * vis);
      el.style.transform = `rotate(${rot}deg) scale(${(0.35 + 0.65 * u).toFixed(3)})`;
    };
    const slam = (el, at, rot = 0, floor = 0) => {
      if (!el) return;
      const u = all ? 1 : expoOut((t - at) / 0.14);
      const vis = all ? 1 : clamp((t - at) / 0.05);
      const bounce = all ? 0 : Math.sin(Math.PI * clamp((t - at - 0.14) / 0.14)) * -0.05;
      el.style.opacity = String(floor + (1 - floor) * vis);
      el.style.transform = `rotate(${rot}deg) scale(${(1.65 - 0.65 * u + bounce).toFixed(3)})`;
    };
    const root = id => document.querySelector(`#world [data-component="${id}"]`);

    // 1. opening-question (0..4.2s)：从空白逐拍生长
    let r = root('opening-question');
    if (r) {
      pop(r.querySelector('.op-hero-title'), 0.15, 0, 0);
      show(r.querySelector('.op-sub-line'), 0.45, 0, 14, 0.16, 0);
      pop(r.querySelector('.fn1'), 1.0, 0, 0);
      pop(r.querySelector('.fn2'), 1.4, 0, 0);
      pop(r.querySelector('.fn3'), 1.8, 0, 0);
      pop(r.querySelector('.st-delay'), 2.49, -3, 0);
      pop(r.querySelector('.st-stay'), 3.2, 3, 0);
    }

    // 2. task-chain (5.3..14.3s)：前段大标题情境幕承接铺垫句，10.05s 切入 6 项清单逐条弹爆
    r = root('task-chain');
    if (r) {
      const intro = r.querySelector('.tc-intro');
      const listStage = r.querySelector('.tc-list-stage');
      const switchAt = 10.05;
      const introOut = all ? 1 : ease((t - (switchAt - 0.12)) / 0.22);
      const listIn = all ? 1 : ease((t - switchAt) / 0.18);
      if (intro) {
        const op = all ? 0 : (1 - introOut);
        intro.style.opacity = op.toFixed(3);
        intro.style.transform = `scale(${(1 - 0.06 * introOut).toFixed(3)}) translateY(${(-14 * introOut).toFixed(1)}px)`;
        intro.style.pointerEvents = op > 0.02 ? '' : 'none';
      }
      if (listStage) {
        listStage.style.opacity = listIn.toFixed(3);
        listStage.style.transform = `translateY(${((1 - listIn) * 18).toFixed(1)}px)`;
      }
      if (!all && introOut < 1) {
        show(r.querySelector('.tc-intro-tag'), 5.32, 0, 12, 0.14, 0);
        pop(r.querySelector('.tc-intro-title'), 5.42, 0, 0);
        pop(r.querySelector('.tc-scene-chip'), 6.82, 0, 0);
        show(r.querySelector('.tc-scene-arrow'), 7.45, -10, 0, 0.14, 0);
        pop(r.querySelector('.tc-stuck-chip'), 7.88, -2, 0);
        show(r.querySelector('.tc-intro-lead'), 9.28, 0, 14, 0.16, 0);
      }
      const taskTimes = [10.61, 11.09, 11.65, 12.09, 13.01, 13.61];
      r.querySelectorAll('[data-task-index]').forEach((node, i) => {
        const at = taskTimes[i];
        const u = all ? 1 : backOut((t - at) / 0.15);
        const vis = all ? 1 : clamp((t - at) / 0.06);
        const hot = !all && t >= at && t < at + 0.38;
        node.classList.remove('is-ghost');
        node.classList.toggle('is-hot', hot);
        node.style.opacity = String(vis.toFixed(3));
        node.style.transform = `translateY(${(1 - Math.min(1, u)) * 22}px) scale(${(0.72 + 0.28 * u).toFixed(3)})`;
        setRipple(node.querySelector('.beat-ripple'), t, at, 0.42, all);
      });
      show(r.querySelector('.tc-stress-bar'), 12.00, 0, 14, 0.16, 0);
      const fill = r.querySelector('.tc-fill');
      if (fill) fill.style.width = (within(12.05, 2.2) * 100).toFixed(1) + '%';
    }

    // 3. step-one：先左卡，甩镜后再出右卡
    r = root('step-one');
    if (r) {
      show(r.querySelector('.s1-left'), 19.45, -18, 0, 0.16, 0);
      const typed = r.querySelector('.typed-chars');
      const cursor = r.querySelector('.pen-cursor');
      if (typed) {
        const full = typed.dataset.type || '一句话';
        const s = Number(typed.dataset.start), e = Number(typed.dataset.end);
        const count = all ? full.length : Math.floor(clamp((t - s) / Math.max(0.05, e - s)) * full.length + 0.999);
        typed.textContent = full.slice(0, t < s && !all ? 0 : Math.min(full.length, count));
        if (cursor) cursor.style.opacity = (!all && t >= s && t < e + 0.45) ? String(0.5 + 0.5 * Math.cos((t - s) * 16)) : '0';
      }
      pop(r.querySelector('.s1-strike-badge'), 22.13, 0, 0);
      show(r.querySelector('.s1-right'), 23.62, 22, 0, 0.16, 0);
      setDraw(r.querySelector('.hand-oval path'), within(24.85, 0.30));
      setRipple(r.querySelector('.circle-emphasis .beat-ripple'), t, 24.95, 0.48, all);
    }

    // 4. step-two：三段逐拍弹出
    r = root('step-two');
    if (r) {
      pop(r.querySelector('.s2-card.own'), 28.20, 0, 0);
      pop(r.querySelector('.s2-card.compare'), 29.60, 0, 0);
      show(r.querySelector('.s2-footer'), 31.45, 0, 18, 0.16, 0);
      setRipple(r.querySelector('.s2-footer .beat-ripple'), t, 31.6, 0.48, all);
    }

    // 5. step-three：公式 + 声波 + 砸印章 + 便签
    r = root('step-three');
    if (r) {
      const timer = r.querySelector('.s3-timer');
      if (timer) {
        const sec = all ? 35 : Math.floor(within(33.5, 4.5) * 35);
        timer.textContent = `00:${String(sec).padStart(2, '0')}`;
      }
      show(r.querySelector('.s3-pills'), 33.05, 0, 14, 0.15, 0);
      show(r.querySelector('.record-wave'), 33.80, 0, 12, 0.15, 0);
      r.querySelectorAll('[data-wave-index]').forEach(bar => {
        const i = Number(bar.dataset.waveIndex);
        const active = all ? 0.6 : (t >= 34.0 && t < 38.0 ? (0.32 + 0.68 * Math.abs(Math.sin(t * 11.5 + i * 0.72))) : 0.2);
        bar.style.height = (10 + active * (24 + Math.sin(i * 2.1) ** 2 * 38)) + 'px';
      });
      slam(r.querySelector('.vermilion-stamp'), 35.8, -2, 0);
      setRipple(r.querySelector('.vermilion-stamp .beat-ripple'), t, 35.84, 0.55, all);
      pop(r.querySelector('.s3-fix1'), 36.85, -3, 0);
      pop(r.querySelector('.s3-fix2'), 38.45, 3, 0);
    }

    // 6. revision：左空白 → 右对比面板 + 红笔划改
    r = root('revision');
    if (r) {
      show(r.querySelector('.rev-blank'), 42.50, -18, 0, 0.16, 0);
      show(r.querySelector('.rev-diff'), 44.80, 22, 0, 0.16, 0);
      setDraw(r.querySelector('.strike-svg path'), within(45.18, 0.20));
      pop(r.querySelector('.proof-new'), 45.35, 0, 0);
      const rows = r.querySelectorAll('.proof-row');
      if (rows[1]) pop(rows[1], 46.25, 0, 0);
      setRipple(r.querySelector('.proof-row .beat-ripple'), t, 46.42, 0.48, all);
    }

    // 7. make-smaller：上下两行先后长出
    r = root('make-smaller');
    if (r) {
      show(r.querySelector('.shrink-row.writing'), 49.50, -18, 0, 0.15, 0);
      show(r.querySelector('.shrink-row.recording'), 51.60, -18, 0, 0.15, 0);
      for (const [sel, at] of [['.writing', 50.48], ['.recording', 52.55]]) {
        const row = r.querySelector(sel);
        if (!row) continue;
        pop(row.querySelector('.mini-block'), at, 0, 0);
        setRipple(row.querySelector('.beat-ripple'), t, at + 0.04, 0.48, all);
      }
    }
  }

  window.SmallStepDiagrams = { html, render };
})();
