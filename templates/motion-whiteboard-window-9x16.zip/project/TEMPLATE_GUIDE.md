# XYCut Motion 快节奏白板流模板指南（9:16 竖屏中轴双态）

- **推荐模板 ID**：`motion-whiteboard-window-9x16`
- **展示名称**：`极客白板流 · 人物小窗`
- **画幅与帧率**：`1080×1920 @ 25fps`（`presentation_mode: "portrait"`, `narrative_mode: "presenter-led"`）
- **适用场景**：短视频干货口播、效率方法论、AI 工作流拆解、高完播率信息流内容

## 1. 核心三段式构图规范
- **顶部固定标题区（`y: 126..374`）**：无浏览器外壳，干净居中主标题 `<header id="film-title" class="m9-top-title">`，4 个文字块全部绑定 `data-preview-text` 与 `data-preview-label`，支持右侧工作台实时修改与「显示片内标题」一键开关。
- **中部无边界 1:1 饱满主画布（`framing.content_rect: {x: 32, y: 395, width: 1016, height: 900}`）**：左右均匀保留 `32px` 安全边距，上下采用柔和羽化遮罩（无硬矩形外框），组件按 `900×760`–`940×780` 方形饱满比例纵向/2×3 排版，字号更大更易读。
- **中轴极简双态人物（零左右跳脱）**：
  - **常规态**：固定于画布下沿正中、字幕正上方的 `160×160` 圆形头像（`x: 460, y: 1320`），外圈配 `#presenter-ring` 电光蓝细光圈随口播句段呼吸；
  - **压场态**：在 `impact_sections`（炭黑 / 电光蓝微点阵）沿画面中轴线垂直上浮放大为 `600×800` 居中大竖卡 + 3 圈同心扩散冲击波纹。
- **3:4 居中封面 + 零闪烁胶囊字幕**：前 5 帧封面居中于 `3:4` 安全区（`848×1130`）；底部字幕位于 `bottom: 300`，隐藏 `.canvas-caption-shade` 避免句间阴影闪烁。

## 2. 快节奏动效标准
- **22 镜头极速调度**：`move` 压缩至 `0.22–0.28s`（比横屏快约 10%），每 `2.5–3s` 一次局部 `focuses` 推拉/甩镜；
- **零提前剧透 + DOM 实时框选**：复用标准 `assets/full-diagrams.js`（`floor = 0`）与 `assets/collab-cursors.js`（`getBoundingClientRect()` 实时测量 + `gridTemplateColumns` 自适应 2/3 列网格），配合 12 处火花、11 处震动与 46 处 UI 音效。

## 3. 复用与替换清单
- `assets/presenter.mp4` / `assets/cover-portrait.jpg` / `assets/preview-mix.m4a`；
- `final-timeline.json`、`canvas-plan.json` / `canvas-plan.js`；
- 顶部标题文案可直接在右侧工作台「封面、标题与字幕」中实时试改。
