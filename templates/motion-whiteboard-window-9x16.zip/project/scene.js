(() => {
  'use strict';
  const P = window.CANVAS_PLAN;
  const $ = s => document.querySelector(s);
  const stage = $('#stage');
  const world = $('#world');
  const video = $('#presenter-video');
  const voice = $('#voice');
  const renderMode = new URLSearchParams(location.search).get('render') === '1';
  if (renderMode) document.body.classList.add('render-mode');
  document.body.classList.add('mode-portrait');

  const clamp = x => Math.max(0, Math.min(1, x));
  const smooth = x => { x = clamp(x); return x * x * (3 - 2 * x); };
  const expoOut = x => { x = clamp(x); return x <= 0 ? 0 : x >= 1 ? 1 : 1 - Math.pow(2, -10 * x); };
  const mix = (a, b, u) => a + (b - a) * u;
  const originalLead = P.intro?.duration || 0;

  let time = 0, lead = originalLead, coverEnabled = true, mode = 'demo', playing = false;
  let freeCamera = null, frame = 0, lastSync = 0, seekQueue = Promise.resolve();
  let viewport = { ...P.output }, browseTarget = 'overview', segment = null, selected = '';
  let tool = 'select', drag = null, spaceDown = false, lastTapTarget = null;

  const duration = () => P.content_duration + lead;
  const audioOffset = () => originalLead - lead;
  const bodyTime = () => Math.max(0, time - lead);

  world.style.width = P.world.width + 'px';
  world.style.height = P.world.height + 'px';

  // World-level dashed connecting wires between the 3 boards (visible during overview zoom-outs)
  const wiresSvg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  wiresSvg.setAttribute('class', 'world-wires');
  wiresSvg.setAttribute('viewBox', `0 0 ${P.world.width} ${P.world.height}`);
  wiresSvg.innerHTML = `
    <path d="M2200 840 C2260 840, 2300 840, 2360 840"/>
    <path d="M3600 1700 C3600 1750, 3600 1790, 3600 1840"/>
  `;
  world.append(wiresSvg);

  // 画布外围轻量 Figma 流程徽章（严格避开组件区域）
  for (const deco of [
    { x: 1240, y: 280, text: '⚡ 快节奏拆解' },
    { x: 2160, y: 770, text: '01 → 02 拆解' },
    { x: 3480, y: 1740, text: '02 → 03 迭代' },
    { x: 2540, y: 2040, text: '✓ 最小可执行' }
  ]) {
    const chip = document.createElement('div');
    chip.className = 'wb-deco-chip';
    chip.textContent = deco.text;
    Object.assign(chip.style, { left: deco.x + 'px', top: deco.y + 'px' });
    world.append(chip);
  }

  for (const b of P.boards) {
    const boardEl = document.createElement('div');
    boardEl.className = 'board-frame';
    boardEl.dataset.board = b.id;
    Object.assign(boardEl.style, { left: b.x + 'px', top: b.y + 'px', width: b.width + 'px', height: b.height + 'px' });
    const label = document.createElement('div');
    label.className = 'board-frame-label';
    label.textContent = b.name || b.id;
    boardEl.append(label);
    world.append(boardEl);
  }

  const elements = new Map();
  for (const c of P.components) {
    const el = document.createElement('section');
    el.className = 'component';
    el.dataset.component = c.id;
    const board = P.boards.find(b => b.id === c.board_id);
    Object.assign(el.style, {
      left: (board.x + c.bounds.x) + 'px',
      top: (board.y + c.bounds.y) + 'px',
      width: c.bounds.width + 'px',
      height: c.bounds.height + 'px'
    });
    el.innerHTML = SmallStepDiagrams.html[c.id] || '';
    world.append(el);
    elements.set(c.id, el);
  }

  const waveBox = $('#wb-waveform');
  const waveBars = [];
  if (waveBox) {
    for (let i = 0; i < 24; i++) {
      const bar = document.createElement('i');
      waveBox.append(bar);
      waveBars.push(bar);
    }
  }

  window.CanvasScene = { elements, render: t => draw(t + lead) };
  const captions = window.CanvasSubtitles = CanvasSubtitleTrack.create({
    stage,
    timeline: FINAL_TIMELINE,
    output: P.output,
    config: P.subtitle_settings,
    isBrowsing: () => mode === 'browse',
    requestRender: () => draw(time)
  });

  function cameraAt(t) {
    if (segment && P.components.some(c => c.id === segment.target)) {
      const fitted = CanvasCamera.fit(CanvasCamera.bounds(P, segment.target), P.output, 0.06);
      fitted.scale *= 0.94;
      return { ...fitted, shot: { target: segment.target }, index: 0, u: 1 };
    }
    return CanvasCamera.at(P, t);
  }

  function poseAt(t) {
    const poses = P.presenter_layout.poses || [];
    if (!poses.length) return { x: 1324, y: 74, width: 556, height: 856, radius: 24, tool: 0 };
    if (t <= poses[0].t) return poses[0];
    if (t >= poses[poses.length - 1].t) return poses[poses.length - 1];
    let idx = 0;
    for (let i = 1; i < poses.length; i++) {
      if (t < poses[i].t) { idx = i - 1; break; }
    }
    const a = poses[idx], b = poses[idx + 1];
    const span = Math.min(0.36, Math.max(0.14, b.t - a.t));
    const u = smooth((t - Math.max(a.t, b.t - span)) / span);
    return {
      x: mix(a.x, b.x, u),
      y: mix(a.y, b.y, u),
      width: mix(a.width, b.width, u),
      height: mix(a.height, b.height, u),
      radius: mix(a.radius, b.radius, u),
      tool: u > 0.5 ? (b.tool ?? 0) : (a.tool ?? 0)
    };
  }

  function impactAt(t) {
    for (const s of (P.impact_sections || [])) {
      if (t >= s.start - 0.10 && t <= s.end + 0.10) {
        const enter = expoOut((t - (s.start - 0.10)) / 0.13);
        const exit = 1 - expoOut((t - (s.end - 0.03)) / 0.13);
        return { alpha: Math.min(enter, exit), enter, section: s };
      }
    }
    return { alpha: 0, enter: 1, section: null };
  }

  const shakeBeats = [
    [2.49, 5, 0.16], [3.20, 5.5, 0.16], [13.61, 9, 0.22], [14.41, 13, 0.26],
    [24.95, 7, 0.18], [31.60, 6.5, 0.18], [35.80, 12, 0.26], [45.18, 7.5, 0.18],
    [50.48, 6, 0.16], [52.55, 6.5, 0.16], [53.92, 13, 0.26]
  ];
  function shakeAt(t) {
    let sx = 0, sy = 0, rot = 0;
    for (const [at, amp, dur] of shakeBeats) {
      if (t >= at && t <= at + dur) {
        const u = (t - at) / dur;
        const decay = Math.exp(-9 * u);
        sx += amp * decay * Math.sin(58 * u);
        sy += amp * decay * Math.cos(74 * u) * 0.78;
        rot += amp * 0.045 * decay * Math.sin(48 * u);
      }
    }
    return { sx, sy, rot };
  }

  function applyAttention(t, cam, browsing) {
    const idx = cam.index ?? 0;
    const shot = cam.shot || P.shots[idx];
    const prior = P.shots[Math.max(0, idx - 1)];
    const u = browsing ? 1 : smooth(cam.u ?? 1);
    const targetId = shot?.target?.split('/')[0];
    const priorId = prior?.target?.split('/')[0];
    const isOverview = targetId === 'overview';
    const targetComp = P.components.find(c => c.id === targetId);
    const activeBoard = targetComp?.board_id;
    const pixelScale = browsing ? 1 : Math.max(0.4, cam.scale || 1);

    for (const c of P.components) {
      const el = elements.get(c.id);
      if (browsing || isOverview) {
        el.style.opacity = '1';
        el.style.filter = 'none';
        continue;
      }
      const weight = Math.min(1, (c.id === priorId ? 1 - u : 0) + (c.id === targetId ? u : 0));
      const sameBoard = c.board_id === activeBoard;
      const blur = ((sameBoard ? 3.8 : 5.5) / pixelScale) * (1 - weight);
      const baseOpacity = sameBoard ? 0.34 : 0.18;
      el.style.opacity = String(baseOpacity + (1 - baseOpacity) * weight);
      el.style.filter = weight > 0.995
        ? 'none'
        : `saturate(${(0.55 + 0.45 * weight).toFixed(3)}) blur(${blur.toFixed(2)}px)`;
    }
  }

  function draw(presentationTime) {
    time = Math.max(0, Math.min(duration(), presentationTime));
    const t = bodyTime();
    const browsing = mode === 'browse';
    const cam = browsing ? freeCamera : cameraAt(t);
    const activeShake = (browsing || time < lead) ? { sx: 0, sy: 0, rot: 0 } : shakeAt(t);
    const whipSpeed = browsing ? 0 : (cam.speed || 0);

    const camMatrix = CanvasCamera.matrix(cam, browsing ? viewport : P.output);
    world.style.transform = whipSpeed > 0.15
      ? `${camMatrix} skewX(${(whipSpeed * 1.1).toFixed(2)}deg)`
      : camMatrix;
    world.style.filter = whipSpeed > 0.15
      ? `blur(${(whipSpeed * 1.35).toFixed(2)}px)`
      : 'none';

    const vp = $('#canvas-viewport');
    if (vp) {
      vp.style.transform = (Math.abs(activeShake.sx) > 0.05 || Math.abs(activeShake.sy) > 0.05)
        ? `translate(${activeShake.sx.toFixed(2)}px, ${activeShake.sy.toFixed(2)}px) rotate(${activeShake.rot.toFixed(3)}deg)`
        : 'none';
    }
    const current = cam.shot?.target;

    stage.style.setProperty('--canvas-mix', '1');
    stage.classList.add('canvas-active');

    applyAttention(t, cam, browsing);

    const imp = browsing || time < lead ? { alpha: 0, enter: 1, section: null } : impactAt(t);
    const pose = poseAt(t);
    const box = $('#presenter');
    Object.assign(box.style, {
      left: (pose.x + activeShake.sx * 0.35).toFixed(1) + 'px',
      top: (pose.y + activeShake.sy * 0.35).toFixed(1) + 'px',
      width: pose.width.toFixed(1) + 'px',
      height: pose.height.toFixed(1) + 'px',
      borderRadius: pose.radius.toFixed(1) + 'px',
      transform: 'none'
    });
    const vw = pose.width * 1.15;
    const vh = vw * 1920 / 1080;
    Object.assign(video.style, {
      width: vw.toFixed(1) + 'px',
      height: vh.toFixed(1) + 'px',
      left: (-(vw - pose.width) / 2).toFixed(1) + 'px',
      top: (-vh * 0.11).toFixed(1) + 'px'
    });

    const ringEl = $('#presenter-ring');
    if (ringEl) {
      if (browsing || time < lead || imp.alpha > 0.18 || pose.width > 220) {
        ringEl.style.opacity = '0';
      } else {
        const speaking = FINAL_TIMELINE.lines.some(l => t >= l.target_start_ms / 1000 && t <= l.target_end_ms / 1000);
        const pulse = speaking ? (0.5 + 0.5 * Math.sin(t * 10.5)) : (0.3 + 0.2 * Math.sin(t * 3.5));
        const sc = 1.04 + pulse * 0.14;
        const op = speaking ? (0.35 + pulse * 0.38) : 0.28;
        Object.assign(ringEl.style, {
          left: (pose.x + activeShake.sx * 0.35).toFixed(1) + 'px',
          top: (pose.y + activeShake.sy * 0.35).toFixed(1) + 'px',
          width: pose.width.toFixed(1) + 'px',
          height: pose.height.toFixed(1) + 'px',
          opacity: op.toFixed(3),
          transform: `scale(${sc.toFixed(3)})`
        });
      }
    }

    document.body.classList.toggle('impact-active', imp.alpha > 0.35);
    const impEl = $('#wb-impact');
    if (impEl) {
      impEl.style.opacity = imp.alpha.toFixed(3);
      impEl.style.transform = (Math.abs(activeShake.sx) > 0.05 || Math.abs(activeShake.sy) > 0.05)
        ? `translate(${activeShake.sx.toFixed(2)}px, ${activeShake.sy.toFixed(2)}px) rotate(${activeShake.rot.toFixed(3)}deg)`
        : 'none';
      if (imp.section) {
        impEl.dataset.tone = imp.section.tone || 'blue';
        $('#wb-impact-kicker').textContent = imp.section.kicker;
        const wordEl = $('#wb-impact-word');
        const rightEl = impEl.querySelector('.wb-impact-right');
        const slamScale = (1.12 - 0.12 * imp.enter).toFixed(3);
        wordEl.textContent = imp.section.left_word;
        wordEl.style.transform = `scale(${slamScale})`;
        $('#wb-impact-main').innerHTML = imp.section.title;
        $('#wb-impact-sub').textContent = imp.section.sub;
        if (rightEl) rightEl.style.transform = `scale(${(1.06 - 0.06 * imp.enter).toFixed(3)})`;
        impEl.querySelectorAll('.wb-shockwaves i').forEach((ring, idx) => {
          const phase = ((t * 0.9) + idx * 0.333) % 1;
          const sc = (0.65 + phase * 1.50).toFixed(3);
          const op = (Math.sin(Math.PI * phase) * 0.44).toFixed(3);
          ring.style.opacity = op;
          ring.style.transform = `scale(${sc})`;
        });
      }
    }

    const zoomPill = $('#wb-zoom');
    if (zoomPill) zoomPill.textContent = Math.round((cam.scale || 1) * 100) + '%';
    const tcEl = $('#wb-tc');
    if (tcEl) {
      const mm = String(Math.floor(t / 60)).padStart(2, '0');
      const ss = String(Math.floor(t % 60)).padStart(2, '0');
      const ff = String(Math.floor((t % 1) * 25)).padStart(2, '0');
      tcEl.textContent = `${mm}:${ss}:${ff}`;
    }
    document.querySelectorAll('.wb-tool-btn').forEach((btn, idx) => {
      btn.classList.toggle('is-active', idx === (pose.tool ?? 0));
    });
    for (let i = 0; i < waveBars.length; i++) {
      const h = 6 + Math.abs(Math.sin(t * 7.8 + i * 0.65) * Math.cos(t * 3.4 + i * 0.4)) * 18;
      waveBars[i].style.height = h.toFixed(1) + 'px';
    }

    $('#cover').style.display = (!browsing && coverEnabled && time < lead) ? 'flex' : 'none';
    SmallStepDiagrams.render(t, { all: browsing });
    const selState = window.CollabCursors?.render(t, { browsing, cover: time < lead, impact: imp.alpha > 0.35 });
    const propPill = $('#wb-prop-pill');
    if (propPill) {
      if (imp.alpha > 0.35 && imp.section) {
        propPill.innerHTML = `<b>IMPACT</b><span>${imp.section.kicker}</span>`;
      } else if (selState) {
        propPill.innerHTML = `<b>SEL</b><span>${selState.label} · ${Math.round(selState.w)}×${Math.round(selState.h)}</span>`;
      } else {
        propPill.innerHTML = `<b>LAYER</b><span>${cam.shot?.label || 'Canvas'}</span>`;
      }
    }
    const dashTitle = $('#wb-dash-title');
    if (dashTitle) dashTitle.textContent = cam.shot?.label || '任务拆解';
    const dashKicker = $('#wb-dash-kicker');
    if (dashKicker) {
      const compId = current?.split('/')[0];
      const bName = P.components.find(c => c.id === compId)?.board_id;
      const bTitle = P.boards.find(b => b.id === bName)?.name;
      dashKicker.textContent = bTitle || 'OVERVIEW · 全局鸟瞰';
    }

    captions.render(t);
    captions.root.style.display = (time < lead || browsing || captions.getMode() === 'off') ? 'none' : 'block';
    const line = FINAL_TIMELINE.lines.find(l => l.line_id === captions.root.dataset.lineId);
    const entry = line ? smooth((t - line.target_start_ms / 1000) / 0.14) : 1;
    const lineNode = captions.root.querySelector('.canvas-caption-line');
    if (lineNode) lineNode.style.transform = `translateY(${(1 - entry) * 8}px)`;

    for (const el of stage.querySelectorAll('[id^="canvas-subtitles-"]')) {
      el.style.visibility = time < lead ? 'hidden' : 'visible';
    }

    if (!renderMode) {
      $('#seek').min = segment?.start || 0;
      $('#seek').max = segment?.end ?? duration();
      $('#seek').value = time;
      $('#time-label').textContent = segment
        ? (time - segment.start).toFixed(2) + ' / ' + (segment.end - segment.start).toFixed(2) + ' 秒'
        : time.toFixed(2) + ' / ' + duration().toFixed(2) + ' 秒';
      const activeChapter = P.chapters.filter(c => c.at <= t).at(-1);
      $('#current-chapter').textContent = segment ? '局部播放 · ' + segment.label : (activeChapter?.label || '');
      for (const b of document.querySelectorAll('.phases button')) {
        b.classList.toggle('current', Number(b.dataset.at) === activeChapter?.at);
      }
      $('#zoom-label').textContent = Math.round(cam.scale * 100) + '%';
      window.dispatchEvent(new CustomEvent('canvas-render', {
        detail: { time, bodyTime: t, mode: mode === 'browse' ? 'resource' : 'demo', playing, segment }
      }));
    }
    return { time, contentTime: t, small: 1, sourceTime: video.currentTime, shot: current };
  }

  function pause() {
    playing = false;
    voice.pause();
    video.pause();
    cancelAnimationFrame(frame);
    $('#play').textContent = '播放';
    if (!renderMode) {
      window.dispatchEvent(new CustomEvent('canvas-render', {
        detail: { time, bodyTime: bodyTime(), mode: mode === 'browse' ? 'resource' : 'demo', playing, segment }
      }));
    }
  }

  async function mediaSeek(target) {
    const t = Math.max(0, Math.min(P.content_duration - 0.001, target));
    if (Math.abs(video.currentTime - t) < 0.018 && video.readyState >= 2) return;
    await new Promise((resolve, reject) => {
      const timeout = setTimeout(() => { cleanup(); reject(Error('人物源帧定位超时：' + t)); }, 9000);
      function cleanup() { clearTimeout(timeout); video.removeEventListener('seeked', done); video.removeEventListener('error', fail); }
      function done() { cleanup(); resolve(); }
      function fail() { cleanup(); reject(Error('人物素材加载失败')); }
      video.addEventListener('seeked', done, { once: true });
      video.addEventListener('error', fail, { once: true });
      video.currentTime = t;
    });
    if (video.requestVideoFrameCallback) {
      await new Promise(resolve => {
        const timer = setTimeout(resolve, 120);
        video.requestVideoFrameCallback(() => { clearTimeout(timer); resolve(); });
      });
    }
  }

  function setMode(next) {
    const changed = next !== mode;
    mode = next;
    document.body.classList.toggle('resource-mode', mode === 'browse');
    document.body.classList.toggle('demo-mode', mode === 'demo');
    resize();
    if (changed) window.dispatchEvent(new CustomEvent('canvas-mode-change', { detail: { mode: mode === 'browse' ? 'resource' : 'demo' } }));
  }

  async function position(target, { keepSegment = false } = {}) {
    pause();
    if (!keepSegment) segment = null;
    setMode('demo');
    time = Math.max(0, Math.min(duration(), target));
    await mediaSeek(bodyTime());
    voice.currentTime = time + audioOffset();
    return draw(time);
  }

  function seek(target, options) {
    seekQueue = seekQueue.catch(() => {}).then(() => position(target, options));
    return seekQueue;
  }

  window.END = duration();
  window.renderAt = target => seek(target);

  function tick() {
    if (!playing) return;
    draw(voice.currentTime - audioOffset());
    if (time >= lead && video.paused) video.play().catch(report);
    if (time >= lead && performance.now() - lastSync > 900 && Math.abs(video.currentTime - bodyTime()) > 0.14) {
      video.currentTime = bodyTime();
      lastSync = performance.now();
    }
    const end = segment?.end ?? duration();
    if (voice.ended || time >= end - 0.01) { pause(); draw(end); return; }
    frame = requestAnimationFrame(tick);
  }

  function report(e) { $('#review-status').textContent = e.message; console.error(e); }

  async function play() {
    if (playing) { pause(); return; }
    const end = segment?.end ?? duration(), start = segment?.start || 0;
    await seek(time >= end - 0.01 ? start : Math.max(start, time), { keepSegment: true });
    await voice.play();
    if (time >= lead) await video.play();
    playing = true;
    $('#play').textContent = '暂停';
    frame = requestAnimationFrame(tick);
  }

  function resize() {
    const work = $('.workspace');
    const w = renderMode ? P.output.width : work.clientWidth;
    const h = renderMode ? P.output.height : work.clientHeight;
    if (w <= 0 || h <= 0) return;
    viewport = mode === 'browse' && !renderMode ? { width: w, height: h } : { ...P.output };
    const scale = Math.min(w / viewport.width, h / viewport.height);
    Object.assign($('#screen').style, { width: w + 'px', height: h + 'px' });
    Object.assign(stage.style, {
      width: viewport.width + 'px',
      height: viewport.height + 'px',
      transform: `translate(${(w - viewport.width * scale) / 2}px,${(h - viewport.height * scale) / 2}px) scale(${scale})`
    });
  }

  function fitBrowse(target, padding = 0.06) { return CanvasCamera.fit(CanvasCamera.bounds(P, target), viewport, padding); }
  function browse() { pause(); segment = null; const entering = mode !== 'browse'; setMode('browse'); if (entering || !freeCamera) { browseTarget = 'overview'; freeCamera = fitBrowse('overview', 0.05); } draw(time); }
  function focus(id) { browse(); browseTarget = id; select(elements.has(id) ? id : ''); freeCamera = fitBrowse(id, id === 'overview' ? 0.05 : 0.08); draw(time); }
  function select(id) { if (id && !elements.has(id)) return; selected = id; for (const [key, el] of elements) el.classList.toggle('selected', key === id); window.dispatchEvent(new CustomEvent('canvas-selection', { detail: { id } })); }
  function setTool(next) { tool = next === 'pan' ? 'pan' : 'select'; document.body.classList.toggle('tool-pan', tool === 'pan'); window.dispatchEvent(new CustomEvent('canvas-tool-change', { detail: { tool } })); }

  async function preview(target) {
    const members = P.components.filter(c => c.id === target || c.board_id === target || target === 'overview');
    const ranges = members.map(c => c.preview_range).filter(Boolean);
    if (!ranges.length) return;
    pause();
    segment = {
      target,
      label: members.length === 1 ? members[0].content.title : P.boards.find(b => b.id === target)?.name || '完整项目',
      start: lead + Math.min(...ranges.map(r => r.start)),
      end: lead + Math.max(...ranges.map(r => r.end))
    };
    await seek(segment.start, { keepSegment: true });
    return play();
  }

  async function setCoverEnabled(enabled) {
    pause();
    const t = bodyTime();
    coverEnabled = !!enabled;
    lead = coverEnabled ? originalLead : 0;
    window.END = duration();
    segment = null;
    const result = await seek(t + lead);
    window.dispatchEvent(new CustomEvent('canvas-timing-change', { detail: { lead, audioOffset: audioOffset() } }));
    return result;
  }

  window.CanvasExplorer = {
    getMode: () => mode === 'browse' ? 'resource' : 'demo',
    getTime: () => time,
    getBodyTime: bodyTime,
    getView: () => ({ ...(mode === 'browse' ? freeCamera : cameraAt(bodyTime())) }),
    getSelected: () => selected,
    getTool: () => tool,
    getSegment: () => segment ? { ...segment } : null,
    getLead: () => lead,
    getAudioOffset: audioOffset,
    getCoverEnabled: () => coverEnabled,
    setCoverEnabled, pause, seek, focus, select, setTool, preview, play, browse,
    overview: () => focus('overview')
  };

  $('#play').onclick = () => play().catch(report);
  $('#replay').onclick = () => seek(segment?.start || 0, { keepSegment: true }).then(play).catch(report);
  $('#browse').onclick = browse;
  $('#overview').onclick = () => focus('overview');

  let requestedTime = null, uiSeeking = false;
  $('#seek').oninput = async () => {
    requestedTime = Number($('#seek').value);
    pause();
    if (uiSeeking) return;
    uiSeeking = true;
    try {
      while (requestedTime !== null) {
        const target = requestedTime;
        requestedTime = null;
        await seek(target, { keepSegment: true });
      }
    } catch (e) { report(e); } finally { uiSeeking = false; }
  };

  $('#subtitle-mode').onchange = () => captions.setMode($('#subtitle-mode').value);

  $('#voice-only').onchange = async () => {
    pause();
    const at = time;
    const loaded = new Promise(resolve => voice.addEventListener('loadedmetadata', resolve, { once: true }));
    voice.src = $('#voice-only').checked ? 'assets/voice-aligned.m4a' : 'assets/preview-mix.m4a';
    await loaded;
    voice.currentTime = at + audioOffset();
  };

  for (const c of P.chapters) {
    const b = document.createElement('button');
    b.dataset.at = c.at;
    b.title = c.label;
    b.innerHTML = `<span>${c.at.toFixed(1)}s</span><b>${c.label}</b>`;
    b.onclick = () => seek(c.at + lead).catch(report);
    $('.phases').append(b);
  }

  function zoom(factor, point) {
    if (mode !== 'browse') browse();
    browseTarget = null;
    const old = freeCamera.scale;
    const next = Math.max(0.065, Math.min(6, old * factor));
    const p = point || { x: viewport.width / 2, y: viewport.height / 2 };
    freeCamera.cx += (p.x - viewport.width / 2) * (1 / old - 1 / next);
    freeCamera.cy += (p.y - viewport.height / 2) * (1 / old - 1 / next);
    freeCamera.scale = next;
    draw(time);
  }
  $('#zoom-in').onclick = () => zoom(1.3);
  $('#zoom-out').onclick = () => zoom(1 / 1.3);

  const screen = $('#screen');
  screen.addEventListener('pointerdown', e => {
    if (renderMode || ![0, 1].includes(e.button)) return;
    pause();
    const pan = tool === 'pan' || e.button === 1;
    if (pan && mode !== 'browse') browse();
    drag = { id: e.pointerId, x: e.clientX, y: e.clientY, camera: { ...(freeCamera || cameraAt(bodyTime())) }, target: e.target, moved: false, pan };
    screen.setPointerCapture(e.pointerId);
    if (pan) screen.classList.add('dragging');
  });
  screen.addEventListener('pointermove', e => {
    if (!drag || drag.id !== e.pointerId) return;
    const dx = e.clientX - drag.x, dy = e.clientY - drag.y;
    if (Math.hypot(dx, dy) > 6) drag.moved = true;
    if (!drag.pan) return;
    browseTarget = null;
    freeCamera = { ...drag.camera, cx: drag.camera.cx - dx / drag.camera.scale, cy: drag.camera.cy - dy / drag.camera.scale };
    draw(time);
  });
  function endDrag(e, cancelled = false) {
    if (!drag || drag.id !== e.pointerId) return;
    const previous = drag;
    drag = null;
    screen.classList.remove('dragging');
    lastTapTarget = !cancelled && !previous.pan && !previous.moved ? previous.target : null;
    if (lastTapTarget) {
      const el = lastTapTarget.closest('[data-component]');
      if (el) {
        select(el.dataset.component);
        window.dispatchEvent(new CustomEvent('canvas-review-request', { detail: { id: el.dataset.component, point: { x: e.clientX, y: e.clientY } } }));
      }
    }
  }
  screen.addEventListener('pointerup', e => endDrag(e));
  screen.addEventListener('pointercancel', e => endDrag(e, true));
  screen.addEventListener('lostpointercapture', e => endDrag(e, true));
  screen.addEventListener('wheel', e => {
    if (renderMode) return;
    e.preventDefault();
    if (mode !== 'browse') browse();
    const r = screen.getBoundingClientRect();
    zoom(Math.exp(-e.deltaY * 0.0013), { x: e.clientX - r.left, y: e.clientY - r.top });
  }, { passive: false });
  screen.addEventListener('dblclick', e => {
    if (renderMode) return;
    const el = e.target.closest('[data-component]') || lastTapTarget?.closest('[data-component]');
    if (el) focus(el.dataset.component);
  });

  const isEditing = e => e.target.closest('input,textarea,select,[contenteditable="true"],[role="dialog"]');
  document.addEventListener('keydown', e => {
    if (renderMode || isEditing(e)) return;
    if (e.code === 'Space') { e.preventDefault(); spaceDown = true; setTool('pan'); }
    else if (e.key.toLowerCase() === 'f') { e.preventDefault(); focus('overview'); }
  });
  document.addEventListener('keyup', e => { if (e.code === 'Space' && spaceDown) { e.preventDefault(); spaceDown = false; setTool('select'); } });
  window.addEventListener('blur', () => { spaceDown = false; setTool('select'); if (drag) endDrag({ pointerId: drag.id }, true); });
  voice.addEventListener('ended', () => { pause(); draw(segment?.end ?? duration()); });
  window.addEventListener('resize', () => { resize(); if (mode === 'browse' && browseTarget) freeCamera = fitBrowse(browseTarget, browseTarget === 'overview' ? 0.05 : 0.08); draw(time); });

  const loaded = el => el.readyState >= 2 ? Promise.resolve() : new Promise((resolve, reject) => {
    el.addEventListener('loadeddata', resolve, { once: true });
    el.addEventListener('error', () => reject(Error('媒体加载失败：' + el.src)), { once: true });
  });
  window.READY = Promise.all([loaded(video), loaded(voice), document.fonts.ready]).then(() => { setMode('demo'); return seek(0); });
  window.PREVIEW_STATE = () => ({
    time, bodyTime: bodyTime(), lead, audioOffset: audioOffset(), mode, playing, segment,
    viewport: { ...viewport }, videoTime: video.currentTime, audioTime: voice.currentTime,
    videoReady: video.readyState, audioReady: voice.readyState
  });
})();
