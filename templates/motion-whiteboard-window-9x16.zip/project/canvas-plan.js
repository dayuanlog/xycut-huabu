window.CANVAS_PLAN = {
  "id": "small-step-motion-9x16",
  "theme_key": "motion-9x16",
  "output": {
    "width": 1080,
    "height": 1920,
    "fps": 25
  },
  "world": {
    "width": 5560,
    "height": 3500
  },
  "duration": 62.32,
  "content_duration": 62.12,
  "intro": {
    "frames": 5,
    "duration": 0.2
  },
  "presentation_mode": "portrait",
  "narrative_mode": "presenter-led",
  "framing": {
    "mode": "custom",
    "content_rect": {
      "x": 32,
      "y": 395,
      "width": 1016,
      "height": 900
    }
  },
  "series": {
    "title": "任务太大，迟迟没开始？",
    "subtitle": "先把第一步缩小",
    "cover_lines": [
      "任务太大，",
      "先缩小一步"
    ]
  },
  "theme": {
    "background": "#f6f8fb",
    "foreground": "#141923",
    "accent": "#1d5eff"
  },
  "timing_precision": "cloud-asr-word",
  "timeline_revision": "sha256:5adc785d29189a6de7e995291e28fa7f32913972fef14d81d78821625256785e",
  "boards": [
    {
      "id": "board-1",
      "name": "01 为什么迟迟不开始",
      "x": 80,
      "y": 80,
      "width": 2120,
      "height": 1520
    },
    {
      "id": "board-2",
      "name": "02 先做三步",
      "x": 2360,
      "y": 80,
      "width": 3080,
      "height": 1620
    },
    {
      "id": "board-3",
      "name": "03 具体修改与继续拆小",
      "x": 2360,
      "y": 1840,
      "width": 2240,
      "height": 1560
    }
  ],
  "components": [
    {
      "id": "opening-question",
      "board_id": "board-1",
      "kind": "custom",
      "module_source": "assets/full-diagrams.js",
      "bounds": {
        "x": 60,
        "y": 60,
        "width": 900,
        "height": 760
      },
      "content": {
        "title": "完美主义拖延症"
      },
      "focuses": [
        {
          "id": "bottom",
          "bounds": {
            "x": 20,
            "y": 360,
            "width": 860,
            "height": 370
          },
          "label": "底部流程与便利贴"
        }
      ],
      "preview_range": {
        "start": 0,
        "end": 4.2
      }
    },
    {
      "id": "task-chain",
      "board_id": "board-1",
      "kind": "custom",
      "module_source": "assets/full-diagrams.js",
      "bounds": {
        "x": 1100,
        "y": 640,
        "width": 940,
        "height": 780
      },
      "content": {
        "title": "6 项隐形任务"
      },
      "focuses": [
        {
          "id": "row1",
          "bounds": {
            "x": 24,
            "y": 210,
            "width": 892,
            "height": 330
          },
          "label": "前四项隐形任务"
        },
        {
          "id": "row2",
          "bounds": {
            "x": 24,
            "y": 400,
            "width": 892,
            "height": 350
          },
          "label": "后段任务与负荷条"
        }
      ],
      "preview_range": {
        "start": 5.3,
        "end": 14.3
      }
    },
    {
      "id": "step-one",
      "board_id": "board-2",
      "kind": "custom",
      "module_source": "assets/full-diagrams.js",
      "bounds": {
        "x": 60,
        "y": 60,
        "width": 900,
        "height": 760
      },
      "content": {
        "title": "第一步：一个观点"
      },
      "focuses": [
        {
          "id": "left",
          "bounds": {
            "x": 24,
            "y": 120,
            "width": 852,
            "height": 300
          },
          "label": "核心输出区"
        },
        {
          "id": "right",
          "bounds": {
            "x": 24,
            "y": 430,
            "width": 852,
            "height": 310
          },
          "label": "记住什么圈点"
        }
      ],
      "preview_range": {
        "start": 19.4,
        "end": 26.4
      }
    },
    {
      "id": "step-two",
      "board_id": "board-2",
      "kind": "custom",
      "module_source": "assets/full-diagrams.js",
      "bounds": {
        "x": 1080,
        "y": 740,
        "width": 900,
        "height": 760
      },
      "content": {
        "title": "第二步：一个例子"
      },
      "focuses": [
        {
          "id": "own",
          "bounds": {
            "x": 24,
            "y": 115,
            "width": 852,
            "height": 260
          },
          "label": "方式 A 自己的经历"
        },
        {
          "id": "compare",
          "bounds": {
            "x": 24,
            "y": 380,
            "width": 852,
            "height": 260
          },
          "label": "方式 B 两种做法对比"
        }
      ],
      "preview_range": {
        "start": 26.45,
        "end": 32.8
      }
    },
    {
      "id": "step-three",
      "board_id": "board-2",
      "kind": "custom",
      "module_source": "assets/full-diagrams.js",
      "bounds": {
        "x": 2100,
        "y": 60,
        "width": 900,
        "height": 760
      },
      "content": {
        "title": "第三步：第一版"
      },
      "focuses": [
        {
          "id": "stamp",
          "bounds": {
            "x": 24,
            "y": 440,
            "width": 852,
            "height": 300
          },
          "label": "第一版印章落槌"
        }
      ],
      "preview_range": {
        "start": 32.85,
        "end": 40.2
      }
    },
    {
      "id": "revision",
      "board_id": "board-3",
      "kind": "custom",
      "module_source": "assets/full-diagrams.js",
      "bounds": {
        "x": 1220,
        "y": 60,
        "width": 920,
        "height": 760
      },
      "content": {
        "title": "问题变具体：缩短与补充"
      },
      "focuses": [
        {
          "id": "diff",
          "bounds": {
            "x": 24,
            "y": 340,
            "width": 872,
            "height": 390
          },
          "label": "红笔划改与补充"
        }
      ],
      "preview_range": {
        "start": 42.4,
        "end": 49.3
      }
    },
    {
      "id": "make-smaller",
      "board_id": "board-3",
      "kind": "custom",
      "module_source": "assets/full-diagrams.js",
      "bounds": {
        "x": 80,
        "y": 700,
        "width": 920,
        "height": 760
      },
      "content": {
        "title": "继续缩小：一句与开头"
      },
      "focuses": [
        {
          "id": "top",
          "bounds": {
            "x": 24,
            "y": 140,
            "width": 872,
            "height": 270
          },
          "label": "先写一句"
        },
        {
          "id": "bottom",
          "bounds": {
            "x": 24,
            "y": 430,
            "width": 872,
            "height": 290
          },
          "label": "先录开头"
        }
      ],
      "preview_range": {
        "start": 49.4,
        "end": 53.8
      }
    }
  ],
  "shots": [
    {
      "id": "shot-opening",
      "target": "opening-question",
      "at": 0,
      "move": 0,
      "padding": 0.05,
      "context_scale": 0.94,
      "label": "开场白板"
    },
    {
      "id": "shot-opening-bottom",
      "target": "opening-question/bottom",
      "at": 1.95,
      "move": 0.24,
      "padding": 0.03,
      "context_scale": 0.96,
      "travel_scale": 0.9,
      "settle": 0.04,
      "label": "推近便利贴"
    },
    {
      "id": "shot-overview-0",
      "target": "overview",
      "at": 4.15,
      "move": 0.26,
      "padding": 0.03,
      "context_scale": 1.0,
      "travel_scale": 0.85,
      "settle": 0.035,
      "label": "鸟瞰：整条视频工程"
    },
    {
      "id": "shot-task",
      "target": "task-chain",
      "at": 5.3,
      "move": 0.28,
      "padding": 0.05,
      "context_scale": 0.94,
      "travel_scale": 0.85,
      "curve": 46,
      "settle": 0.045,
      "label": "6 项隐形任务"
    },
    {
      "id": "shot-task-row1",
      "target": "task-chain/row1",
      "at": 10.0,
      "move": 0.22,
      "padding": 0.03,
      "context_scale": 0.96,
      "travel_scale": 0.92,
      "settle": 0.04,
      "label": "跟焦任务网格"
    },
    {
      "id": "shot-task-row2",
      "target": "task-chain/row2",
      "at": 11.95,
      "move": 0.22,
      "padding": 0.03,
      "context_scale": 0.96,
      "travel_scale": 0.92,
      "settle": 0.04,
      "label": "跟焦超载警告"
    },
    {
      "id": "shot-overview-1",
      "target": "overview",
      "at": 17.2,
      "move": 0.24,
      "padding": 0.03,
      "context_scale": 1.0,
      "travel_scale": 0.85,
      "settle": 0.035,
      "label": "鸟瞰：先缩小三步"
    },
    {
      "id": "shot-step-one-left",
      "target": "step-one/left",
      "at": 19.35,
      "move": 0.26,
      "padding": 0.03,
      "context_scale": 0.96,
      "travel_scale": 0.85,
      "curve": -44,
      "settle": 0.045,
      "label": "第一步：只写一句话"
    },
    {
      "id": "shot-step-one-right",
      "target": "step-one/right",
      "at": 23.55,
      "move": 0.22,
      "padding": 0.03,
      "context_scale": 0.96,
      "travel_scale": 0.88,
      "curve": 28,
      "settle": 0.045,
      "label": "甩镜：记住什么？"
    },
    {
      "id": "shot-step-two",
      "target": "step-two",
      "at": 26.45,
      "move": 0.26,
      "padding": 0.05,
      "context_scale": 0.94,
      "travel_scale": 0.85,
      "curve": 52,
      "settle": 0.045,
      "label": "第二步：一个例子"
    },
    {
      "id": "shot-step-two-own",
      "target": "step-two/own",
      "at": 28.05,
      "move": 0.22,
      "padding": 0.035,
      "context_scale": 0.96,
      "travel_scale": 0.92,
      "settle": 0.04,
      "label": "方式 A：自己经历"
    },
    {
      "id": "shot-step-two-compare",
      "target": "step-two/compare",
      "at": 29.45,
      "move": 0.22,
      "padding": 0.035,
      "context_scale": 0.96,
      "travel_scale": 0.88,
      "curve": 24,
      "settle": 0.045,
      "label": "方式 B：做法对比"
    },
    {
      "id": "shot-step-two-out",
      "target": "step-two",
      "at": 31.15,
      "move": 0.22,
      "padding": 0.05,
      "context_scale": 0.94,
      "travel_scale": 0.92,
      "settle": 0.04,
      "label": "目标：听得明白"
    },
    {
      "id": "shot-step-three",
      "target": "step-three",
      "at": 32.85,
      "move": 0.24,
      "padding": 0.05,
      "context_scale": 0.94,
      "travel_scale": 0.85,
      "curve": -52,
      "settle": 0.045,
      "label": "第三步：录成第一版"
    },
    {
      "id": "shot-step-three-stamp",
      "target": "step-three/stamp",
      "at": 35.3,
      "move": 0.22,
      "padding": 0.03,
      "context_scale": 0.96,
      "travel_scale": 0.92,
      "settle": 0.045,
      "label": "推近第一版印章"
    },
    {
      "id": "shot-step-three-out",
      "target": "step-three",
      "at": 37.65,
      "move": 0.22,
      "padding": 0.05,
      "context_scale": 0.94,
      "travel_scale": 0.92,
      "settle": 0.04,
      "label": "不顺就改补一句"
    },
    {
      "id": "shot-overview-2",
      "target": "overview",
      "at": 40.3,
      "move": 0.24,
      "padding": 0.03,
      "context_scale": 1.0,
      "travel_scale": 0.85,
      "settle": 0.035,
      "label": "鸟瞰：有了第一版"
    },
    {
      "id": "shot-revision",
      "target": "revision",
      "at": 42.4,
      "move": 0.26,
      "padding": 0.05,
      "context_scale": 0.94,
      "travel_scale": 0.85,
      "curve": 44,
      "settle": 0.045,
      "label": "告别空白文档"
    },
    {
      "id": "shot-revision-diff",
      "target": "revision/diff",
      "at": 44.7,
      "move": 0.22,
      "padding": 0.03,
      "context_scale": 0.96,
      "travel_scale": 0.88,
      "curve": 24,
      "settle": 0.045,
      "label": "推近红笔划改"
    },
    {
      "id": "shot-make-smaller-top",
      "target": "make-smaller/top",
      "at": 49.4,
      "move": 0.24,
      "padding": 0.03,
      "context_scale": 0.96,
      "travel_scale": 0.85,
      "curve": -48,
      "settle": 0.045,
      "label": "继续拆小：先写一句"
    },
    {
      "id": "shot-make-smaller-bottom",
      "target": "make-smaller/bottom",
      "at": 51.55,
      "move": 0.22,
      "padding": 0.03,
      "context_scale": 0.96,
      "travel_scale": 0.92,
      "settle": 0.045,
      "label": "继续拆小：先录开头"
    },
    {
      "id": "shot-overview-end",
      "target": "overview",
      "at": 53.9,
      "move": 0.26,
      "padding": 0.03,
      "context_scale": 1.0,
      "travel_scale": 0.85,
      "settle": 0.035,
      "label": "蓝底收尾：先动起来"
    }
  ],
  "impact_sections": [
    {
      "start": 14.41,
      "end": 17.18,
      "tone": "charcoal",
      "kicker": "CORE INSIGHT",
      "left_word": "拆解",
      "title": "一整串<em>还没拆开</em>的任务",
      "sub": "别盯着整座山，先把第一步缩小"
    },
    {
      "start": 53.92,
      "end": 62.12,
      "tone": "blue",
      "kicker": "TAKE ACTION",
      "left_word": "开始",
      "title": "先让事情<em>有个开头</em>",
      "sub": "接下来的五分钟，你能先完成哪一个小动作？"
    }
  ],
  "presenter_layout": {
    "source": "assets/presenter.mp4",
    "voice": "assets/preview-mix.m4a",
    "source_mapping": "source_time = content_time",
    "poses": [
      {
        "t": 0.0,
        "x": 460,
        "y": 1320,
        "width": 160,
        "height": 160,
        "radius": 80,
        "tool": 0
      },
      {
        "t": 14.3,
        "x": 240,
        "y": 500,
        "width": 600,
        "height": 800,
        "radius": 28,
        "tool": 4
      },
      {
        "t": 17.2,
        "x": 460,
        "y": 1320,
        "width": 160,
        "height": 160,
        "radius": 80,
        "tool": 1
      },
      {
        "t": 53.9,
        "x": 240,
        "y": 500,
        "width": 600,
        "height": 800,
        "radius": 28,
        "tool": 4
      }
    ]
  },
  "beats": [
    {
      "component_id": "opening-question",
      "start": 0,
      "end": 4.2,
      "action": "semantic-diagram"
    },
    {
      "component_id": "task-chain",
      "start": 5.3,
      "end": 14.3,
      "action": "semantic-diagram"
    },
    {
      "component_id": "step-one",
      "start": 19.4,
      "end": 26.4,
      "action": "semantic-diagram"
    },
    {
      "component_id": "step-two",
      "start": 26.45,
      "end": 32.8,
      "action": "semantic-diagram"
    },
    {
      "component_id": "step-three",
      "start": 32.85,
      "end": 40.2,
      "action": "semantic-diagram"
    },
    {
      "component_id": "revision",
      "start": 42.4,
      "end": 49.3,
      "action": "semantic-diagram"
    },
    {
      "component_id": "make-smaller",
      "start": 49.4,
      "end": 53.8,
      "action": "semantic-diagram"
    }
  ],
  "subtitle_settings": {
    "mode": "emphasis",
    "reveal": "typewriter",
    "font_size": 46,
    "line_height": 1.35,
    "bottom": 300,
    "safe_bottom": 340,
    "margin_x": 56,
    "color": "#ffffff",
    "accent": "#ffd43b",
    "keywords": {
      "line_0009": [
        "选题",
        "写稿",
        "录音",
        "剪辑"
      ],
      "line_0010": [
        "字幕",
        "封面"
      ],
      "line_0016": [
        "观点"
      ],
      "line_0019": [
        "记住什么"
      ],
      "line_0021": [
        "具体"
      ],
      "line_0024": [
        "听得明白"
      ],
      "line_0028": [
        "第一版"
      ],
      "line_0035": [
        "缩短"
      ],
      "line_0036": [
        "补充"
      ],
      "line_0040": [
        "写一句"
      ],
      "line_0042": [
        "录个开头"
      ]
    },
    "strong_lines": [
      "line_0019",
      "line_0024",
      "line_0028"
    ],
    "display_aliases": {}
  },
  "caption_audio": {
    "emphasis": "assets/preview-mix.m4a",
    "normal": "assets/preview-mix.m4a",
    "off": "assets/preview-mix.m4a",
    "voice": "assets/preview-mix.m4a"
  },
  "cues": {},
  "chapters": [
    {
      "at": 0,
      "label": "01 开场：为什么迟迟不开始"
    },
    {
      "at": 4.15,
      "label": "02 鸟瞰：整条视频工程"
    },
    {
      "at": 5.3,
      "label": "03 6 项隐形任务"
    },
    {
      "at": 14.41,
      "label": "04 压场：一整串未拆任务"
    },
    {
      "at": 17.2,
      "label": "05 鸟瞰：先缩小三步"
    },
    {
      "at": 19.35,
      "label": "06 第一步：一个观点"
    },
    {
      "at": 26.45,
      "label": "07 第二步：一个例子"
    },
    {
      "at": 32.85,
      "label": "08 第三步：录成第一版"
    },
    {
      "at": 40.3,
      "label": "09 鸟瞰：有了第一版"
    },
    {
      "at": 42.4,
      "label": "10 问题变具体"
    },
    {
      "at": 49.4,
      "label": "11 继续拆小"
    },
    {
      "at": 53.92,
      "label": "12 蓝底收尾：先让事情有个开头"
    }
  ],
  "show_ai_label": false,
  "scene_source": "scene.js"
};

window.FINAL_TIMELINE = {
  "schema_version": "1.0",
  "timeline_revision": "sha256:5adc785d29189a6de7e995291e28fa7f32913972fef14d81d78821625256785e",
  "duration_ms": 61960,
  "lines": [
    {
      "line_id": "line_0001",
      "text": "你有没有发现",
      "target_start_ms": 330,
      "target_end_ms": 1050,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "你",
          "target_start_ms": 330,
          "target_end_ms": 450,
          "source_word_index": 0,
          "source_char_start": 0,
          "source_char_end": 1
        },
        {
          "token_id": "token_002",
          "text": "有",
          "target_start_ms": 450,
          "target_end_ms": 570,
          "source_word_index": 1,
          "source_char_start": 1,
          "source_char_end": 2
        },
        {
          "token_id": "token_003",
          "text": "没",
          "target_start_ms": 570,
          "target_end_ms": 690,
          "source_word_index": 2,
          "source_char_start": 2,
          "source_char_end": 3
        },
        {
          "token_id": "token_004",
          "text": "有",
          "target_start_ms": 690,
          "target_end_ms": 770,
          "source_word_index": 3,
          "source_char_start": 3,
          "source_char_end": 4
        },
        {
          "token_id": "token_005",
          "text": "发",
          "target_start_ms": 770,
          "target_end_ms": 890,
          "source_word_index": 4,
          "source_char_start": 4,
          "source_char_end": 5
        },
        {
          "token_id": "token_006",
          "text": "现",
          "target_start_ms": 890,
          "target_end_ms": 1050,
          "source_word_index": 5,
          "source_char_start": 5,
          "source_char_end": 6
        }
      ]
    },
    {
      "line_id": "line_0002",
      "text": "越想把一件事做好",
      "target_start_ms": 1130,
      "target_end_ms": 2450,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "越",
          "target_start_ms": 1130,
          "target_end_ms": 1330,
          "source_word_index": 0,
          "source_char_start": 0,
          "source_char_end": 1
        },
        {
          "token_id": "token_002",
          "text": "想",
          "target_start_ms": 1330,
          "target_end_ms": 1530,
          "source_word_index": 1,
          "source_char_start": 1,
          "source_char_end": 2
        },
        {
          "token_id": "token_003",
          "text": "把",
          "target_start_ms": 1530,
          "target_end_ms": 1690,
          "source_word_index": 2,
          "source_char_start": 2,
          "source_char_end": 3
        },
        {
          "token_id": "token_004",
          "text": "一",
          "target_start_ms": 1690,
          "target_end_ms": 1850,
          "source_word_index": 3,
          "source_char_start": 3,
          "source_char_end": 4
        },
        {
          "token_id": "token_005",
          "text": "件",
          "target_start_ms": 1850,
          "target_end_ms": 1930,
          "source_word_index": 4,
          "source_char_start": 4,
          "source_char_end": 5
        },
        {
          "token_id": "token_006",
          "text": "事",
          "target_start_ms": 1930,
          "target_end_ms": 2090,
          "source_word_index": 5,
          "source_char_start": 5,
          "source_char_end": 6
        },
        {
          "token_id": "token_007",
          "text": "做",
          "target_start_ms": 2090,
          "target_end_ms": 2250,
          "source_word_index": 6,
          "source_char_start": 6,
          "source_char_end": 7
        },
        {
          "token_id": "token_008",
          "text": "好",
          "target_start_ms": 2250,
          "target_end_ms": 2450,
          "source_word_index": 7,
          "source_char_start": 7,
          "source_char_end": 8
        }
      ]
    },
    {
      "line_id": "line_0003",
      "text": "越容易迟迟不开始",
      "target_start_ms": 2490,
      "target_end_ms": 4010,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "越",
          "target_start_ms": 2490,
          "target_end_ms": 2690,
          "source_word_index": 0,
          "source_char_start": 0,
          "source_char_end": 1
        },
        {
          "token_id": "token_002",
          "text": "容",
          "target_start_ms": 2690,
          "target_end_ms": 2850,
          "source_word_index": 1,
          "source_char_start": 1,
          "source_char_end": 2
        },
        {
          "token_id": "token_003",
          "text": "易",
          "target_start_ms": 2850,
          "target_end_ms": 2970,
          "source_word_index": 2,
          "source_char_start": 2,
          "source_char_end": 3
        },
        {
          "token_id": "token_004",
          "text": "迟",
          "target_start_ms": 3010,
          "target_end_ms": 3250,
          "source_word_index": 3,
          "source_char_start": 3,
          "source_char_end": 4
        },
        {
          "token_id": "token_005",
          "text": "迟",
          "target_start_ms": 3290,
          "target_end_ms": 3410,
          "source_word_index": 4,
          "source_char_start": 4,
          "source_char_end": 5
        },
        {
          "token_id": "token_006",
          "text": "不",
          "target_start_ms": 3410,
          "target_end_ms": 3650,
          "source_word_index": 5,
          "source_char_start": 5,
          "source_char_end": 6
        },
        {
          "token_id": "token_007",
          "text": "开",
          "target_start_ms": 3650,
          "target_end_ms": 3810,
          "source_word_index": 6,
          "source_char_start": 6,
          "source_char_end": 7
        },
        {
          "token_id": "token_008",
          "text": "始",
          "target_start_ms": 3810,
          "target_end_ms": 4010,
          "source_word_index": 7,
          "source_char_start": 7,
          "source_char_end": 8
        }
      ]
    },
    {
      "line_id": "line_0004",
      "text": "比如你告诉自己",
      "target_start_ms": 4250,
      "target_end_ms": 5250,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "比",
          "target_start_ms": 4250,
          "target_end_ms": 4410,
          "source_word_index": 0,
          "source_char_start": 0,
          "source_char_end": 1
        },
        {
          "token_id": "token_002",
          "text": "如",
          "target_start_ms": 4410,
          "target_end_ms": 4530,
          "source_word_index": 1,
          "source_char_start": 1,
          "source_char_end": 2
        },
        {
          "token_id": "token_003",
          "text": "你",
          "target_start_ms": 4530,
          "target_end_ms": 4690,
          "source_word_index": 2,
          "source_char_start": 2,
          "source_char_end": 3
        },
        {
          "token_id": "token_004",
          "text": "告",
          "target_start_ms": 4690,
          "target_end_ms": 4850,
          "source_word_index": 3,
          "source_char_start": 3,
          "source_char_end": 4
        },
        {
          "token_id": "token_005",
          "text": "诉",
          "target_start_ms": 4850,
          "target_end_ms": 4930,
          "source_word_index": 4,
          "source_char_start": 4,
          "source_char_end": 5
        },
        {
          "token_id": "token_006",
          "text": "自",
          "target_start_ms": 4930,
          "target_end_ms": 5090,
          "source_word_index": 5,
          "source_char_start": 5,
          "source_char_end": 6
        },
        {
          "token_id": "token_007",
          "text": "己",
          "target_start_ms": 5090,
          "target_end_ms": 5250,
          "source_word_index": 6,
          "source_char_start": 6,
          "source_char_end": 7
        }
      ]
    },
    {
      "line_id": "line_0005",
      "text": "今天要做完一条视频",
      "target_start_ms": 5410,
      "target_end_ms": 6730,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "今",
          "target_start_ms": 5410,
          "target_end_ms": 5610,
          "source_word_index": 0,
          "source_char_start": 0,
          "source_char_end": 1
        },
        {
          "token_id": "token_002",
          "text": "天",
          "target_start_ms": 5610,
          "target_end_ms": 5690,
          "source_word_index": 1,
          "source_char_start": 1,
          "source_char_end": 2
        },
        {
          "token_id": "token_003",
          "text": "要",
          "target_start_ms": 5690,
          "target_end_ms": 5850,
          "source_word_index": 2,
          "source_char_start": 2,
          "source_char_end": 3
        },
        {
          "token_id": "token_004",
          "text": "做",
          "target_start_ms": 5850,
          "target_end_ms": 6010,
          "source_word_index": 3,
          "source_char_start": 3,
          "source_char_end": 4
        },
        {
          "token_id": "token_005",
          "text": "完",
          "target_start_ms": 6010,
          "target_end_ms": 6130,
          "source_word_index": 4,
          "source_char_start": 4,
          "source_char_end": 5
        },
        {
          "token_id": "token_006",
          "text": "一",
          "target_start_ms": 6130,
          "target_end_ms": 6250,
          "source_word_index": 5,
          "source_char_start": 5,
          "source_char_end": 6
        },
        {
          "token_id": "token_007",
          "text": "条",
          "target_start_ms": 6250,
          "target_end_ms": 6410,
          "source_word_index": 6,
          "source_char_start": 6,
          "source_char_end": 7
        },
        {
          "token_id": "token_008",
          "text": "视",
          "target_start_ms": 6410,
          "target_end_ms": 6570,
          "source_word_index": 7,
          "source_char_start": 7,
          "source_char_end": 8
        },
        {
          "token_id": "token_009",
          "text": "频",
          "target_start_ms": 6570,
          "target_end_ms": 6730,
          "source_word_index": 8,
          "source_char_start": 8,
          "source_char_end": 9
        }
      ]
    },
    {
      "line_id": "line_0006",
      "text": "可坐到电脑前",
      "target_start_ms": 6850,
      "target_end_ms": 7890,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "可",
          "target_start_ms": 6850,
          "target_end_ms": 7090,
          "source_word_index": 0,
          "source_char_start": 0,
          "source_char_end": 1
        },
        {
          "token_id": "token_002",
          "text": "坐",
          "target_start_ms": 7130,
          "target_end_ms": 7250,
          "source_word_index": 1,
          "source_char_start": 1,
          "source_char_end": 2
        },
        {
          "token_id": "token_003",
          "text": "到",
          "target_start_ms": 7250,
          "target_end_ms": 7410,
          "source_word_index": 2,
          "source_char_start": 2,
          "source_char_end": 3
        },
        {
          "token_id": "token_004",
          "text": "电",
          "target_start_ms": 7410,
          "target_end_ms": 7530,
          "source_word_index": 3,
          "source_char_start": 3,
          "source_char_end": 4
        },
        {
          "token_id": "token_005",
          "text": "脑",
          "target_start_ms": 7530,
          "target_end_ms": 7650,
          "source_word_index": 4,
          "source_char_start": 4,
          "source_char_end": 5
        },
        {
          "token_id": "token_006",
          "text": "前",
          "target_start_ms": 7650,
          "target_end_ms": 7890,
          "source_word_index": 5,
          "source_char_start": 5,
          "source_char_end": 6
        }
      ]
    },
    {
      "line_id": "line_0007",
      "text": "又不知道从哪下手",
      "target_start_ms": 7890,
      "target_end_ms": 9170,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "又",
          "target_start_ms": 7890,
          "target_end_ms": 8090,
          "source_word_index": 0,
          "source_char_start": 0,
          "source_char_end": 1
        },
        {
          "token_id": "token_002",
          "text": "不",
          "target_start_ms": 8090,
          "target_end_ms": 8250,
          "source_word_index": 1,
          "source_char_start": 1,
          "source_char_end": 2
        },
        {
          "token_id": "token_003",
          "text": "知",
          "target_start_ms": 8250,
          "target_end_ms": 8330,
          "source_word_index": 2,
          "source_char_start": 2,
          "source_char_end": 3
        },
        {
          "token_id": "token_004",
          "text": "道",
          "target_start_ms": 8330,
          "target_end_ms": 8410,
          "source_word_index": 3,
          "source_char_start": 3,
          "source_char_end": 4
        },
        {
          "token_id": "token_005",
          "text": "从",
          "target_start_ms": 8410,
          "target_end_ms": 8610,
          "source_word_index": 4,
          "source_char_start": 4,
          "source_char_end": 5
        },
        {
          "token_id": "token_006",
          "text": "哪",
          "target_start_ms": 8610,
          "target_end_ms": 8770,
          "source_word_index": 5,
          "source_char_start": 5,
          "source_char_end": 6
        },
        {
          "token_id": "token_007",
          "text": "下",
          "target_start_ms": 8770,
          "target_end_ms": 8970,
          "source_word_index": 6,
          "source_char_start": 6,
          "source_char_end": 7
        },
        {
          "token_id": "token_008",
          "text": "手",
          "target_start_ms": 8970,
          "target_end_ms": 9170,
          "source_word_index": 7,
          "source_char_start": 7,
          "source_char_end": 8
        }
      ]
    },
    {
      "line_id": "line_0008",
      "text": "因为这句话里面",
      "target_start_ms": 9330,
      "target_end_ms": 10210,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "因",
          "target_start_ms": 9330,
          "target_end_ms": 9450,
          "source_word_index": 0,
          "source_char_start": 0,
          "source_char_end": 1
        },
        {
          "token_id": "token_002",
          "text": "为",
          "target_start_ms": 9450,
          "target_end_ms": 9570,
          "source_word_index": 1,
          "source_char_start": 1,
          "source_char_end": 2
        },
        {
          "token_id": "token_003",
          "text": "这",
          "target_start_ms": 9570,
          "target_end_ms": 9690,
          "source_word_index": 2,
          "source_char_start": 2,
          "source_char_end": 3
        },
        {
          "token_id": "token_004",
          "text": "句",
          "target_start_ms": 9690,
          "target_end_ms": 9850,
          "source_word_index": 3,
          "source_char_start": 3,
          "source_char_end": 4
        },
        {
          "token_id": "token_005",
          "text": "话",
          "target_start_ms": 9850,
          "target_end_ms": 9970,
          "source_word_index": 4,
          "source_char_start": 4,
          "source_char_end": 5
        },
        {
          "token_id": "token_006",
          "text": "里",
          "target_start_ms": 9970,
          "target_end_ms": 10090,
          "source_word_index": 5,
          "source_char_start": 5,
          "source_char_end": 6
        },
        {
          "token_id": "token_007",
          "text": "面",
          "target_start_ms": 10090,
          "target_end_ms": 10210,
          "source_word_index": 6,
          "source_char_start": 6,
          "source_char_end": 7
        }
      ]
    },
    {
      "line_id": "line_0009",
      "text": "藏着选题、写稿、录音、剪辑",
      "target_start_ms": 10250,
      "target_end_ms": 12490,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "藏",
          "target_start_ms": 10250,
          "target_end_ms": 10450,
          "source_word_index": 0,
          "source_char_start": 0,
          "source_char_end": 1
        },
        {
          "token_id": "token_002",
          "text": "着",
          "target_start_ms": 10450,
          "target_end_ms": 10610,
          "source_word_index": 1,
          "source_char_start": 1,
          "source_char_end": 2
        },
        {
          "token_id": "token_003",
          "text": "选",
          "target_start_ms": 10610,
          "target_end_ms": 10810,
          "source_word_index": 2,
          "source_char_start": 2,
          "source_char_end": 3
        },
        {
          "token_id": "token_004",
          "text": "题",
          "target_start_ms": 10810,
          "target_end_ms": 11050,
          "source_word_index": 3,
          "source_char_start": 3,
          "source_char_end": 4
        },
        {
          "token_id": "token_005",
          "text": "写",
          "target_start_ms": 11090,
          "target_end_ms": 11330,
          "source_word_index": 4,
          "source_char_start": 5,
          "source_char_end": 6
        },
        {
          "token_id": "token_006",
          "text": "稿",
          "target_start_ms": 11330,
          "target_end_ms": 11570,
          "source_word_index": 5,
          "source_char_start": 6,
          "source_char_end": 7
        },
        {
          "token_id": "token_007",
          "text": "录",
          "target_start_ms": 11650,
          "target_end_ms": 11850,
          "source_word_index": 6,
          "source_char_start": 8,
          "source_char_end": 9
        },
        {
          "token_id": "token_008",
          "text": "音",
          "target_start_ms": 11850,
          "target_end_ms": 12050,
          "source_word_index": 7,
          "source_char_start": 9,
          "source_char_end": 10
        },
        {
          "token_id": "token_009",
          "text": "剪",
          "target_start_ms": 12090,
          "target_end_ms": 12330,
          "source_word_index": 8,
          "source_char_start": 11,
          "source_char_end": 12
        },
        {
          "token_id": "token_010",
          "text": "辑",
          "target_start_ms": 12330,
          "target_end_ms": 12490,
          "source_word_index": 9,
          "source_char_start": 12,
          "source_char_end": 13
        }
      ]
    },
    {
      "line_id": "line_0010",
      "text": "还有字幕和封面",
      "target_start_ms": 12730,
      "target_end_ms": 13970,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "还",
          "target_start_ms": 12730,
          "target_end_ms": 12850,
          "source_word_index": 0,
          "source_char_start": 0,
          "source_char_end": 1
        },
        {
          "token_id": "token_002",
          "text": "有",
          "target_start_ms": 12850,
          "target_end_ms": 13010,
          "source_word_index": 1,
          "source_char_start": 1,
          "source_char_end": 2
        },
        {
          "token_id": "token_003",
          "text": "字",
          "target_start_ms": 13010,
          "target_end_ms": 13210,
          "source_word_index": 2,
          "source_char_start": 2,
          "source_char_end": 3
        },
        {
          "token_id": "token_004",
          "text": "幕",
          "target_start_ms": 13210,
          "target_end_ms": 13370,
          "source_word_index": 3,
          "source_char_start": 3,
          "source_char_end": 4
        },
        {
          "token_id": "token_005",
          "text": "和",
          "target_start_ms": 13410,
          "target_end_ms": 13610,
          "source_word_index": 4,
          "source_char_start": 4,
          "source_char_end": 5
        },
        {
          "token_id": "token_006",
          "text": "封",
          "target_start_ms": 13610,
          "target_end_ms": 13770,
          "source_word_index": 5,
          "source_char_start": 5,
          "source_char_end": 6
        },
        {
          "token_id": "token_007",
          "text": "面",
          "target_start_ms": 13770,
          "target_end_ms": 13970,
          "source_word_index": 6,
          "source_char_start": 6,
          "source_char_end": 7
        }
      ]
    },
    {
      "line_id": "line_0011",
      "text": "你面对的",
      "target_start_ms": 14410,
      "target_end_ms": 15130,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "你",
          "target_start_ms": 14410,
          "target_end_ms": 14650,
          "source_word_index": 0,
          "source_char_start": 0,
          "source_char_end": 1
        },
        {
          "token_id": "token_002",
          "text": "面",
          "target_start_ms": 14650,
          "target_end_ms": 14810,
          "source_word_index": 1,
          "source_char_start": 1,
          "source_char_end": 2
        },
        {
          "token_id": "token_003",
          "text": "对",
          "target_start_ms": 14810,
          "target_end_ms": 14930,
          "source_word_index": 2,
          "source_char_start": 2,
          "source_char_end": 3
        },
        {
          "token_id": "token_004",
          "text": "的",
          "target_start_ms": 14930,
          "target_end_ms": 15130,
          "source_word_index": 3,
          "source_char_start": 3,
          "source_char_end": 4
        }
      ]
    },
    {
      "line_id": "line_0012",
      "text": "其实是一整串还没拆开的任务",
      "target_start_ms": 15130,
      "target_end_ms": 17130,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "其",
          "target_start_ms": 15130,
          "target_end_ms": 15290,
          "source_word_index": 0,
          "source_char_start": 0,
          "source_char_end": 1
        },
        {
          "token_id": "token_002",
          "text": "实",
          "target_start_ms": 15290,
          "target_end_ms": 15410,
          "source_word_index": 1,
          "source_char_start": 1,
          "source_char_end": 2
        },
        {
          "token_id": "token_003",
          "text": "是",
          "target_start_ms": 15410,
          "target_end_ms": 15570,
          "source_word_index": 2,
          "source_char_start": 2,
          "source_char_end": 3
        },
        {
          "token_id": "token_004",
          "text": "一",
          "target_start_ms": 15570,
          "target_end_ms": 15730,
          "source_word_index": 3,
          "source_char_start": 3,
          "source_char_end": 4
        },
        {
          "token_id": "token_005",
          "text": "整",
          "target_start_ms": 15730,
          "target_end_ms": 15890,
          "source_word_index": 4,
          "source_char_start": 4,
          "source_char_end": 5
        },
        {
          "token_id": "token_006",
          "text": "串",
          "target_start_ms": 15890,
          "target_end_ms": 16090,
          "source_word_index": 5,
          "source_char_start": 5,
          "source_char_end": 6
        },
        {
          "token_id": "token_007",
          "text": "还",
          "target_start_ms": 16090,
          "target_end_ms": 16250,
          "source_word_index": 6,
          "source_char_start": 6,
          "source_char_end": 7
        },
        {
          "token_id": "token_008",
          "text": "没",
          "target_start_ms": 16250,
          "target_end_ms": 16410,
          "source_word_index": 7,
          "source_char_start": 7,
          "source_char_end": 8
        },
        {
          "token_id": "token_009",
          "text": "拆",
          "target_start_ms": 16410,
          "target_end_ms": 16570,
          "source_word_index": 8,
          "source_char_start": 8,
          "source_char_end": 9
        },
        {
          "token_id": "token_010",
          "text": "开",
          "target_start_ms": 16570,
          "target_end_ms": 16730,
          "source_word_index": 9,
          "source_char_start": 9,
          "source_char_end": 10
        },
        {
          "token_id": "token_011",
          "text": "的",
          "target_start_ms": 16730,
          "target_end_ms": 16890,
          "source_word_index": 10,
          "source_char_start": 10,
          "source_char_end": 11
        },
        {
          "token_id": "token_012",
          "text": "任",
          "target_start_ms": 16890,
          "target_end_ms": 17010,
          "source_word_index": 11,
          "source_char_start": 11,
          "source_char_end": 12
        },
        {
          "token_id": "token_013",
          "text": "务",
          "target_start_ms": 17010,
          "target_end_ms": 17130,
          "source_word_index": 12,
          "source_char_start": 12,
          "source_char_end": 13
        }
      ]
    },
    {
      "line_id": "line_0013",
      "text": "试着把它缩小",
      "target_start_ms": 17250,
      "target_end_ms": 18210,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "试",
          "target_start_ms": 17250,
          "target_end_ms": 17410,
          "source_word_index": 0,
          "source_char_start": 0,
          "source_char_end": 1
        },
        {
          "token_id": "token_002",
          "text": "着",
          "target_start_ms": 17410,
          "target_end_ms": 17530,
          "source_word_index": 1,
          "source_char_start": 1,
          "source_char_end": 2
        },
        {
          "token_id": "token_003",
          "text": "把",
          "target_start_ms": 17530,
          "target_end_ms": 17690,
          "source_word_index": 2,
          "source_char_start": 2,
          "source_char_end": 3
        },
        {
          "token_id": "token_004",
          "text": "它",
          "target_start_ms": 17690,
          "target_end_ms": 17770,
          "source_word_index": 3,
          "source_char_start": 3,
          "source_char_end": 4
        },
        {
          "token_id": "token_005",
          "text": "缩",
          "target_start_ms": 17810,
          "target_end_ms": 18010,
          "source_word_index": 4,
          "source_char_start": 4,
          "source_char_end": 5
        },
        {
          "token_id": "token_006",
          "text": "小",
          "target_start_ms": 18010,
          "target_end_ms": 18210,
          "source_word_index": 5,
          "source_char_start": 5,
          "source_char_end": 6
        }
      ]
    },
    {
      "line_id": "line_0014",
      "text": "先做三步",
      "target_start_ms": 18330,
      "target_end_ms": 19250,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "先",
          "target_start_ms": 18330,
          "target_end_ms": 18570,
          "source_word_index": 0,
          "source_char_start": 0,
          "source_char_end": 1
        },
        {
          "token_id": "token_002",
          "text": "做",
          "target_start_ms": 18570,
          "target_end_ms": 18810,
          "source_word_index": 1,
          "source_char_start": 1,
          "source_char_end": 2
        },
        {
          "token_id": "token_003",
          "text": "三",
          "target_start_ms": 18810,
          "target_end_ms": 19010,
          "source_word_index": 2,
          "source_char_start": 2,
          "source_char_end": 3
        },
        {
          "token_id": "token_004",
          "text": "步",
          "target_start_ms": 19010,
          "target_end_ms": 19250,
          "source_word_index": 3,
          "source_char_start": 3,
          "source_char_end": 4
        }
      ]
    },
    {
      "line_id": "line_0015",
      "text": "第一步",
      "target_start_ms": 19530,
      "target_end_ms": 19970,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "第",
          "target_start_ms": 19530,
          "target_end_ms": 19690,
          "source_word_index": 0,
          "source_char_start": 0,
          "source_char_end": 1
        },
        {
          "token_id": "token_002",
          "text": "一",
          "target_start_ms": 19690,
          "target_end_ms": 19810,
          "source_word_index": 1,
          "source_char_start": 1,
          "source_char_end": 2
        },
        {
          "token_id": "token_003",
          "text": "步",
          "target_start_ms": 19810,
          "target_end_ms": 19970,
          "source_word_index": 2,
          "source_char_start": 2,
          "source_char_end": 3
        }
      ]
    },
    {
      "line_id": "line_0016",
      "text": "只写一句你想表达的观点",
      "target_start_ms": 20250,
      "target_end_ms": 22010,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "只",
          "target_start_ms": 20250,
          "target_end_ms": 20450,
          "source_word_index": 0,
          "source_char_start": 0,
          "source_char_end": 1
        },
        {
          "token_id": "token_002",
          "text": "写",
          "target_start_ms": 20450,
          "target_end_ms": 20650,
          "source_word_index": 1,
          "source_char_start": 1,
          "source_char_end": 2
        },
        {
          "token_id": "token_003",
          "text": "一",
          "target_start_ms": 20650,
          "target_end_ms": 20770,
          "source_word_index": 2,
          "source_char_start": 2,
          "source_char_end": 3
        },
        {
          "token_id": "token_004",
          "text": "句",
          "target_start_ms": 20770,
          "target_end_ms": 20890,
          "source_word_index": 3,
          "source_char_start": 3,
          "source_char_end": 4
        },
        {
          "token_id": "token_005",
          "text": "你",
          "target_start_ms": 20890,
          "target_end_ms": 21050,
          "source_word_index": 4,
          "source_char_start": 4,
          "source_char_end": 5
        },
        {
          "token_id": "token_006",
          "text": "想",
          "target_start_ms": 21050,
          "target_end_ms": 21250,
          "source_word_index": 5,
          "source_char_start": 5,
          "source_char_end": 6
        },
        {
          "token_id": "token_007",
          "text": "表",
          "target_start_ms": 21250,
          "target_end_ms": 21410,
          "source_word_index": 6,
          "source_char_start": 6,
          "source_char_end": 7
        },
        {
          "token_id": "token_008",
          "text": "达",
          "target_start_ms": 21410,
          "target_end_ms": 21490,
          "source_word_index": 7,
          "source_char_start": 7,
          "source_char_end": 8
        },
        {
          "token_id": "token_009",
          "text": "的",
          "target_start_ms": 21490,
          "target_end_ms": 21690,
          "source_word_index": 8,
          "source_char_start": 8,
          "source_char_end": 9
        },
        {
          "token_id": "token_010",
          "text": "观",
          "target_start_ms": 21690,
          "target_end_ms": 21850,
          "source_word_index": 9,
          "source_char_start": 9,
          "source_char_end": 10
        },
        {
          "token_id": "token_011",
          "text": "点",
          "target_start_ms": 21850,
          "target_end_ms": 22010,
          "source_word_index": 10,
          "source_char_start": 10,
          "source_char_end": 11
        }
      ]
    },
    {
      "line_id": "line_0017",
      "text": "先不用纠结开头",
      "target_start_ms": 22130,
      "target_end_ms": 23170,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "先",
          "target_start_ms": 22130,
          "target_end_ms": 22330,
          "source_word_index": 0,
          "source_char_start": 0,
          "source_char_end": 1
        },
        {
          "token_id": "token_002",
          "text": "不",
          "target_start_ms": 22330,
          "target_end_ms": 22450,
          "source_word_index": 1,
          "source_char_start": 1,
          "source_char_end": 2
        },
        {
          "token_id": "token_003",
          "text": "用",
          "target_start_ms": 22450,
          "target_end_ms": 22530,
          "source_word_index": 2,
          "source_char_start": 2,
          "source_char_end": 3
        },
        {
          "token_id": "token_004",
          "text": "纠",
          "target_start_ms": 22530,
          "target_end_ms": 22730,
          "source_word_index": 3,
          "source_char_start": 3,
          "source_char_end": 4
        },
        {
          "token_id": "token_005",
          "text": "结",
          "target_start_ms": 22730,
          "target_end_ms": 22810,
          "source_word_index": 4,
          "source_char_start": 4,
          "source_char_end": 5
        },
        {
          "token_id": "token_006",
          "text": "开",
          "target_start_ms": 22810,
          "target_end_ms": 22970,
          "source_word_index": 5,
          "source_char_start": 5,
          "source_char_end": 6
        },
        {
          "token_id": "token_007",
          "text": "头",
          "target_start_ms": 22970,
          "target_end_ms": 23170,
          "source_word_index": 6,
          "source_char_start": 6,
          "source_char_end": 7
        }
      ]
    },
    {
      "line_id": "line_0018",
      "text": "只回答：这条视频",
      "target_start_ms": 23210,
      "target_end_ms": 24690,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "只",
          "target_start_ms": 23210,
          "target_end_ms": 23410,
          "source_word_index": 0,
          "source_char_start": 0,
          "source_char_end": 1
        },
        {
          "token_id": "token_002",
          "text": "回",
          "target_start_ms": 23410,
          "target_end_ms": 23570,
          "source_word_index": 1,
          "source_char_start": 1,
          "source_char_end": 2
        },
        {
          "token_id": "token_003",
          "text": "答",
          "target_start_ms": 23570,
          "target_end_ms": 23730,
          "source_word_index": 2,
          "source_char_start": 2,
          "source_char_end": 3
        },
        {
          "token_id": "token_004",
          "text": "这",
          "target_start_ms": 23930,
          "target_end_ms": 24170,
          "source_word_index": 3,
          "source_char_start": 4,
          "source_char_end": 5
        },
        {
          "token_id": "token_005",
          "text": "条",
          "target_start_ms": 24170,
          "target_end_ms": 24370,
          "source_word_index": 4,
          "source_char_start": 5,
          "source_char_end": 6
        },
        {
          "token_id": "token_006",
          "text": "视",
          "target_start_ms": 24370,
          "target_end_ms": 24530,
          "source_word_index": 5,
          "source_char_start": 6,
          "source_char_end": 7
        },
        {
          "token_id": "token_007",
          "text": "频",
          "target_start_ms": 24530,
          "target_end_ms": 24690,
          "source_word_index": 6,
          "source_char_start": 7,
          "source_char_end": 8
        }
      ]
    },
    {
      "line_id": "line_0019",
      "text": "最想让别人记住什么",
      "target_start_ms": 24730,
      "target_end_ms": 26170,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "最",
          "target_start_ms": 24730,
          "target_end_ms": 24930,
          "source_word_index": 0,
          "source_char_start": 0,
          "source_char_end": 1
        },
        {
          "token_id": "token_002",
          "text": "想",
          "target_start_ms": 24930,
          "target_end_ms": 25130,
          "source_word_index": 1,
          "source_char_start": 1,
          "source_char_end": 2
        },
        {
          "token_id": "token_003",
          "text": "让",
          "target_start_ms": 25130,
          "target_end_ms": 25330,
          "source_word_index": 2,
          "source_char_start": 2,
          "source_char_end": 3
        },
        {
          "token_id": "token_004",
          "text": "别",
          "target_start_ms": 25330,
          "target_end_ms": 25410,
          "source_word_index": 3,
          "source_char_start": 3,
          "source_char_end": 4
        },
        {
          "token_id": "token_005",
          "text": "人",
          "target_start_ms": 25410,
          "target_end_ms": 25530,
          "source_word_index": 4,
          "source_char_start": 4,
          "source_char_end": 5
        },
        {
          "token_id": "token_006",
          "text": "记",
          "target_start_ms": 25530,
          "target_end_ms": 25730,
          "source_word_index": 5,
          "source_char_start": 5,
          "source_char_end": 6
        },
        {
          "token_id": "token_007",
          "text": "住",
          "target_start_ms": 25730,
          "target_end_ms": 25890,
          "source_word_index": 6,
          "source_char_start": 6,
          "source_char_end": 7
        },
        {
          "token_id": "token_008",
          "text": "什",
          "target_start_ms": 25890,
          "target_end_ms": 26050,
          "source_word_index": 7,
          "source_char_start": 7,
          "source_char_end": 8
        },
        {
          "token_id": "token_009",
          "text": "么",
          "target_start_ms": 26050,
          "target_end_ms": 26170,
          "source_word_index": 8,
          "source_char_start": 8,
          "source_char_end": 9
        }
      ]
    },
    {
      "line_id": "line_0020",
      "text": "第二步",
      "target_start_ms": 26530,
      "target_end_ms": 26930,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "第",
          "target_start_ms": 26530,
          "target_end_ms": 26610,
          "source_word_index": 0,
          "source_char_start": 0,
          "source_char_end": 1
        },
        {
          "token_id": "token_002",
          "text": "二",
          "target_start_ms": 26610,
          "target_end_ms": 26730,
          "source_word_index": 1,
          "source_char_start": 1,
          "source_char_end": 2
        },
        {
          "token_id": "token_003",
          "text": "步",
          "target_start_ms": 26730,
          "target_end_ms": 26930,
          "source_word_index": 2,
          "source_char_start": 2,
          "source_char_end": 3
        }
      ]
    },
    {
      "line_id": "line_0021",
      "text": "找一个具体的例子",
      "target_start_ms": 26970,
      "target_end_ms": 28250,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "找",
          "target_start_ms": 26970,
          "target_end_ms": 27170,
          "source_word_index": 0,
          "source_char_start": 0,
          "source_char_end": 1
        },
        {
          "token_id": "token_002",
          "text": "一",
          "target_start_ms": 27170,
          "target_end_ms": 27290,
          "source_word_index": 1,
          "source_char_start": 1,
          "source_char_end": 2
        },
        {
          "token_id": "token_003",
          "text": "个",
          "target_start_ms": 27290,
          "target_end_ms": 27410,
          "source_word_index": 2,
          "source_char_start": 2,
          "source_char_end": 3
        },
        {
          "token_id": "token_004",
          "text": "具",
          "target_start_ms": 27410,
          "target_end_ms": 27570,
          "source_word_index": 3,
          "source_char_start": 3,
          "source_char_end": 4
        },
        {
          "token_id": "token_005",
          "text": "体",
          "target_start_ms": 27570,
          "target_end_ms": 27690,
          "source_word_index": 4,
          "source_char_start": 4,
          "source_char_end": 5
        },
        {
          "token_id": "token_006",
          "text": "的",
          "target_start_ms": 27690,
          "target_end_ms": 27890,
          "source_word_index": 5,
          "source_char_start": 5,
          "source_char_end": 6
        },
        {
          "token_id": "token_007",
          "text": "例",
          "target_start_ms": 27890,
          "target_end_ms": 28050,
          "source_word_index": 6,
          "source_char_start": 6,
          "source_char_end": 7
        },
        {
          "token_id": "token_008",
          "text": "子",
          "target_start_ms": 28050,
          "target_end_ms": 28250,
          "source_word_index": 7,
          "source_char_start": 7,
          "source_char_end": 8
        }
      ]
    },
    {
      "line_id": "line_0022",
      "text": "可以是自己的经历",
      "target_start_ms": 28610,
      "target_end_ms": 29690,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "可",
          "target_start_ms": 28610,
          "target_end_ms": 28770,
          "source_word_index": 0,
          "source_char_start": 0,
          "source_char_end": 1
        },
        {
          "token_id": "token_002",
          "text": "以",
          "target_start_ms": 28770,
          "target_end_ms": 28890,
          "source_word_index": 1,
          "source_char_start": 1,
          "source_char_end": 2
        },
        {
          "token_id": "token_003",
          "text": "是",
          "target_start_ms": 28890,
          "target_end_ms": 29050,
          "source_word_index": 2,
          "source_char_start": 2,
          "source_char_end": 3
        },
        {
          "token_id": "token_004",
          "text": "自",
          "target_start_ms": 29050,
          "target_end_ms": 29170,
          "source_word_index": 3,
          "source_char_start": 3,
          "source_char_end": 4
        },
        {
          "token_id": "token_005",
          "text": "己",
          "target_start_ms": 29170,
          "target_end_ms": 29250,
          "source_word_index": 4,
          "source_char_start": 4,
          "source_char_end": 5
        },
        {
          "token_id": "token_006",
          "text": "的",
          "target_start_ms": 29250,
          "target_end_ms": 29410,
          "source_word_index": 5,
          "source_char_start": 5,
          "source_char_end": 6
        },
        {
          "token_id": "token_007",
          "text": "经",
          "target_start_ms": 29410,
          "target_end_ms": 29570,
          "source_word_index": 6,
          "source_char_start": 6,
          "source_char_end": 7
        },
        {
          "token_id": "token_008",
          "text": "历",
          "target_start_ms": 29570,
          "target_end_ms": 29690,
          "source_word_index": 7,
          "source_char_start": 7,
          "source_char_end": 8
        }
      ]
    },
    {
      "line_id": "line_0023",
      "text": "也可以是两种做法的对比",
      "target_start_ms": 29730,
      "target_end_ms": 31330,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "也",
          "target_start_ms": 29730,
          "target_end_ms": 29930,
          "source_word_index": 0,
          "source_char_start": 0,
          "source_char_end": 1
        },
        {
          "token_id": "token_002",
          "text": "可",
          "target_start_ms": 29930,
          "target_end_ms": 30010,
          "source_word_index": 1,
          "source_char_start": 1,
          "source_char_end": 2
        },
        {
          "token_id": "token_003",
          "text": "以",
          "target_start_ms": 30010,
          "target_end_ms": 30090,
          "source_word_index": 2,
          "source_char_start": 2,
          "source_char_end": 3
        },
        {
          "token_id": "token_004",
          "text": "是",
          "target_start_ms": 30090,
          "target_end_ms": 30250,
          "source_word_index": 3,
          "source_char_start": 3,
          "source_char_end": 4
        },
        {
          "token_id": "token_005",
          "text": "两",
          "target_start_ms": 30250,
          "target_end_ms": 30410,
          "source_word_index": 4,
          "source_char_start": 4,
          "source_char_end": 5
        },
        {
          "token_id": "token_006",
          "text": "种",
          "target_start_ms": 30410,
          "target_end_ms": 30530,
          "source_word_index": 5,
          "source_char_start": 5,
          "source_char_end": 6
        },
        {
          "token_id": "token_007",
          "text": "做",
          "target_start_ms": 30530,
          "target_end_ms": 30690,
          "source_word_index": 6,
          "source_char_start": 6,
          "source_char_end": 7
        },
        {
          "token_id": "token_008",
          "text": "法",
          "target_start_ms": 30690,
          "target_end_ms": 30810,
          "source_word_index": 7,
          "source_char_start": 7,
          "source_char_end": 8
        },
        {
          "token_id": "token_009",
          "text": "的",
          "target_start_ms": 30810,
          "target_end_ms": 30970,
          "source_word_index": 8,
          "source_char_start": 8,
          "source_char_end": 9
        },
        {
          "token_id": "token_010",
          "text": "对",
          "target_start_ms": 30970,
          "target_end_ms": 31130,
          "source_word_index": 9,
          "source_char_start": 9,
          "source_char_end": 10
        },
        {
          "token_id": "token_011",
          "text": "比",
          "target_start_ms": 31130,
          "target_end_ms": 31330,
          "source_word_index": 10,
          "source_char_start": 10,
          "source_char_end": 11
        }
      ]
    },
    {
      "line_id": "line_0024",
      "text": "让别人听得明白",
      "target_start_ms": 31530,
      "target_end_ms": 32690,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "让",
          "target_start_ms": 31530,
          "target_end_ms": 31770,
          "source_word_index": 0,
          "source_char_start": 0,
          "source_char_end": 1
        },
        {
          "token_id": "token_002",
          "text": "别",
          "target_start_ms": 31770,
          "target_end_ms": 31890,
          "source_word_index": 1,
          "source_char_start": 1,
          "source_char_end": 2
        },
        {
          "token_id": "token_003",
          "text": "人",
          "target_start_ms": 31890,
          "target_end_ms": 32010,
          "source_word_index": 2,
          "source_char_start": 2,
          "source_char_end": 3
        },
        {
          "token_id": "token_004",
          "text": "听",
          "target_start_ms": 32010,
          "target_end_ms": 32210,
          "source_word_index": 3,
          "source_char_start": 3,
          "source_char_end": 4
        },
        {
          "token_id": "token_005",
          "text": "得",
          "target_start_ms": 32210,
          "target_end_ms": 32330,
          "source_word_index": 4,
          "source_char_start": 4,
          "source_char_end": 5
        },
        {
          "token_id": "token_006",
          "text": "明",
          "target_start_ms": 32370,
          "target_end_ms": 32530,
          "source_word_index": 5,
          "source_char_start": 5,
          "source_char_end": 6
        },
        {
          "token_id": "token_007",
          "text": "白",
          "target_start_ms": 32530,
          "target_end_ms": 32690,
          "source_word_index": 6,
          "source_char_start": 6,
          "source_char_end": 7
        }
      ]
    },
    {
      "line_id": "line_0025",
      "text": "第三步",
      "target_start_ms": 32930,
      "target_end_ms": 33490,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "第",
          "target_start_ms": 32930,
          "target_end_ms": 33090,
          "source_word_index": 0,
          "source_char_start": 0,
          "source_char_end": 1
        },
        {
          "token_id": "token_002",
          "text": "三",
          "target_start_ms": 33090,
          "target_end_ms": 33250,
          "source_word_index": 1,
          "source_char_start": 1,
          "source_char_end": 2
        },
        {
          "token_id": "token_003",
          "text": "步",
          "target_start_ms": 33250,
          "target_end_ms": 33490,
          "source_word_index": 2,
          "source_char_start": 2,
          "source_char_end": 3
        }
      ]
    },
    {
      "line_id": "line_0026",
      "text": "把观点和例子连起来",
      "target_start_ms": 33690,
      "target_end_ms": 35250,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "把",
          "target_start_ms": 33690,
          "target_end_ms": 33930,
          "source_word_index": 0,
          "source_char_start": 0,
          "source_char_end": 1
        },
        {
          "token_id": "token_002",
          "text": "观",
          "target_start_ms": 33930,
          "target_end_ms": 34130,
          "source_word_index": 1,
          "source_char_start": 1,
          "source_char_end": 2
        },
        {
          "token_id": "token_003",
          "text": "点",
          "target_start_ms": 34130,
          "target_end_ms": 34250,
          "source_word_index": 2,
          "source_char_start": 2,
          "source_char_end": 3
        },
        {
          "token_id": "token_004",
          "text": "和",
          "target_start_ms": 34250,
          "target_end_ms": 34410,
          "source_word_index": 3,
          "source_char_start": 3,
          "source_char_end": 4
        },
        {
          "token_id": "token_005",
          "text": "例",
          "target_start_ms": 34410,
          "target_end_ms": 34570,
          "source_word_index": 4,
          "source_char_start": 4,
          "source_char_end": 5
        },
        {
          "token_id": "token_006",
          "text": "子",
          "target_start_ms": 34570,
          "target_end_ms": 34690,
          "source_word_index": 5,
          "source_char_start": 5,
          "source_char_end": 6
        },
        {
          "token_id": "token_007",
          "text": "连",
          "target_start_ms": 34730,
          "target_end_ms": 34930,
          "source_word_index": 6,
          "source_char_start": 6,
          "source_char_end": 7
        },
        {
          "token_id": "token_008",
          "text": "起",
          "target_start_ms": 34930,
          "target_end_ms": 35090,
          "source_word_index": 7,
          "source_char_start": 7,
          "source_char_end": 8
        },
        {
          "token_id": "token_009",
          "text": "来",
          "target_start_ms": 35090,
          "target_end_ms": 35250,
          "source_word_index": 8,
          "source_char_start": 8,
          "source_char_end": 9
        }
      ]
    },
    {
      "line_id": "line_0027",
      "text": "读出来",
      "target_start_ms": 35250,
      "target_end_ms": 35770,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "读",
          "target_start_ms": 35250,
          "target_end_ms": 35450,
          "source_word_index": 0,
          "source_char_start": 0,
          "source_char_end": 1
        },
        {
          "token_id": "token_002",
          "text": "出",
          "target_start_ms": 35450,
          "target_end_ms": 35610,
          "source_word_index": 1,
          "source_char_start": 1,
          "source_char_end": 2
        },
        {
          "token_id": "token_003",
          "text": "来",
          "target_start_ms": 35610,
          "target_end_ms": 35770,
          "source_word_index": 2,
          "source_char_start": 2,
          "source_char_end": 3
        }
      ]
    },
    {
      "line_id": "line_0028",
      "text": "录成第一版",
      "target_start_ms": 35810,
      "target_end_ms": 36730,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "录",
          "target_start_ms": 35810,
          "target_end_ms": 35930,
          "source_word_index": 0,
          "source_char_start": 0,
          "source_char_end": 1
        },
        {
          "token_id": "token_002",
          "text": "成",
          "target_start_ms": 36050,
          "target_end_ms": 36210,
          "source_word_index": 1,
          "source_char_start": 1,
          "source_char_end": 2
        },
        {
          "token_id": "token_003",
          "text": "第",
          "target_start_ms": 36250,
          "target_end_ms": 36370,
          "source_word_index": 2,
          "source_char_start": 2,
          "source_char_end": 3
        },
        {
          "token_id": "token_004",
          "text": "一",
          "target_start_ms": 36370,
          "target_end_ms": 36490,
          "source_word_index": 3,
          "source_char_start": 3,
          "source_char_end": 4
        },
        {
          "token_id": "token_005",
          "text": "版",
          "target_start_ms": 36490,
          "target_end_ms": 36730,
          "source_word_index": 4,
          "source_char_start": 4,
          "source_char_end": 5
        }
      ]
    },
    {
      "line_id": "line_0029",
      "text": "哪里不顺就改哪里",
      "target_start_ms": 36850,
      "target_end_ms": 38210,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "哪",
          "target_start_ms": 36850,
          "target_end_ms": 37010,
          "source_word_index": 0,
          "source_char_start": 0,
          "source_char_end": 1
        },
        {
          "token_id": "token_002",
          "text": "里",
          "target_start_ms": 37010,
          "target_end_ms": 37090,
          "source_word_index": 1,
          "source_char_start": 1,
          "source_char_end": 2
        },
        {
          "token_id": "token_003",
          "text": "不",
          "target_start_ms": 37090,
          "target_end_ms": 37250,
          "source_word_index": 2,
          "source_char_start": 2,
          "source_char_end": 3
        },
        {
          "token_id": "token_004",
          "text": "顺",
          "target_start_ms": 37250,
          "target_end_ms": 37450,
          "source_word_index": 3,
          "source_char_start": 3,
          "source_char_end": 4
        },
        {
          "token_id": "token_005",
          "text": "就",
          "target_start_ms": 37450,
          "target_end_ms": 37650,
          "source_word_index": 4,
          "source_char_start": 4,
          "source_char_end": 5
        },
        {
          "token_id": "token_006",
          "text": "改",
          "target_start_ms": 37650,
          "target_end_ms": 37890,
          "source_word_index": 5,
          "source_char_start": 5,
          "source_char_end": 6
        },
        {
          "token_id": "token_007",
          "text": "哪",
          "target_start_ms": 37930,
          "target_end_ms": 38050,
          "source_word_index": 6,
          "source_char_start": 6,
          "source_char_end": 7
        },
        {
          "token_id": "token_008",
          "text": "里",
          "target_start_ms": 38050,
          "target_end_ms": 38210,
          "source_word_index": 7,
          "source_char_start": 7,
          "source_char_end": 8
        }
      ]
    },
    {
      "line_id": "line_0030",
      "text": "哪里没讲清楚就补一句",
      "target_start_ms": 38450,
      "target_end_ms": 40050,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "哪",
          "target_start_ms": 38450,
          "target_end_ms": 38610,
          "source_word_index": 0,
          "source_char_start": 0,
          "source_char_end": 1
        },
        {
          "token_id": "token_002",
          "text": "里",
          "target_start_ms": 38610,
          "target_end_ms": 38730,
          "source_word_index": 1,
          "source_char_start": 1,
          "source_char_end": 2
        },
        {
          "token_id": "token_003",
          "text": "没",
          "target_start_ms": 38730,
          "target_end_ms": 38890,
          "source_word_index": 2,
          "source_char_start": 2,
          "source_char_end": 3
        },
        {
          "token_id": "token_004",
          "text": "讲",
          "target_start_ms": 38890,
          "target_end_ms": 39090,
          "source_word_index": 3,
          "source_char_start": 3,
          "source_char_end": 4
        },
        {
          "token_id": "token_005",
          "text": "清",
          "target_start_ms": 39090,
          "target_end_ms": 39250,
          "source_word_index": 4,
          "source_char_start": 4,
          "source_char_end": 5
        },
        {
          "token_id": "token_006",
          "text": "楚",
          "target_start_ms": 39250,
          "target_end_ms": 39330,
          "source_word_index": 5,
          "source_char_start": 5,
          "source_char_end": 6
        },
        {
          "token_id": "token_007",
          "text": "就",
          "target_start_ms": 39330,
          "target_end_ms": 39530,
          "source_word_index": 6,
          "source_char_start": 6,
          "source_char_end": 7
        },
        {
          "token_id": "token_008",
          "text": "补",
          "target_start_ms": 39530,
          "target_end_ms": 39730,
          "source_word_index": 7,
          "source_char_start": 7,
          "source_char_end": 8
        },
        {
          "token_id": "token_009",
          "text": "一",
          "target_start_ms": 39730,
          "target_end_ms": 39890,
          "source_word_index": 8,
          "source_char_start": 8,
          "source_char_end": 9
        },
        {
          "token_id": "token_010",
          "text": "句",
          "target_start_ms": 39890,
          "target_end_ms": 40050,
          "source_word_index": 9,
          "source_char_start": 9,
          "source_char_end": 10
        }
      ]
    },
    {
      "line_id": "line_0031",
      "text": "有了第一版",
      "target_start_ms": 40360,
      "target_end_ms": 41080,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "有",
          "target_start_ms": 40360,
          "target_end_ms": 40520,
          "source_word_index": 0,
          "source_char_start": 0,
          "source_char_end": 1
        },
        {
          "token_id": "token_002",
          "text": "了",
          "target_start_ms": 40520,
          "target_end_ms": 40640,
          "source_word_index": 1,
          "source_char_start": 1,
          "source_char_end": 2
        },
        {
          "token_id": "token_003",
          "text": "第",
          "target_start_ms": 40640,
          "target_end_ms": 40720,
          "source_word_index": 2,
          "source_char_start": 2,
          "source_char_end": 3
        },
        {
          "token_id": "token_004",
          "text": "一",
          "target_start_ms": 40720,
          "target_end_ms": 40880,
          "source_word_index": 3,
          "source_char_start": 3,
          "source_char_end": 4
        },
        {
          "token_id": "token_005",
          "text": "版",
          "target_start_ms": 40880,
          "target_end_ms": 41080,
          "source_word_index": 4,
          "source_char_start": 4,
          "source_char_end": 5
        }
      ]
    },
    {
      "line_id": "line_0032",
      "text": "问题就具体了",
      "target_start_ms": 41160,
      "target_end_ms": 42240,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "问",
          "target_start_ms": 41160,
          "target_end_ms": 41360,
          "source_word_index": 0,
          "source_char_start": 0,
          "source_char_end": 1
        },
        {
          "token_id": "token_002",
          "text": "题",
          "target_start_ms": 41360,
          "target_end_ms": 41480,
          "source_word_index": 1,
          "source_char_start": 1,
          "source_char_end": 2
        },
        {
          "token_id": "token_003",
          "text": "就",
          "target_start_ms": 41480,
          "target_end_ms": 41680,
          "source_word_index": 2,
          "source_char_start": 2,
          "source_char_end": 3
        },
        {
          "token_id": "token_004",
          "text": "具",
          "target_start_ms": 41680,
          "target_end_ms": 41800,
          "source_word_index": 3,
          "source_char_start": 3,
          "source_char_end": 4
        },
        {
          "token_id": "token_005",
          "text": "体",
          "target_start_ms": 41800,
          "target_end_ms": 41960,
          "source_word_index": 4,
          "source_char_start": 4,
          "source_char_end": 5
        },
        {
          "token_id": "token_006",
          "text": "了",
          "target_start_ms": 41960,
          "target_end_ms": 42240,
          "source_word_index": 5,
          "source_char_start": 5,
          "source_char_end": 6
        }
      ]
    },
    {
      "line_id": "line_0033",
      "text": "你不再对着空白文档发愁",
      "target_start_ms": 42480,
      "target_end_ms": 44320,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "你",
          "target_start_ms": 42480,
          "target_end_ms": 42640,
          "source_word_index": 0,
          "source_char_start": 0,
          "source_char_end": 1
        },
        {
          "token_id": "token_002",
          "text": "不",
          "target_start_ms": 42640,
          "target_end_ms": 42800,
          "source_word_index": 1,
          "source_char_start": 1,
          "source_char_end": 2
        },
        {
          "token_id": "token_003",
          "text": "再",
          "target_start_ms": 42800,
          "target_end_ms": 42920,
          "source_word_index": 2,
          "source_char_start": 2,
          "source_char_end": 3
        },
        {
          "token_id": "token_004",
          "text": "对",
          "target_start_ms": 42920,
          "target_end_ms": 43080,
          "source_word_index": 3,
          "source_char_start": 3,
          "source_char_end": 4
        },
        {
          "token_id": "token_005",
          "text": "着",
          "target_start_ms": 43080,
          "target_end_ms": 43200,
          "source_word_index": 4,
          "source_char_start": 4,
          "source_char_end": 5
        },
        {
          "token_id": "token_006",
          "text": "空",
          "target_start_ms": 43240,
          "target_end_ms": 43440,
          "source_word_index": 5,
          "source_char_start": 5,
          "source_char_end": 6
        },
        {
          "token_id": "token_007",
          "text": "白",
          "target_start_ms": 43440,
          "target_end_ms": 43600,
          "source_word_index": 6,
          "source_char_start": 6,
          "source_char_end": 7
        },
        {
          "token_id": "token_008",
          "text": "文",
          "target_start_ms": 43600,
          "target_end_ms": 43760,
          "source_word_index": 7,
          "source_char_start": 7,
          "source_char_end": 8
        },
        {
          "token_id": "token_009",
          "text": "档",
          "target_start_ms": 43760,
          "target_end_ms": 43920,
          "source_word_index": 8,
          "source_char_start": 8,
          "source_char_end": 9
        },
        {
          "token_id": "token_010",
          "text": "发",
          "target_start_ms": 43960,
          "target_end_ms": 44160,
          "source_word_index": 9,
          "source_char_start": 9,
          "source_char_end": 10
        },
        {
          "token_id": "token_011",
          "text": "愁",
          "target_start_ms": 44160,
          "target_end_ms": 44320,
          "source_word_index": 10,
          "source_char_start": 10,
          "source_char_end": 11
        }
      ]
    },
    {
      "line_id": "line_0034",
      "text": "而是知道",
      "target_start_ms": 44360,
      "target_end_ms": 44960,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "而",
          "target_start_ms": 44360,
          "target_end_ms": 44480,
          "source_word_index": 0,
          "source_char_start": 0,
          "source_char_end": 1
        },
        {
          "token_id": "token_002",
          "text": "是",
          "target_start_ms": 44480,
          "target_end_ms": 44640,
          "source_word_index": 1,
          "source_char_start": 1,
          "source_char_end": 2
        },
        {
          "token_id": "token_003",
          "text": "知",
          "target_start_ms": 44640,
          "target_end_ms": 44760,
          "source_word_index": 2,
          "source_char_start": 2,
          "source_char_end": 3
        },
        {
          "token_id": "token_004",
          "text": "道",
          "target_start_ms": 44760,
          "target_end_ms": 44960,
          "source_word_index": 3,
          "source_char_start": 3,
          "source_char_end": 4
        }
      ]
    },
    {
      "line_id": "line_0035",
      "text": "这句话要缩短",
      "target_start_ms": 45120,
      "target_end_ms": 46160,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "这",
          "target_start_ms": 45120,
          "target_end_ms": 45320,
          "source_word_index": 0,
          "source_char_start": 0,
          "source_char_end": 1
        },
        {
          "token_id": "token_002",
          "text": "句",
          "target_start_ms": 45320,
          "target_end_ms": 45440,
          "source_word_index": 1,
          "source_char_start": 1,
          "source_char_end": 2
        },
        {
          "token_id": "token_003",
          "text": "话",
          "target_start_ms": 45440,
          "target_end_ms": 45560,
          "source_word_index": 2,
          "source_char_start": 2,
          "source_char_end": 3
        },
        {
          "token_id": "token_004",
          "text": "要",
          "target_start_ms": 45560,
          "target_end_ms": 45720,
          "source_word_index": 3,
          "source_char_start": 3,
          "source_char_end": 4
        },
        {
          "token_id": "token_005",
          "text": "缩",
          "target_start_ms": 45720,
          "target_end_ms": 45920,
          "source_word_index": 4,
          "source_char_start": 4,
          "source_char_end": 5
        },
        {
          "token_id": "token_006",
          "text": "短",
          "target_start_ms": 45920,
          "target_end_ms": 46160,
          "source_word_index": 5,
          "source_char_start": 5,
          "source_char_end": 6
        }
      ]
    },
    {
      "line_id": "line_0036",
      "text": "那个例子要补充",
      "target_start_ms": 46240,
      "target_end_ms": 47360,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "那",
          "target_start_ms": 46240,
          "target_end_ms": 46400,
          "source_word_index": 0,
          "source_char_start": 0,
          "source_char_end": 1
        },
        {
          "token_id": "token_002",
          "text": "个",
          "target_start_ms": 46400,
          "target_end_ms": 46560,
          "source_word_index": 1,
          "source_char_start": 1,
          "source_char_end": 2
        },
        {
          "token_id": "token_003",
          "text": "例",
          "target_start_ms": 46560,
          "target_end_ms": 46680,
          "source_word_index": 2,
          "source_char_start": 2,
          "source_char_end": 3
        },
        {
          "token_id": "token_004",
          "text": "子",
          "target_start_ms": 46680,
          "target_end_ms": 46800,
          "source_word_index": 3,
          "source_char_start": 3,
          "source_char_end": 4
        },
        {
          "token_id": "token_005",
          "text": "要",
          "target_start_ms": 46800,
          "target_end_ms": 46960,
          "source_word_index": 4,
          "source_char_start": 4,
          "source_char_end": 5
        },
        {
          "token_id": "token_006",
          "text": "补",
          "target_start_ms": 46960,
          "target_end_ms": 47120,
          "source_word_index": 5,
          "source_char_start": 5,
          "source_char_end": 6
        },
        {
          "token_id": "token_007",
          "text": "充",
          "target_start_ms": 47120,
          "target_end_ms": 47360,
          "source_word_index": 6,
          "source_char_start": 6,
          "source_char_end": 7
        }
      ]
    },
    {
      "line_id": "line_0037",
      "text": "如果还是不想动",
      "target_start_ms": 47640,
      "target_end_ms": 48680,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "如",
          "target_start_ms": 47640,
          "target_end_ms": 47800,
          "source_word_index": 0,
          "source_char_start": 0,
          "source_char_end": 1
        },
        {
          "token_id": "token_002",
          "text": "果",
          "target_start_ms": 47800,
          "target_end_ms": 47920,
          "source_word_index": 1,
          "source_char_start": 1,
          "source_char_end": 2
        },
        {
          "token_id": "token_003",
          "text": "还",
          "target_start_ms": 47920,
          "target_end_ms": 48120,
          "source_word_index": 2,
          "source_char_start": 2,
          "source_char_end": 3
        },
        {
          "token_id": "token_004",
          "text": "是",
          "target_start_ms": 48120,
          "target_end_ms": 48240,
          "source_word_index": 3,
          "source_char_start": 3,
          "source_char_end": 4
        },
        {
          "token_id": "token_005",
          "text": "不",
          "target_start_ms": 48240,
          "target_end_ms": 48360,
          "source_word_index": 4,
          "source_char_start": 4,
          "source_char_end": 5
        },
        {
          "token_id": "token_006",
          "text": "想",
          "target_start_ms": 48360,
          "target_end_ms": 48480,
          "source_word_index": 5,
          "source_char_start": 5,
          "source_char_end": 6
        },
        {
          "token_id": "token_007",
          "text": "动",
          "target_start_ms": 48480,
          "target_end_ms": 48680,
          "source_word_index": 6,
          "source_char_start": 6,
          "source_char_end": 7
        }
      ]
    },
    {
      "line_id": "line_0038",
      "text": "就继续拆",
      "target_start_ms": 48680,
      "target_end_ms": 49360,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "就",
          "target_start_ms": 48680,
          "target_end_ms": 48880,
          "source_word_index": 0,
          "source_char_start": 0,
          "source_char_end": 1
        },
        {
          "token_id": "token_002",
          "text": "继",
          "target_start_ms": 48880,
          "target_end_ms": 48960,
          "source_word_index": 1,
          "source_char_start": 1,
          "source_char_end": 2
        },
        {
          "token_id": "token_003",
          "text": "续",
          "target_start_ms": 48960,
          "target_end_ms": 49080,
          "source_word_index": 2,
          "source_char_start": 2,
          "source_char_end": 3
        },
        {
          "token_id": "token_004",
          "text": "拆",
          "target_start_ms": 49120,
          "target_end_ms": 49360,
          "source_word_index": 3,
          "source_char_start": 3,
          "source_char_end": 4
        }
      ]
    },
    {
      "line_id": "line_0039",
      "text": "写一段太难",
      "target_start_ms": 49560,
      "target_end_ms": 50480,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "写",
          "target_start_ms": 49560,
          "target_end_ms": 49760,
          "source_word_index": 0,
          "source_char_start": 0,
          "source_char_end": 1
        },
        {
          "token_id": "token_002",
          "text": "一",
          "target_start_ms": 49760,
          "target_end_ms": 49920,
          "source_word_index": 1,
          "source_char_start": 1,
          "source_char_end": 2
        },
        {
          "token_id": "token_003",
          "text": "段",
          "target_start_ms": 49920,
          "target_end_ms": 50080,
          "source_word_index": 2,
          "source_char_start": 2,
          "source_char_end": 3
        },
        {
          "token_id": "token_004",
          "text": "太",
          "target_start_ms": 50080,
          "target_end_ms": 50280,
          "source_word_index": 3,
          "source_char_start": 3,
          "source_char_end": 4
        },
        {
          "token_id": "token_005",
          "text": "难",
          "target_start_ms": 50280,
          "target_end_ms": 50480,
          "source_word_index": 4,
          "source_char_start": 4,
          "source_char_end": 5
        }
      ]
    },
    {
      "line_id": "line_0040",
      "text": "就先写一句",
      "target_start_ms": 50480,
      "target_end_ms": 51400,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "就",
          "target_start_ms": 50480,
          "target_end_ms": 50680,
          "source_word_index": 0,
          "source_char_start": 0,
          "source_char_end": 1
        },
        {
          "token_id": "token_002",
          "text": "先",
          "target_start_ms": 50680,
          "target_end_ms": 50880,
          "source_word_index": 1,
          "source_char_start": 1,
          "source_char_end": 2
        },
        {
          "token_id": "token_003",
          "text": "写",
          "target_start_ms": 50880,
          "target_end_ms": 51080,
          "source_word_index": 2,
          "source_char_start": 2,
          "source_char_end": 3
        },
        {
          "token_id": "token_004",
          "text": "一",
          "target_start_ms": 51080,
          "target_end_ms": 51240,
          "source_word_index": 3,
          "source_char_start": 3,
          "source_char_end": 4
        },
        {
          "token_id": "token_005",
          "text": "句",
          "target_start_ms": 51240,
          "target_end_ms": 51400,
          "source_word_index": 4,
          "source_char_start": 4,
          "source_char_end": 5
        }
      ]
    },
    {
      "line_id": "line_0041",
      "text": "录完整条太难",
      "target_start_ms": 51560,
      "target_end_ms": 52600,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "录",
          "target_start_ms": 51560,
          "target_end_ms": 51720,
          "source_word_index": 0,
          "source_char_start": 0,
          "source_char_end": 1
        },
        {
          "token_id": "token_002",
          "text": "完",
          "target_start_ms": 51760,
          "target_end_ms": 51920,
          "source_word_index": 1,
          "source_char_start": 1,
          "source_char_end": 2
        },
        {
          "token_id": "token_003",
          "text": "整",
          "target_start_ms": 51920,
          "target_end_ms": 52080,
          "source_word_index": 2,
          "source_char_start": 2,
          "source_char_end": 3
        },
        {
          "token_id": "token_004",
          "text": "条",
          "target_start_ms": 52080,
          "target_end_ms": 52280,
          "source_word_index": 3,
          "source_char_start": 3,
          "source_char_end": 4
        },
        {
          "token_id": "token_005",
          "text": "太",
          "target_start_ms": 52280,
          "target_end_ms": 52440,
          "source_word_index": 4,
          "source_char_start": 4,
          "source_char_end": 5
        },
        {
          "token_id": "token_006",
          "text": "难",
          "target_start_ms": 52440,
          "target_end_ms": 52600,
          "source_word_index": 5,
          "source_char_start": 5,
          "source_char_end": 6
        }
      ]
    },
    {
      "line_id": "line_0042",
      "text": "就先录个开头",
      "target_start_ms": 52600,
      "target_end_ms": 53480,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "就",
          "target_start_ms": 52600,
          "target_end_ms": 52760,
          "source_word_index": 0,
          "source_char_start": 0,
          "source_char_end": 1
        },
        {
          "token_id": "token_002",
          "text": "先",
          "target_start_ms": 52760,
          "target_end_ms": 52880,
          "source_word_index": 1,
          "source_char_start": 1,
          "source_char_end": 2
        },
        {
          "token_id": "token_003",
          "text": "录",
          "target_start_ms": 52880,
          "target_end_ms": 53040,
          "source_word_index": 2,
          "source_char_start": 2,
          "source_char_end": 3
        },
        {
          "token_id": "token_004",
          "text": "个",
          "target_start_ms": 53080,
          "target_end_ms": 53240,
          "source_word_index": 3,
          "source_char_start": 3,
          "source_char_end": 4
        },
        {
          "token_id": "token_005",
          "text": "开",
          "target_start_ms": 53240,
          "target_end_ms": 53360,
          "source_word_index": 4,
          "source_char_start": 4,
          "source_char_end": 5
        },
        {
          "token_id": "token_006",
          "text": "头",
          "target_start_ms": 53360,
          "target_end_ms": 53480,
          "source_word_index": 5,
          "source_char_start": 5,
          "source_char_end": 6
        }
      ]
    },
    {
      "line_id": "line_0043",
      "text": "先让事情有个开头",
      "target_start_ms": 53920,
      "target_end_ms": 55040,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "先",
          "target_start_ms": 53920,
          "target_end_ms": 54040,
          "source_word_index": 0,
          "source_char_start": 0,
          "source_char_end": 1
        },
        {
          "token_id": "token_002",
          "text": "让",
          "target_start_ms": 54040,
          "target_end_ms": 54200,
          "source_word_index": 1,
          "source_char_start": 1,
          "source_char_end": 2
        },
        {
          "token_id": "token_003",
          "text": "事",
          "target_start_ms": 54200,
          "target_end_ms": 54320,
          "source_word_index": 2,
          "source_char_start": 2,
          "source_char_end": 3
        },
        {
          "token_id": "token_004",
          "text": "情",
          "target_start_ms": 54320,
          "target_end_ms": 54400,
          "source_word_index": 3,
          "source_char_start": 3,
          "source_char_end": 4
        },
        {
          "token_id": "token_005",
          "text": "有",
          "target_start_ms": 54400,
          "target_end_ms": 54560,
          "source_word_index": 4,
          "source_char_start": 4,
          "source_char_end": 5
        },
        {
          "token_id": "token_006",
          "text": "个",
          "target_start_ms": 54560,
          "target_end_ms": 54720,
          "source_word_index": 5,
          "source_char_start": 5,
          "source_char_end": 6
        },
        {
          "token_id": "token_007",
          "text": "开",
          "target_start_ms": 54720,
          "target_end_ms": 54880,
          "source_word_index": 6,
          "source_char_start": 6,
          "source_char_end": 7
        },
        {
          "token_id": "token_008",
          "text": "头",
          "target_start_ms": 54880,
          "target_end_ms": 55040,
          "source_word_index": 7,
          "source_char_start": 7,
          "source_char_end": 8
        }
      ]
    },
    {
      "line_id": "line_0044",
      "text": "再一点点把它做好",
      "target_start_ms": 55120,
      "target_end_ms": 56680,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "再",
          "target_start_ms": 55120,
          "target_end_ms": 55320,
          "source_word_index": 0,
          "source_char_start": 0,
          "source_char_end": 1
        },
        {
          "token_id": "token_002",
          "text": "一",
          "target_start_ms": 55320,
          "target_end_ms": 55480,
          "source_word_index": 1,
          "source_char_start": 1,
          "source_char_end": 2
        },
        {
          "token_id": "token_003",
          "text": "点",
          "target_start_ms": 55480,
          "target_end_ms": 55640,
          "source_word_index": 2,
          "source_char_start": 2,
          "source_char_end": 3
        },
        {
          "token_id": "token_004",
          "text": "点",
          "target_start_ms": 55680,
          "target_end_ms": 55800,
          "source_word_index": 3,
          "source_char_start": 3,
          "source_char_end": 4
        },
        {
          "token_id": "token_005",
          "text": "把",
          "target_start_ms": 55840,
          "target_end_ms": 56040,
          "source_word_index": 4,
          "source_char_start": 4,
          "source_char_end": 5
        },
        {
          "token_id": "token_006",
          "text": "它",
          "target_start_ms": 56040,
          "target_end_ms": 56120,
          "source_word_index": 5,
          "source_char_start": 5,
          "source_char_end": 6
        },
        {
          "token_id": "token_007",
          "text": "做",
          "target_start_ms": 56200,
          "target_end_ms": 56360,
          "source_word_index": 6,
          "source_char_start": 6,
          "source_char_end": 7
        },
        {
          "token_id": "token_008",
          "text": "好",
          "target_start_ms": 56360,
          "target_end_ms": 56680,
          "source_word_index": 7,
          "source_char_start": 7,
          "source_char_end": 8
        }
      ]
    },
    {
      "line_id": "line_0045",
      "text": "想想那件你一直没开始的事",
      "target_start_ms": 57080,
      "target_end_ms": 59000,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "想",
          "target_start_ms": 57080,
          "target_end_ms": 57240,
          "source_word_index": 0,
          "source_char_start": 0,
          "source_char_end": 1
        },
        {
          "token_id": "token_002",
          "text": "想",
          "target_start_ms": 57320,
          "target_end_ms": 57400,
          "source_word_index": 1,
          "source_char_start": 1,
          "source_char_end": 2
        },
        {
          "token_id": "token_003",
          "text": "那",
          "target_start_ms": 57400,
          "target_end_ms": 57520,
          "source_word_index": 2,
          "source_char_start": 2,
          "source_char_end": 3
        },
        {
          "token_id": "token_004",
          "text": "件",
          "target_start_ms": 57520,
          "target_end_ms": 57680,
          "source_word_index": 3,
          "source_char_start": 3,
          "source_char_end": 4
        },
        {
          "token_id": "token_005",
          "text": "你",
          "target_start_ms": 57680,
          "target_end_ms": 57840,
          "source_word_index": 4,
          "source_char_start": 4,
          "source_char_end": 5
        },
        {
          "token_id": "token_006",
          "text": "一",
          "target_start_ms": 57840,
          "target_end_ms": 58000,
          "source_word_index": 5,
          "source_char_start": 5,
          "source_char_end": 6
        },
        {
          "token_id": "token_007",
          "text": "直",
          "target_start_ms": 58000,
          "target_end_ms": 58160,
          "source_word_index": 6,
          "source_char_start": 6,
          "source_char_end": 7
        },
        {
          "token_id": "token_008",
          "text": "没",
          "target_start_ms": 58160,
          "target_end_ms": 58360,
          "source_word_index": 7,
          "source_char_start": 7,
          "source_char_end": 8
        },
        {
          "token_id": "token_009",
          "text": "开",
          "target_start_ms": 58360,
          "target_end_ms": 58520,
          "source_word_index": 8,
          "source_char_start": 8,
          "source_char_end": 9
        },
        {
          "token_id": "token_010",
          "text": "始",
          "target_start_ms": 58520,
          "target_end_ms": 58640,
          "source_word_index": 9,
          "source_char_start": 9,
          "source_char_end": 10
        },
        {
          "token_id": "token_011",
          "text": "的",
          "target_start_ms": 58640,
          "target_end_ms": 58800,
          "source_word_index": 10,
          "source_char_start": 10,
          "source_char_end": 11
        },
        {
          "token_id": "token_012",
          "text": "事",
          "target_start_ms": 58800,
          "target_end_ms": 59000,
          "source_word_index": 11,
          "source_char_start": 11,
          "source_char_end": 12
        }
      ]
    },
    {
      "line_id": "line_0046",
      "text": "接下来的五分钟",
      "target_start_ms": 59200,
      "target_end_ms": 60120,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "接",
          "target_start_ms": 59200,
          "target_end_ms": 59360,
          "source_word_index": 0,
          "source_char_start": 0,
          "source_char_end": 1
        },
        {
          "token_id": "token_002",
          "text": "下",
          "target_start_ms": 59360,
          "target_end_ms": 59480,
          "source_word_index": 1,
          "source_char_start": 1,
          "source_char_end": 2
        },
        {
          "token_id": "token_003",
          "text": "来",
          "target_start_ms": 59480,
          "target_end_ms": 59600,
          "source_word_index": 2,
          "source_char_start": 2,
          "source_char_end": 3
        },
        {
          "token_id": "token_004",
          "text": "的",
          "target_start_ms": 59600,
          "target_end_ms": 59720,
          "source_word_index": 3,
          "source_char_start": 3,
          "source_char_end": 4
        },
        {
          "token_id": "token_005",
          "text": "五",
          "target_start_ms": 59720,
          "target_end_ms": 59840,
          "source_word_index": 4,
          "source_char_start": 4,
          "source_char_end": 5
        },
        {
          "token_id": "token_006",
          "text": "分",
          "target_start_ms": 59840,
          "target_end_ms": 60000,
          "source_word_index": 5,
          "source_char_start": 5,
          "source_char_end": 6
        },
        {
          "token_id": "token_007",
          "text": "钟",
          "target_start_ms": 60000,
          "target_end_ms": 60120,
          "source_word_index": 6,
          "source_char_start": 6,
          "source_char_end": 7
        }
      ]
    },
    {
      "line_id": "line_0047",
      "text": "你能先完成哪一个小动作",
      "target_start_ms": 60120,
      "target_end_ms": 61960,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "你",
          "target_start_ms": 60120,
          "target_end_ms": 60280,
          "source_word_index": 0,
          "source_char_start": 0,
          "source_char_end": 1
        },
        {
          "token_id": "token_002",
          "text": "能",
          "target_start_ms": 60280,
          "target_end_ms": 60480,
          "source_word_index": 1,
          "source_char_start": 1,
          "source_char_end": 2
        },
        {
          "token_id": "token_003",
          "text": "先",
          "target_start_ms": 60480,
          "target_end_ms": 60720,
          "source_word_index": 2,
          "source_char_start": 2,
          "source_char_end": 3
        },
        {
          "token_id": "token_004",
          "text": "完",
          "target_start_ms": 60720,
          "target_end_ms": 60880,
          "source_word_index": 3,
          "source_char_start": 3,
          "source_char_end": 4
        },
        {
          "token_id": "token_005",
          "text": "成",
          "target_start_ms": 60880,
          "target_end_ms": 61040,
          "source_word_index": 4,
          "source_char_start": 4,
          "source_char_end": 5
        },
        {
          "token_id": "token_006",
          "text": "哪",
          "target_start_ms": 61080,
          "target_end_ms": 61280,
          "source_word_index": 5,
          "source_char_start": 5,
          "source_char_end": 6
        },
        {
          "token_id": "token_007",
          "text": "一",
          "target_start_ms": 61280,
          "target_end_ms": 61400,
          "source_word_index": 6,
          "source_char_start": 6,
          "source_char_end": 7
        },
        {
          "token_id": "token_008",
          "text": "个",
          "target_start_ms": 61400,
          "target_end_ms": 61480,
          "source_word_index": 7,
          "source_char_start": 7,
          "source_char_end": 8
        },
        {
          "token_id": "token_009",
          "text": "小",
          "target_start_ms": 61480,
          "target_end_ms": 61680,
          "source_word_index": 8,
          "source_char_start": 8,
          "source_char_end": 9
        },
        {
          "token_id": "token_010",
          "text": "动",
          "target_start_ms": 61680,
          "target_end_ms": 61840,
          "source_word_index": 9,
          "source_char_start": 9,
          "source_char_end": 10
        },
        {
          "token_id": "token_011",
          "text": "作",
          "target_start_ms": 61840,
          "target_end_ms": 61960,
          "source_word_index": 10,
          "source_char_start": 10,
          "source_char_end": 11
        }
      ]
    }
  ]
};
