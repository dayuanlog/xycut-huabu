# 模板使用指南：暖白板 · 画布小窗横屏（canvas-intro-presenter-light-landscape）

## 模板定位
- **画幅与比例**：16:9 横屏（1920×1080，暖白板画布 + 真人口播小窗）
- **叙事模式**：画布主导 + 人物小窗（canvas-led）
- **视觉配色**：暖米白纸底 `#f3efe5` + 深青墨 `#203c42` + 白板青 `#008793` + 人物画中画
- **字体体系**：Noto Sans SC（`XYCut Noto`）
- **适用场景**：B 站 / 知识区横屏课程、清爽白板讲解 + 讲师出镜陪伴

## 结构与动效特征
- **画布结构**：9 块 16:9 逻辑画板（蛇形 3×3 排布）+ 20 个模块化视觉组件，全部绑定音频字词时间戳（`timing_precision: "word"`）。
- **跨画板纸飞机引导**：`film-flight.js` 仅在开场入画与**跨画板切换**（`prevBoard !== nextBoard`）时触发，避免同画板内部频繁飞行干扰阅读。
- **封面规范**：竖屏版严格居中于 3:4 安全区；横屏版为 16:9 展示海报（正文 `intro.frames = 0` 直接进入画面）。

## AI 复用改写要点
1. 替换 `canvas-plan.json`（并同步 `canvas-plan.js`）中的 `series.title`、`series.subtitle`、`series.cover_lines` 与各组件 `content` 文案和音频锚点。
2. 保持每个组件的 `bounds` 不超出所属 `board`，修改后运行 `validate_canvas_plan.py` 校验通过。
3. 若为人物版模板，替换 `assets/media/presenter.mp4` 与 `assets/media/person-poster.jpg` 即可同步更新口播人物与封面人物形象。
