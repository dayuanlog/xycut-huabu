(()=>{
 const style=document.createElement('style');style.id='warm-whiteboard-theme';
 style.textContent=`
 :root{--bg:#f3efe5;--ink:#203c42;--muted:#617879;--line:#a0b3a9;--accent:#008793}
 body,.workspace,.screen{background:#f3efe5;color:#203c42}.screen{box-shadow:none}
 .stage{background-color:#f3efe5;background-image:radial-gradient(ellipse at 25% 45%,#e5ede230,transparent 68%),radial-gradient(#658b8340 1.25px,transparent 1.7px),linear-gradient(#82978b1a 1px,transparent 1px),linear-gradient(90deg,#82978b1a 1px,transparent 1px);background-size:100% 100%,40px 40px,180px 180px,180px 180px}
 .world{background-color:#f3efe5;background-image:radial-gradient(#658b8340 1.4px,transparent 1.9px),linear-gradient(#82978b1a 1px,transparent 1px),linear-gradient(90deg,#82978b1a 1px,transparent 1px);background-size:44px 44px,180px 180px,180px 180px}
 .demo-mode .world{background:none}
 .board-label{color:#617879}.board-label span{color:#008793}.board:before{border-color:#8aa59970}.board:after{color:#668d87}
 .film-series b{color:#3e656b}.film-series i{color:#203c42}
 .film-cover{background-color:#f3efe5;background-image:radial-gradient(ellipse at 35% 48%,#e0eadd55,transparent 68%),radial-gradient(#658b8340 1.25px,transparent 1.7px),linear-gradient(#82978b1a 1px,transparent 1px),linear-gradient(90deg,#82978b1a 1px,transparent 1px);background-size:100% 100%,40px 40px,180px 180px,180px 180px}
 .series-cover-name{color:#3e656b}.series-cover-day{color:#aa6229}.series-cover-divider{background:#8da8a0}.series-cover-subtitle{color:#203c42}.series-cover-subtitle .cover-line-1{color:#008793}
 .intro-scene{color:#203c42}.i-word:after{color:#007c87;text-shadow:0 0 8px #00879333}
 .made-proof{color:#9a602d}.brand-free span{color:#aa6229!important}
 #stage [id^="canvas-subtitles-"] .canvas-caption-line{color:#203c42;text-shadow:0 1px 1px #fff8;-webkit-text-stroke:.2px #f3efe5}
 #stage [id^="canvas-subtitles-"] .canvas-caption-cursor{background:#007f8b;box-shadow:0 0 8px #00879344}
 #stage [id^="canvas-subtitles-"] .canvas-caption-shade{background:none}
 #stage [id^="canvas-subtitles-"] .canvas-caption-sheen{color:#007f8b;text-shadow:0 0 10px #00879344}
 .resource-mode .component{opacity:1!important}
 #canvas-reveal-outro h2{color:#203c42}#canvas-reveal-outro h2 span{color:#008793}
 #canvas-reveal-outro p,#canvas-reveal-order{color:#526f72}
 .demo-mode.outro-overview .world{background-color:#f3efe5;background-image:radial-gradient(#658b8340 3px,transparent 4px),linear-gradient(#82978b1a 2px,transparent 2px),linear-gradient(90deg,#82978b1a 2px,transparent 2px);background-size:90px 90px,360px 360px,360px 360px}
 .outro-preview{background:#e0e9df;color:#264e55;border-color:#9ebcad}
 `;document.head.append(style);
})();
