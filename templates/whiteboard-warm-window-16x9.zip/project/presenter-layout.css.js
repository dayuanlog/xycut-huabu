(()=>{
const s=document.createElement('style');s.textContent=`
.intro-brand .brand-code{display:none}
.intro-aspect-switch .i-title{font-size:42px!important}
.intro-aspect-switch .i-title>span:not(.i-word){font-size:46px!important}
`;document.head.append(s);
})();