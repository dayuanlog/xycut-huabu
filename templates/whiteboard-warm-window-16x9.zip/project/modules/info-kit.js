(()=>{
 const clamp=t=>Math.max(0,Math.min(1,t)),ease=t=>1-Math.pow(1-clamp(t),3),phase=(t,s,d=.45)=>ease((t-s)/d);
 const esc=t=>String(t??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const normal=s=>String(s??'').replace(/[\s\p{P}\p{S}]/gu,'').toLowerCase();
 function time(number,phrase='',edge='start'){
  const line=window.FINAL_TIMELINE.lines.find(l=>l.line_id===`line_${String(number).padStart(3,'0')}`);
  if(!line)throw Error('缺少本次字幕行 '+number);
  if(phrase){let text='',owners=[];for(const token of line.tokens||[]){const word=normal(token.text);for(const c of word){text+=c;owners.push(token)}}
   const at=text.indexOf(normal(phrase));if(at>=0&&owners[at]){const token=owners[edge==='end'?at+normal(phrase).length-1:at];return token[edge==='end'?'target_end_ms':'target_start_ms']/1000;}}
  return line[edge==='end'?'target_end_ms':'target_start_ms']/1000;
 }
 function show(node,t,start,duration=.45,dy=8){if(!node)return;const u=phase(t,start,duration),v=Math.sin(Math.PI*u);node.style.opacity='1';node.style.transform=`translateY(${-dy*v}px)`;node.style.filter='none';}
 function glow(node,t,start,duration=.8){if(!node)return;const u=clamp((t-start)/duration),v=Math.sin(Math.PI*u);node.style.textShadow=`0 0 ${26*v}px rgba(92,233,255,${v*.7})`;node.style.setProperty('--glint',`${u*150-25}%`);}
 function draw(path,t,start,duration=.75){if(!path)return;const length=path.getTotalLength();path.style.strokeDasharray=length;path.style.strokeDashoffset=length*(1-phase(t,start,duration));}
 function active(node,t,start,end=Infinity){if(!node)return;const u=phase(t,start,.35),v=Number.isFinite(end)?1-phase(t,end,.35):1;node.style.opacity=String(u*v);node.style.transform=`translateY(${(1-u)*7}px)`;}
 function highlight(node,t,start,duration=.7){const u=phase(t,start,duration);node.style.borderColor=t>=start?'#00c1cd':'#4d5965';node.style.boxShadow=`0 0 ${22*Math.sin(Math.PI*u)}px #00c1cd35`;}
 function wave(t,start,index){return Math.sin((t-start)*5+index*.65)*(t>=start&&t<=start+1.6?1:0)}
 const style=document.createElement('style');style.textContent=`[data-module^="info/"]{position:relative;color:#f5f8fb;font-family:'XYCut Noto','Microsoft YaHei UI',sans-serif}[data-module^="info/"] *{box-sizing:border-box}[data-module^="info/"] .info-accent{color:#00c1cd}[data-module^="info/"] .info-muted{color:#a7b8c7}[data-module^="info/"] .info-cursor{position:absolute;width:34px;height:44px;z-index:20;pointer-events:none}[data-module^="info/"] .info-cursor svg{width:100%;height:100%;fill:#f5ffff;stroke:#11232c;stroke-width:1;filter:drop-shadow(0 4px 5px #0007)}[data-module^="info/"] .info-line{stroke:#00c1cd;stroke-width:3;fill:none}[data-module^="info/"] .info-line-bg{stroke:#607581;stroke-width:2;fill:none}[data-module^="info/"] .ui-icon{width:48px;height:48px;fill:currentColor}.resource-mode [data-module^="info/"] .info-cursor{opacity:0!important}`;document.head.append(style);
 window.InfoKit={clamp,ease,phase,esc,time,show,glow,draw,active,highlight,wave,icon:n=>window.CanvasIcons[n]||window.CanvasIcons.file};
})();
