(() => {
  'use strict';
  const P = window.CANVAS_PLAN;
  const config = P.presenter_layout || {};
  const cameraAPI = window.CanvasCamera;
  const scene = window.CanvasScene;
  const explorer = window.CanvasExplorer;
  const stage = document.querySelector('#stage');
  const voice = document.querySelector('#voice');
  if (!stage || !cameraAPI || !scene || !explorer) throw Error('Presenter runtime must load after the canvas player.');
  const exporting = new URLSearchParams(location.search).get('render') === '1';
  const led = config.mode === 'presenter-led';
  const output = P.output || {width: 1080, height: 1920};
  const sourceEnd = config.source_duration ?? 126.88;
  const outro = config.outro_start ?? sourceEnd;
  const slots = config.slots || {};
  const intervals = [...(config.focus_intervals || [])].sort((a, b) => a.start - b.start);
  const previews = new Map();
  const clamp = x => Math.max(0, Math.min(1, x));
  const ease = cameraAPI.ease || (x => { x = clamp(x); return x * x * (3 - 2 * x); });
  const mix = (a, b, q) => a + (b - a) * q;
  const componentId = target => String(target || '').split('/')[0];
  const originalCameraAt = cameraAPI.at;
  const isBrowsing = () => explorer.getMode() === 'resource' || document.body.classList.contains('resource-mode');
  document.body.classList.add(led ? 'presenter-led' : 'canvas-led');

  document.querySelectorAll('video[data-presenter-owner]').forEach(node => {
    const image = document.createElement('img');
    image.src = node.poster || config.poster || 'assets/media/person-poster.jpg';
    image.alt = '';
    image.className = 'presenter-static-image';
    node.pause();
    node.replaceWith(image);
  });
  for (const [id, slot] of Object.entries(slots)) {
    const component = P.components.find(item => item.id === id);
    if (!component) throw Error('Unknown presenter component: ' + id);
    const size = component.design_size || {width: 600, height: 420};
    if (![slot.x, slot.y, slot.width, slot.height].every(Number.isFinite) || slot.x < 0 || slot.y < 0 || slot.width <= 0 || slot.height <= 0 || slot.x + slot.width > size.width || slot.y + slot.height > size.height) {
      throw Error('Presenter slot exceeds component design bounds: ' + id);
    }
    const element = scene.elements.get(id);
    const root = element?.querySelector('.intro-scene') || element;
    if (!root) throw Error('Presenter component has no scene: ' + id);
    let preview = root.querySelector('[data-presenter-preview]');
    if (!preview) {
      preview = document.createElement('div');
      preview.dataset.presenterPreview = id;
      const image = document.createElement('img');
      image.src = config.poster || 'assets/media/person-poster.jpg';
      image.alt = '';
      image.className = 'presenter-static-image';
      preview.append(image);
      root.append(preview);
    }
    preview.classList.add('presenter-slot-preview');
    Object.assign(preview.style, {
      left: slot.x + 'px', top: slot.y + 'px', width: slot.width + 'px', height: slot.height + 'px',
      borderRadius: slot.shape === 'circle' ? '50%' : '14px'
    });
    previews.set(id, preview);
  }

  const layer = document.createElement('div');
  layer.className = 'canvas-presenter-layer';
  const frame = document.createElement('div');
  frame.className = 'canvas-presenter-frame';
  const video = document.createElement('video');
  video.muted = true;
  video.defaultMuted = true;
  video.playsInline = true;
  video.preload = 'auto';
  video.setAttribute('muted', '');
  video.setAttribute('playsinline', '');
  video.poster = config.poster || 'assets/media/person-poster.jpg';
  video.src = config.source || 'assets/media/presenter.mp4';
  video.dataset.presenterLive = 'true';
  frame.append(video);
  layer.append(frame);
  stage.append(layer);
  const words = document.createElement('div');
  words.className = 'canvas-presenter-words';
  const heading = document.createElement('h2');
  words.append(heading);
  stage.append(words);
  const style = document.createElement('style');
  style.textContent = `
    .presenter-slot-preview{position:absolute;overflow:hidden;box-sizing:border-box;border:2px solid #8aa4af66;pointer-events:none}
    .presenter-static-image{display:block;width:100%;height:100%;object-fit:cover;object-position:50% 34%}
    .canvas-presenter-layer{position:absolute;inset:0;z-index:25;pointer-events:none;overflow:hidden}
    .canvas-presenter-frame{position:absolute;overflow:hidden;box-sizing:border-box;border:0 solid #91a7b5;background:#101720;transform-origin:0 0}
    .canvas-presenter-frame video{display:block;width:100%;height:100%;object-fit:cover;object-position:50% 34%}
    .canvas-presenter-words{position:absolute;inset:0;z-index:30;pointer-events:none;background:linear-gradient(#0002,transparent 22%,transparent 53%,#0004 85%,#0008)}
    .canvas-presenter-words h2{position:absolute;top:1190px;left:90px;right:90px;margin:0;color:#fff;font-size:66px;font-weight:850;line-height:1.2;white-space:pre-line;overflow-wrap:anywhere;text-shadow:0 3px 16px #0009}
    .canvas-presenter-words h2 em{font-style:normal;color:#8be5e9}
    body.presenter-fullscreen .film-series,body.presenter-morph .film-series,body.presenter-fullscreen .film-window{visibility:hidden!important}
    body.presenter-led.presenter-morph .film-window{visibility:visible!important;opacity:1!important}
    body.presenter-fullscreen #camera-flight-guide,body.presenter-morph #camera-flight-guide,body.presenter-led:not(.presenter-transfer) #camera-flight-guide{visibility:hidden!important;opacity:0!important}
    body.presenter-fullscreen #stage [id^="canvas-subtitles-"] .canvas-caption-line,body.presenter-caption-on-video #stage [id^="canvas-subtitles-"] .canvas-caption-line{color:#fff!important;-webkit-text-stroke:.4px #0009!important;text-shadow:0 3px 10px #000b!important}
    body.presenter-fullscreen #stage [id^="canvas-subtitles-"] .canvas-caption-keyword,body.presenter-caption-on-video #stage [id^="canvas-subtitles-"] .canvas-caption-keyword{color:#fff!important;text-decoration-color:#fff!important}
    body.presenter-fullscreen #stage [id^="canvas-subtitles-"] .canvas-caption-shade,body.presenter-caption-on-video #stage [id^="canvas-subtitles-"] .canvas-caption-shade{background:linear-gradient(transparent,#0009)!important}
    body.presenter-caption-on-video #stage [id^="canvas-subtitles-"] .canvas-caption-cursor{background:#fff!important;box-shadow:0 0 10px #ffffff80!important}
    body.resource-mode .canvas-presenter-layer,body.resource-mode .canvas-presenter-words,body.intro-on .canvas-presenter-layer,body.intro-on .canvas-presenter-words{visibility:hidden!important}
  `;
  document.head.append(style);

  function intervalAt(t) {
    return intervals.find(interval => t >= interval.start && t < interval.end + (interval.transition_out ?? .34));
  }
  function entryShot(interval) {
    const id = interval.components[0];
    const matches = P.shots.map((shot, index) => ({shot, index})).filter(item => componentId(item.shot.target) === id && item.shot.at < interval.end);
    if (!matches.length) throw Error('Presenter interval has no camera shot for ' + id);
    return matches.reduce((best, item) => Math.abs(item.shot.at - interval.start) < Math.abs(best.shot.at - interval.start) ? item : best);
  }
  function entryCamera(plan, interval) {
    const {shot, index} = entryShot(interval);
    const result = cameraAPI.fit(cameraAPI.bounds(plan, shot.target), plan.output, shot.padding ?? .12);
    result.scale *= shot.context_scale ?? 1;
    return {...result, index, shot: {...shot, move: 0}, presenterLock: 'entry', presenterSampleTime: shot.at + (shot.move || 0)};
  }
  function allowedTarget(interval, target) {
    const id = componentId(target);
    return interval.components.includes(id) || P.components.some(component => component.board_id === id && interval.components.includes(component.id));
  }
  function intervalExitTime(interval) {
    const entry = entryShot(interval);
    const next = P.shots.slice(entry.index + 1).find(shot => shot.at < interval.end && !allowedTarget(interval, shot.target));
    return next ? Math.min(interval.end, next.at) : interval.end;
  }
  function intervalCamera(plan, t, interval) {
    const entry = entryShot(interval);
    const lockUntil = Math.max(interval.start + (interval.transition_in ?? .38), entry.shot.at + (entry.shot.move || 0));
    if (t < lockUntil) return entryCamera(plan, interval);
    const exitAt = intervalExitTime(interval);
    const sample = Math.min(t, exitAt - 1e-6);
    const result = originalCameraAt(plan, sample);
    return t >= exitAt ? {...result, presenterLock: 'exit', presenterSampleTime: sample} : result;
  }
  if (led) cameraAPI.at = (plan, t) => {
    if (isBrowsing()) return originalCameraAt(plan, t);
    const interval = intervalAt(t);
    if (!interval) return originalCameraAt(plan, t);
    return intervalCamera(plan, t, interval);
  };

  if (led && window.CanvasAttention?.render) {
    const originalAttention = window.CanvasAttention.render;
    const smooth = x => { x = clamp(x); return x * x * (3 - 2 * x); };
    window.CanvasAttention.render = function(t) {
      const result = originalAttention.call(this, t);
      const camera = cameraAPI.at(P, t);
      if (isBrowsing() || !camera.presenterLock) return result;
      const sample = camera.presenterSampleTime ?? t;
      const shot = camera.shot;
      const previous = P.shots[Math.max(0, camera.index - 1)];
      const q = shot.move ? smooth((sample - shot.at) / shot.move) : 1;
      const target = componentId(shot.target);
      const prior = componentId(previous.target);
      const owner = P.components.find(component => component.id === target);
      const board = P.boards.find(item => item.id === target);
      const activeBoard = owner?.board_id ?? board?.id;
      const anchor = window.FILM_ANCHORS?.[owner?.id]?.start ?? shot.at;
      const prepared = smooth((sample - anchor + .1) / .35);
      const matches = (component, id) => id === 'overview' || component.id === id || component.board_id === id;
      for (const component of P.components) {
        const node = scene.elements.get(component.id);
        if (!node) continue;
        const weight = clamp((matches(component, prior) ? 1 - q : 0) + (matches(component, target) ? q : 0));
        const same = component.board_id === activeBoard;
        const base = same ? .34 + .1 * prepared : .2;
        const blur = (same ? 5.5 - prepared : 7) / camera.scale;
        if (config.theme === 'light') {
          node.style.opacity = String(base + (1 - base) * weight);
          node.style.filter = `saturate(${.65 + .35 * weight}) blur(${(1 - weight) * blur}px)`;
        } else node.style.filter = `brightness(${base + (1 - base) * weight}) blur(${(1 - weight) * blur}px)`;
        node.dataset.attentionState = matches(component, target) ? 'active' : t < (component.content?.activation ?? 0) ? 'preview' : 'retained';
      }
      document.body.classList.toggle('board-overview', Boolean(board));
      document.querySelectorAll('.board').forEach(node => node.classList.toggle('active-overview', Boolean(board) && node.dataset.board === board.id));
      return result;
    };
  }

  function slotBox(id, camera) {
    const slot = slots[id];
    if (!slot) return null;
    const component = P.components.find(item => item.id === id);
    const size = component.design_size || {width: 600, height: 420};
    const bounds = cameraAPI.bounds(P, id);
    const scale = Math.min(bounds.width / size.width, bounds.height / size.height);
    const ox = (bounds.width - size.width * scale) / 2;
    const oy = (bounds.height - size.height * scale) / 2;
    const width = slot.width * scale * camera.scale;
    const height = slot.height * scale * camera.scale;
    const reserve = window.CanvasSubtitles?.reserve(output) || 0;
    return {
      x: (camera.screen_cx ?? output.width / 2) + (bounds.x + ox + slot.x * scale - camera.cx) * camera.scale,
      y: (camera.screen_cy ?? (output.height - reserve) / 2) + (bounds.y + oy + slot.y * scale - camera.cy) * camera.scale,
      width, height, radius: slot.shape === 'circle' ? Math.min(width, height) / 2 : 14 * scale * camera.scale
    };
  }
  function blendBox(a, b, q) {
    return Object.fromEntries(Object.keys(a).map(key => [key, mix(a[key], b[key], q)]));
  }
  function windowState(t, camera, interval) {
    const index = camera.index ?? 0;
    const shot = camera.shot || P.shots[index];
    const previous = P.shots[Math.max(0, index - 1)];
    const allowed = id => Boolean(slots[id]) && (!interval || interval.components.includes(id));
    let current = componentId(shot.target);
    let prior = componentId(previous?.target);
    if (interval && !allowed(current)) {
      current = interval.components[0];
      for (const item of P.shots) if (item.at <= Math.min(t, interval.end - 1e-6) && allowed(componentId(item.target))) current = componentId(item.target);
      prior = current;
    }
    if (!allowed(current)) current = '';
    if (!allowed(prior)) prior = '';
    const move = shot.move || 0;
    const q = index === 0 || !move ? 1 : ease((t - shot.at) / move);
    const to = slotBox(current, camera);
    const from = slotBox(prior, camera);
    if (to && from) return {box: blendBox(from, to, q), opacity: 1, owner: current, hidden: [current, prior], moving: current !== prior && q > 0 && q < 1};
    if (to) return {box: to, opacity: interval ? 1 : q, owner: current, hidden: [current], moving: false};
    if (from && q < 1) return {box: from, opacity: 1 - q, owner: prior, hidden: [prior], moving: false};
    return {box: null, opacity: 0, owner: '', hidden: [], moving: false};
  }

  let active = false;
  let lastBodyTime = 0;
  let targetTime = 0;
  let seekRequested = false;
  let seeking = false;
  let pending = Promise.resolve();
  let failure = null;
  let playPending = null;
  let pausedByController = false;
  const ready = new Promise((resolve, reject) => {
    const timer = setTimeout(() => finish(Error('Presenter media loading timed out.')), 30000);
    function finish(error) {
      clearTimeout(timer);
      video.removeEventListener('loadeddata', loaded);
      video.removeEventListener('error', failed);
      error ? reject(error) : resolve(video);
    }
    const loaded = () => { if (video.readyState >= 2 && Number.isFinite(video.duration)) finish(); };
    const failed = () => finish(Error('Presenter media failed to load: ' + video.currentSrc));
    video.addEventListener('loadeddata', loaded);
    video.addEventListener('error', failed);
    loaded();
  });
  ready.catch(error => { failure = error; });
  const canPlay = () => !exporting && active && !pausedByController && voice && !voice.paused && !voice.ended && !seeking && !seekRequested;
  function playVideo() {
    if (!canPlay() || !video.paused || playPending) return;
    playPending = video.play().catch(error => { if (error.name !== 'AbortError') video.dataset.playError = error.message; }).finally(() => { playPending = null; });
  }
  function mediaVisibility() {
    frame.style.visibility = active && !seeking && !seekRequested && video.readyState >= 2 ? 'visible' : 'hidden';
    if (canPlay()) playVideo();
  }
  function exactSeek(time) {
    if (!video.seeking && video.readyState >= 2 && Math.abs(video.currentTime - time) < .001) return Promise.resolve();
    return new Promise((resolve, reject) => {
      let callback = null;
      let fallback = null;
      const timer = setTimeout(() => finish(Error('Presenter frame seek timed out at ' + time.toFixed(3))), 12000);
      let finished = false;
      function finish(error) {
        if (finished) return;
        finished = true;
        clearTimeout(timer);
        clearTimeout(fallback);
        video.removeEventListener('seeked', seeked);
        video.removeEventListener('error', failed);
        if (callback !== null && video.cancelVideoFrameCallback) video.cancelVideoFrameCallback(callback);
        error ? reject(error) : resolve();
      }
      const failed = () => finish(Error('Presenter decode error.'));
      function seeked() {
        if (Math.abs(video.currentTime - time) > .003 || video.seeking) return;
        if (video.requestVideoFrameCallback) callback = video.requestVideoFrameCallback(() => finish());
        fallback = setTimeout(() => {
          if (video.readyState >= 2 && !video.seeking && Math.abs(video.currentTime - time) <= .003) finish();
        }, 100);
      }
      video.addEventListener('seeked', seeked);
      video.addEventListener('error', failed);
      try { video.currentTime = time; } catch (error) { finish(error); }
    });
  }
  function requestSeek(time) {
    targetTime = time;
    seekRequested = true;
    video.pause();
    video.playbackRate = 1;
    mediaVisibility();
    if (seeking) return pending;
    seeking = true;
    pending = (async () => {
      await ready;
      while (seekRequested) {
        seekRequested = false;
        const requested = targetTime;
        await exactSeek(requested);
        if (Math.abs(targetTime - requested) >= .001) seekRequested = true;
      }
    })().catch(error => { failure = error; throw error; }).finally(() => {
      seeking = false;
      mediaVisibility();
    });
    pending.catch(() => {});
    return pending;
  }
  async function settle() {
    await ready;
    while (seeking || seekRequested) {
      const work = pending;
      await work;
      if (work === pending && !seekRequested) break;
    }
    if (failure) throw failure;
    mediaVisibility();
  }
  function headlineAt(t) {
    const cue = (config.headlines || []).find(item => t >= item.start && t < item.end);
    const text = cue?.text || '';
    if (heading.dataset.cue === text) return;
    heading.dataset.cue = text;
    heading.replaceChildren();
    const accent = typeof cue?.accent === 'string' ? cue.accent : '';
    const index = accent ? text.indexOf(accent) : -1;
    if (index < 0) heading.textContent = text;
    else {
      heading.append(document.createTextNode(text.slice(0, index)));
      const emphasis = document.createElement('em');
      emphasis.textContent = accent;
      heading.append(emphasis, document.createTextNode(text.slice(index + accent.length)));
    }
    heading.style.fontSize = text.includes('xycut-canvas-video-skill') ? '52px' : text.length > 29 ? '60px' : '66px';
  }
  function render(t) {
    lastBodyTime = Math.max(0, Number(t) || 0);
    const browsing = isBrowsing();
    const cover = explorer.getTime() < (P.intro?.duration || 0) - 1e-8;
    const ended = lastBodyTime >= Math.min(outro, sourceEnd) - 1e-8;
    const camera = cameraAPI.at(P, lastBodyTime);
    const interval = led ? intervalAt(lastBodyTime) : null;
    const sampleTime = camera.presenterSampleTime ?? (interval ? Math.min(lastBodyTime, interval.end - 1e-6) : lastBodyTime);
    const state = windowState(sampleTime, camera, interval);
    let weight = led ? 0 : 1;
    if (interval) {
      const inDuration = interval.transition_in ?? .38;
      const outDuration = interval.transition_out ?? .34;
      weight = lastBodyTime < interval.end ? ease((lastBodyTime - interval.start) / inDuration) : 1 - ease((lastBodyTime - interval.end) / outDuration);
    }
    const full = {x: 0, y: 0, width: output.width, height: output.height, radius: 0};
    const rect = led ? blendBox(full, state.box || full, weight) : state.box || full;
    const opacity = led ? 1 : state.opacity;
    active = !browsing && !cover && !ended && opacity > .0001;
    const fullscreen = led && active && weight < .0001;
    const morph = led && active && weight >= .0001 && weight < .9999;
    const subtitle = P.subtitle_settings || {};
    const captionHeight = (subtitle.font_size || 54) * (subtitle.line_height || 1.45);
    const captionX = output.width / 2;
    const captionY = subtitle.top != null ? subtitle.top + captionHeight / 2 : output.height - (subtitle.bottom ?? 54) - captionHeight / 2;
    const captionOnVideo = led && active && captionX >= rect.x + 20 && captionX <= rect.x + rect.width - 20 && captionY >= rect.y + 20 && captionY <= rect.y + rect.height - 20;
    document.body.classList.toggle('presenter-fullscreen', fullscreen);
    document.body.classList.toggle('presenter-morph', morph);
    document.body.classList.toggle('presenter-caption-on-video', captionOnVideo);
    document.body.classList.toggle('presenter-windowed', active && !fullscreen && !morph);
    document.body.classList.toggle('presenter-transfer', active && !fullscreen && !morph && state.moving);
    for (const [id, preview] of previews) preview.style.visibility = active && weight > .0001 && state.hidden.includes(id) ? 'hidden' : 'visible';
    Object.assign(frame.style, {
      left: rect.x + 'px', top: rect.y + 'px', width: rect.width + 'px', height: rect.height + 'px',
      borderRadius: rect.radius + 'px', borderWidth: (led ? 2 * weight : 2) + 'px', opacity: String(opacity)
    });
    frame.dataset.mode = active ? fullscreen ? 'fullscreen' : morph ? 'morph' : state.moving ? 'moving' : 'window' : 'hidden';
    frame.dataset.owner = state.owner;
    frame.dataset.weight = String(weight);
    words.style.display = led && active ? 'block' : 'none';
    words.style.opacity = String(1 - ease(weight / .45));
    headlineAt(lastBodyTime);
    const duration = Number.isFinite(video.duration) ? Math.min(sourceEnd, video.duration) : sourceEnd;
    const source = cover ? 0 : Math.min(lastBodyTime, Math.max(0, duration - .0001));
    video.dataset.targetTime = String(source);
    video.dataset.active = String(active);
    if (voice && !voice.paused) pausedByController = false;
    if (!active) {
      video.pause();
      if (cover && (Math.abs(video.currentTime) > .001 || video.readyState < 2)) requestSeek(0);
      mediaVisibility();
      return;
    }
    const running = !exporting && voice && !voice.paused && !voice.ended;
    const drift = video.currentTime - source;
    if (running && (seeking || seekRequested)) {
      mediaVisibility();
      return;
    }
    if (!running || video.paused && Math.abs(drift) > .045 || Math.abs(drift) > .28 || video.readyState < 2) {
      requestSeek(source);
    } else {
      video.playbackRate = (voice.playbackRate || 1) * (drift < -.045 ? 1.035 : drift > .045 ? .965 : 1);
      playVideo();
    }
    mediaVisibility();
  }

  const originalRender = scene.render;
  scene.render = function(t) {
    const result = originalRender.call(this, t);
    render(t);
    if (led && cameraAPI.at(P, t).presenterLock) window.CanvasAttention?.render(t);
    return result;
  };
  function pause() {
    pausedByController = true;
    video.pause();
    video.playbackRate = 1;
  }
  window.VideoMedia = {items: [{video}], ready, render, settle, pause};
  window.CanvasPresenter = {video, frame, layer, slots, previews, ready, render, settle, pause, slotBox, windowState, intervalAt, intervalExitTime};
  const originalReady = window.READY;
  const posterReady = Promise.all([...previews.values()].map(preview => {
    const image = preview.querySelector('img');
    return image?.decode ? image.decode() : Promise.resolve();
  }));
  window.READY = Promise.all([originalReady, ready, posterReady]).then(async () => {
    render(explorer.getBodyTime());
    await settle();
    return true;
  });
  const originalRenderAt = window.renderAt;
  window.renderAt = async function(t) {
    await ready;
    const result = await originalRenderAt.call(this, t);
    await settle();
    return result;
  };
  const originalSeek = explorer.seek;
  explorer.seek = async function(t) {
    const result = originalSeek.call(this, t);
    await settle();
    return result;
  };
  const playButton = document.querySelector('#play');
  if (playButton?.onclick && !exporting) {
    const originalPlay = playButton.onclick;
    playButton.onclick = async function(event) {
      if (voice?.paused) {
        render(explorer.getBodyTime());
        await settle();
        pausedByController = false;
      }
      return originalPlay.call(this, event);
    };
  }
  voice?.addEventListener('pause', () => video.pause());
  voice?.addEventListener('ratechange', () => { video.playbackRate = voice.playbackRate; });
})();
