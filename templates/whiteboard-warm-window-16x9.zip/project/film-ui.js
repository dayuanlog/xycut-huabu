(()=>{
 const P=CANVAS_PLAN,$=s=>document.querySelector(s),stage=$('#stage'),world=$('#world'),series=P.series,esc=InfoKit.esc;
 const win=document.createElement('div');win.className='film-window';world.before(win);win.append(world);
 const label=document.createElement('div');label.className='film-series';
 label.innerHTML='<b data-preview-text="title-heading">'+esc(series.title)+'</b><i data-preview-text="title-description">'+esc(series.subtitle)+'</i>';stage.append(label);
 document.body.classList.toggle('preview-title-off',series.title_enabled===false);
 const cover=document.createElement('div');cover.className='film-cover';
 cover.innerHTML='<div class="series-cover-content"><div class="series-cover-heading"><span class="series-cover-name" data-preview-text="cover-heading">'+esc(series.title)+'</span><span class="series-cover-day"></span></div><div class="series-cover-divider"></div><h1 class="series-cover-subtitle">'+series.cover_lines.map((line,i)=>'<span class="cover-line-'+i+'" data-preview-text="cover-line-'+i+'">'+esc(line)+'</span>').join('')+'</h1></div>';stage.append(cover);
 const guides=document.createElement('div');guides.className='film-guides';guides.innerHTML='<span>横屏正文安全范围 · 字幕位于下方</span>';stage.append(guides);
 $('#guides').closest('label').lastChild.textContent=' 横屏构图参考线';
 $('#guides').onchange=e=>document.body.classList.toggle('show-guides',e.target.checked);
 function render(t){const visible=Number.isFinite(t)&&t<(P.intro?.duration||0)-1e-9;cover.hidden=!visible;document.body.classList.toggle('intro-on',visible)}
 function fitTitles(){if(cover.querySelector('.v2-cover'))return;
  const prev=cover.style.display;cover.style.setProperty('display','block','important');
  const head=cover.querySelector('.series-cover-heading');
  cover.querySelector('.series-cover-divider').style.width=Math.min(1500,head.scrollWidth)+'px';
  const text=cover.querySelector('.series-cover-subtitle');let size=118;text.style.fontSize=size+'px';
  while(text.scrollWidth>1550&&size>70){size-=1;text.style.fontSize=size+'px'}
  if(prev)cover.style.display=prev;else cover.style.removeProperty('display');
 }
 document.fonts.ready.then(fitTitles);
 window.FilmSeries={render,cover,config:series,fitTitles};render(CanvasExplorer.getTime());
})();

// === V2 COVER UPGRADE: light_landscape_canvas ===
(()=>{
 const cover=document.querySelector('.film-cover');
 if(!cover)return;
 const s=CANVAS_PLAN.series||{},esc=InfoKit.esc;
 const lines=s.cover_lines||['配音讲到哪','画面就到哪'];
 cover.innerHTML=`
  <div class="v2-cover v2-ll-canvas">
   <div class="v2-ll-grid">
    <div class="v2-ll-left">
     <div class="v2-badge"><span>16:9 暖白板 · 画布小窗</span><b data-preview-text="cover-heading">${esc(s.title||'XYCUT 画布视频 Skill')}</b></div>
     <h1 class="v2-hero">
      <span class="v2-l0" data-preview-text="cover-line-0">${esc(lines[0]||'')}</span>
      <span class="v2-l1" data-preview-text="cover-line-1">${esc(lines[1]||'')}</span>
     </h1>
     <div class="v2-rule"></div>
     <div class="v2-pills">
      <span>9 块白板画布</span><span>真人口播陪伴</span><span>跨画板飞线运镜</span>
     </div>
    </div>
    <div class="v2-ll-right">
     <div class="v2-photo-frame">
      <img src="assets/media/person-poster.jpg" alt="" class="v2-photo">
      <div class="v2-photo-scrim"></div>
      <div class="v2-photo-chip"><span class="v2-p-dot"></span>画布小窗 · 同步讲解</div>
     </div>
     <div class="v2-float-card">
      <b>20 视觉模块</b>
      <span>字词级音频对齐</span>
     </div>
    </div>
   </div>
  </div>`;
 const st=document.createElement('style');
 st.textContent=`
  .v2-ll-canvas{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;padding:0 110px;background:radial-gradient(ellipse at 30% 45%,#ffffff88,transparent 62%)}
  .v2-ll-canvas .v2-ll-grid{width:100%;display:grid;grid-template-columns:1.12fr 0.88fr;gap:76px;align-items:center}
  .v2-ll-canvas .v2-ll-left{display:flex;flex-direction:column;align-items:flex-start;gap:28px}
  .v2-ll-canvas .v2-badge{display:inline-flex;align-items:center;gap:16px;padding:10px 26px 10px 12px;border-radius:999px;background:#ffffffdd;border:2px solid #9ab8b0;box-shadow:0 8px 24px #203c4212}
  .v2-ll-canvas .v2-badge span{padding:7px 18px;border-radius:999px;background:#008793;color:#ffffff;font-size:24px;font-weight:800}
  .v2-ll-canvas .v2-badge b{color:#203c42;font-size:29px;font-weight:800}
  .v2-ll-canvas .v2-hero{margin:0;display:flex;flex-direction:column;gap:12px;font-size:122px;line-height:1.12;font-weight:900;letter-spacing:-4px}
  .v2-ll-canvas .v2-l0{color:#1d3940}
  .v2-ll-canvas .v2-l1{color:#008793}
  .v2-ll-canvas .v2-rule{width:280px;height:5px;border-radius:5px;background:linear-gradient(90deg,#008793,#aa6229,transparent)}
  .v2-ll-canvas .v2-pills{display:flex;flex-wrap:wrap;gap:14px}
  .v2-ll-canvas .v2-pills span{padding:12px 22px;border-radius:14px;background:#faf8f2;border:1.5px solid #aac2b8;color:#274a50;font-size:25px;font-weight:700}
  .v2-ll-canvas .v2-ll-right{position:relative;display:flex;justify-content:center}
  .v2-ll-canvas .v2-photo-frame{position:relative;width:540px;height:680px;border-radius:32px;overflow:hidden;border:4px solid #008793;box-shadow:0 28px 64px #203c4228;background:#e2e8df}
  .v2-ll-canvas .v2-photo{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;object-position:50% 18%;transform:scale(1.1)}
  .v2-ll-canvas .v2-photo-scrim{position:absolute;inset:0;background:linear-gradient(180deg,transparent 60%,#142c30d8 100%)}
  .v2-ll-canvas .v2-photo-chip{position:absolute;left:22px;right:22px;bottom:22px;padding:14px 20px;border-radius:16px;background:#f3efe5f0;color:#1d3940;font-size:25px;font-weight:800;display:flex;align-items:center;justify-content:center;gap:12px}
  .v2-ll-canvas .v2-p-dot{width:12px;height:12px;border-radius:50%;background:#008793}
  .v2-ll-canvas .v2-float-card{position:absolute;left:-26px;top:54px;padding:20px 26px;border-radius:20px;background:#faf8f2f5;border:2px solid #9ab8b0;box-shadow:0 18px 40px #203c4220;display:flex;flex-direction:column;gap:4px}
  .v2-ll-canvas .v2-float-card b{font-size:28px;font-weight:900;color:#aa6229}
  .v2-ll-canvas .v2-float-card span{font-size:21px;font-weight:700;color:#35585e}
 `;
 document.head.append(st);
 if(window.FilmSeries){window.FilmSeries.fitTitles=()=>{};}
})();
