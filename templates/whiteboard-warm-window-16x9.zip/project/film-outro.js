(()=>{
 const P=CANVAS_PLAN,O=P.outro,S=CanvasScene,C=CanvasCamera;
 if(!O)return;
 const esc=InfoKit.esc,clamp=x=>Math.max(0,Math.min(1,x)),ease=x=>{x=clamp(x);return x*x*(3-2*x)};
 const world=document.querySelector('#world'),stage=document.querySelector('#stage');
 const ns='http://www.w3.org/2000/svg';
 const map=document.createElementNS(ns,'svg');
 map.id='canvas-reveal-map';map.setAttribute('viewBox',`0 0 ${P.world.width} ${P.world.height}`);
 map.setAttribute('aria-hidden','true');
 map.innerHTML=`<defs><filter id="outro-lens-glow" x="-40%" y="-40%" width="180%" height="180%"><feGaussianBlur stdDeviation="12"/></filter></defs>
  <rect class="whole-canvas-border" x="22" y="22" width="${P.world.width-44}" height="${P.world.height-44}" fill="none" stroke="#4c95a4" stroke-width="12"/>
  <path class="outro-route" fill="none" stroke="#00c8d6" stroke-opacity=".24" stroke-width="6"/>
  <g class="outro-viewfinder">
   <rect class="outro-lens-halo" fill="none" stroke="#00e3ec" stroke-width="22" filter="url(#outro-lens-glow)"/>
   <rect class="outro-lens" fill="#00e3ec08" stroke="#00e3ec" stroke-width="13"/>
   <path class="outro-lens-corners" fill="none" stroke="#e8ffff" stroke-width="17"/>
  </g>`;
 Object.assign(map.style,{position:'absolute',left:'0',top:'0',width:P.world.width+'px',height:P.world.height+'px',pointerEvents:'none',overflow:'visible',display:'none',zIndex:'3'});
 world.append(map);
 const caption=document.createElement('section');caption.id='canvas-reveal-outro';
 caption.innerHTML=`<h2>一张<span>画布</span>，组织整段讲解</h2><p>${esc(O.skill_name)}</p>`;
 stage.append(caption);
 const orderLabel=document.createElement('p');orderLabel.id='canvas-reveal-order';
 stage.append(orderLabel);
 const style=document.createElement('style');style.textContent=`
 #canvas-reveal-outro{position:absolute;left:80px;right:80px;top:1290px;z-index:36;pointer-events:none;text-align:center;display:none}
 #canvas-reveal-outro h2{margin:0;font-size:53px;font-weight:850;letter-spacing:-1.4px;line-height:1.3;color:#edf8fb}
 #canvas-reveal-outro h2 span{color:#00d2dd}
 #canvas-reveal-outro p{margin:22px 0 0;font:32px/1.2 'Segoe UI',Consolas,sans-serif;letter-spacing:.6px;color:#9fc3ce}
 #canvas-reveal-order{position:absolute;left:80px;right:80px;top:599px;margin:0;z-index:36;pointer-events:none;text-align:center;font-size:34px;font-weight:650;line-height:1.3;color:#afd3de;display:none}
 .demo-mode.outro-overview .world{background-color:#0b141c;background-image:radial-gradient(#83acbb40 3px,transparent 4px),linear-gradient(#7294a31a 2px,transparent 2px),linear-gradient(90deg,#7294a31a 2px,transparent 2px);background-size:90px 90px,360px 360px,360px 360px}
 .demo-mode.outro-overview .board .board-label{display:flex;font-size:50px;letter-spacing:0;color:#a3c4cf;opacity:var(--outro-map-alpha,0);top:-24px}
 .demo-mode.outro-overview .board:before{display:block;border:3px dashed #63859055;opacity:var(--outro-map-alpha,0)}
 .demo-mode.outro-overview .board:after{display:none}
 .outro-preview{width:100%;padding:9px 8px;border:1px solid #497684;border-radius:7px;background:#15313d;color:#bfe6ed;font:12px inherit;text-align:left}
 .resource-mode #canvas-reveal-outro,.resource-mode #canvas-reveal-map,.resource-mode #canvas-reveal-order{display:none!important}
 `;document.head.append(style);
 const route=map.querySelector('.outro-route'),finder=map.querySelector('.outro-viewfinder');
 // Board IDs and visit times come from narrative order, not the board's row or column.
 const visits=O.route_visits.map(v=>{const board=P.boards.find(b=>b.id===v.board_id);return{...v,board,cx:board.x+board.width/2,cy:board.y+board.height/2}});
 const lengths=[0];
 for(let i=1;i<visits.length;i++)lengths.push(lengths[i-1]+Math.hypot(visits[i].cx-visits[i-1].cx,visits[i].cy-visits[i-1].cy));
 route.setAttribute('d',visits.map((v,i)=>`${i?'L':'M'}${v.cx} ${v.cy}`).join(' '));
 const routeLength=lengths.at(-1);
 function render(t){
  const browse=document.body.classList.contains('resource-mode'),age=t-O.body_start;
  const active=!browse&&age>=.5,alpha=active?ease((t-O.pullback_at-.55)/1.55):0;
  document.body.classList.toggle('outro-overview',active);
  document.body.style.setProperty('--outro-map-alpha',String(alpha));
  map.style.display=active?'block':'none';map.style.opacity=String(alpha);
  let index=0;
  for(let i=1;i<visits.length;i++)if(t>=visits[i].arrive)index=i;
  const current=visits[index],next=visits[Math.min(index+1,visits.length-1)];
  const traveling=index<visits.length-1&&t>current.depart;
  const q=traveling?ease((t-current.depart)/(next.arrive-current.depart)):0;
  const cx=current.cx+(next.cx-current.cx)*q,cy=current.cy+(next.cy-current.cy)*q;
  const fw=current.board.width-32+(next.board.width-current.board.width)*q;
  const fh=current.board.height-32+(next.board.height-current.board.height)*q;
  const x=cx-fw/2,y=cy-fh/2;
  for(const n of map.querySelectorAll('.outro-lens,.outro-lens-halo')){
   n.setAttribute('x',x);n.setAttribute('y',y);n.setAttribute('width',fw);n.setAttribute('height',fh);
  }
  map.querySelector('.outro-lens-corners').setAttribute('d',`M${x} ${y+70}v-70h70M${x+fw-70} ${y}h70v70M${x} ${y+fh-70}v70h70M${x+fw-70} ${y+fh}h70v-70`);
  finder.style.opacity=t>=O.route_start?String(.9):'0';
  const distance=lengths[index]+(lengths[Math.min(index+1,visits.length-1)]-lengths[index])*q;
  route.style.strokeDasharray=String(routeLength);route.style.strokeDashoffset=String(routeLength-distance);
  route.style.opacity=t>=O.route_start?'.65':'0';
  map.dataset.activeBoard=current.board_id;map.dataset.targetBoard=next.board_id;map.dataset.traveling=String(traveling);map.dataset.visit=String(index+1);
  const routeVisible=!browse&&t>=O.route_start;
  orderLabel.style.display=routeVisible?'block':'none';
  orderLabel.style.opacity=String(ease((t-O.route_start)/.2));
  const number=String(current.number).padStart(2,'0'),total=String(visits.length).padStart(2,'0');
  orderLabel.textContent=traveling?`画板 ${number} → ${String(next.number).padStart(2,'0')} / ${total}`:`画板 ${number} / ${total} · ${current.board.name}`;
  const titleQ=ease((t-O.title_at)/.45);
  caption.style.display=!browse&&t>=O.title_at?'block':'none';
  caption.style.opacity=String(titleQ);
  caption.querySelector('h2').style.textShadow=`0 0 ${Math.sin(Math.PI*titleQ)*16}px #8cf5ff55`;
 }
 const old=S.render;S.render=t=>{old(t);render(t)};
 const button=document.createElement('button');button.type='button';button.className='outro-preview';
 button.textContent='▷ 预览结尾：拉远整张画布';
 document.querySelector('.phases').after(button);
 button.onclick=()=>{CanvasExplorer.seek(P.intro.duration+O.body_start);document.querySelector('#play').click()};
 window.CanvasOutro={render,config:O,map,caption,orderLabel};
 render(0);
})();
