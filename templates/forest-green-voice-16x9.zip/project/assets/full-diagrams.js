(() => {
  'use strict';
  const clamp = n => Math.max(0, Math.min(1, n));
  const ease = n => { n = clamp(n); return 1 - Math.pow(1 - n, 3); };
  const backOut = n => { n = clamp(n); const c1 = 1.6, c3 = c1 + 1; return 1 + c3 * Math.pow(n - 1, 3) + c1 * Math.pow(n - 1, 2); };

  const html = {
    // 1. Animated Balance Scale / Seesaw (100% 完美 weighs down vs 开始行动 floats)
    'opening-question': `
      <div class="canvas-unit v-opening">
        <div class="v-eyebrow"><span class="v-dot"></span>心理失衡 · 01</div>
        <h2 class="v-open-l1">越想把一件事<em>做好</em></h2>
        <div class="v-punch-wrap">
          <strong class="v-open-l2 glint-target">越容易迟迟不开始</strong>
          <svg class="v-underline" viewBox="0 0 420 16" aria-hidden="true"><path pathLength="1" d="M4 10 Q210 2 416 11"/></svg>
          <i class="beat-ripple"></i>
        </div>
        <div class="v-scale-stage">
          <svg class="v-scale-svg" viewBox="0 0 520 190" aria-hidden="true">
            <line x1="160" y1="176" x2="360" y2="176" class="v-scale-base"/>
            <polygon points="260,118 238,176 282,176" class="v-scale-fulcrum"/>
            <g class="v-scale-beam" style="transform-origin:260px 118px">
              <line x1="88" y1="118" x2="432" y2="118" class="v-scale-bar"/>
              <circle cx="260" cy="118" r="8" class="v-scale-pivot"/>
              <g class="v-pan-left">
                <rect x="46" y="64" width="136" height="46" rx="10" class="v-weight-heavy"/>
                <text x="114" y="93" text-anchor="middle" class="v-weight-txt heavy">100% 完美</text>
              </g>
              <g class="v-pan-right">
                <rect x="352" y="74" width="116" height="36" rx="18" class="v-weight-light"/>
                <text x="410" y="98" text-anchor="middle" class="v-weight-txt light">开始行动</text>
              </g>
            </g>
          </svg>
        </div>
      </div>`,

    // 2. Stalled 0% Circular Loading Ring + Task Prompt
    'example-start': `
      <div class="canvas-unit v-example">
        <div class="step-head"><span class="step-num">例</span><h2>今天要做完<em>一条视频</em></h2></div>
        <div class="v-stall-card">
          <div class="v-ring-box">
            <svg class="v-ring-svg" viewBox="0 0 140 140" aria-hidden="true">
              <circle cx="70" cy="70" r="56" class="v-ring-track"/>
              <circle cx="70" cy="70" r="56" class="v-ring-arc" pathLength="1"/>
            </svg>
            <div class="v-ring-center">
              <b>0%</b>
              <span>未启动</span>
            </div>
          </div>
          <div class="v-stall-info">
            <div class="v-stall-tag">新项目 · 停滞中</div>
            <p class="v-stall-q">坐到电脑前<br>不知道<strong class="glint-target">从哪下手</strong></p>
            <div class="v-stall-dots"><i></i><i></i><i></i><span>等待第一步…</span></div>
            <i class="beat-ripple"></i>
          </div>
        </div>
      </div>`,

    // 3. 360° Radial Hub-and-Spoke Constellation (6 tasks radiating from center hub)
    'task-chain': `
      <div class="canvas-unit v-constellation">
        <div class="v-const-head">
          <span class="step-badge">背后藏着一整串任务</span>
        </div>
        <div class="v-const-stage">
          <svg class="v-const-svg" viewBox="0 0 560 390" aria-hidden="true">
            <circle cx="280" cy="195" r="142" class="v-orbit-ring"/>
            <path data-spoke="0" pathLength="1" d="M280 195 L136 78"/>
            <path data-spoke="1" pathLength="1" d="M280 195 L424 78"/>
            <path data-spoke="2" pathLength="1" d="M280 195 L88 195"/>
            <path data-spoke="3" pathLength="1" d="M280 195 L472 195"/>
            <path data-spoke="4" pathLength="1" d="M280 195 L136 312"/>
            <path data-spoke="5" pathLength="1" d="M280 195 L424 312"/>
          </svg>
          <div class="v-const-hub">
            <span>目标</span>
            <strong>一条视频</strong>
          </div>
          <div class="v-cnode" data-task-index="0" style="left:64px;top:44px"><b>01</b><span>选题</span><i class="node-ripple"></i></div>
          <div class="v-cnode is-accent" data-task-index="1" style="left:358px;top:44px"><b>02</b><span>写稿</span><i class="node-ripple"></i></div>
          <div class="v-cnode" data-task-index="2" style="left:14px;top:164px"><b>03</b><span>录音</span><i class="node-ripple"></i></div>
          <div class="v-cnode is-accent" data-task-index="3" style="left:410px;top:164px"><b>04</b><span>剪辑</span><i class="node-ripple"></i></div>
          <div class="v-cnode" data-task-index="4" style="left:64px;top:284px"><b>05</b><span>字幕</span><i class="node-ripple"></i></div>
          <div class="v-cnode is-accent" data-task-index="5" style="left:358px;top:284px"><b>06</b><span>封面</span><i class="node-ripple"></i></div>
        </div>
      </div>`,

    // 4. Animated Funnel Diagram (Big vague task -> narrowed into 3 concrete steps)
    'three-intro': `
      <div class="canvas-unit v-funnel">
        <div class="v-eyebrow"><span class="v-dot"></span>拆解漏斗</div>
        <div class="v-funnel-title">试着把它缩小，<strong class="glint-target">先做三步</strong><i class="beat-ripple"></i></div>
        <div class="v-funnel-stage">
          <div class="v-funnel-top">一整串庞大任务（选题·写稿·录音·剪辑·字幕·封面）</div>
          <svg class="v-funnel-svg" viewBox="0 0 520 82" aria-hidden="true">
            <polygon points="18,4 502,4 388,76 132,76" class="v-funnel-poly"/>
            <path class="v-funnel-flow" pathLength="1" d="M260 6 L260 76 M170 6 L220 76 M350 6 L300 76"/>
          </svg>
          <div class="v-funnel-steps">
            <div class="v-fstep fs1"><em>01</em><strong>写观点</strong></div>
            <span class="v-farr">→</span>
            <div class="v-fstep fs2"><em>02</em><strong>找例子</strong></div>
            <span class="v-farr">→</span>
            <div class="v-fstep fs3"><em>03</em><strong>第一版</strong></div>
          </div>
        </div>
      </div>`,

    // 5. Spotlight Focus Card (dimmed messy draft lines behind illuminated 1-sentence card)
    'step-one': `
      <div class="canvas-unit v-spotlight">
        <div class="step-head"><span class="step-num">01</span><h2>只写<em>一个观点</em></h2></div>
        <div class="v-spot-stack">
          <div class="v-noise-lines" aria-hidden="true">
            <span class="v-nl l1"></span>
            <span class="v-nl l2"></span>
            <span class="v-nl l3"></span>
          </div>
          <div class="v-spot-card">
            <div class="v-spot-tag">聚焦核心 · 暂不写长稿</div>
            <div class="type-line"><span class="typed-chars" data-type="一句话" data-start="20.25" data-end="21.05"></span><i class="pen-cursor"></i></div>
          </div>
        </div>
        <div class="remember-block">
          <p>这条视频，最想让别人</p>
          <div class="circle-emphasis">
            <strong class="glint-target">记住什么？</strong>
            <svg class="hand-oval" viewBox="0 0 320 112" aria-hidden="true">
              <path pathLength="1" d="M24 58 C20 18, 128 8, 224 14 C298 18, 314 54, 294 84 C272 108, 134 108, 52 94 C14 86, 10 56, 36 44"/>
            </svg>
            <i class="beat-ripple"></i>
          </div>
        </div>
      </div>`,

    // 6. Dual-Track Toggle Bridge (A 个人经历 ⇄ B 两种做法对比 -> 听得明白)
    'step-two': `
      <div class="canvas-unit v-bridge">
        <div class="step-head"><span class="step-num">02</span><h2>找一个<em>具体例子</em></h2></div>
        <div class="v-bridge-row">
          <div class="v-track-card own">
            <span class="v-tbadge">A 轨</span>
            <strong>自己的经历</strong>
            <small>真实踩坑或体会</small>
          </div>
          <div class="v-toggle-mid">⇄</div>
          <div class="v-track-card compare">
            <span class="v-tbadge">B 轨</span>
            <strong>两种做法对比</strong>
            <small>好坏一眼分明</small>
          </div>
        </div>
        <svg class="v-bridge-svg" viewBox="0 0 540 54" aria-hidden="true">
          <path pathLength="1" d="M124 4 C124 34, 250 26, 270 50 M416 4 C416 34, 290 26, 270 50"/>
        </svg>
        <div class="v-bridge-pill">
          <span class="glint-target">让别人<em>听得明白</em></span>
          <i class="beat-ripple"></i>
        </div>
      </div>`,

    // 7. Mini Audio Studio Bar (23-bar live waveform + REC timer + centered seal)
    'step-three': `
      <div class="canvas-unit v-studio">
        <div class="step-head"><span class="step-num">03</span><h2>录成<em>第一版</em></h2></div>
        <div class="v-studio-bar">
          <div class="v-studio-top">
            <span class="v-rec-dot"><i></i>REC</span>
            <span class="v-studio-mix">观点 ＋ 例子</span>
            <span class="v-rec-timer">00:00</span>
          </div>
          <div class="v-studio-wave">${Array.from({ length: 23 }, (_, i) => `<i data-wave-index="${i}"></i>`).join('')}</div>
        </div>
        <div class="v-studio-stamp">
          <div class="vermilion-stamp">
            <span>初稿落地</span>
            <strong>第一版</strong>
          </div>
          <i class="beat-ripple"></i>
        </div>
      </div>`,

    // 8. Animated Concentric Bullseye / Target (fog -> target lock-on)
    'first-version': `
      <div class="canvas-unit v-bullseye">
        <div class="step-head"><span class="step-num">转</span><h2>有了<em>第一版</em></h2></div>
        <div class="v-bull-stage">
          <div class="v-fog-pill">不再对着空白发愁</div>
          <div class="v-target-wrap">
            <svg class="v-target-svg" viewBox="0 0 520 140" aria-hidden="true">
              <ellipse cx="260" cy="70" rx="230" ry="62" class="v-tr r3"/>
              <ellipse cx="260" cy="70" rx="178" ry="48" class="v-tr r2"/>
              <ellipse cx="260" cy="70" rx="130" ry="34" class="v-tr r1"/>
            </svg>
            <div class="v-target-core">
              <strong class="glint-target">问题就具体了</strong>
              <i class="beat-ripple"></i>
            </div>
          </div>
          <div class="v-bull-chips">
            <span class="fv-chip">✓ 看清卡点在哪</span>
            <span class="fv-chip">✓ 知道怎么优化</span>
          </div>
        </div>
      </div>`,

    // 9. Clean Diff Card (- long line / + short line / + insert example) — guaranteed zero overflow
    'revision': `
      <div class="canvas-unit v-diff">
        <div class="step-head"><span class="step-num">改</span><h2>具体修改<em>两件事</em></h2></div>
        <div class="v-diff-card">
          <div class="v-diff-row is-del">
            <span class="v-dtag del">−</span>
            <span class="v-dold">这句话太长要缩短<svg class="strike-svg" viewBox="0 0 280 20" preserveAspectRatio="none" aria-hidden="true"><path pathLength="1" d="M2 11 Q140 6 278 12"/></svg></span>
          </div>
          <div class="v-diff-row is-add add-short">
            <span class="v-dtag add">＋</span>
            <strong class="v-dnew glint-target">缩短这句话</strong>
          </div>
          <div class="v-diff-sep"></div>
          <div class="v-diff-row is-add add-ex">
            <span class="v-dtag add">∧</span>
            <strong class="v-dins">补充一个具体例子</strong>
            <i class="beat-ripple"></i>
          </div>
        </div>
      </div>`,

    // 10. Cascading Block Split (1 Big -> 2 Medium -> 4 Small)
    'keep-breaking': `
      <div class="canvas-unit v-cascade">
        <div class="step-head"><span class="step-num">拆</span><h2>还是<em>不想动？</em></h2></div>
        <div class="v-cas-tiers">
          <div class="v-tier t1"><div class="v-blk big">一整件大任务</div></div>
          <div class="v-tier t2"><div class="v-blk mid">拆成一半</div><div class="v-blk mid">拆成一半</div></div>
          <div class="v-tier t3">
            <div class="v-blk sml">小步 1</div>
            <div class="v-blk sml">小步 2</div>
            <div class="v-blk sml">小步 3</div>
            <div class="v-blk sml">小步 4</div>
          </div>
        </div>
        <div class="kb-punch"><strong class="glint-target">就继续拆小</strong><i class="beat-ripple"></i></div>
      </div>`,

    // 11. Horizontal Scale-Down Compression Bars (100% -> 28% mini action)
    'make-smaller': `
      <div class="canvas-unit v-compress">
        <div class="step-head"><span class="step-num">小</span><h2>把动作<em>降到最轻</em></h2></div>
        <div class="v-comp-list">
          <div class="v-comp-item writing">
            <div class="v-comp-bar-wrap">
              <div class="v-bar-full"><span>写一段</span></div>
              <div class="v-bar-mini"><strong class="glint-target">写一句</strong><i class="beat-ripple"></i></div>
            </div>
          </div>
          <div class="v-comp-item recording">
            <div class="v-comp-bar-wrap">
              <div class="v-bar-full"><span>录完整条</span></div>
              <div class="v-bar-mini"><strong class="glint-target">录个开头</strong><i class="beat-ripple"></i></div>
            </div>
          </div>
        </div>
      </div>`,

    // 12. 5-Minute Circular Countdown Ring + Editorial Motto + Bold CTA Stamp
    'closing': `
      <div class="canvas-unit v-closing">
        <div class="v-timer-wrap">
          <svg class="v-timer-svg" viewBox="0 0 156 156" aria-hidden="true">
            <circle cx="78" cy="78" r="64" class="v-t-track"/>
            <circle cx="78" cy="78" r="64" class="v-t-fill" pathLength="1"/>
          </svg>
          <div class="v-timer-txt">
            <b>05:00</b>
            <span>现在开始</span>
          </div>
        </div>
        <div class="v-closing-motto">
          <p class="cm-1">先让事情有个<em>开头</em> · 再一点点做好</p>
        </div>
        <div class="closing-cta">
          <div class="vermilion-stamp cta-stamp">
            <span>接下来的 5 分钟</span>
            <strong class="glint-target">先完成一个小动作</strong>
          </div>
          <i class="beat-ripple"></i>
        </div>
      </div>`
  };

  function setRipple(el, t, at, duration = 0.65, all = false) {
    if (!el) return;
    if (all || t < at || t > at + duration) {
      el.style.opacity = '0';
      el.style.transform = 'translate(-50%,-50%) scale(.4)';
      return;
    }
    const u = clamp((t - at) / duration);
    el.style.opacity = String(0.75 * (1 - u));
    el.style.transform = `translate(-50%,-50%) scale(${0.45 + 1.45 * ease(u)})`;
  }

  function setGlint(el, t, at, duration = 0.72, all = false) {
    if (!el) return;
    if (all || t < at || t > at + duration) {
      el.style.setProperty('--glint-pos', '-30%');
      el.style.setProperty('--glint-alpha', '0');
      return;
    }
    const u = clamp((t - at) / duration);
    el.style.setProperty('--glint-pos', (-30 + 160 * ease(u)) + '%');
    el.style.setProperty('--glint-alpha', String(Math.sin(Math.PI * u)));
  }

  function setDraw(path, u) {
    if (!path) return;
    path.style.strokeDasharray = '1';
    path.style.strokeDashoffset = String(1 - clamp(u));
  }

  function render(t, { all = false } = {}) {
    const within = (at, dur = 0.34) => all ? 1 : ease((t - at) / dur);
    const show = (el, at, dx = 0, dy = 18, dur = 0.34, floor = 0) => {
      if (!el) return;
      const u = within(at, dur);
      el.style.opacity = String(floor + (1 - floor) * u);
      el.style.transform = `translate(${dx * (1 - u)}px,${dy * (1 - u)}px)`;
    };
    const root = id => document.querySelector(`#world [data-component="${id}"]`);

    // 1. opening-question (animated balance tilt)
    let r = root('opening-question');
    if (r) {
      show(r.querySelector('.v-open-l1'), 0.33, 0, 14, 0.36, 0.72);
      show(r.querySelector('.v-open-l2'), 2.49, 0, 16, 0.36, 0.45);
      setDraw(r.querySelector('.v-underline path'), within(2.75, 0.52));
      setGlint(r.querySelector('.v-open-l2'), t, 2.75, 0.75, all);
      setRipple(r.querySelector('.beat-ripple'), t, 2.65, 0.7, all);
      const beam = r.querySelector('.v-scale-beam');
      if (beam) {
        const tilt = all ? -11 : (-11 * within(1.13, 0.9) - Math.sin(t * 2.4) * 1.1);
        beam.style.transform = `rotate(${tilt.toFixed(2)}deg)`;
      }
    }

    // 2. example-start (stalled 0% ring)
    r = root('example-start');
    if (r) {
      show(r.querySelector('.step-head'), 4.4, 0, 12, 0.34, 0.72);
      show(r.querySelector('.v-stall-card'), 5.2, 0, 14, 0.36, 0.62);
      const arc = r.querySelector('.v-ring-arc');
      if (arc) {
        const pulse = all ? 0.14 : (0.08 + 0.08 * Math.abs(Math.sin(t * 3.2)));
        arc.style.strokeDasharray = `${pulse.toFixed(3)} 1`;
        arc.style.transformOrigin = '70px 70px';
        arc.style.transform = `rotate(${all ? -90 : (-90 + (t * 48) % 360)}deg)`;
      }
      show(r.querySelector('.v-stall-q'), 7.2, 0, 10, 0.34, 0.55);
      setGlint(r.querySelector('.v-stall-q .glint-target'), t, 8.2, 0.7, all);
      setRipple(r.querySelector('.v-stall-info .beat-ripple'), t, 8.1, 0.65, all);
    }

    // 3. task-chain (radial constellation)
    r = root('task-chain');
    if (r) {
      show(r.querySelector('.v-const-head'), 9.45, 0, 10, 0.34, 0.7);
      const taskTimes = [10.61, 11.09, 11.65, 12.09, 13.01, 13.61];
      r.querySelectorAll('[data-spoke]').forEach((path, i) => setDraw(path, within(taskTimes[i] - 0.15, 0.28)));
      r.querySelectorAll('[data-task-index]').forEach((node, i) => {
        const at = taskTimes[i];
        const u = all ? 1 : backOut((t - at) / 0.32);
        const vis = all ? 1 : clamp((t - at) / 0.14);
        node.style.opacity = String(0.24 + 0.76 * vis);
        node.style.transform = `scale(${0.86 + 0.14 * u})`;
        node.classList.toggle('is-active', !all && t >= at && t < at + 0.55);
        setRipple(node.querySelector('.node-ripple'), t, at, 0.55, all);
      });
    }

    // 4. three-intro (funnel)
    r = root('three-intro');
    if (r) {
      show(r.querySelector('.v-funnel-title'), 17.35, 0, 12, 0.32, 0.72);
      setGlint(r.querySelector('.v-funnel-title .glint-target'), t, 18.35, 0.7, all);
      setRipple(r.querySelector('.v-funnel-title .beat-ripple'), t, 18.3, 0.65, all);
      setDraw(r.querySelector('.v-funnel-flow'), within(18.2, 0.52));
      show(r.querySelector('.fs1'), 18.35, 0, 12, 0.26, 0.45);
      show(r.querySelector('.fs2'), 18.62, 0, 12, 0.26, 0.45);
      show(r.querySelector('.fs3'), 18.88, 0, 12, 0.26, 0.45);
    }

    // 5. step-one (spotlight card + typewriter + oval)
    r = root('step-one');
    if (r) {
      show(r.querySelector('.step-head'), 19.62, 0, 12, 0.34, 0.72);
      show(r.querySelector('.v-spot-card'), 20.15, 0, 14, 0.34, 0.65);
      const typed = r.querySelector('.typed-chars');
      const cursor = r.querySelector('.pen-cursor');
      if (typed) {
        const full = typed.dataset.type || '一句话';
        const s = Number(typed.dataset.start), e = Number(typed.dataset.end);
        const count = all ? full.length : Math.floor(clamp((t - s) / Math.max(0.05, e - s)) * full.length + 0.999);
        const shown = t < s && !all ? 0 : Math.min(full.length, count);
        typed.textContent = full.slice(0, shown);
        if (cursor) {
          const active = !all && t >= s && t < e + 0.45;
          cursor.style.opacity = active ? String(0.5 + 0.5 * Math.cos((t - s) * 14)) : '0';
        }
      }
      show(r.querySelector('.remember-block'), 23.6, 0, 16, 0.34, 0.2);
      setDraw(r.querySelector('.hand-oval path'), within(24.85, 0.62));
      setGlint(r.querySelector('.remember-block .glint-target'), t, 24.95, 0.72, all);
      setRipple(r.querySelector('.remember-block .beat-ripple'), t, 24.95, 0.65, all);
    }

    // 6. step-two (dual track bridge)
    r = root('step-two');
    if (r) {
      show(r.querySelector('.step-head'), 26.6, 0, 12, 0.34, 0.75);
      show(r.querySelector('.v-track-card.own'), 28.55, -18, 0, 0.34, 0.55);
      show(r.querySelector('.v-toggle-mid'), 29.35, 0, 6, 0.24, 0.4);
      show(r.querySelector('.v-track-card.compare'), 29.7, 18, 0, 0.34, 0.55);
      setDraw(r.querySelector('.v-bridge-svg path'), within(31.2, 0.42));
      show(r.querySelector('.v-bridge-pill'), 31.53, 0, 14, 0.34, 0.25);
      setGlint(r.querySelector('.v-bridge-pill .glint-target'), t, 31.68, 0.72, all);
      setRipple(r.querySelector('.v-bridge-pill .beat-ripple'), t, 31.6, 0.65, all);
    }

    // 7. step-three (studio waveform + live REC timer + stamp)
    r = root('step-three');
    if (r) {
      show(r.querySelector('.step-head'), 33.0, 0, 12, 0.34, 0.75);
      show(r.querySelector('.v-studio-bar'), 33.65, 0, 12, 0.34, 0.65);
      const timerEl = r.querySelector('.v-rec-timer');
      if (timerEl) {
        const sec = all ? 35 : Math.min(35, Math.max(0, Math.floor((t - 33.6) * 8.5)));
        timerEl.textContent = '00:' + String(sec).padStart(2, '0');
      }
      r.querySelectorAll('[data-wave-index]').forEach(bar => {
        const i = Number(bar.dataset.waveIndex);
        const u = within(34.2, 0.35);
        const centerBoost = 1 - Math.abs(i - 11) / 14;
        const active = all ? 0.62 : (t >= 34.0 && t < 38.5 ? (0.34 + 0.66 * Math.abs(Math.sin(t * 9.5 + i * 0.72))) : 0.16);
        bar.style.height = (10 + u * active * (22 + centerBoost * 46)) + 'px';
      });
      const stamp = r.querySelector('.vermilion-stamp');
      if (stamp) {
        const su = all ? 1 : backOut((t - 35.8) / 0.34);
        const vis = all ? 1 : clamp((t - 35.8) / 0.12);
        stamp.style.opacity = String(0.25 + 0.75 * vis);
        stamp.style.transform = `rotate(${-5 + 2.5 * Math.min(1, su)}deg) scale(${1.3 - 0.3 * su})`;
      }
      setRipple(r.querySelector('.v-studio-stamp .beat-ripple'), t, 35.84, 0.72, all);
    }

    // 8. first-version (concentric bullseye lock-on)
    r = root('first-version');
    if (r) {
      show(r.querySelector('.step-head'), 40.4, 0, 12, 0.32, 0.72);
      const fog = r.querySelector('.v-fog-pill');
      if (fog) fog.style.opacity = String(1 - 0.45 * within(41.1, 0.4));
      ['.r3', '.r2', '.r1'].forEach((sel, i) => {
        const ring = r.querySelector(sel);
        if (!ring) return;
        const u = within(40.9 + i * 0.14, 0.36);
        ring.style.opacity = String(0.15 + 0.65 * u);
        ring.style.transformOrigin = '260px 70px';
        ring.style.transform = `scale(${1.18 - 0.18 * u})`;
      });
      show(r.querySelector('.v-target-core'), 41.16, 0, 10, 0.34, 0.35);
      setGlint(r.querySelector('.v-target-core .glint-target'), t, 41.3, 0.7, all);
      setRipple(r.querySelector('.v-target-core .beat-ripple'), t, 41.24, 0.65, all);
      show(r.querySelector('.v-bull-chips'), 42.45, 0, 12, 0.34, 0.25);
    }

    // 9. revision (clean diff card)
    r = root('revision');
    if (r) {
      show(r.querySelector('.step-head'), 44.36, 0, 12, 0.34, 0.75);
      show(r.querySelector('.is-del'), 45.0, 0, 10, 0.3, 0.6);
      setDraw(r.querySelector('.strike-svg path'), within(45.18, 0.36));
      show(r.querySelector('.add-short'), 45.36, 0, 10, 0.32, 0.35);
      setGlint(r.querySelector('.v-dnew'), t, 45.5, 0.65, all);
      show(r.querySelector('.add-ex'), 46.22, 0, 12, 0.32, 0.35);
      setRipple(r.querySelector('.add-ex .beat-ripple'), t, 46.42, 0.65, all);
    }

    // 10. keep-breaking (1 -> 2 -> 4 cascade)
    r = root('keep-breaking');
    if (r) {
      show(r.querySelector('.step-head'), 47.64, 0, 12, 0.32, 0.72);
      show(r.querySelector('.t1'), 47.8, 0, 8, 0.28, 0.7);
      show(r.querySelector('.t2'), 48.25, 0, 12, 0.3, 0.35);
      show(r.querySelector('.t3'), 48.55, 0, 14, 0.32, 0.25);
      show(r.querySelector('.kb-punch'), 48.72, 0, 14, 0.34, 0.35);
      setGlint(r.querySelector('.kb-punch .glint-target'), t, 48.84, 0.65, all);
      setRipple(r.querySelector('.kb-punch .beat-ripple'), t, 48.78, 0.65, all);
    }

    // 11. make-smaller (scale-down compression bars)
    r = root('make-smaller');
    if (r) {
      show(r.querySelector('.step-head'), 49.56, 0, 12, 0.34, 0.75);
      const pairs = [['.writing', 49.65, 50.48], ['.recording', 51.5, 52.55]];
      for (const [sel, rowAt, hitAt] of pairs) {
        const row = r.querySelector(sel);
        if (!row) continue;
        show(row, rowAt, 0, 14, 0.34, 0.55);
        const u = within(hitAt, 0.44);
        const fullBar = row.querySelector('.v-bar-full');
        if (fullBar) fullBar.style.opacity = String(1 - 0.58 * u);
        const mini = row.querySelector('.v-bar-mini');
        if (mini) {
          const mu = all ? 1 : backOut((t - hitAt) / 0.34);
          const vis = all ? 1 : clamp((t - hitAt) / 0.14);
          mini.style.opacity = String(0.3 + 0.7 * vis);
          mini.style.transform = `scale(${0.86 + 0.14 * mu})`;
        }
        setGlint(row.querySelector('.glint-target'), t, hitAt + 0.08, 0.68, all);
        setRipple(row.querySelector('.beat-ripple'), t, hitAt + 0.04, 0.65, all);
      }
    }

    // 12. closing (5-minute circular countdown ring + motto + CTA)
    r = root('closing');
    if (r) {
      show(r.querySelector('.v-timer-wrap'), 54.0, 0, 12, 0.36, 0.65);
      const fill = r.querySelector('.v-t-fill');
      if (fill) setDraw(fill, within(54.2, 4.8));
      show(r.querySelector('.v-closing-motto'), 54.6, 0, 12, 0.34, 0.6);
      const cta = r.querySelector('.cta-stamp');
      if (cta) {
        const su = all ? 1 : backOut((t - 59.2) / 0.38);
        const vis = all ? 1 : clamp((t - 59.2) / 0.16);
        cta.style.opacity = String(0.3 + 0.7 * vis);
        cta.style.transform = `rotate(${-2.5 + 1.8 * Math.min(1, su)}deg) scale(${1.16 - 0.16 * su})`;
      }
      setGlint(r.querySelector('.closing-cta .glint-target'), t, 60.15, 0.75, all);
      setRipple(r.querySelector('.closing-cta .beat-ripple'), t, 59.35, 0.72, all);
    }
  }

  window.SmallStepDiagrams = { html, render };
})();
