(()=>{
 const stage=document.querySelector('#stage'),world=document.querySelector('#world');
 const win=document.createElement('div');win.className='film-window';world.before(win);win.append(world);
 const series=CANVAS_PLAN.series,escape=InfoKit.esc;
 const label=document.createElement('div');label.className='film-series';label.innerHTML=`<b data-preview-text="title-heading">${escape(series.title)}${series.episode_label?` <span>· ${escape(series.episode_label)}</span>`:''}</b><i data-preview-text="title-description">${escape(series.subtitle)}</i>`;stage.append(label);
 const cover=document.createElement('div');cover.className='film-cover';cover.innerHTML=`<div class="series-cover-content"><div class="series-cover-heading"><span class="series-cover-name">${escape(series.title)}</span><span class="series-cover-day">${escape(series.episode_label)}</span></div><div class="series-cover-divider"></div><h1 class="series-cover-subtitle">${series.cover_lines.map((line,i)=>`<span class="cover-line-${i}">${escape(line).replace(/(\d+)/g,'<em>$1</em>')}</span>`).join('')}</h1></div>`;stage.append(cover);
 const guides=document.createElement('div');guides.className='film-guides';guides.innerHTML='<span>中央 1:1 · 当前重点与邻近内容</span>';stage.append(guides);
 const style=document.createElement('style');style.textContent=`
 .stage{background-color:#0c141c;background-image:radial-gradient(ellipse at 25% 40%,#143c4733,transparent 68%),radial-gradient(#8ca8b638 1px,transparent 1.6px),linear-gradient(#89a2b30e 1px,transparent 1px),linear-gradient(90deg,#89a2b30e 1px,transparent 1px);background-size:100% 100%,40px 40px,180px 180px,180px 180px}.film-window{position:absolute;inset:0;clip-path:inset(410px 0 410px);overflow:hidden}.resource-mode .film-window{clip-path:none}.demo-mode .world{background:none}.demo-mode .world:before{display:none}.demo-mode .board:before,.demo-mode .board:after{display:none}
 .film-series{position:absolute;left:90px;right:90px;top:160px;z-index:32;display:flex;flex-direction:column;gap:20px;pointer-events:none}.film-series span{font:19px 'Segoe UI',sans-serif;letter-spacing:4px;color:#6892a5}.film-series b{font-size:37px;letter-spacing:0;color:#d4e5ec}.film-series i{font-size:26px;font-style:normal;color:#739aaa}.resource-mode .film-series{display:none}.film-guides{display:none;position:absolute;left:0;top:420px;width:1080px;height:1080px;border:2px dashed #ffc67699;pointer-events:none;z-index:50}.film-guides span{position:absolute;left:15px;top:10px;font-size:22px;color:#ffc676}.show-guides .film-guides{display:block}.resource-mode .film-guides,.render .film-guides{display:none!important}.guide-toggle{font-size:11px;color:#abc7d3;display:flex;align-items:center;gap:7px}.guide-toggle input{width:14px!important;margin:0!important}.sidebar .phases{grid-template-columns:1fr 1fr}
 .demo-mode .film-window{mask-image:linear-gradient(transparent 410px,#000 450px,#000 1470px,transparent 1510px)}
 .film-series{top:220px;gap:25px}.film-series b{font-size:52px;font-weight:750;line-height:1.2;letter-spacing:-1px;white-space:nowrap;color:#bdd9e3}.film-series b span{font:inherit;letter-spacing:inherit;color:#ffce86}.film-series i{font-size:66px;font-weight:850;line-height:1.2;color:#f4f9fb;letter-spacing:-2px}
 .film-cover{position:absolute;inset:0;z-index:100;overflow:hidden;pointer-events:none;background-color:#0c141c;background-image:radial-gradient(ellipse at 35% 48%,#14546844,transparent 68%),radial-gradient(#8ca8b638 1px,transparent 1.6px),linear-gradient(#89a2b30e 1px,transparent 1px),linear-gradient(90deg,#89a2b30e 1px,transparent 1px);background-size:100% 100%,40px 40px,180px 180px,180px 180px}.film-cover[hidden]{display:none}.series-cover-name{position:absolute;left:100px;right:100px;top:472px;font-size:48px;font-weight:700;letter-spacing:1px;color:#b8d7e2}.series-cover-day{position:absolute;left:100px;top:558px;padding-left:19px;border-left:4px solid #00c8d6;font-size:42px;font-weight:650;color:#ffce86}.series-cover-watermark{position:absolute;left:540px;top:528px;font:900 480px/1.2 'Segoe UI',sans-serif;letter-spacing:-30px;color:transparent;-webkit-text-stroke:2px #476e7a;opacity:.15}.series-cover-subtitle{position:absolute;left:92px;right:80px;top:710px;margin:0;font-size:132px;line-height:1.35;letter-spacing:-5px;font-weight:900;color:#f4fafb}.series-cover-subtitle>span{display:block;white-space:nowrap;position:relative}.series-cover-subtitle em{font:900 165px/1 'Segoe UI',sans-serif;color:#ffce86;font-style:normal;letter-spacing:-7px}.series-cover-subtitle .cover-line-1{color:#00c8d6;margin-top:18px}.series-cover-rule{position:absolute;left:100px;right:100px;top:1158px;height:3px;background:linear-gradient(90deg,#00c8d6,#456c7a88,transparent)}.series-cover-foot{position:absolute;left:100px;top:1210px;margin:0;font-size:32px;letter-spacing:2px;color:#7298aa}
 .intro-on .film-window,.intro-on .film-series,.intro-on [id^="canvas-subtitles-"]{visibility:hidden}.resource-mode .film-cover{display:none!important}.resource-mode .film-window{visibility:visible!important}
 .series-cover-content{position:absolute;left:120px;right:120px;top:50%;transform:translateY(-50%);display:flex;flex-direction:column;text-align:left}.series-cover-heading{position:static;display:flex;justify-content:flex-start;align-items:baseline;gap:26px;white-space:nowrap;font-size:64px;line-height:1.25;font-weight:750;letter-spacing:-1px}.series-cover-name,.series-cover-day{position:static;padding:0;border:0;font:inherit;letter-spacing:inherit}.series-cover-name{color:#b8d7e2}.series-cover-day{color:#ffce86}.series-cover-divider{height:2px;width:680px;align-self:flex-start;margin:24px 0;background:#62848d}.series-cover-subtitle{position:static;margin:0;font-size:136px;line-height:1.15;letter-spacing:-5px}.series-cover-subtitle em{font-size:170px}.series-cover-subtitle .cover-line-1{margin-top:12px}
 .series-cover-subtitle{font-size:120px}
 `;document.head.append(style);
 document.querySelector('#guides').onchange=e=>document.body.classList.toggle('show-guides',e.target.checked);
 function render(t){const visible=Number.isFinite(t)&&t<(CANVAS_PLAN.intro?.duration||0)-1e-9;cover.hidden=!visible;document.body.classList.toggle('intro-on',visible)}
 function fitTitles(){if(cover.querySelector('.v2-cover'))return;
  const restoreDisplay=cover.style.display;cover.style.setProperty('display','block','important');
  const heading=cover.querySelector('.series-cover-heading'),rule=cover.querySelector('.series-cover-divider'),range=document.createRange();
  range.selectNodeContents(heading);rule.style.width=Math.ceil(range.getBoundingClientRect().width)+'px';
  const subtitle=label.querySelector('i');subtitle.style.whiteSpace='nowrap';
  let size=66;subtitle.style.fontSize=size+'px';
  while(subtitle.scrollWidth>subtitle.clientWidth&&size>45){size-=.5;subtitle.style.fontSize=size+'px'}
  const title=cover.querySelector('.series-cover-subtitle');let coverSize=120;
  const apply=()=>{title.style.fontSize=coverSize+'px';title.querySelectorAll('em').forEach(n=>n.style.fontSize=coverSize*1.22+'px')};apply();
  while([...title.children].some(n=>n.scrollWidth>840)&&coverSize>90){coverSize-=.5;apply()}
  if(restoreDisplay)cover.style.display=restoreDisplay;else cover.style.removeProperty('display');
 }
 document.fonts.ready.then(fitTitles);
 window.FilmSeries={render,cover,config:series,fitTitles};render(window.CanvasExplorer?.getTime()||0);
})();

// === V2 COVER UPGRADE: dark_portrait_canvas ===
(()=>{
 const cover=document.querySelector('.film-cover');
 if(!cover)return;
 const s=CANVAS_PLAN.series||{},esc=InfoKit.esc;
 const lines=s.cover_lines||['配音讲到哪','画面就到哪'];
 cover.innerHTML=`
  <div class="v2-cover v2-dp-canvas">
   <div class="v2-safe">
    <div class="v2-eyebrow"><span class="v2-pill">画布小窗版</span><span class="v2-sub" data-preview-text="cover-heading">${esc(s.title||'XYCUT 画布视频 Skill')}</span></div>
    <h1 class="v2-hero">
     <span class="v2-l0" data-preview-text="cover-line-0">${esc(lines[0]||'')}</span>
     <span class="v2-l1" data-preview-text="cover-line-1">${esc(lines[1]||'')}</span>
    </h1>
    <div class="v2-split">
     <div class="v2-mini-canvas">
      <div class="v2-mc-head"><span>CANVAS · 9 画板</span><b>同步讲解</b></div>
      <div class="v2-mc-node active"><i>01</i><div><b>无限大画布</b><span>20 组视觉模块自动排布</span></div></div>
      <div class="v2-mc-node"><i>02</i><div><b>纸飞机飞线</b><span>跨画板顺滑运镜衔接</span></div></div>
      <div class="v2-mc-node"><i>03</i><div><b>人物画中画</b><span>不挡内容 · 增强陪伴感</span></div></div>
     </div>
     <div class="v2-presenter-card">
      <img src="assets/media/person-poster.jpg" alt="" class="v2-presenter-img">
      <div class="v2-presenter-scrim"></div>
      <div class="v2-live-tag"><span class="v2-live-dot"></span>真人口播小窗</div>
     </div>
    </div>
   </div>
  </div>`;
 const st=document.createElement('style');
 st.textContent=`
  .v2-dp-canvas{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;background:radial-gradient(ellipse at 72% 62%,#00c8d628,transparent 56%),radial-gradient(ellipse at 26% 32%,#164b5c44,transparent 60%)}
  .v2-dp-canvas .v2-safe{width:848px;display:flex;flex-direction:column;align-items:center;text-align:center;gap:30px}
  .v2-dp-canvas .v2-eyebrow{display:inline-flex;align-items:center;gap:16px;padding:10px 26px 10px 12px;border-radius:999px;background:#10222f;border:1.5px solid #2b6778}
  .v2-dp-canvas .v2-pill{padding:8px 20px;border-radius:999px;background:#00c8d6;color:#06151c;font-size:26px;font-weight:900;letter-spacing:.5px}
  .v2-dp-canvas .v2-sub{color:#cde7ef;font-size:30px;font-weight:700}
  .v2-dp-canvas .v2-hero{margin:0;display:flex;flex-direction:column;gap:10px;font-size:118px;line-height:1.12;font-weight:900;letter-spacing:-4px}
  .v2-dp-canvas .v2-l0{color:#f4fafb}
  .v2-dp-canvas .v2-l1{color:#00dce8}
  .v2-dp-canvas .v2-split{width:100%;display:grid;grid-template-columns:1.18fr 0.82fr;gap:24px;align-items:stretch;margin-top:8px}
  .v2-dp-canvas .v2-mini-canvas{padding:26px;border-radius:26px;background:linear-gradient(160deg,#101f2be8,#0a141ce8);border:1.5px solid #2a5d6e;display:flex;flex-direction:column;justify-content:space-between;gap:16px;text-align:left;box-shadow:0 20px 50px #0007}
  .v2-dp-canvas .v2-mc-head{display:flex;justify-content:space-between;align-items:center;font-size:22px;font-weight:700;padding-bottom:12px;border-bottom:1px solid #234756}
  .v2-dp-canvas .v2-mc-head span{color:#00d8e6;letter-spacing:1px}
  .v2-dp-canvas .v2-mc-head b{color:#ffce86}
  .v2-dp-canvas .v2-mc-node{display:flex;align-items:center;gap:16px;padding:18px 18px;border-radius:16px;background:#0e1b26;border:1px solid #234454}
  .v2-dp-canvas .v2-mc-node.active{background:#122a37;border:1.5px solid #00c8d6}
  .v2-dp-canvas .v2-mc-node i{font-style:normal;width:44px;height:44px;border-radius:12px;background:#00c8d620;color:#00e1ee;font-size:22px;font-weight:900;display:flex;align-items:center;justify-content:center;flex:none}
  .v2-dp-canvas .v2-mc-node b{display:block;font-size:28px;font-weight:800;color:#eef9fb;margin-bottom:4px}
  .v2-dp-canvas .v2-mc-node span{display:block;font-size:21px;color:#93b6c6}
  .v2-dp-canvas .v2-presenter-card{position:relative;border-radius:26px;overflow:hidden;border:3px solid #00d4e2;box-shadow:0 22px 54px #0009,0 0 36px #00c8d633;min-height:430px;background:#101a22}
  .v2-dp-canvas .v2-presenter-img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;object-position:50% 18%;transform:scale(1.12)}
  .v2-dp-canvas .v2-presenter-scrim{position:absolute;inset:0;background:linear-gradient(180deg,transparent 52%,#06131be8 100%)}
  .v2-dp-canvas .v2-live-tag{position:absolute;left:18px;right:18px;bottom:18px;padding:12px 16px;border-radius:14px;background:#081822cc;border:1px solid #00c8d688;color:#e8fbff;font-size:24px;font-weight:800;display:flex;align-items:center;justify-content:center;gap:10px}
  .v2-dp-canvas .v2-live-dot{width:11px;height:11px;border-radius:50%;background:#00f0ff;box-shadow:0 0 12px #00f0ff}
 `;
 document.head.append(st);
 if(window.FilmSeries){window.FilmSeries.fitTitles=()=>{};}
})();
