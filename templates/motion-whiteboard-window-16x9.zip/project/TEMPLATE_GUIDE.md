# XYCut Motion 快节奏白板流模板指南（16:9 横屏人物小窗）

- **推荐模板 ID**：`motion-whiteboard-window-16x9`
- **展示名称**：`极客白板流 · 人物小窗`
- **画幅与帧率**：`1920×1080 @ 25fps`（`presentation_mode: "landscape"`, `narrative_mode: "presenter-led"`）
- **适用场景**：AI 工具评测、工作流拆解、方法论干货口播、知识博主深度讲解

## 1. 核心构图规范
- **黄金分屏**：左侧 65% 为满幅点阵白板工作台（`framing.content_rect: {x: 76, y: 74, width: 1216, height: 856}`，含极客顶栏缩放/时间码、左侧工具条、左下 24 根声波胶囊与实时属性胶囊）；右侧 35% 为超大圆角人物立卡（`556×856`）。
- **居中压场冲击**：关键转折/金句段（`impact_sections`）切换为全屏炭黑/电光蓝微点阵渐变 + 人物居中放大（`540×840`）+ 人物背后 **3 圈同心扩散冲击波纹** + 左右双侧大号压场字。
- **双栏 16:9 封面**：前 5 帧（`0.2s`）默认开启，左侧大字标题 + 蓝底黄影强调词 + 标签胶囊，右侧大图人物实拍，均支持右侧工作台实时修改。

## 2. 快节奏动效与交互标准
- **22 镜头高频调度**：利用组件 `focuses` 局部关注框，平均每 `2.5–3s` 一次局部推拉或左右甩镜，`move` 严格控制在 `0.24–0.32s`，采用凌厉五次快切缓动（`assets/camera.js`）+ 甩镜瞬时动态模糊。
- **零提前剧透生长**：`assets/full-diagrams.js` 中所有子模块基础透明度 `floor = 0`，随口播逐拍 `expoOut / backOut(c1=2.15)` 凭空弹入；印章采用 `1.65 → 1.0` 砸落弹跳。
- **实时 DOM 框选与 8 点控制框**：`assets/collab-cursors.js` 通过 `getBoundingClientRect()` 实时测量目标 DOM 边界，自动换算 `#stage` 逻辑坐标，绘制鼠标拉框（`.wb-marquee`）→ Figma 8 控制点变换框（`.wb-selbox`），并触发 12 处径向粒子火花（`.wb-sparks`）。
- **阻尼高频震动**：`scene.js` 内置 `shakeAt(t)`，在 11 处强拍触发确定性阻尼画面震动。
- **多轨 UI 音效与零闪烁字幕**：混音 46 处 UI 音效至 `assets/preview-mix.m4a`；隐藏 `subtitles.js` 默认 `.canvas-caption-shade` 底部渐变黑雾，采用高对比深炭胶囊打字机字幕。

## 3. 复用与替换清单
- `assets/presenter.mp4`：主讲人物口播原视频；
- `assets/cover-portrait.jpg`：封面人物高清半身图；
- `assets/voice-aligned.m4a` / `assets/preview-mix.m4a`：对齐人声与 UI 音效混音轨；
- `final-timeline.json`、`canvas-plan.json` / `canvas-plan.js`：按新口播稿重新生成时间轴、组件、镜头与 `impact_sections`。
