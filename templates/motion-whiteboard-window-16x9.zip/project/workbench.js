(() => {
  'use strict';
  if (new URLSearchParams(location.search).get('render') === '1') return;
  const $ = selector => document.querySelector(selector);
  const P = window.CANVAS_PLAN;
  const E = window.CanvasExplorer;
  const controls = $('#packaging-settings');
  const notice = $('#preview-change-notice');
  const coverBlocks = [];
  const titleBlocks = [];
  const byId = new Map();
  const previewNodes = [...document.querySelectorAll('[data-preview-text]')];
  let initialized = false;

  function fail(error) {
    $('#review-status').textContent = error?.message || String(error);
  }

  function act(action) {
    return Promise.resolve().then(action).catch(fail);
  }

  for (const node of previewNodes) {
    const id = node.dataset.previewText;
    if (byId.has(id)) throw Error('预览文字块 ID 重复：' + id);
    const block = { id, node, initial: node.textContent };
    byId.set(id, block);
    const isCover = !!node.closest('#cover');
    const label = document.createElement('label');
    label.className = 'packaging-text-control';
    label.textContent = node.dataset.previewLabel || id;
    const input = document.createElement('textarea');
    input.rows = node.textContent.includes('\n') ? 2 : 1;
    input.value = node.textContent;
    input.dataset.blockId = id;
    input.setAttribute('aria-label', label.textContent);
    label.append(input);
    $(isCover ? '#cover-text-fields' : '#title-text-fields').append(label);
    block.input = input;
    (isCover ? coverBlocks : titleBlocks).push(block);
  }

  function values(blocks) {
    return blocks.map(block => ({ id: block.id, text: block.input.value }));
  }

  function settings() {
    return {
      cover: { enabled: $('#edit-cover-on').checked, blocks: values(coverBlocks) },
      title: { enabled: $('#edit-title-on').checked, blocks: values(titleBlocks) },
      subtitles: $('#subtitle-mode').value
    };
  }

  const baseline = settings();
  const baselineText = JSON.stringify(baseline);

  function changed() {
    notice.hidden = JSON.stringify(settings()) === baselineText;
    $('#preview-copy-status').textContent = '';
    $('#preview-copy-output').hidden = true;
    $('#edit-cover-preview').disabled = !$('#edit-cover-on').checked;
    checkTextBounds();
  }

  function checkTextBounds() {
    const title = $('#film-title');
    const cover = $('#cover');
    const oldDisplay = cover.style.display;
    cover.style.setProperty('display', 'block', 'important');
    const lines = [...cover.querySelectorAll('h1 > span')];
    const unsafe = lines.some(node => node.scrollWidth > node.clientWidth + 1)
      || (!!title && title.scrollWidth > title.clientWidth + 1);
    if (oldDisplay) cover.style.display = oldDisplay;
    else cover.style.removeProperty('display');
    $('#packaging-overflow').hidden = !unsafe;
    $('#packaging-overflow').textContent = unsafe ? '当前文字超出排版宽度，建议缩短文案后再查看效果。' : '';
  }

  controls.addEventListener('input', event => {
    const block = byId.get(event.target.dataset.blockId);
    if (block) {
      block.node.textContent = block.input.value;
      block.node.style.whiteSpace = 'pre-wrap';
      if (coverBlocks.includes(block) && $('#edit-cover-on').checked) act(() => E.seek(0));
    }
    if (event.target.id === 'edit-title-on') {
      document.body.classList.toggle('preview-title-off', !event.target.checked);
    }
    changed();
  });

  $('#edit-cover-on').addEventListener('change', () => act(async () => {
    await E.setCoverEnabled($('#edit-cover-on').checked);
    changed();
    refresh();
  }));
  $('#edit-cover-preview').onclick = () => act(() => E.seek(0));
  $('#subtitle-mode').addEventListener('change', changed);
  $('#return-to-video').onclick = () => act(() => E.seek(E.getTime()));
  $('#guides').onchange = event => {
    document.body.classList.toggle('show-guides', event.target.checked);
    refresh();
  };
  $('#check-caption').onchange = event => {
    $('#spoken-line').hidden = !event.target.checked;
    refresh();
  };

  function componentLabel(component) {
    return component.content?.title || component.name || component.id;
  }

  function button(text, action, className = '') {
    const node = document.createElement('button');
    node.type = 'button';
    node.textContent = text;
    node.className = className;
    node.onclick = () => act(action);
    return node;
  }

  for (const board of P.boards) {
    const group = document.createElement('details');
    group.open = true;
    const summary = document.createElement('summary');
    summary.textContent = board.name || board.id;
    group.append(summary);
    const boardActions = document.createElement('div');
    boardActions.className = 'library-actions';
    boardActions.append(button('聚焦整个区域', () => E.focus(board.id)), button('播放本区域', () => E.preview(board.id)));
    group.append(boardActions);
    for (const component of P.components.filter(item => item.board_id === board.id)) {
      const row = document.createElement('div');
      row.className = 'library-component';
      row.dataset.componentId = component.id;
      const focus = button(componentLabel(component), () => E.focus(component.id), 'library-focus');
      focus.title = '聚焦组件 · ' + component.id;
      const preview = button('局部播放', () => E.preview(component.id), 'preview-entry');
      preview.setAttribute('aria-label', '局部播放：' + componentLabel(component));
      row.append(focus, preview);
      group.append(row);
    }
    $('#library').append(group);
  }

  function refresh() {
    if (!initialized) return;
    const mode = E.getMode();
    const resource = mode === 'resource' || mode === 'browse';
    const bodyTime = E.getBodyTime();
    const segment = E.getSegment?.();
    $('#preview-mode-label').textContent = resource ? '自由浏览' : segment ? '局部播放' : '视频预览';
    const spoken = window.FINAL_TIMELINE.lines.find(line => bodyTime >= line.target_start_ms / 1000 && bodyTime <= line.target_end_ms / 1000);
    $('#spoken-line').textContent = spoken?.text || '当前时刻没有口播字幕';
    $('#canvas-guides').dataset.frame = E.getLead() > 0 && E.getTime() < E.getLead() ? 'cover' : 'content';
    const selected = E.getSelected?.();
    for (const row of document.querySelectorAll('.library-component')) row.classList.toggle('selected', row.dataset.componentId === selected);
    document.body.classList.toggle('canvas-pan-tool', E.getTool?.() === 'pan');
  }

  $('#copy-preview-changes').onclick = () => act(async () => {
    const current = settings();
    const changes = [];
    if (current.cover.enabled !== baseline.cover.enabled) {
      changes.push(current.cover.enabled
        ? '启用前5帧封面，同步调整原声音轨、字幕和章节的播放偏移，保留正文 ASR 时间。'
        : '取消前5帧封面，同步调整原声音轨、字幕和章节的播放偏移，保留正文 ASR 时间。');
    }
    if (current.title.enabled !== baseline.title.enabled) changes.push(current.title.enabled ? '显示片内固定标题。' : '隐藏片内固定标题，保留重点短句和正文内容。');
    for (const kind of ['cover', 'title']) {
      for (const block of current[kind].blocks) {
        const previous = baseline[kind].blocks.find(item => item.id === block.id);
        if (previous?.text !== block.text) changes.push('将文字块 ' + block.id + ' 从 ' + JSON.stringify(previous.text) + ' 改为 ' + JSON.stringify(block.text) + '。');
      }
    }
    const modes = { emphasis: '自动字幕包装', normal: '普通白字', off: '关闭字幕' };
    if (current.subtitles !== baseline.subtitles) changes.push('画面字幕改为“' + modes[current.subtitles] + '”。');
    if (!changes.length) {
      $('#preview-copy-status').textContent = '当前没有需要提交的修改。';
      return;
    }
    const text = '请更新以下画布视频项目。这些是浏览器中的试调意见，尚未保存到工程。\n项目入口：' + location.href + '\n\n'
      + changes.map((line, index) => (index + 1) + '. ' + line).join('\n')
      + '\n\n按稳定文字块 ID 定位源码。保留人物口型与原声同步，其余未提及内容保持当前设计。修改后先提供 HTML 预览，确认后再导出 MP4。';
    try {
      if (!navigator.clipboard?.writeText) throw Error('Clipboard unavailable');
      await navigator.clipboard.writeText(text);
      $('#preview-copy-status').textContent = '已复制，请发送给 AI 保存到项目。';
    } catch {
      const output = $('#preview-copy-output');
      output.hidden = false;
      output.value = text;
      output.focus();
      output.select();
      $('#preview-copy-status').textContent = '请手动复制下方修改提示词。';
    }
  });

  const updateCopyButton = () => { $('#review-copy-all').hidden = $('#review-copy-all').disabled; };
  new MutationObserver(updateCopyButton).observe($('#review-copy-all'), { attributes: true, attributeFilter: ['disabled'] });
  updateCopyButton();
  addEventListener('canvas-render', refresh);
  addEventListener('canvas-mode-change', refresh);
  addEventListener('canvas-selection', refresh);
  addEventListener('canvas-tool-change', refresh);
  addEventListener('resize', checkTextBounds);
  window.Workbench = { refresh, settings, checkTextBounds };
  Promise.resolve(window.READY).then(() => {
    initialized = true;
    $('#edit-cover-on').checked = E.getCoverEnabled();
    refresh();
    checkTextBounds();
  }).catch(fail);
})();
