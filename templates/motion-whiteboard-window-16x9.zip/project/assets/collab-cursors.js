(() => {
  'use strict';
  const stage = document.querySelector('#stage');
  if (!stage) return;

  const layer = document.createElement('div');
  layer.id = 'collab-cursors';
  layer.setAttribute('aria-hidden', 'true');

  // 1. 实时鼠标拖拽框选矩形（Marquee）
  const marquee = document.createElement('div');
  marquee.className = 'wb-marquee';
  marquee.innerHTML = '<span class="wb-marquee-dim"></span>';
  layer.append(marquee);

  // 2. Figma 风格 8 控制点选中框（Selection Box）
  const selbox = document.createElement('div');
  selbox.className = 'wb-selbox';
  selbox.innerHTML = `
    <span class="wb-sel-tag"></span>
    <span class="wb-sel-dim"></span>
    <i class="wb-handle tl"></i><i class="wb-handle tm"></i><i class="wb-handle tr"></i>
    <i class="wb-handle ml"></i><i class="wb-handle mr"></i>
    <i class="wb-handle bl"></i><i class="wb-handle bm"></i><i class="wb-handle br"></i>
  `;
  layer.append(selbox);

  // 3. 高速粒子火花池（12 个短线段径向爆发）
  const sparkPool = [];
  const sparkBox = document.createElement('div');
  sparkBox.className = 'wb-sparks';
  for (let i = 0; i < 12; i++) {
    const sp = document.createElement('i');
    sp.className = 'wb-spark' + (i % 3 === 1 ? ' is-yellow' : i % 3 === 2 ? ' is-orange' : '');
    sparkBox.append(sp);
    sparkPool.push(sp);
  }
  layer.append(sparkBox);

  function makeCursor(name, color) {
    const el = document.createElement('div');
    el.className = 'collab-cursor';
    el.style.color = color;
    el.innerHTML = `
      <i class="collab-cursor-ring"></i>
      <svg width="24" height="26" viewBox="0 0 26 28" fill="none">
        <path d="M3 2 L23 12 L13 15 L9 25 Z" fill="${color}" stroke="#ffffff" stroke-width="2.2" stroke-linejoin="round"/>
      </svg>
      <div class="collab-cursor-tag" style="background:${color}">${name}</div>
    `;
    layer.append(el);
    return el;
  }

  const aiCursor = makeCursor('AI 导演', '#1d5eff');
  const edCursor = makeCursor('剪辑助手', '#ff6b35');
  stage.append(layer);

  const clamp = x => Math.max(0, Math.min(1, x));
  const expoOut = x => { x = clamp(x); return x <= 0 ? 0 : x >= 1 ? 1 : 1 - Math.pow(2, -10 * x); };
  const backOut = x => { x = clamp(x); const c1 = 2.0, c3 = c1 + 1; return 1 + c3 * Math.pow(x - 1, 3) + c1 * Math.pow(x - 1, 2); };

  function getSafeRect() {
    const cr = window.CANVAS_PLAN?.framing?.content_rect;
    if (cr) {
      return { left: cr.x + 8, top: cr.y + 8, right: cr.x + cr.width - 8, bottom: cr.y + cr.height - 8, rect: cr };
    }
    const w = stage.offsetWidth || 1920;
    const h = stage.offsetHeight || 1080;
    return { left: 20, top: 20, right: w - 20, bottom: h - 20, rect: { x: 20, y: 20, width: w - 40, height: h - 40 } };
  }

  // 根据真实 DOM getBoundingClientRect() 精准换算为 #stage 逻辑坐标，彻底消除偏移
  function measureTarget(spec) {
    const el = document.querySelector(`#world ${spec.selector}`);
    if (!el) return null;
    const stageRect = stage.getBoundingClientRect();
    const sx = (stage.offsetWidth || 1920) / Math.max(1, stageRect.width);
    const sy = (stage.offsetHeight || 1080) / Math.max(1, stageRect.height);
    const br = el.getBoundingClientRect();
    if (br.width < 4 || br.height < 4) return null;

    let x1 = (br.left - stageRect.left) * sx;
    let y1 = (br.top - stageRect.top) * sy;
    let x2 = (br.right - stageRect.left) * sx;
    let y2 = (br.bottom - stageRect.top) * sy;
    const w = x2 - x1;
    const h = y2 - y1;

    if (spec.slice === 'top') {
      const cols = getComputedStyle(el).gridTemplateColumns.trim().split(/\s+/).length;
      y2 = y1 + h * (cols === 2 ? 0.33 : 0.48);
    } else if (spec.slice === 'firstCard') {
      const isCol = getComputedStyle(el).flexDirection === 'column';
      if (!isCol) x2 = x1 + w * 0.488;
      else y2 = y1 + h * 0.48;
    }

    const pad = spec.pad ?? 8;
    x1 -= pad;
    y1 -= pad;
    x2 += pad;
    y2 += pad;

    const safe = getSafeRect();
    x1 = Math.max(safe.left, Math.min(safe.right - 24, x1));
    y1 = Math.max(safe.top, Math.min(safe.bottom - 24, y1));
    x2 = Math.max(x1 + 24, Math.min(safe.right, x2));
    y2 = Math.max(y1 + 24, Math.min(safe.bottom, y2));
    return { x1, y1, x2, y2, w: x2 - x1, h: y2 - y1, cx: (x1 + x2) / 2, cy: (y1 + y2) / 2 };
  }

  // 7 组绑定真实 DOM 元素的 Figma 框选 + 8 点变换控制框
  const selections = [
    { dragStart: 2.05, dragEnd: 2.32, holdEnd: 3.55, selector: '[data-component="opening-question"] .op-stickies', pad: 10, label: 'Group / 行动便利贴' },
    { dragStart: 10.15, dragEnd: 10.42, holdEnd: 11.85, selector: '[data-component="task-chain"] .tc-grid', slice: 'top', pad: 8, label: 'Grid / 前三项任务' },
    { dragStart: 24.45, dragEnd: 24.72, holdEnd: 26.05, selector: '[data-component="step-one"] .circle-emphasis', pad: 6, label: 'Focus / 核心记忆点' },
    { dragStart: 28.10, dragEnd: 28.36, holdEnd: 29.35, selector: '[data-component="step-two"] .s2-grid', slice: 'firstCard', pad: 8, label: 'Variant / 自己经历' },
    { dragStart: 35.94, dragEnd: 36.16, holdEnd: 37.55, selector: '[data-component="step-three"] .vermilion-stamp', pad: 8, label: 'Stamp / 第一版归档' },
    { dragStart: 44.96, dragEnd: 45.20, holdEnd: 47.40, selector: '[data-component="revision"] .rev-diff', pad: 8, label: 'Diff / 红笔划改区' },
    { dragStart: 50.65, dragEnd: 50.86, holdEnd: 51.48, selector: '[data-component="make-smaller"] .writing .mini-block', pad: 10, label: 'Action / 先写一句' }
  ];

  // 12 处强拍粒子火花（绑定真实 DOM 元素中心）
  const bursts = [
    { at: 2.49, selector: '[data-component="opening-question"] .st-delay' },
    { at: 3.20, selector: '[data-component="opening-question"] .st-stay' },
    { at: 10.61, selector: '[data-component="task-chain"] [data-task-index="0"]' },
    { at: 12.09, selector: '[data-component="task-chain"] [data-task-index="3"]' },
    { at: 13.61, selector: '[data-component="task-chain"] [data-task-index="5"]' },
    { at: 24.95, selector: '[data-component="step-one"] .circle-emphasis' },
    { at: 31.60, selector: '[data-component="step-two"] .s2-footer' },
    { at: 35.80, selector: '[data-component="step-three"] .vermilion-stamp' },
    { at: 45.18, selector: '[data-component="revision"] .proof-old' },
    { at: 46.42, selector: '[data-component="revision"] .proof-row:nth-child(2)' },
    { at: 50.48, selector: '[data-component="make-smaller"] .writing .mini-block' },
    { at: 52.55, selector: '[data-component="make-smaller"] .recording .mini-block' }
  ];

  // 光标相对 content_rect 的归一化轨迹 (rx: 0..1, ry: 0..1)，自动兼容 16:9 与 9:16 方形主画布
  const aiTracks = [
    { t: 0.2, rx: 0.16, ry: 0.78, click: false },
    { t: 1.80, rx: 0.50, ry: 0.55, click: false },
    { t: 3.30, rx: 0.78, ry: 0.62, click: true },
    { t: 4.50, rx: 0.48, ry: 0.42, click: false },
    { t: 9.85, rx: 0.15, ry: 0.42, click: false },
    { t: 12.20, rx: 0.74, ry: 0.48, click: true },
    { t: 17.60, rx: 0.52, ry: 0.38, click: false },
    { t: 20.50, rx: 0.48, ry: 0.52, click: true },
    { t: 27.80, rx: 0.20, ry: 0.30, click: false },
    { t: 31.60, rx: 0.52, ry: 0.78, click: true },
    { t: 35.60, rx: 0.20, ry: 0.58, click: false },
    { t: 44.60, rx: 0.22, ry: 0.28, click: false },
    { t: 50.30, rx: 0.60, ry: 0.45, click: false },
    { t: 53.00, rx: 0.72, ry: 0.52, click: true }
  ];

  const edTracks = [
    { t: 1.0, rx: 0.72, ry: 0.24, click: false },
    { t: 3.1, rx: 0.68, ry: 0.62, click: true },
    { t: 6.2, rx: 0.38, ry: 0.28, click: true },
    { t: 11.4, rx: 0.55, ry: 0.52, click: true },
    { t: 13.4, rx: 0.48, ry: 0.68, click: true },
    { t: 22.8, rx: 0.32, ry: 0.64, click: true },
    { t: 29.8, rx: 0.74, ry: 0.48, click: true },
    { t: 38.4, rx: 0.78, ry: 0.66, click: true },
    { t: 46.4, rx: 0.72, ry: 0.62, click: true },
    { t: 52.5, rx: 0.74, ry: 0.64, click: true }
  ];

  function evalTrack(track, t) {
    const cr = getSafeRect().rect;
    const toPx = pt => ({ x: cr.x + cr.width * pt.rx, y: cr.y + cr.height * pt.ry });
    if (t <= track[0].t) {
      const p = toPx(track[0]);
      return { x: p.x, y: p.y, pulse: 0 };
    }
    if (t >= track[track.length - 1].t) {
      const p = toPx(track[track.length - 1]);
      return { x: p.x, y: p.y, pulse: 0 };
    }
    let idx = 0;
    for (let i = 1; i < track.length; i++) {
      if (t < track[i].t) { idx = i - 1; break; }
    }
    const a = toPx(track[idx]), b = toPx(track[idx + 1]);
    const span = Math.max(0.05, track[idx + 1].t - track[idx].t);
    const moveWindow = Math.min(0.28, span);
    const u = expoOut((t - track[idx].t) / moveWindow);
    const arc = Math.sin(Math.PI * u) * 24;
    const x = a.x + (b.x - a.x) * u;
    const y = a.y + (b.y - a.y) * u - arc;
    let pulse = 0;
    for (const k of track) {
      if (k.click && t >= k.t && t < k.t + 0.36) pulse = Math.max(pulse, (t - k.t) / 0.36);
    }
    return { x, y, pulse };
  }

  function applyCursor(el, st) {
    const scale = st.pulse > 0 ? 1 - 0.18 * Math.sin(Math.PI * st.pulse) : 1;
    el.style.transform = `translate(${st.x.toFixed(1)}px, ${st.y.toFixed(1)}px) scale(${scale.toFixed(3)})`;
    const ring = el.querySelector('.collab-cursor-ring');
    if (ring) {
      if (st.pulse > 0) {
        ring.style.opacity = String((0.92 * (1 - st.pulse)).toFixed(3));
        ring.style.transform = `scale(${(0.4 + 1.65 * st.pulse).toFixed(3)})`;
      } else {
        ring.style.opacity = '0';
      }
    }
  }

  function renderSelection(t, aiBase) {
    // 磁吸接近期（dragStart 前 0.20s）：把光标精准拉到真实元素的左上角起点
    const upcoming = selections.find(s => t >= s.dragStart - 0.20 && t < s.dragStart);
    if (upcoming) {
      const box = measureTarget(upcoming);
      marquee.style.display = 'none';
      selbox.style.display = 'none';
      if (box) {
        const u = expoOut((t - (upcoming.dragStart - 0.20)) / 0.20);
        return {
          active: null,
          cursorOverride: {
            x: aiBase.x + (box.x1 - aiBase.x) * u,
            y: aiBase.y + (box.y1 - aiBase.y) * u,
            pulse: 0
          }
        };
      }
      return { active: null, cursorOverride: null };
    }

    const active = selections.find(s => t >= s.dragStart && t <= s.holdEnd);
    if (!active) {
      marquee.style.display = 'none';
      selbox.style.display = 'none';
      return { active: null, cursorOverride: null };
    }

    const box = measureTarget(active);
    if (!box) {
      marquee.style.display = 'none';
      selbox.style.display = 'none';
      return { active: null, cursorOverride: null };
    }

    if (t < active.dragEnd) {
      // 鼠标拖拽拉框：框大小按真实目标框动态增长，光标严密贴合右下顶点
      const u = expoOut((t - active.dragStart) / Math.max(0.05, active.dragEnd - active.dragStart));
      const w = Math.max(12, box.w * u);
      const h = Math.max(12, box.h * u);
      marquee.style.display = 'block';
      selbox.style.display = 'none';
      Object.assign(marquee.style, {
        left: box.x1.toFixed(1) + 'px',
        top: box.y1.toFixed(1) + 'px',
        width: w.toFixed(1) + 'px',
        height: h.toFixed(1) + 'px'
      });
      marquee.querySelector('.wb-marquee-dim').textContent = `${Math.round(w)} × ${Math.round(h)}`;
      return {
        active: { label: '框选 · ' + active.label, x: box.x1, y: box.y1, w, h },
        cursorOverride: { x: box.x1 + w, y: box.y1 + h, pulse: 0 }
      };
    }

    // 松手瞬间切换为贴合真实元素边界的 Figma 8 点控制框
    marquee.style.display = 'none';
    selbox.style.display = 'block';
    const settle = clamp((t - active.dragEnd) / 0.14);
    const fadeOut = clamp((active.holdEnd - t) / 0.10);
    const popScale = 1.0 + 0.025 * (1 - backOut(settle));
    Object.assign(selbox.style, {
      left: box.x1.toFixed(1) + 'px',
      top: box.y1.toFixed(1) + 'px',
      width: box.w.toFixed(1) + 'px',
      height: box.h.toFixed(1) + 'px',
      opacity: String(fadeOut.toFixed(3)),
      transform: `scale(${popScale.toFixed(4)})`
    });
    selbox.querySelector('.wb-sel-tag').textContent = active.label;
    selbox.querySelector('.wb-sel-dim').textContent = `${Math.round(box.w)} × ${Math.round(box.h)}`;
    const clickAge = t - active.dragEnd;
    return {
      active: { label: active.label, x: Math.round(box.x1), y: Math.round(box.y1), w: box.w, h: box.h },
      cursorOverride: clickAge < 0.25 ? { x: box.x2, y: box.y2, pulse: clickAge / 0.25 } : null
    };
  }

  function renderSparks(t) {
    const burst = bursts.find(b => t >= b.at && t <= b.at + 0.30);
    if (!burst) {
      sparkBox.style.display = 'none';
      return;
    }
    const box = measureTarget({ selector: burst.selector, pad: 0 });
    if (!box) {
      sparkBox.style.display = 'none';
      return;
    }
    sparkBox.style.display = 'block';
    const u = clamp((t - burst.at) / 0.30);
    const eu = expoOut(u);
    const alpha = Math.max(0, 1 - u * u);
    sparkPool.forEach((sp, i) => {
      const ang = (i / sparkPool.length) * Math.PI * 2 + (i % 2) * 0.18;
      const dist = (28 + (i % 3) * 22) * eu;
      const sx = box.cx + Math.cos(ang) * dist;
      const sy = box.cy + Math.sin(ang) * dist;
      const deg = (ang * 180 / Math.PI).toFixed(1);
      const len = (14 * (1 - u * 0.7)).toFixed(1);
      sp.style.opacity = alpha.toFixed(3);
      sp.style.width = len + 'px';
      sp.style.transform = `translate(${sx.toFixed(1)}px, ${sy.toFixed(1)}px) rotate(${deg}deg)`;
    });
  }

  function render(t, { browsing = false, cover = false, impact = false } = {}) {
    if (browsing || cover || impact) {
      layer.style.display = 'none';
      return null;
    }
    layer.style.display = 'block';
    const aiState = evalTrack(aiTracks, t);
    const sel = renderSelection(t, aiState);
    if (sel.cursorOverride) {
      aiState.x = sel.cursorOverride.x;
      aiState.y = sel.cursorOverride.y;
      if (sel.cursorOverride.pulse > 0) aiState.pulse = sel.cursorOverride.pulse;
    }
    applyCursor(aiCursor, aiState);
    applyCursor(edCursor, evalTrack(edTracks, t));
    renderSparks(t);
    return sel.active;
  }

  window.CollabCursors = { render };
})();
