(()=>{
 const stage=document.querySelector('#stage'),world=document.querySelector('#world');
 const win=document.createElement('div');win.className='film-window';world.before(win);win.append(world);
 const series=CANVAS_PLAN.series,escape=InfoKit.esc;
 const label=document.createElement('div');label.className='film-series';label.innerHTML=`<b data-preview-text="title-heading">${escape(series.title)}${series.episode_label?` <span>· ${escape(series.episode_label)}</span>`:''}</b><i data-preview-text="title-description">${escape(series.subtitle)}</i>`;stage.append(label);
 const cover=document.createElement('div');cover.className='film-cover';cover.innerHTML=`<div class="series-cover-content"><div class="series-cover-heading"><span class="series-cover-name">${escape(series.title)}</span><span class="series-cover-day">${escape(series.episode_label)}</span></div><div class="series-cover-divider"></div><h1 class="series-cover-subtitle">${series.cover_lines.map((line,i)=>`<span class="cover-line-${i}">${escape(line).replace(/(\d+)/g,'<em>$1</em>')}</span>`).join('')}</h1></div>`;stage.append(cover);
 const guides=document.createElement('div');guides.className='film-guides';guides.innerHTML='<span>中央 1:1 · 当前重点与邻近内容</span>';stage.append(guides);
 const style=document.createElement('style');style.textContent=`
 .stage{background-color:#0c141c;background-image:radial-gradient(ellipse at 25% 40%,#143c4733,transparent 68%),radial-gradient(#8ca8b638 1px,transparent 1.6px),linear-gradient(#89a2b30e 1px,transparent 1px),linear-gradient(90deg,#89a2b30e 1px,transparent 1px);background-size:100% 100%,40px 40px,180px 180px,180px 180px}.film-window{position:absolute;inset:0;clip-path:inset(410px 0 410px);overflow:hidden}.resource-mode .film-window{clip-path:none}.demo-mode .world{background:none}.demo-mode .world:before{display:none}.demo-mode .board:before,.demo-mode .board:after{display:none}
 .film-series{position:absolute;left:90px;right:90px;top:160px;z-index:32;display:flex;flex-direction:column;gap:20px;pointer-events:none}.film-series span{font:19px 'Segoe UI',sans-serif;letter-spacing:4px;color:#6892a5}.film-series b{font-size:37px;letter-spacing:0;color:#d4e5ec}.film-series i{font-size:26px;font-style:normal;color:#739aaa}.resource-mode .film-series{display:none}.film-guides{display:none;position:absolute;left:0;top:420px;width:1080px;height:1080px;border:2px dashed #ffc67699;pointer-events:none;z-index:50}.film-guides span{position:absolute;left:15px;top:10px;font-size:22px;color:#ffc676}.show-guides .film-guides{display:block}.resource-mode .film-guides,.render .film-guides{display:none!important}.guide-toggle{font-size:11px;color:#abc7d3;display:flex;align-items:center;gap:7px}.guide-toggle input{width:14px!important;margin:0!important}.sidebar .phases{grid-template-columns:1fr 1fr}
 .demo-mode .film-window{mask-image:linear-gradient(transparent 410px,#000 450px,#000 1470px,transparent 1510px)}
 .film-series{top:220px;gap:25px}.film-series b{font-size:52px;font-weight:750;line-height:1.2;letter-spacing:-1px;white-space:nowrap;color:#bdd9e3}.film-series b span{font:inherit;letter-spacing:inherit;color:#ffce86}.film-series i{font-size:66px;font-weight:850;line-height:1.2;color:#f4f9fb;letter-spacing:-2px}
 .film-cover{position:absolute;inset:0;z-index:100;overflow:hidden;pointer-events:none;background-color:#0c141c;background-image:radial-gradient(ellipse at 35% 48%,#14546844,transparent 68%),radial-gradient(#8ca8b638 1px,transparent 1.6px),linear-gradient(#89a2b30e 1px,transparent 1px),linear-gradient(90deg,#89a2b30e 1px,transparent 1px);background-size:100% 100%,40px 40px,180px 180px,180px 180px}.film-cover[hidden]{display:none}.series-cover-name{position:absolute;left:100px;right:100px;top:472px;font-size:48px;font-weight:700;letter-spacing:1px;color:#b8d7e2}.series-cover-day{position:absolute;left:100px;top:558px;padding-left:19px;border-left:4px solid #00c8d6;font-size:42px;font-weight:650;color:#ffce86}.series-cover-watermark{position:absolute;left:540px;top:528px;font:900 480px/1.2 'Segoe UI',sans-serif;letter-spacing:-30px;color:transparent;-webkit-text-stroke:2px #476e7a;opacity:.15}.series-cover-subtitle{position:absolute;left:92px;right:80px;top:710px;margin:0;font-size:132px;line-height:1.35;letter-spacing:-5px;font-weight:900;color:#f4fafb}.series-cover-subtitle>span{display:block;white-space:nowrap;position:relative}.series-cover-subtitle em{font:900 165px/1 'Segoe UI',sans-serif;color:#ffce86;font-style:normal;letter-spacing:-7px}.series-cover-subtitle .cover-line-1{color:#00c8d6;margin-top:18px}.series-cover-rule{position:absolute;left:100px;right:100px;top:1158px;height:3px;background:linear-gradient(90deg,#00c8d6,#456c7a88,transparent)}.series-cover-foot{position:absolute;left:100px;top:1210px;margin:0;font-size:32px;letter-spacing:2px;color:#7298aa}
 .intro-on .film-window,.intro-on .film-series,.intro-on [id^="canvas-subtitles-"]{visibility:hidden}.resource-mode .film-cover{display:none!important}.resource-mode .film-window{visibility:visible!important}
 .series-cover-content{position:absolute;left:120px;right:120px;top:50%;transform:translateY(-50%);display:flex;flex-direction:column;text-align:left}.series-cover-heading{position:static;display:flex;justify-content:flex-start;align-items:baseline;gap:26px;white-space:nowrap;font-size:64px;line-height:1.25;font-weight:750;letter-spacing:-1px}.series-cover-name,.series-cover-day{position:static;padding:0;border:0;font:inherit;letter-spacing:inherit}.series-cover-name{color:#b8d7e2}.series-cover-day{color:#ffce86}.series-cover-divider{height:2px;width:680px;align-self:flex-start;margin:24px 0;background:#62848d}.series-cover-subtitle{position:static;margin:0;font-size:136px;line-height:1.15;letter-spacing:-5px}.series-cover-subtitle em{font-size:170px}.series-cover-subtitle .cover-line-1{margin-top:12px}
 .series-cover-subtitle{font-size:120px}
 `;document.head.append(style);
 document.querySelector('#guides').onchange=e=>document.body.classList.toggle('show-guides',e.target.checked);
 function render(t){const visible=Number.isFinite(t)&&t<(CANVAS_PLAN.intro?.duration||0)-1e-9;cover.hidden=!visible;document.body.classList.toggle('intro-on',visible)}
 function fitTitles(){if(cover.querySelector('.v2-cover'))return;
  const restoreDisplay=cover.style.display;cover.style.setProperty('display','block','important');
  const heading=cover.querySelector('.series-cover-heading'),rule=cover.querySelector('.series-cover-divider'),range=document.createRange();
  range.selectNodeContents(heading);rule.style.width=Math.ceil(range.getBoundingClientRect().width)+'px';
  const subtitle=label.querySelector('i');subtitle.style.whiteSpace='nowrap';
  let size=66;subtitle.style.fontSize=size+'px';
  while(subtitle.scrollWidth>subtitle.clientWidth&&size>45){size-=.5;subtitle.style.fontSize=size+'px'}
  const title=cover.querySelector('.series-cover-subtitle');let coverSize=120;
  const apply=()=>{title.style.fontSize=coverSize+'px';title.querySelectorAll('em').forEach(n=>n.style.fontSize=coverSize*1.22+'px')};apply();
  while([...title.children].some(n=>n.scrollWidth>840)&&coverSize>90){coverSize-=.5;apply()}
  if(restoreDisplay)cover.style.display=restoreDisplay;else cover.style.removeProperty('display');
 }
 document.fonts.ready.then(fitTitles);
 window.FilmSeries={render,cover,config:series,fitTitles};render(window.CanvasExplorer?.getTime()||0);
})();

// === V2 COVER UPGRADE: dark_portrait_voice ===
(()=>{
 const cover=document.querySelector('.film-cover');
 if(!cover)return;
 const s=CANVAS_PLAN.series||{},esc=InfoKit.esc;
 const lines=s.cover_lines||['配音讲到哪','画面就到哪'];
 cover.innerHTML=`
  <div class="v2-cover v2-dp-voice">
   <div class="v2-safe">
    <div class="v2-eyebrow"><span class="v2-dot"></span><span data-preview-text="cover-heading">${esc(s.title||'XYCUT 画布视频 Skill')}</span></div>
    <h1 class="v2-hero">
     <span class="v2-l0" data-preview-text="cover-line-0">${esc(lines[0]||'')}</span>
     <span class="v2-l1" data-preview-text="cover-line-1">${esc(lines[1]||'')}</span>
    </h1>
    <div class="v2-rule"></div>
    <div class="v2-blueprint-card">
     <div class="v2-bp-top">
      <span class="v2-bp-tag">INFINITE CANVAS · 9:16</span>
      <span class="v2-bp-stat">9 画板 · 20 模块</span>
     </div>
     <svg class="v2-bp-svg" viewBox="0 0 760 230" fill="none" aria-hidden="true">
      <rect x="18" y="34" width="208" height="148" rx="14" fill="#101d28" stroke="#2c5968" stroke-width="2"/>
      <rect x="38" y="58" width="96" height="14" rx="7" fill="#00c8d6" opacity=".88"/>
      <rect x="38" y="86" width="152" height="10" rx="5" fill="#7da4b5" opacity=".45"/>
      <rect x="38" y="108" width="124" height="10" rx="5" fill="#7da4b5" opacity=".32"/>
      <rect x="38" y="138" width="68" height="22" rx="11" fill="#ffce8622" stroke="#ffce86" stroke-width="1.4"/>
      <rect x="276" y="18" width="208" height="148" rx="14" fill="#122733" stroke="#00c8d6" stroke-width="2.4"/>
      <circle cx="322" cy="70" r="22" fill="#00c8d624" stroke="#00c8d6" stroke-width="2"/>
      <path d="M314 70l6 6 12-13" stroke="#9effff" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"/>
      <rect x="358" y="56" width="102" height="14" rx="7" fill="#eef9fb"/>
      <rect x="358" y="80" width="84" height="10" rx="5" fill="#7fdce3" opacity=".6"/>
      <rect x="300" y="116" width="160" height="28" rx="8" fill="#0c1822" stroke="#2b5563" stroke-width="1.4"/>
      <rect x="312" y="126" width="98" height="8" rx="4" fill="#00c8d6"/>
      <rect x="534" y="48" width="208" height="148" rx="14" fill="#101d28" stroke="#2c5968" stroke-width="2"/>
      <rect x="554" y="72" width="112" height="14" rx="7" fill="#ffce86" opacity=".9"/>
      <rect x="554" y="100" width="150" height="10" rx="5" fill="#7da4b5" opacity=".45"/>
      <rect x="554" y="122" width="128" height="10" rx="5" fill="#7da4b5" opacity=".32"/>
      <path d="M226 108 C248 108, 254 88, 276 88" stroke="#00d8e6" stroke-width="2.6" stroke-dasharray="6 6"/>
      <path d="M484 94 C508 94, 512 120, 534 120" stroke="#00d8e6" stroke-width="2.6" stroke-dasharray="6 6"/>
      <g transform="translate(509 109) rotate(24) scale(1.1)">
       <path d="M16 0 4-3.5-4-14h-4l4 11.5-10-1.5-3.5-4h-2.5l2.5 8-2.5 8h2.5l3.5-4 10-1.5-4 11.5h4L4 3.5Z" fill="#a5f0f4" stroke="#ffffff" stroke-width="1"/>
      </g>
     </svg>
     <div class="v2-bp-foot"><span>音频字词对齐</span><i>·</i><span>跨画板飞线运镜</span><i>·</i><span>纯配音蓝图版</span></div>
    </div>
   </div>
  </div>`;
 const st=document.createElement('style');
 st.textContent=`
  .v2-dp-voice{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;background:radial-gradient(ellipse at 50% 30%,#14546858,transparent 62%),radial-gradient(ellipse at 80% 78%,#24345a44,transparent 55%)}
  .v2-dp-voice .v2-safe{width:848px;display:flex;flex-direction:column;align-items:center;text-align:center;gap:34px}
  .v2-dp-voice .v2-eyebrow{display:inline-flex;align-items:center;gap:14px;padding:14px 30px;border-radius:999px;background:#10222f;border:1.5px solid #2b6778;color:#b8e3ec;font-size:34px;font-weight:700;letter-spacing:1px;box-shadow:0 8px 28px #0006}
  .v2-dp-voice .v2-dot{width:14px;height:14px;border-radius:50%;background:#00e5f2;box-shadow:0 0 16px #00e5f2}
  .v2-dp-voice .v2-hero{margin:0;display:flex;flex-direction:column;gap:14px;font-size:126px;line-height:1.12;font-weight:900;letter-spacing:-4px}
  .v2-dp-voice .v2-l0{color:#f4fafb;text-shadow:0 6px 28px #0008}
  .v2-dp-voice .v2-l1{color:#00dce8;text-shadow:0 0 36px #00c8d644}
  .v2-dp-voice .v2-rule{width:220px;height:4px;border-radius:4px;background:linear-gradient(90deg,transparent,#00d4e2,#ffce86,transparent)}
  .v2-dp-voice .v2-blueprint-card{width:100%;padding:28px 30px 26px;border-radius:26px;background:linear-gradient(160deg,#0f1d28ee,#0a131bee);border:1.5px solid #285666;box-shadow:0 24px 60px #0008;display:flex;flex-direction:column;gap:16px}
  .v2-dp-voice .v2-bp-top{display:flex;justify-content:space-between;align-items:center;font-size:24px;font-weight:700;letter-spacing:1.5px}
  .v2-dp-voice .v2-bp-tag{color:#00d8e6}
  .v2-dp-voice .v2-bp-stat{color:#ffce86}
  .v2-dp-voice .v2-bp-svg{width:100%;height:auto;display:block}
  .v2-dp-voice .v2-bp-foot{display:flex;justify-content:center;align-items:center;gap:16px;font-size:26px;font-weight:600;color:#9fc1cf}
  .v2-dp-voice .v2-bp-foot i{font-style:normal;color:#00c8d6}
 `;
 document.head.append(st);
 if(window.FilmSeries){window.FilmSeries.fitTitles=()=>{};}
})();
