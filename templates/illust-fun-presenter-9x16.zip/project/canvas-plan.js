window.CANVAS_PLAN = {
  "id": "fishing-buddy-illust-fun",
  "theme_key": "illust-fun",
  "output": {
    "width": 1080,
    "height": 1920,
    "fps": 25
  },
  "world": {
    "width": 4120,
    "height": 2420
  },
  "duration": 73.27,
  "content_duration": 73.07,
  "intro": {
    "frames": 5,
    "duration": 0.2
  },
  "presentation_mode": "portrait",
  "narrative_mode": "presenter-led",
  "framing": {
    "mode": "center-square",
    "content_rect": {
      "x": 0,
      "y": 420,
      "width": 1080,
      "height": 1080
    }
  },
  "series": {
    "title": "钓了一年鱼的「好兄弟」",
    "subtitle": "居然连真名都不知道？",
    "cover_lines": [
      "钓了一年鱼",
      "连真名都不知道？"
    ]
  },
  "theme": {
    "background": "#e9f4fc",
    "foreground": "#163a5f",
    "accent": "#1d78f2"
  },
  "timing_precision": "ctc-token-time-points",
  "timeline_revision": "sha256:7c39c464d03f7cc11609206b21b8bbf4d74652a5256a0ab5942827aa6b0faacf",
  "boards": [
    {
      "id": "board-1",
      "name": "01 反差故事：一年钓鱼搭子",
      "x": 80,
      "y": 80,
      "width": 1920,
      "height": 1080
    },
    {
      "id": "board-2",
      "name": "02 评论区三连暴击",
      "x": 2120,
      "y": 80,
      "width": 1920,
      "height": 1080
    },
    {
      "id": "board-3",
      "name": "03 为什么让人羡慕",
      "x": 2120,
      "y": 1260,
      "width": 1920,
      "height": 1080
    }
  ],
  "components": [
    {
      "id": "year-buddy",
      "board_id": "board-1",
      "kind": "custom",
      "module_source": "assets/full-diagrams.js",
      "bounds": {
        "x": 110,
        "y": 50,
        "width": 700,
        "height": 680
      },
      "content": {
        "title": "一年钓鱼搭子"
      },
      "focuses": [],
      "preview_range": {
        "start": 2.94,
        "end": 9.84
      }
    },
    {
      "id": "no-name",
      "board_id": "board-1",
      "kind": "custom",
      "module_source": "assets/full-diagrams.js",
      "bounds": {
        "x": 1020,
        "y": 340,
        "width": 700,
        "height": 680
      },
      "content": {
        "title": "大型喜剧反转：真名不知道"
      },
      "focuses": [],
      "preview_range": {
        "start": 9.84,
        "end": 20.28
      }
    },
    {
      "id": "comment-1",
      "board_id": "board-2",
      "kind": "custom",
      "module_source": "assets/full-diagrams.js",
      "bounds": {
        "x": 36,
        "y": 36,
        "width": 590,
        "height": 640
      },
      "content": {
        "title": "评论① 十年鱼友转账知真名"
      },
      "focuses": [],
      "preview_range": {
        "start": 22.74,
        "end": 29.98
      }
    },
    {
      "id": "comment-2",
      "board_id": "board-2",
      "kind": "custom",
      "module_source": "assets/full-diagrams.js",
      "bounds": {
        "x": 665,
        "y": 380,
        "width": 590,
        "height": 650
      },
      "content": {
        "title": "评论② 丈人的老张与王胖"
      },
      "focuses": [],
      "preview_range": {
        "start": 29.98,
        "end": 41.68
      }
    },
    {
      "id": "comment-3",
      "board_id": "board-2",
      "kind": "custom",
      "module_source": "assets/full-diagrams.js",
      "bounds": {
        "x": 1294,
        "y": 36,
        "width": 590,
        "height": 660
      },
      "content": {
        "title": "评论③ 神评补刀：是正经爱好吗"
      },
      "focuses": [],
      "preview_range": {
        "start": 41.68,
        "end": 55.78
      }
    },
    {
      "id": "pure-reasons",
      "board_id": "board-3",
      "kind": "custom",
      "module_source": "assets/full-diagrams.js",
      "bounds": {
        "x": 1060,
        "y": 50,
        "width": 700,
        "height": 670
      },
      "content": {
        "title": "为什么羡慕：足够纯粹"
      },
      "focuses": [],
      "preview_range": {
        "start": 59.74,
        "end": 65.5
      }
    },
    {
      "id": "light-ending",
      "board_id": "board-3",
      "kind": "custom",
      "module_source": "assets/full-diagrams.js",
      "bounds": {
        "x": 180,
        "y": 340,
        "width": 700,
        "height": 670
      },
      "content": {
        "title": "成年人轻装上阵"
      },
      "focuses": [],
      "preview_range": {
        "start": 65.5,
        "end": 69.28
      }
    }
  ],
  "shots": [
    {
      "id": "shot-year-buddy",
      "target": "year-buddy",
      "at": 0,
      "move": 0,
      "padding": 0.05,
      "context_scale": 0.91,
      "label": "一年钓鱼搭子"
    },
    {
      "id": "shot-no-name",
      "target": "no-name",
      "at": 9.8,
      "move": 0.78,
      "padding": 0.05,
      "context_scale": 0.91,
      "travel_scale": 0.92,
      "curve": 56,
      "settle": 0.032,
      "label": "大型喜剧反转"
    },
    {
      "id": "shot-comment-1",
      "target": "comment-1",
      "at": 22.3,
      "move": 0.35,
      "padding": 0.05,
      "context_scale": 0.89,
      "flight": {
        "enabled": false
      },
      "label": "同款经历① 十年鱼友"
    },
    {
      "id": "shot-comment-2",
      "target": "comment-2",
      "at": 29.95,
      "move": 0.78,
      "padding": 0.05,
      "context_scale": 0.89,
      "travel_scale": 0.92,
      "curve": 58,
      "settle": 0.032,
      "label": "同款经历② 老张王胖"
    },
    {
      "id": "shot-comment-3",
      "target": "comment-3",
      "at": 41.65,
      "move": 0.78,
      "padding": 0.05,
      "context_scale": 0.89,
      "travel_scale": 0.92,
      "curve": -58,
      "settle": 0.032,
      "label": "压轴神评③ 正经爱好吗"
    },
    {
      "id": "shot-pure-reasons",
      "target": "pure-reasons",
      "at": 59.2,
      "move": 0.35,
      "padding": 0.05,
      "context_scale": 0.91,
      "flight": {
        "enabled": false
      },
      "label": "为什么让人羡慕"
    },
    {
      "id": "shot-light-ending",
      "target": "light-ending",
      "at": 65.45,
      "move": 0.76,
      "padding": 0.05,
      "context_scale": 0.91,
      "travel_scale": 0.92,
      "curve": 54,
      "settle": 0.032,
      "label": "轻装上阵挺舒服"
    }
  ],
  "flight_guides": {
    "lead": 0.16,
    "trail_fraction": 0.45,
    "plane_size": 1.05,
    "landing_hold": 0.08,
    "landing_fade": 0.36,
    "swoops": [
      {
        "id": "opening-swoop",
        "start": 0.25,
        "arrive": 1.05,
        "requires_canvas": false,
        "plane_size": 1.0,
        "points": [
          {
            "x": 110,
            "y": 1440
          },
          {
            "x": 290,
            "y": 1310
          },
          {
            "x": 630,
            "y": 1220
          },
          {
            "x": 860,
            "y": 1150
          }
        ]
      },
      {
        "id": "enter-board-1",
        "start": 3.12,
        "arrive": 3.74,
        "requires_canvas": true,
        "plane_size": 1.0,
        "points": [
          {
            "x": 820,
            "y": 560
          },
          {
            "x": 640,
            "y": 620
          },
          {
            "x": 440,
            "y": 660
          },
          {
            "x": 280,
            "y": 730
          }
        ]
      },
      {
        "id": "enter-board-2",
        "start": 22.92,
        "arrive": 23.54,
        "requires_canvas": true,
        "plane_size": 1.0,
        "points": [
          {
            "x": 820,
            "y": 560
          },
          {
            "x": 620,
            "y": 615
          },
          {
            "x": 420,
            "y": 665
          },
          {
            "x": 260,
            "y": 735
          }
        ]
      },
      {
        "id": "enter-board-3",
        "start": 59.92,
        "arrive": 60.52,
        "requires_canvas": true,
        "plane_size": 1.0,
        "points": [
          {
            "x": 820,
            "y": 560
          },
          {
            "x": 620,
            "y": 625
          },
          {
            "x": 430,
            "y": 670
          },
          {
            "x": 270,
            "y": 735
          }
        ]
      }
    ]
  },
  "beats": [
    {
      "component_id": "year-buddy",
      "start": 2.94,
      "end": 9.84,
      "action": "semantic-diagram"
    },
    {
      "component_id": "no-name",
      "start": 9.84,
      "end": 20.28,
      "action": "semantic-diagram"
    },
    {
      "component_id": "comment-1",
      "start": 22.74,
      "end": 29.98,
      "action": "semantic-diagram"
    },
    {
      "component_id": "comment-2",
      "start": 29.98,
      "end": 41.68,
      "action": "semantic-diagram"
    },
    {
      "component_id": "comment-3",
      "start": 41.68,
      "end": 55.78,
      "action": "semantic-diagram"
    },
    {
      "component_id": "pure-reasons",
      "start": 59.74,
      "end": 65.5,
      "action": "semantic-diagram"
    },
    {
      "component_id": "light-ending",
      "start": 65.5,
      "end": 69.28,
      "action": "semantic-diagram"
    }
  ],
  "subtitle_settings": {
    "mode": "emphasis",
    "reveal": "typewriter",
    "top": 1530,
    "font_size": 44,
    "line_height": 1.42,
    "margin_x": 100,
    "safe_bottom": 0,
    "color": "#1e2436",
    "accent": "#ff5733",
    "keywords": {
      "line_0004": [
        "钓鱼搭子"
      ],
      "line_0006": [
        "整整一年"
      ],
      "line_0010": [
        "不知道"
      ],
      "line_0011": [
        "真名都不知道"
      ],
      "line_0012": [
        "兄弟"
      ],
      "line_0016": [
        "十多年"
      ],
      "line_0019": [
        "转账打名字"
      ],
      "line_0023": [
        "老张",
        "王胖"
      ],
      "line_0025": [
        "干净单纯"
      ],
      "line_0031": [
        "微信转账记录"
      ],
      "line_0035": [
        "正经爱好吗"
      ],
      "line_0038": [
        "足够纯粹"
      ],
      "line_0039": [
        "不查户口"
      ],
      "line_0040": [
        "有事说事"
      ],
      "line_0042": [
        "不内耗"
      ],
      "line_0044": [
        "轻装上阵"
      ]
    },
    "strong_lines": [
      "line_0010",
      "line_0019",
      "line_0035",
      "line_0044"
    ],
    "display_aliases": {
      "简单的": "简单得",
      "热情的": "热情地",
      "他仗人": "他丈人",
      "最绝得": "最绝的",
      "话风一转": "话锋一转",
      "他足够": "它足够",
      "连全民": "连全名",
      "却处的": "却处得"
    }
  },
  "caption_audio": {
    "emphasis": "assets/preview-mix.m4a",
    "normal": "assets/preview-mix.m4a",
    "off": "assets/preview-mix.m4a",
    "voice": "assets/preview-mix.m4a"
  },
  "cues": {},
  "presenter_layout": {
    "source": "assets/presenter.mp4",
    "voice": "assets/preview-mix.m4a",
    "source_mapping": "source_time = content_time",
    "canvas_intervals": [
      [
        2.94,
        20.28
      ],
      [
        22.74,
        55.78
      ],
      [
        59.74,
        69.28
      ]
    ],
    "window": {
      "x": 790,
      "y": 462,
      "width": 208,
      "height": 208
    }
  },
  "chapters": [
    {
      "at": 0,
      "label": "01 开场：简单得让人佩服"
    },
    {
      "at": 2.94,
      "label": "02 一年钓鱼搭子"
    },
    {
      "at": 9.84,
      "label": "03 反转：真名不知道"
    },
    {
      "at": 20.28,
      "label": "04 评论区全是同款"
    },
    {
      "at": 22.74,
      "label": "05 评论① 十年鱼友"
    },
    {
      "at": 29.98,
      "label": "06 评论② 老张与王胖"
    },
    {
      "at": 41.68,
      "label": "07 评论③ 压轴神评"
    },
    {
      "at": 55.78,
      "label": "08 笑完感慨：足够纯粹"
    },
    {
      "at": 59.74,
      "label": "09 为什么羡慕这种关系"
    },
    {
      "at": 65.5,
      "label": "10 轻装上阵与互动"
    }
  ],
  "cover_design": {
    "mode": "presenter-pop-variety",
    "portrait": "assets/cover-portrait.jpg",
    "safe_rect": {
      "x": 0,
      "y": 240,
      "width": 1080,
      "height": 1440
    },
    "title_rect": {
      "x": 116,
      "y": 1060,
      "width": 848,
      "height": 420
    },
    "source_frame_seconds": 1.2,
    "text_lines": 2,
    "portrait_mask": false,
    "bottom_shadow": "deep indigo gradient for vibrant pop contrast"
  },
  "show_ai_label": false,
  "design_settings": {
    "content_margin_x": 100,
    "component_style": "vibrant comic-variety pop cards with crisp borders and real comment embeds",
    "subtitle_style": "bold rounded sans typewriter with coral-red keywords"
  },
  "scene_source": "scene.js",
  "workbench": {
    "layout": "adaptive browse viewport with portrait playback",
    "settings": "preview only until applied by agent",
    "interaction": "pointer anchored zoom, space pan, double click focus, F overview",
    "background": "warm sunlit apricot canvas with subtle comic halftone dots"
  },
  "title_design": {
    "lines": [
      "钓了一年鱼的「好兄弟」",
      "居然连真名都不知道？"
    ],
    "keywords": [
      [
        "好兄弟"
      ],
      [
        "真名都不知道"
      ]
    ],
    "marker_words": [
      [],
      [
        "真名都不知道"
      ]
    ],
    "font_size": 74,
    "top": 184,
    "margin_x": 108
  },
  "caption_groups": [
    {
      "id": "opening-hook",
      "start": 0.12,
      "end": 2.92,
      "rows": [
        {
          "text": "男性之间的交友方式",
          "at": 0.12,
          "size": 72,
          "accent_words": [
            "交友方式"
          ],
          "marker_words": [],
          "enter": "rise",
          "align": "center"
        },
        {
          "text": "简单得让人佩服！",
          "at": 1.44,
          "size": 102,
          "accent_words": [
            "简单得让人佩服"
          ],
          "marker_words": [
            "简单"
          ],
          "enter": "stamp",
          "align": "center"
        }
      ],
      "source_line_ids": [
        "line_0001",
        "line_0002"
      ],
      "layout": "stack",
      "top": 1185,
      "left": 100,
      "right": 100,
      "max_height": 320
    },
    {
      "id": "comments-bridge",
      "start": 20.28,
      "end": 22.72,
      "rows": [
        {
          "text": "结果评论区更精彩",
          "at": 20.28,
          "size": 76,
          "accent_words": [
            "评论区"
          ],
          "marker_words": [],
          "enter": "slide",
          "align": "center"
        },
        {
          "text": "全都是同款经历！",
          "at": 21.6,
          "size": 102,
          "accent_words": [
            "同款经历"
          ],
          "marker_words": [
            "同款经历"
          ],
          "enter": "pop",
          "align": "center"
        }
      ],
      "source_line_ids": [
        "line_0014",
        "line_0015"
      ],
      "layout": "stack",
      "top": 1185,
      "left": 100,
      "right": 100,
      "max_height": 320
    },
    {
      "id": "pure-bridge",
      "start": 55.78,
      "end": 59.72,
      "rows": [
        {
          "text": "笑完之后其实挺感慨",
          "at": 55.78,
          "size": 72,
          "accent_words": [],
          "marker_words": [],
          "enter": "rise",
          "align": "center"
        },
        {
          "text": "因为它足够纯粹",
          "at": 58.2,
          "size": 106,
          "accent_words": [
            "足够纯粹"
          ],
          "marker_words": [
            "足够纯粹"
          ],
          "enter": "stamp",
          "align": "center"
        }
      ],
      "source_line_ids": [
        "line_0036",
        "line_0037",
        "line_0038"
      ],
      "layout": "stack",
      "top": 1185,
      "left": 100,
      "right": 100,
      "max_height": 320
    },
    {
      "id": "closing-cta",
      "start": 69.28,
      "end": 73.06,
      "rows": [
        {
          "text": "连全名都不知道",
          "at": 69.28,
          "size": 78,
          "accent_words": [
            "全名"
          ],
          "marker_words": [],
          "enter": "rise",
          "align": "center"
        },
        {
          "text": "却处得特别轻松的搭子？",
          "at": 71.1,
          "size": 86,
          "accent_words": [
            "特别轻松",
            "搭子"
          ],
          "marker_words": [
            "特别轻松"
          ],
          "enter": "pop",
          "align": "center"
        }
      ],
      "source_line_ids": [
        "line_0046",
        "line_0047",
        "line_0048"
      ],
      "layout": "stack",
      "top": 1185,
      "left": 100,
      "right": 100,
      "max_height": 320
    }
  ]
};
window.FINAL_TIMELINE = {
  "schema_version": "1.0",
  "timeline_revision": "sha256:7c39c464d03f7cc11609206b21b8bbf4d74652a5256a0ab5942827aa6b0faacf",
  "duration_ms": 73067,
  "lines": [
    {
      "line_id": "line_0001",
      "text": "男性之间的交友方式",
      "target_start_ms": 120,
      "target_end_ms": 1440,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "男",
          "target_start_ms": 120,
          "target_end_ms": 180,
          "source_word_index": 0,
          "source_char_start": 0,
          "source_char_end": 1
        },
        {
          "token_id": "token_002",
          "text": "性",
          "target_start_ms": 180,
          "target_end_ms": 360,
          "source_word_index": 1,
          "source_char_start": 1,
          "source_char_end": 2
        },
        {
          "token_id": "token_003",
          "text": "之",
          "target_start_ms": 360,
          "target_end_ms": 480,
          "source_word_index": 2,
          "source_char_start": 2,
          "source_char_end": 3
        },
        {
          "token_id": "token_004",
          "text": "间",
          "target_start_ms": 480,
          "target_end_ms": 600,
          "source_word_index": 3,
          "source_char_start": 3,
          "source_char_end": 4
        },
        {
          "token_id": "token_005",
          "text": "的",
          "target_start_ms": 600,
          "target_end_ms": 780,
          "source_word_index": 4,
          "source_char_start": 4,
          "source_char_end": 5
        },
        {
          "token_id": "token_006",
          "text": "交",
          "target_start_ms": 780,
          "target_end_ms": 900,
          "source_word_index": 5,
          "source_char_start": 5,
          "source_char_end": 6
        },
        {
          "token_id": "token_007",
          "text": "友",
          "target_start_ms": 900,
          "target_end_ms": 1080,
          "source_word_index": 6,
          "source_char_start": 6,
          "source_char_end": 7
        },
        {
          "token_id": "token_008",
          "text": "方",
          "target_start_ms": 1080,
          "target_end_ms": 1200,
          "source_word_index": 7,
          "source_char_start": 7,
          "source_char_end": 8
        },
        {
          "token_id": "token_009",
          "text": "式",
          "target_start_ms": 1200,
          "target_end_ms": 1440,
          "source_word_index": 8,
          "source_char_start": 8,
          "source_char_end": 9
        }
      ]
    },
    {
      "line_id": "line_0002",
      "text": "有时候简单的让人佩服",
      "target_start_ms": 1440,
      "target_end_ms": 2940,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "有",
          "target_start_ms": 1440,
          "target_end_ms": 1620,
          "source_word_index": 9,
          "source_char_start": 9,
          "source_char_end": 10
        },
        {
          "token_id": "token_002",
          "text": "时",
          "target_start_ms": 1620,
          "target_end_ms": 1740,
          "source_word_index": 10,
          "source_char_start": 10,
          "source_char_end": 11
        },
        {
          "token_id": "token_003",
          "text": "候",
          "target_start_ms": 1740,
          "target_end_ms": 1920,
          "source_word_index": 11,
          "source_char_start": 11,
          "source_char_end": 12
        },
        {
          "token_id": "token_004",
          "text": "简",
          "target_start_ms": 1920,
          "target_end_ms": 2040,
          "source_word_index": 12,
          "source_char_start": 12,
          "source_char_end": 13
        },
        {
          "token_id": "token_005",
          "text": "单",
          "target_start_ms": 2040,
          "target_end_ms": 2220,
          "source_word_index": 13,
          "source_char_start": 13,
          "source_char_end": 14
        },
        {
          "token_id": "token_006",
          "text": "的",
          "target_start_ms": 2220,
          "target_end_ms": 2340,
          "source_word_index": 14,
          "source_char_start": 14,
          "source_char_end": 15
        },
        {
          "token_id": "token_007",
          "text": "让",
          "target_start_ms": 2340,
          "target_end_ms": 2400,
          "source_word_index": 15,
          "source_char_start": 15,
          "source_char_end": 16
        },
        {
          "token_id": "token_008",
          "text": "人",
          "target_start_ms": 2400,
          "target_end_ms": 2580,
          "source_word_index": 16,
          "source_char_start": 16,
          "source_char_end": 17
        },
        {
          "token_id": "token_009",
          "text": "佩",
          "target_start_ms": 2580,
          "target_end_ms": 2700,
          "source_word_index": 17,
          "source_char_start": 17,
          "source_char_end": 18
        },
        {
          "token_id": "token_010",
          "text": "服",
          "target_start_ms": 2700,
          "target_end_ms": 2940,
          "source_word_index": 18,
          "source_char_start": 18,
          "source_char_end": 19
        }
      ]
    },
    {
      "line_id": "line_0003",
      "text": "有位网友说",
      "target_start_ms": 2940,
      "target_end_ms": 3720,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "有",
          "target_start_ms": 2940,
          "target_end_ms": 3120,
          "source_word_index": 19,
          "source_char_start": 19,
          "source_char_end": 20
        },
        {
          "token_id": "token_002",
          "text": "位",
          "target_start_ms": 3120,
          "target_end_ms": 3240,
          "source_word_index": 20,
          "source_char_start": 20,
          "source_char_end": 21
        },
        {
          "token_id": "token_003",
          "text": "网",
          "target_start_ms": 3240,
          "target_end_ms": 3360,
          "source_word_index": 21,
          "source_char_start": 21,
          "source_char_end": 22
        },
        {
          "token_id": "token_004",
          "text": "友",
          "target_start_ms": 3360,
          "target_end_ms": 3480,
          "source_word_index": 0,
          "source_char_start": 0,
          "source_char_end": 1
        },
        {
          "token_id": "token_005",
          "text": "说",
          "target_start_ms": 3480,
          "target_end_ms": 3720,
          "source_word_index": 1,
          "source_char_start": 1,
          "source_char_end": 2
        }
      ]
    },
    {
      "line_id": "line_0004",
      "text": "她老公有个钓鱼搭子",
      "target_start_ms": 3720,
      "target_end_ms": 5160,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "她",
          "target_start_ms": 3720,
          "target_end_ms": 3900,
          "source_word_index": 2,
          "source_char_start": 2,
          "source_char_end": 3
        },
        {
          "token_id": "token_002",
          "text": "老",
          "target_start_ms": 3900,
          "target_end_ms": 4080,
          "source_word_index": 3,
          "source_char_start": 3,
          "source_char_end": 4
        },
        {
          "token_id": "token_003",
          "text": "公",
          "target_start_ms": 4080,
          "target_end_ms": 4200,
          "source_word_index": 4,
          "source_char_start": 4,
          "source_char_end": 5
        },
        {
          "token_id": "token_004",
          "text": "有",
          "target_start_ms": 4200,
          "target_end_ms": 4320,
          "source_word_index": 5,
          "source_char_start": 5,
          "source_char_end": 6
        },
        {
          "token_id": "token_005",
          "text": "个",
          "target_start_ms": 4320,
          "target_end_ms": 4440,
          "source_word_index": 6,
          "source_char_start": 6,
          "source_char_end": 7
        },
        {
          "token_id": "token_006",
          "text": "钓",
          "target_start_ms": 4440,
          "target_end_ms": 4560,
          "source_word_index": 7,
          "source_char_start": 7,
          "source_char_end": 8
        },
        {
          "token_id": "token_007",
          "text": "鱼",
          "target_start_ms": 4560,
          "target_end_ms": 4740,
          "source_word_index": 8,
          "source_char_start": 8,
          "source_char_end": 9
        },
        {
          "token_id": "token_008",
          "text": "搭",
          "target_start_ms": 4740,
          "target_end_ms": 4920,
          "source_word_index": 9,
          "source_char_start": 9,
          "source_char_end": 10
        },
        {
          "token_id": "token_009",
          "text": "子",
          "target_start_ms": 4920,
          "target_end_ms": 5160,
          "source_word_index": 10,
          "source_char_start": 10,
          "source_char_end": 11
        }
      ]
    },
    {
      "line_id": "line_0005",
      "text": "每次放假都要一起去钓鱼",
      "target_start_ms": 5160,
      "target_end_ms": 6780,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "每",
          "target_start_ms": 5160,
          "target_end_ms": 5280,
          "source_word_index": 11,
          "source_char_start": 11,
          "source_char_end": 12
        },
        {
          "token_id": "token_002",
          "text": "次",
          "target_start_ms": 5280,
          "target_end_ms": 5460,
          "source_word_index": 12,
          "source_char_start": 12,
          "source_char_end": 13
        },
        {
          "token_id": "token_003",
          "text": "放",
          "target_start_ms": 5460,
          "target_end_ms": 5580,
          "source_word_index": 13,
          "source_char_start": 13,
          "source_char_end": 14
        },
        {
          "token_id": "token_004",
          "text": "假",
          "target_start_ms": 5580,
          "target_end_ms": 5760,
          "source_word_index": 14,
          "source_char_start": 14,
          "source_char_end": 15
        },
        {
          "token_id": "token_005",
          "text": "都",
          "target_start_ms": 5760,
          "target_end_ms": 5880,
          "source_word_index": 15,
          "source_char_start": 15,
          "source_char_end": 16
        },
        {
          "token_id": "token_006",
          "text": "要",
          "target_start_ms": 5880,
          "target_end_ms": 6000,
          "source_word_index": 16,
          "source_char_start": 16,
          "source_char_end": 17
        },
        {
          "token_id": "token_007",
          "text": "一",
          "target_start_ms": 6000,
          "target_end_ms": 6120,
          "source_word_index": 17,
          "source_char_start": 17,
          "source_char_end": 18
        },
        {
          "token_id": "token_008",
          "text": "起",
          "target_start_ms": 6120,
          "target_end_ms": 6240,
          "source_word_index": 18,
          "source_char_start": 18,
          "source_char_end": 19
        },
        {
          "token_id": "token_009",
          "text": "去",
          "target_start_ms": 6240,
          "target_end_ms": 6360,
          "source_word_index": 19,
          "source_char_start": 19,
          "source_char_end": 20
        },
        {
          "token_id": "token_010",
          "text": "钓",
          "target_start_ms": 6360,
          "target_end_ms": 6480,
          "source_word_index": 20,
          "source_char_start": 20,
          "source_char_end": 21
        },
        {
          "token_id": "token_011",
          "text": "鱼",
          "target_start_ms": 6480,
          "target_end_ms": 6780,
          "source_word_index": 21,
          "source_char_start": 21,
          "source_char_end": 22
        }
      ]
    },
    {
      "line_id": "line_0006",
      "text": "已经钓了整整一年",
      "target_start_ms": 6780,
      "target_end_ms": 8040,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "已",
          "target_start_ms": 6780,
          "target_end_ms": 6900,
          "source_word_index": 0,
          "source_char_start": 0,
          "source_char_end": 1
        },
        {
          "token_id": "token_002",
          "text": "经",
          "target_start_ms": 6900,
          "target_end_ms": 7080,
          "source_word_index": 1,
          "source_char_start": 1,
          "source_char_end": 2
        },
        {
          "token_id": "token_003",
          "text": "钓",
          "target_start_ms": 7080,
          "target_end_ms": 7200,
          "source_word_index": 2,
          "source_char_start": 2,
          "source_char_end": 3
        },
        {
          "token_id": "token_004",
          "text": "了",
          "target_start_ms": 7200,
          "target_end_ms": 7320,
          "source_word_index": 3,
          "source_char_start": 3,
          "source_char_end": 4
        },
        {
          "token_id": "token_005",
          "text": "整",
          "target_start_ms": 7320,
          "target_end_ms": 7500,
          "source_word_index": 4,
          "source_char_start": 4,
          "source_char_end": 5
        },
        {
          "token_id": "token_006",
          "text": "整",
          "target_start_ms": 7500,
          "target_end_ms": 7680,
          "source_word_index": 5,
          "source_char_start": 5,
          "source_char_end": 6
        },
        {
          "token_id": "token_007",
          "text": "一",
          "target_start_ms": 7680,
          "target_end_ms": 7800,
          "source_word_index": 6,
          "source_char_start": 6,
          "source_char_end": 7
        },
        {
          "token_id": "token_008",
          "text": "年",
          "target_start_ms": 7800,
          "target_end_ms": 8040,
          "source_word_index": 7,
          "source_char_start": 7,
          "source_char_end": 8
        }
      ]
    },
    {
      "line_id": "line_0007",
      "text": "她一直以为两人是很好的朋友",
      "target_start_ms": 8040,
      "target_end_ms": 9840,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "她",
          "target_start_ms": 8040,
          "target_end_ms": 8220,
          "source_word_index": 8,
          "source_char_start": 8,
          "source_char_end": 9
        },
        {
          "token_id": "token_002",
          "text": "一",
          "target_start_ms": 8220,
          "target_end_ms": 8340,
          "source_word_index": 9,
          "source_char_start": 9,
          "source_char_end": 10
        },
        {
          "token_id": "token_003",
          "text": "直",
          "target_start_ms": 8340,
          "target_end_ms": 8460,
          "source_word_index": 10,
          "source_char_start": 10,
          "source_char_end": 11
        },
        {
          "token_id": "token_004",
          "text": "以",
          "target_start_ms": 8460,
          "target_end_ms": 8580,
          "source_word_index": 11,
          "source_char_start": 11,
          "source_char_end": 12
        },
        {
          "token_id": "token_005",
          "text": "为",
          "target_start_ms": 8580,
          "target_end_ms": 8700,
          "source_word_index": 12,
          "source_char_start": 12,
          "source_char_end": 13
        },
        {
          "token_id": "token_006",
          "text": "两",
          "target_start_ms": 8700,
          "target_end_ms": 8820,
          "source_word_index": 13,
          "source_char_start": 13,
          "source_char_end": 14
        },
        {
          "token_id": "token_007",
          "text": "人",
          "target_start_ms": 8820,
          "target_end_ms": 8940,
          "source_word_index": 14,
          "source_char_start": 14,
          "source_char_end": 15
        },
        {
          "token_id": "token_008",
          "text": "是",
          "target_start_ms": 8940,
          "target_end_ms": 9120,
          "source_word_index": 15,
          "source_char_start": 15,
          "source_char_end": 16
        },
        {
          "token_id": "token_009",
          "text": "很",
          "target_start_ms": 9120,
          "target_end_ms": 9240,
          "source_word_index": 16,
          "source_char_start": 16,
          "source_char_end": 17
        },
        {
          "token_id": "token_010",
          "text": "好",
          "target_start_ms": 9240,
          "target_end_ms": 9360,
          "source_word_index": 17,
          "source_char_start": 17,
          "source_char_end": 18
        },
        {
          "token_id": "token_011",
          "text": "的",
          "target_start_ms": 9360,
          "target_end_ms": 9480,
          "source_word_index": 18,
          "source_char_start": 18,
          "source_char_end": 19
        },
        {
          "token_id": "token_012",
          "text": "朋",
          "target_start_ms": 9480,
          "target_end_ms": 9600,
          "source_word_index": 19,
          "source_char_start": 19,
          "source_char_end": 20
        },
        {
          "token_id": "token_013",
          "text": "友",
          "target_start_ms": 9600,
          "target_end_ms": 9840,
          "source_word_index": 20,
          "source_char_start": 20,
          "source_char_end": 21
        }
      ]
    },
    {
      "line_id": "line_0008",
      "text": "结果有天晚上他们又约钓鱼",
      "target_start_ms": 9840,
      "target_end_ms": 11580,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "结",
          "target_start_ms": 9840,
          "target_end_ms": 10020,
          "source_word_index": 21,
          "source_char_start": 21,
          "source_char_end": 22
        },
        {
          "token_id": "token_002",
          "text": "果",
          "target_start_ms": 10020,
          "target_end_ms": 10140,
          "source_word_index": 0,
          "source_char_start": 0,
          "source_char_end": 1
        },
        {
          "token_id": "token_003",
          "text": "有",
          "target_start_ms": 10140,
          "target_end_ms": 10260,
          "source_word_index": 1,
          "source_char_start": 1,
          "source_char_end": 2
        },
        {
          "token_id": "token_004",
          "text": "天",
          "target_start_ms": 10260,
          "target_end_ms": 10380,
          "source_word_index": 2,
          "source_char_start": 2,
          "source_char_end": 3
        },
        {
          "token_id": "token_005",
          "text": "晚",
          "target_start_ms": 10380,
          "target_end_ms": 10500,
          "source_word_index": 3,
          "source_char_start": 3,
          "source_char_end": 4
        },
        {
          "token_id": "token_006",
          "text": "上",
          "target_start_ms": 10500,
          "target_end_ms": 10680,
          "source_word_index": 4,
          "source_char_start": 4,
          "source_char_end": 5
        },
        {
          "token_id": "token_007",
          "text": "他",
          "target_start_ms": 10680,
          "target_end_ms": 10740,
          "source_word_index": 5,
          "source_char_start": 5,
          "source_char_end": 6
        },
        {
          "token_id": "token_008",
          "text": "们",
          "target_start_ms": 10740,
          "target_end_ms": 10860,
          "source_word_index": 6,
          "source_char_start": 6,
          "source_char_end": 7
        },
        {
          "token_id": "token_009",
          "text": "又",
          "target_start_ms": 10860,
          "target_end_ms": 10980,
          "source_word_index": 7,
          "source_char_start": 7,
          "source_char_end": 8
        },
        {
          "token_id": "token_010",
          "text": "约",
          "target_start_ms": 10980,
          "target_end_ms": 11220,
          "source_word_index": 8,
          "source_char_start": 8,
          "source_char_end": 9
        },
        {
          "token_id": "token_011",
          "text": "钓",
          "target_start_ms": 11220,
          "target_end_ms": 11340,
          "source_word_index": 9,
          "source_char_start": 9,
          "source_char_end": 10
        },
        {
          "token_id": "token_012",
          "text": "鱼",
          "target_start_ms": 11340,
          "target_end_ms": 11580,
          "source_word_index": 10,
          "source_char_start": 10,
          "source_char_end": 11
        }
      ]
    },
    {
      "line_id": "line_0009",
      "text": "她随口问了句对方叫什么名字",
      "target_start_ms": 11580,
      "target_end_ms": 13500,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "她",
          "target_start_ms": 11580,
          "target_end_ms": 11760,
          "source_word_index": 11,
          "source_char_start": 11,
          "source_char_end": 12
        },
        {
          "token_id": "token_002",
          "text": "随",
          "target_start_ms": 11760,
          "target_end_ms": 11880,
          "source_word_index": 12,
          "source_char_start": 12,
          "source_char_end": 13
        },
        {
          "token_id": "token_003",
          "text": "口",
          "target_start_ms": 11880,
          "target_end_ms": 12060,
          "source_word_index": 13,
          "source_char_start": 13,
          "source_char_end": 14
        },
        {
          "token_id": "token_004",
          "text": "问",
          "target_start_ms": 12060,
          "target_end_ms": 12180,
          "source_word_index": 14,
          "source_char_start": 14,
          "source_char_end": 15
        },
        {
          "token_id": "token_005",
          "text": "了",
          "target_start_ms": 12180,
          "target_end_ms": 12240,
          "source_word_index": 15,
          "source_char_start": 15,
          "source_char_end": 16
        },
        {
          "token_id": "token_006",
          "text": "句",
          "target_start_ms": 12240,
          "target_end_ms": 12480,
          "source_word_index": 16,
          "source_char_start": 16,
          "source_char_end": 17
        },
        {
          "token_id": "token_007",
          "text": "对",
          "target_start_ms": 12480,
          "target_end_ms": 12600,
          "source_word_index": 17,
          "source_char_start": 17,
          "source_char_end": 18
        },
        {
          "token_id": "token_008",
          "text": "方",
          "target_start_ms": 12600,
          "target_end_ms": 12720,
          "source_word_index": 18,
          "source_char_start": 18,
          "source_char_end": 19
        },
        {
          "token_id": "token_009",
          "text": "叫",
          "target_start_ms": 12720,
          "target_end_ms": 12840,
          "source_word_index": 19,
          "source_char_start": 19,
          "source_char_end": 20
        },
        {
          "token_id": "token_010",
          "text": "什",
          "target_start_ms": 12840,
          "target_end_ms": 12960,
          "source_word_index": 20,
          "source_char_start": 20,
          "source_char_end": 21
        },
        {
          "token_id": "token_011",
          "text": "么",
          "target_start_ms": 12960,
          "target_end_ms": 13080,
          "source_word_index": 21,
          "source_char_start": 21,
          "source_char_end": 22
        },
        {
          "token_id": "token_012",
          "text": "名",
          "target_start_ms": 13080,
          "target_end_ms": 13200,
          "source_word_index": 0,
          "source_char_start": 0,
          "source_char_end": 1
        },
        {
          "token_id": "token_013",
          "text": "字",
          "target_start_ms": 13200,
          "target_end_ms": 13500,
          "source_word_index": 1,
          "source_char_start": 1,
          "source_char_end": 2
        }
      ]
    },
    {
      "line_id": "line_0010",
      "text": "老公竟然说不知道",
      "target_start_ms": 13500,
      "target_end_ms": 14700,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "老",
          "target_start_ms": 13500,
          "target_end_ms": 13620,
          "source_word_index": 2,
          "source_char_start": 2,
          "source_char_end": 3
        },
        {
          "token_id": "token_002",
          "text": "公",
          "target_start_ms": 13620,
          "target_end_ms": 13800,
          "source_word_index": 3,
          "source_char_start": 3,
          "source_char_end": 4
        },
        {
          "token_id": "token_003",
          "text": "竟",
          "target_start_ms": 13800,
          "target_end_ms": 13920,
          "source_word_index": 4,
          "source_char_start": 4,
          "source_char_end": 5
        },
        {
          "token_id": "token_004",
          "text": "然",
          "target_start_ms": 13920,
          "target_end_ms": 14040,
          "source_word_index": 5,
          "source_char_start": 5,
          "source_char_end": 6
        },
        {
          "token_id": "token_005",
          "text": "说",
          "target_start_ms": 14040,
          "target_end_ms": 14220,
          "source_word_index": 6,
          "source_char_start": 6,
          "source_char_end": 7
        },
        {
          "token_id": "token_006",
          "text": "不",
          "target_start_ms": 14220,
          "target_end_ms": 14340,
          "source_word_index": 7,
          "source_char_start": 7,
          "source_char_end": 8
        },
        {
          "token_id": "token_007",
          "text": "知",
          "target_start_ms": 14340,
          "target_end_ms": 14460,
          "source_word_index": 8,
          "source_char_start": 8,
          "source_char_end": 9
        },
        {
          "token_id": "token_008",
          "text": "道",
          "target_start_ms": 14460,
          "target_end_ms": 14700,
          "source_word_index": 9,
          "source_char_start": 9,
          "source_char_end": 10
        }
      ]
    },
    {
      "line_id": "line_0011",
      "text": "认识一年彼此连真名都不知道",
      "target_start_ms": 14700,
      "target_end_ms": 16620,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "认",
          "target_start_ms": 14700,
          "target_end_ms": 14820,
          "source_word_index": 10,
          "source_char_start": 10,
          "source_char_end": 11
        },
        {
          "token_id": "token_002",
          "text": "识",
          "target_start_ms": 14820,
          "target_end_ms": 15000,
          "source_word_index": 11,
          "source_char_start": 11,
          "source_char_end": 12
        },
        {
          "token_id": "token_003",
          "text": "一",
          "target_start_ms": 15000,
          "target_end_ms": 15120,
          "source_word_index": 12,
          "source_char_start": 12,
          "source_char_end": 13
        },
        {
          "token_id": "token_004",
          "text": "年",
          "target_start_ms": 15120,
          "target_end_ms": 15360,
          "source_word_index": 13,
          "source_char_start": 13,
          "source_char_end": 14
        },
        {
          "token_id": "token_005",
          "text": "彼",
          "target_start_ms": 15360,
          "target_end_ms": 15480,
          "source_word_index": 14,
          "source_char_start": 14,
          "source_char_end": 15
        },
        {
          "token_id": "token_006",
          "text": "此",
          "target_start_ms": 15480,
          "target_end_ms": 15660,
          "source_word_index": 15,
          "source_char_start": 15,
          "source_char_end": 16
        },
        {
          "token_id": "token_007",
          "text": "连",
          "target_start_ms": 15660,
          "target_end_ms": 15840,
          "source_word_index": 16,
          "source_char_start": 16,
          "source_char_end": 17
        },
        {
          "token_id": "token_008",
          "text": "真",
          "target_start_ms": 15840,
          "target_end_ms": 15960,
          "source_word_index": 17,
          "source_char_start": 17,
          "source_char_end": 18
        },
        {
          "token_id": "token_009",
          "text": "名",
          "target_start_ms": 15960,
          "target_end_ms": 16080,
          "source_word_index": 18,
          "source_char_start": 18,
          "source_char_end": 19
        },
        {
          "token_id": "token_010",
          "text": "都",
          "target_start_ms": 16080,
          "target_end_ms": 16200,
          "source_word_index": 19,
          "source_char_start": 19,
          "source_char_end": 20
        },
        {
          "token_id": "token_011",
          "text": "不",
          "target_start_ms": 16200,
          "target_end_ms": 16320,
          "source_word_index": 20,
          "source_char_start": 20,
          "source_char_end": 21
        },
        {
          "token_id": "token_012",
          "text": "知",
          "target_start_ms": 16320,
          "target_end_ms": 16380,
          "source_word_index": 21,
          "source_char_start": 21,
          "source_char_end": 22
        },
        {
          "token_id": "token_013",
          "text": "道",
          "target_start_ms": 16380,
          "target_end_ms": 16620,
          "source_word_index": 0,
          "source_char_start": 0,
          "source_char_end": 1
        }
      ]
    },
    {
      "line_id": "line_0012",
      "text": "可每次见面还是热情的喊着兄弟",
      "target_start_ms": 16620,
      "target_end_ms": 18660,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "可",
          "target_start_ms": 16620,
          "target_end_ms": 16800,
          "source_word_index": 1,
          "source_char_start": 1,
          "source_char_end": 2
        },
        {
          "token_id": "token_002",
          "text": "每",
          "target_start_ms": 16800,
          "target_end_ms": 16920,
          "source_word_index": 2,
          "source_char_start": 2,
          "source_char_end": 3
        },
        {
          "token_id": "token_003",
          "text": "次",
          "target_start_ms": 16920,
          "target_end_ms": 17040,
          "source_word_index": 3,
          "source_char_start": 3,
          "source_char_end": 4
        },
        {
          "token_id": "token_004",
          "text": "见",
          "target_start_ms": 17040,
          "target_end_ms": 17160,
          "source_word_index": 4,
          "source_char_start": 4,
          "source_char_end": 5
        },
        {
          "token_id": "token_005",
          "text": "面",
          "target_start_ms": 17160,
          "target_end_ms": 17340,
          "source_word_index": 5,
          "source_char_start": 5,
          "source_char_end": 6
        },
        {
          "token_id": "token_006",
          "text": "还",
          "target_start_ms": 17340,
          "target_end_ms": 17460,
          "source_word_index": 6,
          "source_char_start": 6,
          "source_char_end": 7
        },
        {
          "token_id": "token_007",
          "text": "是",
          "target_start_ms": 17460,
          "target_end_ms": 17580,
          "source_word_index": 7,
          "source_char_start": 7,
          "source_char_end": 8
        },
        {
          "token_id": "token_008",
          "text": "热",
          "target_start_ms": 17580,
          "target_end_ms": 17760,
          "source_word_index": 8,
          "source_char_start": 8,
          "source_char_end": 9
        },
        {
          "token_id": "token_009",
          "text": "情",
          "target_start_ms": 17760,
          "target_end_ms": 17880,
          "source_word_index": 9,
          "source_char_start": 9,
          "source_char_end": 10
        },
        {
          "token_id": "token_010",
          "text": "的",
          "target_start_ms": 17880,
          "target_end_ms": 18000,
          "source_word_index": 10,
          "source_char_start": 10,
          "source_char_end": 11
        },
        {
          "token_id": "token_011",
          "text": "喊",
          "target_start_ms": 18000,
          "target_end_ms": 18120,
          "source_word_index": 11,
          "source_char_start": 11,
          "source_char_end": 12
        },
        {
          "token_id": "token_012",
          "text": "着",
          "target_start_ms": 18120,
          "target_end_ms": 18240,
          "source_word_index": 12,
          "source_char_start": 12,
          "source_char_end": 13
        },
        {
          "token_id": "token_013",
          "text": "兄",
          "target_start_ms": 18240,
          "target_end_ms": 18360,
          "source_word_index": 13,
          "source_char_start": 13,
          "source_char_end": 14
        },
        {
          "token_id": "token_014",
          "text": "弟",
          "target_start_ms": 18360,
          "target_end_ms": 18660,
          "source_word_index": 14,
          "source_char_start": 14,
          "source_char_end": 15
        }
      ]
    },
    {
      "line_id": "line_0013",
      "text": "光想那个画面就特别搞笑",
      "target_start_ms": 18660,
      "target_end_ms": 20280,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "光",
          "target_start_ms": 18660,
          "target_end_ms": 18780,
          "source_word_index": 15,
          "source_char_start": 15,
          "source_char_end": 16
        },
        {
          "token_id": "token_002",
          "text": "想",
          "target_start_ms": 18780,
          "target_end_ms": 18960,
          "source_word_index": 16,
          "source_char_start": 16,
          "source_char_end": 17
        },
        {
          "token_id": "token_003",
          "text": "那",
          "target_start_ms": 18960,
          "target_end_ms": 19080,
          "source_word_index": 17,
          "source_char_start": 17,
          "source_char_end": 18
        },
        {
          "token_id": "token_004",
          "text": "个",
          "target_start_ms": 19080,
          "target_end_ms": 19200,
          "source_word_index": 18,
          "source_char_start": 18,
          "source_char_end": 19
        },
        {
          "token_id": "token_005",
          "text": "画",
          "target_start_ms": 19200,
          "target_end_ms": 19320,
          "source_word_index": 19,
          "source_char_start": 19,
          "source_char_end": 20
        },
        {
          "token_id": "token_006",
          "text": "面",
          "target_start_ms": 19320,
          "target_end_ms": 19440,
          "source_word_index": 20,
          "source_char_start": 20,
          "source_char_end": 21
        },
        {
          "token_id": "token_007",
          "text": "就",
          "target_start_ms": 19440,
          "target_end_ms": 19620,
          "source_word_index": 21,
          "source_char_start": 21,
          "source_char_end": 22
        },
        {
          "token_id": "token_008",
          "text": "特",
          "target_start_ms": 19620,
          "target_end_ms": 19680,
          "source_word_index": 0,
          "source_char_start": 0,
          "source_char_end": 1
        },
        {
          "token_id": "token_009",
          "text": "别",
          "target_start_ms": 19680,
          "target_end_ms": 19860,
          "source_word_index": 1,
          "source_char_start": 1,
          "source_char_end": 2
        },
        {
          "token_id": "token_010",
          "text": "搞",
          "target_start_ms": 19860,
          "target_end_ms": 19980,
          "source_word_index": 2,
          "source_char_start": 2,
          "source_char_end": 3
        },
        {
          "token_id": "token_011",
          "text": "笑",
          "target_start_ms": 19980,
          "target_end_ms": 20280,
          "source_word_index": 3,
          "source_char_start": 3,
          "source_char_end": 4
        }
      ]
    },
    {
      "line_id": "line_0014",
      "text": "结果评论区更精彩",
      "target_start_ms": 20280,
      "target_end_ms": 21600,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "结",
          "target_start_ms": 20280,
          "target_end_ms": 20400,
          "source_word_index": 4,
          "source_char_start": 4,
          "source_char_end": 5
        },
        {
          "token_id": "token_002",
          "text": "果",
          "target_start_ms": 20400,
          "target_end_ms": 20580,
          "source_word_index": 5,
          "source_char_start": 5,
          "source_char_end": 6
        },
        {
          "token_id": "token_003",
          "text": "评",
          "target_start_ms": 20580,
          "target_end_ms": 20700,
          "source_word_index": 6,
          "source_char_start": 6,
          "source_char_end": 7
        },
        {
          "token_id": "token_004",
          "text": "论",
          "target_start_ms": 20700,
          "target_end_ms": 20820,
          "source_word_index": 7,
          "source_char_start": 7,
          "source_char_end": 8
        },
        {
          "token_id": "token_005",
          "text": "区",
          "target_start_ms": 20820,
          "target_end_ms": 21000,
          "source_word_index": 8,
          "source_char_start": 8,
          "source_char_end": 9
        },
        {
          "token_id": "token_006",
          "text": "更",
          "target_start_ms": 21000,
          "target_end_ms": 21180,
          "source_word_index": 9,
          "source_char_start": 9,
          "source_char_end": 10
        },
        {
          "token_id": "token_007",
          "text": "精",
          "target_start_ms": 21180,
          "target_end_ms": 21300,
          "source_word_index": 10,
          "source_char_start": 10,
          "source_char_end": 11
        },
        {
          "token_id": "token_008",
          "text": "彩",
          "target_start_ms": 21300,
          "target_end_ms": 21600,
          "source_word_index": 11,
          "source_char_start": 11,
          "source_char_end": 12
        }
      ]
    },
    {
      "line_id": "line_0015",
      "text": "全都是同款经历",
      "target_start_ms": 21600,
      "target_end_ms": 22740,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "全",
          "target_start_ms": 21600,
          "target_end_ms": 21780,
          "source_word_index": 12,
          "source_char_start": 12,
          "source_char_end": 13
        },
        {
          "token_id": "token_002",
          "text": "都",
          "target_start_ms": 21780,
          "target_end_ms": 21900,
          "source_word_index": 13,
          "source_char_start": 13,
          "source_char_end": 14
        },
        {
          "token_id": "token_003",
          "text": "是",
          "target_start_ms": 21900,
          "target_end_ms": 22080,
          "source_word_index": 14,
          "source_char_start": 14,
          "source_char_end": 15
        },
        {
          "token_id": "token_004",
          "text": "同",
          "target_start_ms": 22080,
          "target_end_ms": 22200,
          "source_word_index": 15,
          "source_char_start": 15,
          "source_char_end": 16
        },
        {
          "token_id": "token_005",
          "text": "款",
          "target_start_ms": 22200,
          "target_end_ms": 22440,
          "source_word_index": 16,
          "source_char_start": 16,
          "source_char_end": 17
        },
        {
          "token_id": "token_006",
          "text": "经",
          "target_start_ms": 22440,
          "target_end_ms": 22560,
          "source_word_index": 17,
          "source_char_start": 17,
          "source_char_end": 18
        },
        {
          "token_id": "token_007",
          "text": "历",
          "target_start_ms": 22560,
          "target_end_ms": 22740,
          "source_word_index": 18,
          "source_char_start": 18,
          "source_char_end": 19
        }
      ]
    },
    {
      "line_id": "line_0016",
      "text": "有人说自己认识十多年的鱼友",
      "target_start_ms": 22740,
      "target_end_ms": 24820,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "有",
          "target_start_ms": 22740,
          "target_end_ms": 22920,
          "source_word_index": 19,
          "source_char_start": 19,
          "source_char_end": 20
        },
        {
          "token_id": "token_002",
          "text": "人",
          "target_start_ms": 22920,
          "target_end_ms": 23040,
          "source_word_index": 20,
          "source_char_start": 20,
          "source_char_end": 21
        },
        {
          "token_id": "token_003",
          "text": "说",
          "target_start_ms": 23040,
          "target_end_ms": 23280,
          "source_word_index": 21,
          "source_char_start": 21,
          "source_char_end": 22
        },
        {
          "token_id": "token_004",
          "text": "自",
          "target_start_ms": 23280,
          "target_end_ms": 23460,
          "source_word_index": 0,
          "source_char_start": 0,
          "source_char_end": 1
        },
        {
          "token_id": "token_005",
          "text": "己",
          "target_start_ms": 23460,
          "target_end_ms": 23580,
          "source_word_index": 1,
          "source_char_start": 1,
          "source_char_end": 2
        },
        {
          "token_id": "token_006",
          "text": "认",
          "target_start_ms": 23580,
          "target_end_ms": 23700,
          "source_word_index": 2,
          "source_char_start": 2,
          "source_char_end": 3
        },
        {
          "token_id": "token_007",
          "text": "识",
          "target_start_ms": 23700,
          "target_end_ms": 23880,
          "source_word_index": 3,
          "source_char_start": 3,
          "source_char_end": 4
        },
        {
          "token_id": "token_008",
          "text": "十",
          "target_start_ms": 23880,
          "target_end_ms": 24000,
          "source_word_index": 4,
          "source_char_start": 4,
          "source_char_end": 5
        },
        {
          "token_id": "token_009",
          "text": "多",
          "target_start_ms": 24000,
          "target_end_ms": 24120,
          "source_word_index": 5,
          "source_char_start": 5,
          "source_char_end": 6
        },
        {
          "token_id": "token_010",
          "text": "年",
          "target_start_ms": 24120,
          "target_end_ms": 24240,
          "source_word_index": 6,
          "source_char_start": 6,
          "source_char_end": 7
        },
        {
          "token_id": "token_011",
          "text": "的",
          "target_start_ms": 24240,
          "target_end_ms": 24420,
          "source_word_index": 7,
          "source_char_start": 7,
          "source_char_end": 8
        },
        {
          "token_id": "token_012",
          "text": "鱼",
          "target_start_ms": 24420,
          "target_end_ms": 24480,
          "source_word_index": 8,
          "source_char_start": 8,
          "source_char_end": 9
        },
        {
          "token_id": "token_013",
          "text": "友",
          "target_start_ms": 24480,
          "target_end_ms": 24820,
          "source_word_index": 9,
          "source_char_start": 9,
          "source_char_end": 10
        }
      ]
    },
    {
      "line_id": "line_0017",
      "text": "前好几年只知道网名",
      "target_start_ms": 24880,
      "target_end_ms": 26260,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "前",
          "target_start_ms": 24880,
          "target_end_ms": 25060,
          "source_word_index": 0,
          "source_char_start": 0,
          "source_char_end": 1
        },
        {
          "token_id": "token_002",
          "text": "好",
          "target_start_ms": 25060,
          "target_end_ms": 25180,
          "source_word_index": 1,
          "source_char_start": 1,
          "source_char_end": 2
        },
        {
          "token_id": "token_003",
          "text": "几",
          "target_start_ms": 25180,
          "target_end_ms": 25300,
          "source_word_index": 2,
          "source_char_start": 2,
          "source_char_end": 3
        },
        {
          "token_id": "token_004",
          "text": "年",
          "target_start_ms": 25300,
          "target_end_ms": 25420,
          "source_word_index": 3,
          "source_char_start": 3,
          "source_char_end": 4
        },
        {
          "token_id": "token_005",
          "text": "只",
          "target_start_ms": 25420,
          "target_end_ms": 25600,
          "source_word_index": 4,
          "source_char_start": 4,
          "source_char_end": 5
        },
        {
          "token_id": "token_006",
          "text": "知",
          "target_start_ms": 25600,
          "target_end_ms": 25660,
          "source_word_index": 5,
          "source_char_start": 5,
          "source_char_end": 6
        },
        {
          "token_id": "token_007",
          "text": "道",
          "target_start_ms": 25660,
          "target_end_ms": 25840,
          "source_word_index": 6,
          "source_char_start": 6,
          "source_char_end": 7
        },
        {
          "token_id": "token_008",
          "text": "网",
          "target_start_ms": 25840,
          "target_end_ms": 25960,
          "source_word_index": 7,
          "source_char_start": 7,
          "source_char_end": 8
        },
        {
          "token_id": "token_009",
          "text": "名",
          "target_start_ms": 25960,
          "target_end_ms": 26260,
          "source_word_index": 8,
          "source_char_start": 8,
          "source_char_end": 9
        }
      ]
    },
    {
      "line_id": "line_0018",
      "text": "连姓啥都不知道",
      "target_start_ms": 26260,
      "target_end_ms": 27340,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "连",
          "target_start_ms": 26260,
          "target_end_ms": 26380,
          "source_word_index": 9,
          "source_char_start": 9,
          "source_char_end": 10
        },
        {
          "token_id": "token_002",
          "text": "姓",
          "target_start_ms": 26380,
          "target_end_ms": 26560,
          "source_word_index": 10,
          "source_char_start": 10,
          "source_char_end": 11
        },
        {
          "token_id": "token_003",
          "text": "啥",
          "target_start_ms": 26560,
          "target_end_ms": 26740,
          "source_word_index": 11,
          "source_char_start": 11,
          "source_char_end": 12
        },
        {
          "token_id": "token_004",
          "text": "都",
          "target_start_ms": 26740,
          "target_end_ms": 26860,
          "source_word_index": 12,
          "source_char_start": 12,
          "source_char_end": 13
        },
        {
          "token_id": "token_005",
          "text": "不",
          "target_start_ms": 26860,
          "target_end_ms": 26980,
          "source_word_index": 13,
          "source_char_start": 13,
          "source_char_end": 14
        },
        {
          "token_id": "token_006",
          "text": "知",
          "target_start_ms": 26980,
          "target_end_ms": 27100,
          "source_word_index": 14,
          "source_char_start": 14,
          "source_char_end": 15
        },
        {
          "token_id": "token_007",
          "text": "道",
          "target_start_ms": 27100,
          "target_end_ms": 27340,
          "source_word_index": 15,
          "source_char_start": 15,
          "source_char_end": 16
        }
      ]
    },
    {
      "line_id": "line_0019",
      "text": "直到后来要转账打名字",
      "target_start_ms": 27340,
      "target_end_ms": 28840,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "直",
          "target_start_ms": 27340,
          "target_end_ms": 27460,
          "source_word_index": 16,
          "source_char_start": 16,
          "source_char_end": 17
        },
        {
          "token_id": "token_002",
          "text": "到",
          "target_start_ms": 27460,
          "target_end_ms": 27580,
          "source_word_index": 17,
          "source_char_start": 17,
          "source_char_end": 18
        },
        {
          "token_id": "token_003",
          "text": "后",
          "target_start_ms": 27580,
          "target_end_ms": 27700,
          "source_word_index": 18,
          "source_char_start": 18,
          "source_char_end": 19
        },
        {
          "token_id": "token_004",
          "text": "来",
          "target_start_ms": 27700,
          "target_end_ms": 27820,
          "source_word_index": 19,
          "source_char_start": 19,
          "source_char_end": 20
        },
        {
          "token_id": "token_005",
          "text": "要",
          "target_start_ms": 27820,
          "target_end_ms": 28000,
          "source_word_index": 20,
          "source_char_start": 20,
          "source_char_end": 21
        },
        {
          "token_id": "token_006",
          "text": "转",
          "target_start_ms": 28000,
          "target_end_ms": 28120,
          "source_word_index": 21,
          "source_char_start": 21,
          "source_char_end": 22
        },
        {
          "token_id": "token_007",
          "text": "账",
          "target_start_ms": 28120,
          "target_end_ms": 28360,
          "source_word_index": 0,
          "source_char_start": 0,
          "source_char_end": 1
        },
        {
          "token_id": "token_008",
          "text": "打",
          "target_start_ms": 28360,
          "target_end_ms": 28480,
          "source_word_index": 1,
          "source_char_start": 1,
          "source_char_end": 2
        },
        {
          "token_id": "token_009",
          "text": "名",
          "target_start_ms": 28480,
          "target_end_ms": 28660,
          "source_word_index": 2,
          "source_char_start": 2,
          "source_char_end": 3
        },
        {
          "token_id": "token_010",
          "text": "字",
          "target_start_ms": 28660,
          "target_end_ms": 28840,
          "source_word_index": 3,
          "source_char_start": 3,
          "source_char_end": 4
        }
      ]
    },
    {
      "line_id": "line_0020",
      "text": "才知道对方叫啥",
      "target_start_ms": 28840,
      "target_end_ms": 29980,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "才",
          "target_start_ms": 28840,
          "target_end_ms": 29020,
          "source_word_index": 4,
          "source_char_start": 4,
          "source_char_end": 5
        },
        {
          "token_id": "token_002",
          "text": "知",
          "target_start_ms": 29020,
          "target_end_ms": 29140,
          "source_word_index": 5,
          "source_char_start": 5,
          "source_char_end": 6
        },
        {
          "token_id": "token_003",
          "text": "道",
          "target_start_ms": 29140,
          "target_end_ms": 29260,
          "source_word_index": 6,
          "source_char_start": 6,
          "source_char_end": 7
        },
        {
          "token_id": "token_004",
          "text": "对",
          "target_start_ms": 29260,
          "target_end_ms": 29380,
          "source_word_index": 7,
          "source_char_start": 7,
          "source_char_end": 8
        },
        {
          "token_id": "token_005",
          "text": "方",
          "target_start_ms": 29380,
          "target_end_ms": 29500,
          "source_word_index": 8,
          "source_char_start": 8,
          "source_char_end": 9
        },
        {
          "token_id": "token_006",
          "text": "叫",
          "target_start_ms": 29500,
          "target_end_ms": 29680,
          "source_word_index": 9,
          "source_char_start": 9,
          "source_char_end": 10
        },
        {
          "token_id": "token_007",
          "text": "啥",
          "target_start_ms": 29680,
          "target_end_ms": 29980,
          "source_word_index": 10,
          "source_char_start": 10,
          "source_char_end": 11
        }
      ]
    },
    {
      "line_id": "line_0021",
      "text": "还有人说他仗人钓鱼几十年",
      "target_start_ms": 29980,
      "target_end_ms": 32020,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "还",
          "target_start_ms": 29980,
          "target_end_ms": 30100,
          "source_word_index": 11,
          "source_char_start": 11,
          "source_char_end": 12
        },
        {
          "token_id": "token_002",
          "text": "有",
          "target_start_ms": 30100,
          "target_end_ms": 30220,
          "source_word_index": 12,
          "source_char_start": 12,
          "source_char_end": 13
        },
        {
          "token_id": "token_003",
          "text": "人",
          "target_start_ms": 30220,
          "target_end_ms": 30340,
          "source_word_index": 13,
          "source_char_start": 13,
          "source_char_end": 14
        },
        {
          "token_id": "token_004",
          "text": "说",
          "target_start_ms": 30340,
          "target_end_ms": 30580,
          "source_word_index": 14,
          "source_char_start": 14,
          "source_char_end": 15
        },
        {
          "token_id": "token_005",
          "text": "他",
          "target_start_ms": 30580,
          "target_end_ms": 30820,
          "source_word_index": 15,
          "source_char_start": 15,
          "source_char_end": 16
        },
        {
          "token_id": "token_006",
          "text": "仗",
          "target_start_ms": 30820,
          "target_end_ms": 31000,
          "source_word_index": 16,
          "source_char_start": 16,
          "source_char_end": 17
        },
        {
          "token_id": "token_007",
          "text": "人",
          "target_start_ms": 31000,
          "target_end_ms": 31180,
          "source_word_index": 17,
          "source_char_start": 17,
          "source_char_end": 18
        },
        {
          "token_id": "token_008",
          "text": "钓",
          "target_start_ms": 31180,
          "target_end_ms": 31300,
          "source_word_index": 18,
          "source_char_start": 18,
          "source_char_end": 19
        },
        {
          "token_id": "token_009",
          "text": "鱼",
          "target_start_ms": 31300,
          "target_end_ms": 31480,
          "source_word_index": 19,
          "source_char_start": 19,
          "source_char_end": 20
        },
        {
          "token_id": "token_010",
          "text": "几",
          "target_start_ms": 31480,
          "target_end_ms": 31660,
          "source_word_index": 20,
          "source_char_start": 20,
          "source_char_end": 21
        },
        {
          "token_id": "token_011",
          "text": "十",
          "target_start_ms": 31660,
          "target_end_ms": 31780,
          "source_word_index": 21,
          "source_char_start": 21,
          "source_char_end": 22
        },
        {
          "token_id": "token_012",
          "text": "年",
          "target_start_ms": 31780,
          "target_end_ms": 32020,
          "source_word_index": 0,
          "source_char_start": 0,
          "source_char_end": 1
        }
      ]
    },
    {
      "line_id": "line_0022",
      "text": "跟钓友酒没少喝却叫不上全名",
      "target_start_ms": 32020,
      "target_end_ms": 34420,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "跟",
          "target_start_ms": 32020,
          "target_end_ms": 32260,
          "source_word_index": 1,
          "source_char_start": 1,
          "source_char_end": 2
        },
        {
          "token_id": "token_002",
          "text": "钓",
          "target_start_ms": 32260,
          "target_end_ms": 32380,
          "source_word_index": 2,
          "source_char_start": 2,
          "source_char_end": 3
        },
        {
          "token_id": "token_003",
          "text": "友",
          "target_start_ms": 32380,
          "target_end_ms": 32560,
          "source_word_index": 3,
          "source_char_start": 3,
          "source_char_end": 4
        },
        {
          "token_id": "token_004",
          "text": "酒",
          "target_start_ms": 32560,
          "target_end_ms": 32740,
          "source_word_index": 4,
          "source_char_start": 4,
          "source_char_end": 5
        },
        {
          "token_id": "token_005",
          "text": "没",
          "target_start_ms": 32740,
          "target_end_ms": 32860,
          "source_word_index": 5,
          "source_char_start": 5,
          "source_char_end": 6
        },
        {
          "token_id": "token_006",
          "text": "少",
          "target_start_ms": 32860,
          "target_end_ms": 33040,
          "source_word_index": 6,
          "source_char_start": 6,
          "source_char_end": 7
        },
        {
          "token_id": "token_007",
          "text": "喝",
          "target_start_ms": 33040,
          "target_end_ms": 33280,
          "source_word_index": 7,
          "source_char_start": 7,
          "source_char_end": 8
        },
        {
          "token_id": "token_008",
          "text": "却",
          "target_start_ms": 33280,
          "target_end_ms": 33520,
          "source_word_index": 8,
          "source_char_start": 8,
          "source_char_end": 9
        },
        {
          "token_id": "token_009",
          "text": "叫",
          "target_start_ms": 33520,
          "target_end_ms": 33640,
          "source_word_index": 9,
          "source_char_start": 9,
          "source_char_end": 10
        },
        {
          "token_id": "token_010",
          "text": "不",
          "target_start_ms": 33640,
          "target_end_ms": 33760,
          "source_word_index": 10,
          "source_char_start": 10,
          "source_char_end": 11
        },
        {
          "token_id": "token_011",
          "text": "上",
          "target_start_ms": 33760,
          "target_end_ms": 33940,
          "source_word_index": 11,
          "source_char_start": 11,
          "source_char_end": 12
        },
        {
          "token_id": "token_012",
          "text": "全",
          "target_start_ms": 33940,
          "target_end_ms": 34120,
          "source_word_index": 12,
          "source_char_start": 12,
          "source_char_end": 13
        },
        {
          "token_id": "token_013",
          "text": "名",
          "target_start_ms": 34120,
          "target_end_ms": 34420,
          "source_word_index": 13,
          "source_char_start": 13,
          "source_char_end": 14
        }
      ]
    },
    {
      "line_id": "line_0023",
      "text": "平时全靠老张王胖这么招呼",
      "target_start_ms": 34420,
      "target_end_ms": 36580,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "平",
          "target_start_ms": 34420,
          "target_end_ms": 34540,
          "source_word_index": 14,
          "source_char_start": 14,
          "source_char_end": 15
        },
        {
          "token_id": "token_002",
          "text": "时",
          "target_start_ms": 34540,
          "target_end_ms": 34720,
          "source_word_index": 15,
          "source_char_start": 15,
          "source_char_end": 16
        },
        {
          "token_id": "token_003",
          "text": "全",
          "target_start_ms": 34720,
          "target_end_ms": 34900,
          "source_word_index": 16,
          "source_char_start": 16,
          "source_char_end": 17
        },
        {
          "token_id": "token_004",
          "text": "靠",
          "target_start_ms": 34900,
          "target_end_ms": 35140,
          "source_word_index": 17,
          "source_char_start": 17,
          "source_char_end": 18
        },
        {
          "token_id": "token_005",
          "text": "老",
          "target_start_ms": 35140,
          "target_end_ms": 35260,
          "source_word_index": 18,
          "source_char_start": 18,
          "source_char_end": 19
        },
        {
          "token_id": "token_006",
          "text": "张",
          "target_start_ms": 35260,
          "target_end_ms": 35500,
          "source_word_index": 19,
          "source_char_start": 19,
          "source_char_end": 20
        },
        {
          "token_id": "token_007",
          "text": "王",
          "target_start_ms": 35500,
          "target_end_ms": 35740,
          "source_word_index": 20,
          "source_char_start": 20,
          "source_char_end": 21
        },
        {
          "token_id": "token_008",
          "text": "胖",
          "target_start_ms": 35740,
          "target_end_ms": 35980,
          "source_word_index": 21,
          "source_char_start": 21,
          "source_char_end": 22
        },
        {
          "token_id": "token_009",
          "text": "这",
          "target_start_ms": 35980,
          "target_end_ms": 36100,
          "source_word_index": 0,
          "source_char_start": 0,
          "source_char_end": 1
        },
        {
          "token_id": "token_010",
          "text": "么",
          "target_start_ms": 36100,
          "target_end_ms": 36220,
          "source_word_index": 1,
          "source_char_start": 1,
          "source_char_end": 2
        },
        {
          "token_id": "token_011",
          "text": "招",
          "target_start_ms": 36220,
          "target_end_ms": 36340,
          "source_word_index": 2,
          "source_char_start": 2,
          "source_char_end": 3
        },
        {
          "token_id": "token_012",
          "text": "呼",
          "target_start_ms": 36340,
          "target_end_ms": 36580,
          "source_word_index": 3,
          "source_char_start": 3,
          "source_char_end": 4
        }
      ]
    },
    {
      "line_id": "line_0024",
      "text": "底下有条高赞回复说",
      "target_start_ms": 36580,
      "target_end_ms": 38140,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "底",
          "target_start_ms": 36580,
          "target_end_ms": 36760,
          "source_word_index": 4,
          "source_char_start": 4,
          "source_char_end": 5
        },
        {
          "token_id": "token_002",
          "text": "下",
          "target_start_ms": 36760,
          "target_end_ms": 36880,
          "source_word_index": 5,
          "source_char_start": 5,
          "source_char_end": 6
        },
        {
          "token_id": "token_003",
          "text": "有",
          "target_start_ms": 36880,
          "target_end_ms": 37000,
          "source_word_index": 6,
          "source_char_start": 6,
          "source_char_end": 7
        },
        {
          "token_id": "token_004",
          "text": "条",
          "target_start_ms": 37000,
          "target_end_ms": 37300,
          "source_word_index": 7,
          "source_char_start": 7,
          "source_char_end": 8
        },
        {
          "token_id": "token_005",
          "text": "高",
          "target_start_ms": 37300,
          "target_end_ms": 37420,
          "source_word_index": 8,
          "source_char_start": 8,
          "source_char_end": 9
        },
        {
          "token_id": "token_006",
          "text": "赞",
          "target_start_ms": 37420,
          "target_end_ms": 37600,
          "source_word_index": 9,
          "source_char_start": 9,
          "source_char_end": 10
        },
        {
          "token_id": "token_007",
          "text": "回",
          "target_start_ms": 37600,
          "target_end_ms": 37720,
          "source_word_index": 10,
          "source_char_start": 10,
          "source_char_end": 11
        },
        {
          "token_id": "token_008",
          "text": "复",
          "target_start_ms": 37720,
          "target_end_ms": 37840,
          "source_word_index": 11,
          "source_char_start": 11,
          "source_char_end": 12
        },
        {
          "token_id": "token_009",
          "text": "说",
          "target_start_ms": 37840,
          "target_end_ms": 38140,
          "source_word_index": 12,
          "source_char_start": 12,
          "source_char_end": 13
        }
      ]
    },
    {
      "line_id": "line_0025",
      "text": "其实这样挺好干净单纯",
      "target_start_ms": 38140,
      "target_end_ms": 39940,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "其",
          "target_start_ms": 38140,
          "target_end_ms": 38260,
          "source_word_index": 13,
          "source_char_start": 13,
          "source_char_end": 14
        },
        {
          "token_id": "token_002",
          "text": "实",
          "target_start_ms": 38260,
          "target_end_ms": 38440,
          "source_word_index": 14,
          "source_char_start": 14,
          "source_char_end": 15
        },
        {
          "token_id": "token_003",
          "text": "这",
          "target_start_ms": 38440,
          "target_end_ms": 38500,
          "source_word_index": 15,
          "source_char_start": 15,
          "source_char_end": 16
        },
        {
          "token_id": "token_004",
          "text": "样",
          "target_start_ms": 38500,
          "target_end_ms": 38680,
          "source_word_index": 16,
          "source_char_start": 16,
          "source_char_end": 17
        },
        {
          "token_id": "token_005",
          "text": "挺",
          "target_start_ms": 38680,
          "target_end_ms": 38800,
          "source_word_index": 17,
          "source_char_start": 17,
          "source_char_end": 18
        },
        {
          "token_id": "token_006",
          "text": "好",
          "target_start_ms": 38800,
          "target_end_ms": 39160,
          "source_word_index": 18,
          "source_char_start": 18,
          "source_char_end": 19
        },
        {
          "token_id": "token_007",
          "text": "干",
          "target_start_ms": 39160,
          "target_end_ms": 39280,
          "source_word_index": 19,
          "source_char_start": 19,
          "source_char_end": 20
        },
        {
          "token_id": "token_008",
          "text": "净",
          "target_start_ms": 39280,
          "target_end_ms": 39520,
          "source_word_index": 20,
          "source_char_start": 20,
          "source_char_end": 21
        },
        {
          "token_id": "token_009",
          "text": "单",
          "target_start_ms": 39520,
          "target_end_ms": 39640,
          "source_word_index": 21,
          "source_char_start": 21,
          "source_char_end": 22
        },
        {
          "token_id": "token_010",
          "text": "纯",
          "target_start_ms": 39640,
          "target_end_ms": 39940,
          "source_word_index": 0,
          "source_char_start": 0,
          "source_char_end": 1
        }
      ]
    },
    {
      "line_id": "line_0026",
      "text": "哪天不高兴了不联系就是了",
      "target_start_ms": 39940,
      "target_end_ms": 41680,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "哪",
          "target_start_ms": 39940,
          "target_end_ms": 40120,
          "source_word_index": 1,
          "source_char_start": 1,
          "source_char_end": 2
        },
        {
          "token_id": "token_002",
          "text": "天",
          "target_start_ms": 40120,
          "target_end_ms": 40240,
          "source_word_index": 2,
          "source_char_start": 2,
          "source_char_end": 3
        },
        {
          "token_id": "token_003",
          "text": "不",
          "target_start_ms": 40240,
          "target_end_ms": 40420,
          "source_word_index": 3,
          "source_char_start": 3,
          "source_char_end": 4
        },
        {
          "token_id": "token_004",
          "text": "高",
          "target_start_ms": 40420,
          "target_end_ms": 40540,
          "source_word_index": 4,
          "source_char_start": 4,
          "source_char_end": 5
        },
        {
          "token_id": "token_005",
          "text": "兴",
          "target_start_ms": 40540,
          "target_end_ms": 40660,
          "source_word_index": 5,
          "source_char_start": 5,
          "source_char_end": 6
        },
        {
          "token_id": "token_006",
          "text": "了",
          "target_start_ms": 40660,
          "target_end_ms": 40780,
          "source_word_index": 6,
          "source_char_start": 6,
          "source_char_end": 7
        },
        {
          "token_id": "token_007",
          "text": "不",
          "target_start_ms": 40780,
          "target_end_ms": 40900,
          "source_word_index": 7,
          "source_char_start": 7,
          "source_char_end": 8
        },
        {
          "token_id": "token_008",
          "text": "联",
          "target_start_ms": 40900,
          "target_end_ms": 41020,
          "source_word_index": 8,
          "source_char_start": 8,
          "source_char_end": 9
        },
        {
          "token_id": "token_009",
          "text": "系",
          "target_start_ms": 41020,
          "target_end_ms": 41200,
          "source_word_index": 9,
          "source_char_start": 9,
          "source_char_end": 10
        },
        {
          "token_id": "token_010",
          "text": "就",
          "target_start_ms": 41200,
          "target_end_ms": 41320,
          "source_word_index": 10,
          "source_char_start": 10,
          "source_char_end": 11
        },
        {
          "token_id": "token_011",
          "text": "是",
          "target_start_ms": 41320,
          "target_end_ms": 41440,
          "source_word_index": 11,
          "source_char_start": 11,
          "source_char_end": 12
        },
        {
          "token_id": "token_012",
          "text": "了",
          "target_start_ms": 41440,
          "target_end_ms": 41680,
          "source_word_index": 12,
          "source_char_start": 12,
          "source_char_end": 13
        }
      ]
    },
    {
      "line_id": "line_0027",
      "text": "最绝得一条评论开头还特别文艺",
      "target_start_ms": 41680,
      "target_end_ms": 43960,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "最",
          "target_start_ms": 41680,
          "target_end_ms": 41860,
          "source_word_index": 13,
          "source_char_start": 13,
          "source_char_end": 14
        },
        {
          "token_id": "token_002",
          "text": "绝",
          "target_start_ms": 41860,
          "target_end_ms": 42040,
          "source_word_index": 14,
          "source_char_start": 14,
          "source_char_end": 15
        },
        {
          "token_id": "token_003",
          "text": "得",
          "target_start_ms": 42040,
          "target_end_ms": 42160,
          "source_word_index": 15,
          "source_char_start": 15,
          "source_char_end": 16
        },
        {
          "token_id": "token_004",
          "text": "一",
          "target_start_ms": 42160,
          "target_end_ms": 42280,
          "source_word_index": 16,
          "source_char_start": 16,
          "source_char_end": 17
        },
        {
          "token_id": "token_005",
          "text": "条",
          "target_start_ms": 42280,
          "target_end_ms": 42400,
          "source_word_index": 17,
          "source_char_start": 17,
          "source_char_end": 18
        },
        {
          "token_id": "token_006",
          "text": "评",
          "target_start_ms": 42400,
          "target_end_ms": 42520,
          "source_word_index": 18,
          "source_char_start": 18,
          "source_char_end": 19
        },
        {
          "token_id": "token_007",
          "text": "论",
          "target_start_ms": 42520,
          "target_end_ms": 42820,
          "source_word_index": 19,
          "source_char_start": 19,
          "source_char_end": 20
        },
        {
          "token_id": "token_008",
          "text": "开",
          "target_start_ms": 42820,
          "target_end_ms": 42940,
          "source_word_index": 20,
          "source_char_start": 20,
          "source_char_end": 21
        },
        {
          "token_id": "token_009",
          "text": "头",
          "target_start_ms": 42940,
          "target_end_ms": 43120,
          "source_word_index": 21,
          "source_char_start": 21,
          "source_char_end": 22
        },
        {
          "token_id": "token_010",
          "text": "还",
          "target_start_ms": 43120,
          "target_end_ms": 43240,
          "source_word_index": 0,
          "source_char_start": 0,
          "source_char_end": 1
        },
        {
          "token_id": "token_011",
          "text": "特",
          "target_start_ms": 43240,
          "target_end_ms": 43360,
          "source_word_index": 1,
          "source_char_start": 1,
          "source_char_end": 2
        },
        {
          "token_id": "token_012",
          "text": "别",
          "target_start_ms": 43360,
          "target_end_ms": 43540,
          "source_word_index": 2,
          "source_char_start": 2,
          "source_char_end": 3
        },
        {
          "token_id": "token_013",
          "text": "文",
          "target_start_ms": 43540,
          "target_end_ms": 43660,
          "source_word_index": 3,
          "source_char_start": 3,
          "source_char_end": 4
        },
        {
          "token_id": "token_014",
          "text": "艺",
          "target_start_ms": 43660,
          "target_end_ms": 43960,
          "source_word_index": 4,
          "source_char_start": 4,
          "source_char_end": 5
        }
      ]
    },
    {
      "line_id": "line_0028",
      "text": "说在同一个时空做同爱好的事儿",
      "target_start_ms": 43960,
      "target_end_ms": 46000,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "说",
          "target_start_ms": 43960,
          "target_end_ms": 44140,
          "source_word_index": 5,
          "source_char_start": 5,
          "source_char_end": 6
        },
        {
          "token_id": "token_002",
          "text": "在",
          "target_start_ms": 44140,
          "target_end_ms": 44320,
          "source_word_index": 6,
          "source_char_start": 6,
          "source_char_end": 7
        },
        {
          "token_id": "token_003",
          "text": "同",
          "target_start_ms": 44320,
          "target_end_ms": 44440,
          "source_word_index": 7,
          "source_char_start": 7,
          "source_char_end": 8
        },
        {
          "token_id": "token_004",
          "text": "一",
          "target_start_ms": 44440,
          "target_end_ms": 44560,
          "source_word_index": 8,
          "source_char_start": 8,
          "source_char_end": 9
        },
        {
          "token_id": "token_005",
          "text": "个",
          "target_start_ms": 44560,
          "target_end_ms": 44680,
          "source_word_index": 9,
          "source_char_start": 9,
          "source_char_end": 10
        },
        {
          "token_id": "token_006",
          "text": "时",
          "target_start_ms": 44680,
          "target_end_ms": 44800,
          "source_word_index": 10,
          "source_char_start": 10,
          "source_char_end": 11
        },
        {
          "token_id": "token_007",
          "text": "空",
          "target_start_ms": 44800,
          "target_end_ms": 44980,
          "source_word_index": 11,
          "source_char_start": 11,
          "source_char_end": 12
        },
        {
          "token_id": "token_008",
          "text": "做",
          "target_start_ms": 44980,
          "target_end_ms": 45220,
          "source_word_index": 12,
          "source_char_start": 12,
          "source_char_end": 13
        },
        {
          "token_id": "token_009",
          "text": "同",
          "target_start_ms": 45220,
          "target_end_ms": 45340,
          "source_word_index": 13,
          "source_char_start": 13,
          "source_char_end": 14
        },
        {
          "token_id": "token_010",
          "text": "爱",
          "target_start_ms": 45340,
          "target_end_ms": 45460,
          "source_word_index": 14,
          "source_char_start": 14,
          "source_char_end": 15
        },
        {
          "token_id": "token_011",
          "text": "好",
          "target_start_ms": 45460,
          "target_end_ms": 45640,
          "source_word_index": 15,
          "source_char_start": 15,
          "source_char_end": 16
        },
        {
          "token_id": "token_012",
          "text": "的",
          "target_start_ms": 45640,
          "target_end_ms": 45700,
          "source_word_index": 16,
          "source_char_start": 16,
          "source_char_end": 17
        },
        {
          "token_id": "token_013",
          "text": "事",
          "target_start_ms": 45700,
          "target_end_ms": 45820,
          "source_word_index": 17,
          "source_char_start": 17,
          "source_char_end": 18
        },
        {
          "token_id": "token_014",
          "text": "儿",
          "target_start_ms": 45820,
          "target_end_ms": 46000,
          "source_word_index": 18,
          "source_char_start": 18,
          "source_char_end": 19
        }
      ]
    },
    {
      "line_id": "line_0029",
      "text": "就是最好的陪伴",
      "target_start_ms": 46000,
      "target_end_ms": 47080,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "就",
          "target_start_ms": 46000,
          "target_end_ms": 46120,
          "source_word_index": 19,
          "source_char_start": 19,
          "source_char_end": 20
        },
        {
          "token_id": "token_002",
          "text": "是",
          "target_start_ms": 46120,
          "target_end_ms": 46240,
          "source_word_index": 20,
          "source_char_start": 20,
          "source_char_end": 21
        },
        {
          "token_id": "token_003",
          "text": "最",
          "target_start_ms": 46240,
          "target_end_ms": 46420,
          "source_word_index": 21,
          "source_char_start": 21,
          "source_char_end": 22
        },
        {
          "token_id": "token_004",
          "text": "好",
          "target_start_ms": 46420,
          "target_end_ms": 46540,
          "source_word_index": 0,
          "source_char_start": 0,
          "source_char_end": 1
        },
        {
          "token_id": "token_005",
          "text": "的",
          "target_start_ms": 46540,
          "target_end_ms": 46660,
          "source_word_index": 1,
          "source_char_start": 1,
          "source_char_end": 2
        },
        {
          "token_id": "token_006",
          "text": "陪",
          "target_start_ms": 46660,
          "target_end_ms": 46780,
          "source_word_index": 2,
          "source_char_start": 2,
          "source_char_end": 3
        },
        {
          "token_id": "token_007",
          "text": "伴",
          "target_start_ms": 46780,
          "target_end_ms": 47080,
          "source_word_index": 3,
          "source_char_start": 3,
          "source_char_end": 4
        }
      ]
    },
    {
      "line_id": "line_0030",
      "text": "结果话风一转说我这么解释",
      "target_start_ms": 47080,
      "target_end_ms": 49060,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "结",
          "target_start_ms": 47080,
          "target_end_ms": 47200,
          "source_word_index": 4,
          "source_char_start": 4,
          "source_char_end": 5
        },
        {
          "token_id": "token_002",
          "text": "果",
          "target_start_ms": 47200,
          "target_end_ms": 47380,
          "source_word_index": 5,
          "source_char_start": 5,
          "source_char_end": 6
        },
        {
          "token_id": "token_003",
          "text": "话",
          "target_start_ms": 47380,
          "target_end_ms": 47560,
          "source_word_index": 6,
          "source_char_start": 6,
          "source_char_end": 7
        },
        {
          "token_id": "token_004",
          "text": "风",
          "target_start_ms": 47560,
          "target_end_ms": 47680,
          "source_word_index": 7,
          "source_char_start": 7,
          "source_char_end": 8
        },
        {
          "token_id": "token_005",
          "text": "一",
          "target_start_ms": 47680,
          "target_end_ms": 47860,
          "source_word_index": 8,
          "source_char_start": 8,
          "source_char_end": 9
        },
        {
          "token_id": "token_006",
          "text": "转",
          "target_start_ms": 47860,
          "target_end_ms": 48040,
          "source_word_index": 9,
          "source_char_start": 9,
          "source_char_end": 10
        },
        {
          "token_id": "token_007",
          "text": "说",
          "target_start_ms": 48040,
          "target_end_ms": 48220,
          "source_word_index": 10,
          "source_char_start": 10,
          "source_char_end": 11
        },
        {
          "token_id": "token_008",
          "text": "我",
          "target_start_ms": 48220,
          "target_end_ms": 48340,
          "source_word_index": 11,
          "source_char_start": 11,
          "source_char_end": 12
        },
        {
          "token_id": "token_009",
          "text": "这",
          "target_start_ms": 48340,
          "target_end_ms": 48460,
          "source_word_index": 12,
          "source_char_start": 12,
          "source_char_end": 13
        },
        {
          "token_id": "token_010",
          "text": "么",
          "target_start_ms": 48460,
          "target_end_ms": 48580,
          "source_word_index": 13,
          "source_char_start": 13,
          "source_char_end": 14
        },
        {
          "token_id": "token_011",
          "text": "解",
          "target_start_ms": 48580,
          "target_end_ms": 48700,
          "source_word_index": 14,
          "source_char_start": 14,
          "source_char_end": 15
        },
        {
          "token_id": "token_012",
          "text": "释",
          "target_start_ms": 48700,
          "target_end_ms": 49060,
          "source_word_index": 15,
          "source_char_start": 15,
          "source_char_end": 16
        }
      ]
    },
    {
      "line_id": "line_0031",
      "text": "人家还要查微信转账记录",
      "target_start_ms": 49060,
      "target_end_ms": 50740,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "人",
          "target_start_ms": 49060,
          "target_end_ms": 49180,
          "source_word_index": 0,
          "source_char_start": 0,
          "source_char_end": 1
        },
        {
          "token_id": "token_002",
          "text": "家",
          "target_start_ms": 49180,
          "target_end_ms": 49300,
          "source_word_index": 1,
          "source_char_start": 1,
          "source_char_end": 2
        },
        {
          "token_id": "token_003",
          "text": "还",
          "target_start_ms": 49300,
          "target_end_ms": 49360,
          "source_word_index": 2,
          "source_char_start": 2,
          "source_char_end": 3
        },
        {
          "token_id": "token_004",
          "text": "要",
          "target_start_ms": 49360,
          "target_end_ms": 49540,
          "source_word_index": 3,
          "source_char_start": 3,
          "source_char_end": 4
        },
        {
          "token_id": "token_005",
          "text": "查",
          "target_start_ms": 49540,
          "target_end_ms": 49720,
          "source_word_index": 4,
          "source_char_start": 4,
          "source_char_end": 5
        },
        {
          "token_id": "token_006",
          "text": "微",
          "target_start_ms": 49720,
          "target_end_ms": 49840,
          "source_word_index": 5,
          "source_char_start": 5,
          "source_char_end": 6
        },
        {
          "token_id": "token_007",
          "text": "信",
          "target_start_ms": 49840,
          "target_end_ms": 50080,
          "source_word_index": 6,
          "source_char_start": 6,
          "source_char_end": 7
        },
        {
          "token_id": "token_008",
          "text": "转",
          "target_start_ms": 50080,
          "target_end_ms": 50200,
          "source_word_index": 7,
          "source_char_start": 7,
          "source_char_end": 8
        },
        {
          "token_id": "token_009",
          "text": "账",
          "target_start_ms": 50200,
          "target_end_ms": 50380,
          "source_word_index": 8,
          "source_char_start": 8,
          "source_char_end": 9
        },
        {
          "token_id": "token_010",
          "text": "记",
          "target_start_ms": 50380,
          "target_end_ms": 50500,
          "source_word_index": 9,
          "source_char_start": 9,
          "source_char_end": 10
        },
        {
          "token_id": "token_011",
          "text": "录",
          "target_start_ms": 50500,
          "target_end_ms": 50740,
          "source_word_index": 10,
          "source_char_start": 10,
          "source_char_end": 11
        }
      ]
    },
    {
      "line_id": "line_0032",
      "text": "非要我说出真名",
      "target_start_ms": 50740,
      "target_end_ms": 51820,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "非",
          "target_start_ms": 50740,
          "target_end_ms": 50860,
          "source_word_index": 11,
          "source_char_start": 11,
          "source_char_end": 12
        },
        {
          "token_id": "token_002",
          "text": "要",
          "target_start_ms": 50860,
          "target_end_ms": 50980,
          "source_word_index": 12,
          "source_char_start": 12,
          "source_char_end": 13
        },
        {
          "token_id": "token_003",
          "text": "我",
          "target_start_ms": 50980,
          "target_end_ms": 51100,
          "source_word_index": 13,
          "source_char_start": 13,
          "source_char_end": 14
        },
        {
          "token_id": "token_004",
          "text": "说",
          "target_start_ms": 51100,
          "target_end_ms": 51280,
          "source_word_index": 14,
          "source_char_start": 14,
          "source_char_end": 15
        },
        {
          "token_id": "token_005",
          "text": "出",
          "target_start_ms": 51280,
          "target_end_ms": 51400,
          "source_word_index": 15,
          "source_char_start": 15,
          "source_char_end": 16
        },
        {
          "token_id": "token_006",
          "text": "真",
          "target_start_ms": 51400,
          "target_end_ms": 51520,
          "source_word_index": 16,
          "source_char_start": 16,
          "source_char_end": 17
        },
        {
          "token_id": "token_007",
          "text": "名",
          "target_start_ms": 51520,
          "target_end_ms": 51820,
          "source_word_index": 17,
          "source_char_start": 17,
          "source_char_end": 18
        }
      ]
    },
    {
      "line_id": "line_0033",
      "text": "说红红花花还不行",
      "target_start_ms": 51820,
      "target_end_ms": 53200,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "说",
          "target_start_ms": 51820,
          "target_end_ms": 52000,
          "source_word_index": 18,
          "source_char_start": 18,
          "source_char_end": 19
        },
        {
          "token_id": "token_002",
          "text": "红",
          "target_start_ms": 52000,
          "target_end_ms": 52180,
          "source_word_index": 19,
          "source_char_start": 19,
          "source_char_end": 20
        },
        {
          "token_id": "token_003",
          "text": "红",
          "target_start_ms": 52180,
          "target_end_ms": 52420,
          "source_word_index": 20,
          "source_char_start": 20,
          "source_char_end": 21
        },
        {
          "token_id": "token_004",
          "text": "花",
          "target_start_ms": 52420,
          "target_end_ms": 52600,
          "source_word_index": 21,
          "source_char_start": 21,
          "source_char_end": 22
        },
        {
          "token_id": "token_005",
          "text": "花",
          "target_start_ms": 52600,
          "target_end_ms": 52780,
          "source_word_index": 0,
          "source_char_start": 0,
          "source_char_end": 1
        },
        {
          "token_id": "token_006",
          "text": "还",
          "target_start_ms": 52780,
          "target_end_ms": 52840,
          "source_word_index": 1,
          "source_char_start": 1,
          "source_char_end": 2
        },
        {
          "token_id": "token_007",
          "text": "不",
          "target_start_ms": 52840,
          "target_end_ms": 52960,
          "source_word_index": 2,
          "source_char_start": 2,
          "source_char_end": 3
        },
        {
          "token_id": "token_008",
          "text": "行",
          "target_start_ms": 52960,
          "target_end_ms": 53200,
          "source_word_index": 3,
          "source_char_start": 3,
          "source_char_end": 4
        }
      ]
    },
    {
      "line_id": "line_0034",
      "text": "底下网友直接补刀",
      "target_start_ms": 53200,
      "target_end_ms": 54400,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "底",
          "target_start_ms": 53200,
          "target_end_ms": 53320,
          "source_word_index": 4,
          "source_char_start": 4,
          "source_char_end": 5
        },
        {
          "token_id": "token_002",
          "text": "下",
          "target_start_ms": 53320,
          "target_end_ms": 53500,
          "source_word_index": 5,
          "source_char_start": 5,
          "source_char_end": 6
        },
        {
          "token_id": "token_003",
          "text": "网",
          "target_start_ms": 53500,
          "target_end_ms": 53620,
          "source_word_index": 6,
          "source_char_start": 6,
          "source_char_end": 7
        },
        {
          "token_id": "token_004",
          "text": "友",
          "target_start_ms": 53620,
          "target_end_ms": 53800,
          "source_word_index": 7,
          "source_char_start": 7,
          "source_char_end": 8
        },
        {
          "token_id": "token_005",
          "text": "直",
          "target_start_ms": 53800,
          "target_end_ms": 53860,
          "source_word_index": 8,
          "source_char_start": 8,
          "source_char_end": 9
        },
        {
          "token_id": "token_006",
          "text": "接",
          "target_start_ms": 53860,
          "target_end_ms": 54040,
          "source_word_index": 9,
          "source_char_start": 9,
          "source_char_end": 10
        },
        {
          "token_id": "token_007",
          "text": "补",
          "target_start_ms": 54040,
          "target_end_ms": 54160,
          "source_word_index": 10,
          "source_char_start": 10,
          "source_char_end": 11
        },
        {
          "token_id": "token_008",
          "text": "刀",
          "target_start_ms": 54160,
          "target_end_ms": 54400,
          "source_word_index": 11,
          "source_char_start": 11,
          "source_char_end": 12
        }
      ]
    },
    {
      "line_id": "line_0035",
      "text": "你这真是正经爱好吗",
      "target_start_ms": 54400,
      "target_end_ms": 55780,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "你",
          "target_start_ms": 54400,
          "target_end_ms": 54520,
          "source_word_index": 12,
          "source_char_start": 12,
          "source_char_end": 13
        },
        {
          "token_id": "token_002",
          "text": "这",
          "target_start_ms": 54520,
          "target_end_ms": 54700,
          "source_word_index": 13,
          "source_char_start": 13,
          "source_char_end": 14
        },
        {
          "token_id": "token_003",
          "text": "真",
          "target_start_ms": 54700,
          "target_end_ms": 54820,
          "source_word_index": 14,
          "source_char_start": 14,
          "source_char_end": 15
        },
        {
          "token_id": "token_004",
          "text": "是",
          "target_start_ms": 54820,
          "target_end_ms": 55000,
          "source_word_index": 15,
          "source_char_start": 15,
          "source_char_end": 16
        },
        {
          "token_id": "token_005",
          "text": "正",
          "target_start_ms": 55000,
          "target_end_ms": 55120,
          "source_word_index": 16,
          "source_char_start": 16,
          "source_char_end": 17
        },
        {
          "token_id": "token_006",
          "text": "经",
          "target_start_ms": 55120,
          "target_end_ms": 55300,
          "source_word_index": 17,
          "source_char_start": 17,
          "source_char_end": 18
        },
        {
          "token_id": "token_007",
          "text": "爱",
          "target_start_ms": 55300,
          "target_end_ms": 55420,
          "source_word_index": 18,
          "source_char_start": 18,
          "source_char_end": 19
        },
        {
          "token_id": "token_008",
          "text": "好",
          "target_start_ms": 55420,
          "target_end_ms": 55540,
          "source_word_index": 19,
          "source_char_start": 19,
          "source_char_end": 20
        },
        {
          "token_id": "token_009",
          "text": "吗",
          "target_start_ms": 55540,
          "target_end_ms": 55780,
          "source_word_index": 20,
          "source_char_start": 20,
          "source_char_end": 21
        }
      ]
    },
    {
      "line_id": "line_0036",
      "text": "笑完之后其实挺感慨的",
      "target_start_ms": 55780,
      "target_end_ms": 57340,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "笑",
          "target_start_ms": 55780,
          "target_end_ms": 56020,
          "source_word_index": 21,
          "source_char_start": 21,
          "source_char_end": 22
        },
        {
          "token_id": "token_002",
          "text": "完",
          "target_start_ms": 56020,
          "target_end_ms": 56140,
          "source_word_index": 0,
          "source_char_start": 0,
          "source_char_end": 1
        },
        {
          "token_id": "token_003",
          "text": "之",
          "target_start_ms": 56140,
          "target_end_ms": 56260,
          "source_word_index": 1,
          "source_char_start": 1,
          "source_char_end": 2
        },
        {
          "token_id": "token_004",
          "text": "后",
          "target_start_ms": 56260,
          "target_end_ms": 56380,
          "source_word_index": 2,
          "source_char_start": 2,
          "source_char_end": 3
        },
        {
          "token_id": "token_005",
          "text": "其",
          "target_start_ms": 56380,
          "target_end_ms": 56500,
          "source_word_index": 3,
          "source_char_start": 3,
          "source_char_end": 4
        },
        {
          "token_id": "token_006",
          "text": "实",
          "target_start_ms": 56500,
          "target_end_ms": 56620,
          "source_word_index": 4,
          "source_char_start": 4,
          "source_char_end": 5
        },
        {
          "token_id": "token_007",
          "text": "挺",
          "target_start_ms": 56620,
          "target_end_ms": 56800,
          "source_word_index": 5,
          "source_char_start": 5,
          "source_char_end": 6
        },
        {
          "token_id": "token_008",
          "text": "感",
          "target_start_ms": 56800,
          "target_end_ms": 56920,
          "source_word_index": 6,
          "source_char_start": 6,
          "source_char_end": 7
        },
        {
          "token_id": "token_009",
          "text": "慨",
          "target_start_ms": 56920,
          "target_end_ms": 57100,
          "source_word_index": 7,
          "source_char_start": 7,
          "source_char_end": 8
        },
        {
          "token_id": "token_010",
          "text": "的",
          "target_start_ms": 57100,
          "target_end_ms": 57340,
          "source_word_index": 8,
          "source_char_start": 8,
          "source_char_end": 9
        }
      ]
    },
    {
      "line_id": "line_0037",
      "text": "大家羡慕这种关系",
      "target_start_ms": 57340,
      "target_end_ms": 58480,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "大",
          "target_start_ms": 57340,
          "target_end_ms": 57460,
          "source_word_index": 9,
          "source_char_start": 9,
          "source_char_end": 10
        },
        {
          "token_id": "token_002",
          "text": "家",
          "target_start_ms": 57460,
          "target_end_ms": 57580,
          "source_word_index": 10,
          "source_char_start": 10,
          "source_char_end": 11
        },
        {
          "token_id": "token_003",
          "text": "羡",
          "target_start_ms": 57580,
          "target_end_ms": 57760,
          "source_word_index": 11,
          "source_char_start": 11,
          "source_char_end": 12
        },
        {
          "token_id": "token_004",
          "text": "慕",
          "target_start_ms": 57760,
          "target_end_ms": 57880,
          "source_word_index": 12,
          "source_char_start": 12,
          "source_char_end": 13
        },
        {
          "token_id": "token_005",
          "text": "这",
          "target_start_ms": 57880,
          "target_end_ms": 58000,
          "source_word_index": 13,
          "source_char_start": 13,
          "source_char_end": 14
        },
        {
          "token_id": "token_006",
          "text": "种",
          "target_start_ms": 58000,
          "target_end_ms": 58120,
          "source_word_index": 14,
          "source_char_start": 14,
          "source_char_end": 15
        },
        {
          "token_id": "token_007",
          "text": "关",
          "target_start_ms": 58120,
          "target_end_ms": 58240,
          "source_word_index": 15,
          "source_char_start": 15,
          "source_char_end": 16
        },
        {
          "token_id": "token_008",
          "text": "系",
          "target_start_ms": 58240,
          "target_end_ms": 58480,
          "source_word_index": 16,
          "source_char_start": 16,
          "source_char_end": 17
        }
      ]
    },
    {
      "line_id": "line_0038",
      "text": "是因为他足够纯粹",
      "target_start_ms": 58480,
      "target_end_ms": 59740,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "是",
          "target_start_ms": 58480,
          "target_end_ms": 58600,
          "source_word_index": 17,
          "source_char_start": 17,
          "source_char_end": 18
        },
        {
          "token_id": "token_002",
          "text": "因",
          "target_start_ms": 58600,
          "target_end_ms": 58660,
          "source_word_index": 18,
          "source_char_start": 18,
          "source_char_end": 19
        },
        {
          "token_id": "token_003",
          "text": "为",
          "target_start_ms": 58660,
          "target_end_ms": 58780,
          "source_word_index": 19,
          "source_char_start": 19,
          "source_char_end": 20
        },
        {
          "token_id": "token_004",
          "text": "他",
          "target_start_ms": 58780,
          "target_end_ms": 59020,
          "source_word_index": 20,
          "source_char_start": 20,
          "source_char_end": 21
        },
        {
          "token_id": "token_005",
          "text": "足",
          "target_start_ms": 59020,
          "target_end_ms": 59140,
          "source_word_index": 21,
          "source_char_start": 21,
          "source_char_end": 22
        },
        {
          "token_id": "token_006",
          "text": "够",
          "target_start_ms": 59140,
          "target_end_ms": 59320,
          "source_word_index": 0,
          "source_char_start": 0,
          "source_char_end": 1
        },
        {
          "token_id": "token_007",
          "text": "纯",
          "target_start_ms": 59320,
          "target_end_ms": 59440,
          "source_word_index": 1,
          "source_char_start": 1,
          "source_char_end": 2
        },
        {
          "token_id": "token_008",
          "text": "粹",
          "target_start_ms": 59440,
          "target_end_ms": 59740,
          "source_word_index": 2,
          "source_char_start": 2,
          "source_char_end": 3
        }
      ]
    },
    {
      "line_id": "line_0039",
      "text": "不查户口不讲人情世故",
      "target_start_ms": 59740,
      "target_end_ms": 61600,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "不",
          "target_start_ms": 59740,
          "target_end_ms": 59920,
          "source_word_index": 3,
          "source_char_start": 3,
          "source_char_end": 4
        },
        {
          "token_id": "token_002",
          "text": "查",
          "target_start_ms": 59920,
          "target_end_ms": 60160,
          "source_word_index": 4,
          "source_char_start": 4,
          "source_char_end": 5
        },
        {
          "token_id": "token_003",
          "text": "户",
          "target_start_ms": 60160,
          "target_end_ms": 60280,
          "source_word_index": 5,
          "source_char_start": 5,
          "source_char_end": 6
        },
        {
          "token_id": "token_004",
          "text": "口",
          "target_start_ms": 60280,
          "target_end_ms": 60520,
          "source_word_index": 6,
          "source_char_start": 6,
          "source_char_end": 7
        },
        {
          "token_id": "token_005",
          "text": "不",
          "target_start_ms": 60520,
          "target_end_ms": 60640,
          "source_word_index": 7,
          "source_char_start": 7,
          "source_char_end": 8
        },
        {
          "token_id": "token_006",
          "text": "讲",
          "target_start_ms": 60640,
          "target_end_ms": 60820,
          "source_word_index": 8,
          "source_char_start": 8,
          "source_char_end": 9
        },
        {
          "token_id": "token_007",
          "text": "人",
          "target_start_ms": 60820,
          "target_end_ms": 60940,
          "source_word_index": 9,
          "source_char_start": 9,
          "source_char_end": 10
        },
        {
          "token_id": "token_008",
          "text": "情",
          "target_start_ms": 60940,
          "target_end_ms": 61120,
          "source_word_index": 10,
          "source_char_start": 10,
          "source_char_end": 11
        },
        {
          "token_id": "token_009",
          "text": "世",
          "target_start_ms": 61120,
          "target_end_ms": 61300,
          "source_word_index": 11,
          "source_char_start": 11,
          "source_char_end": 12
        },
        {
          "token_id": "token_010",
          "text": "故",
          "target_start_ms": 61300,
          "target_end_ms": 61600,
          "source_word_index": 12,
          "source_char_start": 12,
          "source_char_end": 13
        }
      ]
    },
    {
      "line_id": "line_0040",
      "text": "有事说事简单明了",
      "target_start_ms": 61600,
      "target_end_ms": 63160,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "有",
          "target_start_ms": 61600,
          "target_end_ms": 61720,
          "source_word_index": 13,
          "source_char_start": 13,
          "source_char_end": 14
        },
        {
          "token_id": "token_002",
          "text": "事",
          "target_start_ms": 61720,
          "target_end_ms": 61960,
          "source_word_index": 14,
          "source_char_start": 14,
          "source_char_end": 15
        },
        {
          "token_id": "token_003",
          "text": "说",
          "target_start_ms": 61960,
          "target_end_ms": 62080,
          "source_word_index": 15,
          "source_char_start": 15,
          "source_char_end": 16
        },
        {
          "token_id": "token_004",
          "text": "事",
          "target_start_ms": 62080,
          "target_end_ms": 62440,
          "source_word_index": 16,
          "source_char_start": 16,
          "source_char_end": 17
        },
        {
          "token_id": "token_005",
          "text": "简",
          "target_start_ms": 62440,
          "target_end_ms": 62560,
          "source_word_index": 17,
          "source_char_start": 17,
          "source_char_end": 18
        },
        {
          "token_id": "token_006",
          "text": "单",
          "target_start_ms": 62560,
          "target_end_ms": 62800,
          "source_word_index": 18,
          "source_char_start": 18,
          "source_char_end": 19
        },
        {
          "token_id": "token_007",
          "text": "明",
          "target_start_ms": 62800,
          "target_end_ms": 62920,
          "source_word_index": 19,
          "source_char_start": 19,
          "source_char_end": 20
        },
        {
          "token_id": "token_008",
          "text": "了",
          "target_start_ms": 62920,
          "target_end_ms": 63160,
          "source_word_index": 20,
          "source_char_start": 20,
          "source_char_end": 21
        }
      ]
    },
    {
      "line_id": "line_0041",
      "text": "合得来就一起开心",
      "target_start_ms": 63160,
      "target_end_ms": 64360,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "合",
          "target_start_ms": 63160,
          "target_end_ms": 63280,
          "source_word_index": 21,
          "source_char_start": 21,
          "source_char_end": 22
        },
        {
          "token_id": "token_002",
          "text": "得",
          "target_start_ms": 63280,
          "target_end_ms": 63400,
          "source_word_index": 0,
          "source_char_start": 0,
          "source_char_end": 1
        },
        {
          "token_id": "token_003",
          "text": "来",
          "target_start_ms": 63400,
          "target_end_ms": 63520,
          "source_word_index": 1,
          "source_char_start": 1,
          "source_char_end": 2
        },
        {
          "token_id": "token_004",
          "text": "就",
          "target_start_ms": 63520,
          "target_end_ms": 63700,
          "source_word_index": 2,
          "source_char_start": 2,
          "source_char_end": 3
        },
        {
          "token_id": "token_005",
          "text": "一",
          "target_start_ms": 63700,
          "target_end_ms": 63820,
          "source_word_index": 3,
          "source_char_start": 3,
          "source_char_end": 4
        },
        {
          "token_id": "token_006",
          "text": "起",
          "target_start_ms": 63820,
          "target_end_ms": 63940,
          "source_word_index": 4,
          "source_char_start": 4,
          "source_char_end": 5
        },
        {
          "token_id": "token_007",
          "text": "开",
          "target_start_ms": 63940,
          "target_end_ms": 64060,
          "source_word_index": 5,
          "source_char_start": 5,
          "source_char_end": 6
        },
        {
          "token_id": "token_008",
          "text": "心",
          "target_start_ms": 64060,
          "target_end_ms": 64360,
          "source_word_index": 6,
          "source_char_start": 6,
          "source_char_end": 7
        }
      ]
    },
    {
      "line_id": "line_0042",
      "text": "不合了也不内耗",
      "target_start_ms": 64360,
      "target_end_ms": 65500,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "不",
          "target_start_ms": 64360,
          "target_end_ms": 64540,
          "source_word_index": 7,
          "source_char_start": 7,
          "source_char_end": 8
        },
        {
          "token_id": "token_002",
          "text": "合",
          "target_start_ms": 64540,
          "target_end_ms": 64660,
          "source_word_index": 8,
          "source_char_start": 8,
          "source_char_end": 9
        },
        {
          "token_id": "token_003",
          "text": "了",
          "target_start_ms": 64660,
          "target_end_ms": 64780,
          "source_word_index": 9,
          "source_char_start": 9,
          "source_char_end": 10
        },
        {
          "token_id": "token_004",
          "text": "也",
          "target_start_ms": 64780,
          "target_end_ms": 64900,
          "source_word_index": 10,
          "source_char_start": 10,
          "source_char_end": 11
        },
        {
          "token_id": "token_005",
          "text": "不",
          "target_start_ms": 64900,
          "target_end_ms": 65080,
          "source_word_index": 11,
          "source_char_start": 11,
          "source_char_end": 12
        },
        {
          "token_id": "token_006",
          "text": "内",
          "target_start_ms": 65080,
          "target_end_ms": 65200,
          "source_word_index": 12,
          "source_char_start": 12,
          "source_char_end": 13
        },
        {
          "token_id": "token_007",
          "text": "耗",
          "target_start_ms": 65200,
          "target_end_ms": 65500,
          "source_word_index": 13,
          "source_char_start": 13,
          "source_char_end": 14
        }
      ]
    },
    {
      "line_id": "line_0043",
      "text": "如果成年人处关系",
      "target_start_ms": 65500,
      "target_end_ms": 66820,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "如",
          "target_start_ms": 65500,
          "target_end_ms": 65620,
          "source_word_index": 14,
          "source_char_start": 14,
          "source_char_end": 15
        },
        {
          "token_id": "token_002",
          "text": "果",
          "target_start_ms": 65620,
          "target_end_ms": 65800,
          "source_word_index": 15,
          "source_char_start": 15,
          "source_char_end": 16
        },
        {
          "token_id": "token_003",
          "text": "成",
          "target_start_ms": 65800,
          "target_end_ms": 65920,
          "source_word_index": 16,
          "source_char_start": 16,
          "source_char_end": 17
        },
        {
          "token_id": "token_004",
          "text": "年",
          "target_start_ms": 65920,
          "target_end_ms": 66100,
          "source_word_index": 17,
          "source_char_start": 17,
          "source_char_end": 18
        },
        {
          "token_id": "token_005",
          "text": "人",
          "target_start_ms": 66100,
          "target_end_ms": 66220,
          "source_word_index": 18,
          "source_char_start": 18,
          "source_char_end": 19
        },
        {
          "token_id": "token_006",
          "text": "处",
          "target_start_ms": 66220,
          "target_end_ms": 66400,
          "source_word_index": 19,
          "source_char_start": 19,
          "source_char_end": 20
        },
        {
          "token_id": "token_007",
          "text": "关",
          "target_start_ms": 66400,
          "target_end_ms": 66520,
          "source_word_index": 20,
          "source_char_start": 20,
          "source_char_end": 21
        },
        {
          "token_id": "token_008",
          "text": "系",
          "target_start_ms": 66520,
          "target_end_ms": 66820,
          "source_word_index": 21,
          "source_char_start": 21,
          "source_char_end": 22
        }
      ]
    },
    {
      "line_id": "line_0044",
      "text": "都能像这样轻装上阵",
      "target_start_ms": 66820,
      "target_end_ms": 68380,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "都",
          "target_start_ms": 66820,
          "target_end_ms": 67000,
          "source_word_index": 0,
          "source_char_start": 0,
          "source_char_end": 1
        },
        {
          "token_id": "token_002",
          "text": "能",
          "target_start_ms": 67000,
          "target_end_ms": 67120,
          "source_word_index": 1,
          "source_char_start": 1,
          "source_char_end": 2
        },
        {
          "token_id": "token_003",
          "text": "像",
          "target_start_ms": 67120,
          "target_end_ms": 67300,
          "source_word_index": 2,
          "source_char_start": 2,
          "source_char_end": 3
        },
        {
          "token_id": "token_004",
          "text": "这",
          "target_start_ms": 67300,
          "target_end_ms": 67360,
          "source_word_index": 3,
          "source_char_start": 3,
          "source_char_end": 4
        },
        {
          "token_id": "token_005",
          "text": "样",
          "target_start_ms": 67360,
          "target_end_ms": 67660,
          "source_word_index": 4,
          "source_char_start": 4,
          "source_char_end": 5
        },
        {
          "token_id": "token_006",
          "text": "轻",
          "target_start_ms": 67660,
          "target_end_ms": 67780,
          "source_word_index": 5,
          "source_char_start": 5,
          "source_char_end": 6
        },
        {
          "token_id": "token_007",
          "text": "装",
          "target_start_ms": 67780,
          "target_end_ms": 67960,
          "source_word_index": 6,
          "source_char_start": 6,
          "source_char_end": 7
        },
        {
          "token_id": "token_008",
          "text": "上",
          "target_start_ms": 67960,
          "target_end_ms": 68080,
          "source_word_index": 7,
          "source_char_start": 7,
          "source_char_end": 8
        },
        {
          "token_id": "token_009",
          "text": "阵",
          "target_start_ms": 68080,
          "target_end_ms": 68380,
          "source_word_index": 8,
          "source_char_start": 8,
          "source_char_end": 9
        }
      ]
    },
    {
      "line_id": "line_0045",
      "text": "其实挺舒服的",
      "target_start_ms": 68380,
      "target_end_ms": 69280,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "其",
          "target_start_ms": 68380,
          "target_end_ms": 68500,
          "source_word_index": 9,
          "source_char_start": 9,
          "source_char_end": 10
        },
        {
          "token_id": "token_002",
          "text": "实",
          "target_start_ms": 68500,
          "target_end_ms": 68620,
          "source_word_index": 10,
          "source_char_start": 10,
          "source_char_end": 11
        },
        {
          "token_id": "token_003",
          "text": "挺",
          "target_start_ms": 68620,
          "target_end_ms": 68800,
          "source_word_index": 11,
          "source_char_start": 11,
          "source_char_end": 12
        },
        {
          "token_id": "token_004",
          "text": "舒",
          "target_start_ms": 68800,
          "target_end_ms": 68980,
          "source_word_index": 12,
          "source_char_start": 12,
          "source_char_end": 13
        },
        {
          "token_id": "token_005",
          "text": "服",
          "target_start_ms": 68980,
          "target_end_ms": 69100,
          "source_word_index": 13,
          "source_char_start": 13,
          "source_char_end": 14
        },
        {
          "token_id": "token_006",
          "text": "的",
          "target_start_ms": 69100,
          "target_end_ms": 69280,
          "source_word_index": 14,
          "source_char_start": 14,
          "source_char_end": 15
        }
      ]
    },
    {
      "line_id": "line_0046",
      "text": "你身边有没有这种",
      "target_start_ms": 69280,
      "target_end_ms": 70420,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "你",
          "target_start_ms": 69280,
          "target_end_ms": 69460,
          "source_word_index": 15,
          "source_char_start": 15,
          "source_char_end": 16
        },
        {
          "token_id": "token_002",
          "text": "身",
          "target_start_ms": 69460,
          "target_end_ms": 69580,
          "source_word_index": 16,
          "source_char_start": 16,
          "source_char_end": 17
        },
        {
          "token_id": "token_003",
          "text": "边",
          "target_start_ms": 69580,
          "target_end_ms": 69700,
          "source_word_index": 17,
          "source_char_start": 17,
          "source_char_end": 18
        },
        {
          "token_id": "token_004",
          "text": "有",
          "target_start_ms": 69700,
          "target_end_ms": 69880,
          "source_word_index": 18,
          "source_char_start": 18,
          "source_char_end": 19
        },
        {
          "token_id": "token_005",
          "text": "没",
          "target_start_ms": 69880,
          "target_end_ms": 69940,
          "source_word_index": 19,
          "source_char_start": 19,
          "source_char_end": 20
        },
        {
          "token_id": "token_006",
          "text": "有",
          "target_start_ms": 69940,
          "target_end_ms": 70060,
          "source_word_index": 20,
          "source_char_start": 20,
          "source_char_end": 21
        },
        {
          "token_id": "token_007",
          "text": "这",
          "target_start_ms": 70060,
          "target_end_ms": 70180,
          "source_word_index": 21,
          "source_char_start": 21,
          "source_char_end": 22
        },
        {
          "token_id": "token_008",
          "text": "种",
          "target_start_ms": 70180,
          "target_end_ms": 70420,
          "source_word_index": 0,
          "source_char_start": 0,
          "source_char_end": 1
        }
      ]
    },
    {
      "line_id": "line_0047",
      "text": "连全民都不知道",
      "target_start_ms": 70420,
      "target_end_ms": 71500,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "连",
          "target_start_ms": 70420,
          "target_end_ms": 70660,
          "source_word_index": 1,
          "source_char_start": 1,
          "source_char_end": 2
        },
        {
          "token_id": "token_002",
          "text": "全",
          "target_start_ms": 70660,
          "target_end_ms": 70780,
          "source_word_index": 2,
          "source_char_start": 2,
          "source_char_end": 3
        },
        {
          "token_id": "token_003",
          "text": "民",
          "target_start_ms": 70780,
          "target_end_ms": 70960,
          "source_word_index": 3,
          "source_char_start": 3,
          "source_char_end": 4
        },
        {
          "token_id": "token_004",
          "text": "都",
          "target_start_ms": 70960,
          "target_end_ms": 71080,
          "source_word_index": 4,
          "source_char_start": 4,
          "source_char_end": 5
        },
        {
          "token_id": "token_005",
          "text": "不",
          "target_start_ms": 71080,
          "target_end_ms": 71200,
          "source_word_index": 5,
          "source_char_start": 5,
          "source_char_end": 6
        },
        {
          "token_id": "token_006",
          "text": "知",
          "target_start_ms": 71200,
          "target_end_ms": 71320,
          "source_word_index": 6,
          "source_char_start": 6,
          "source_char_end": 7
        },
        {
          "token_id": "token_007",
          "text": "道",
          "target_start_ms": 71320,
          "target_end_ms": 71500,
          "source_word_index": 7,
          "source_char_start": 7,
          "source_char_end": 8
        }
      ]
    },
    {
      "line_id": "line_0048",
      "text": "却处的特别轻松的搭子",
      "target_start_ms": 71500,
      "target_end_ms": 73067,
      "tokens": [
        {
          "token_id": "token_001",
          "text": "却",
          "target_start_ms": 71500,
          "target_end_ms": 71680,
          "source_word_index": 8,
          "source_char_start": 8,
          "source_char_end": 9
        },
        {
          "token_id": "token_002",
          "text": "处",
          "target_start_ms": 71680,
          "target_end_ms": 71800,
          "source_word_index": 9,
          "source_char_start": 9,
          "source_char_end": 10
        },
        {
          "token_id": "token_003",
          "text": "的",
          "target_start_ms": 71800,
          "target_end_ms": 71980,
          "source_word_index": 10,
          "source_char_start": 10,
          "source_char_end": 11
        },
        {
          "token_id": "token_004",
          "text": "特",
          "target_start_ms": 71980,
          "target_end_ms": 72100,
          "source_word_index": 11,
          "source_char_start": 11,
          "source_char_end": 12
        },
        {
          "token_id": "token_005",
          "text": "别",
          "target_start_ms": 72100,
          "target_end_ms": 72280,
          "source_word_index": 12,
          "source_char_start": 12,
          "source_char_end": 13
        },
        {
          "token_id": "token_006",
          "text": "轻",
          "target_start_ms": 72280,
          "target_end_ms": 72400,
          "source_word_index": 13,
          "source_char_start": 13,
          "source_char_end": 14
        },
        {
          "token_id": "token_007",
          "text": "松",
          "target_start_ms": 72400,
          "target_end_ms": 72520,
          "source_word_index": 14,
          "source_char_start": 14,
          "source_char_end": 15
        },
        {
          "token_id": "token_008",
          "text": "的",
          "target_start_ms": 72520,
          "target_end_ms": 72640,
          "source_word_index": 15,
          "source_char_start": 15,
          "source_char_end": 16
        },
        {
          "token_id": "token_009",
          "text": "搭",
          "target_start_ms": 72640,
          "target_end_ms": 72820,
          "source_word_index": 16,
          "source_char_start": 16,
          "source_char_end": 17
        },
        {
          "token_id": "token_010",
          "text": "子",
          "target_start_ms": 72820,
          "target_end_ms": 73067,
          "source_word_index": 17,
          "source_char_start": 17,
          "source_char_end": 18
        }
      ]
    }
  ],
  "speech_metadata": {
    "provider": "sherpa-onnx-sensevoice",
    "model": {
      "model": "model.int8.onnx",
      "tokens": "tokens.txt",
      "model_sha256": "c71f0ce00bec95b07744e116345e33d8cbbe08cef896382cf907bf4b51a2cd51",
      "tokens_sha256": "f449eb28dc567533d7fa59be34e2abca8784f771850c78a47fb731a31429a1dc",
      "source": "sherpa-onnx-sense-voice",
      "integrity": "sha256-verified",
      "revision": "2365baeacb507f821a0c8120fcee3d484dba7a07"
    },
    "timing_precision": "ctc-token-time-points",
    "end_boundary_method": "next token time capped at 400ms; estimated, not forced alignment",
    "chunking": "energy-aware bounded chunks; original offsets retained",
    "source_media": "男性交友钓鱼搭子.mp4"
  }
};
