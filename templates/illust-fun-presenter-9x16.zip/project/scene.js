(() => {
  'use strict';
  const P = window.CANVAS_PLAN;
  const C = P.cues || {};
  const $ = s => document.querySelector(s);
  const stage = $('#stage');
  const world = $('#world');
  const video = $('#presenter-video');
  const voice = $('#voice');
  const renderMode = new URLSearchParams(location.search).get('render') === '1';
  if (renderMode) document.body.classList.add('render-mode');

  const clamp = x => Math.max(0, Math.min(1, x));
  const smooth = x => { x = clamp(x); return x * x * (3 - 2 * x); };
  const mix = (a, b, u) => a + (b - a) * u;
  const originalLead = P.intro?.duration || 0;
  const isLightTheme = ['cream', 'forest', 'lilac', 'pop-fun', 'illust-fun'].includes(P.theme_key || 'illust-fun');

  let time = 0, lead = originalLead, coverEnabled = true, mode = 'demo', playing = false;
  let freeCamera = null, frame = 0, lastSync = 0, seekQueue = Promise.resolve();
  let viewport = { ...P.output }, browseTarget = 'overview', segment = null, selected = '';
  let tool = 'select', drag = null, spaceDown = false, lastTapTarget = null;

  const duration = () => P.content_duration + lead;
  const audioOffset = () => originalLead - lead;
  const bodyTime = () => Math.max(0, time - lead);

  world.style.width = P.world.width + 'px';
  world.style.height = P.world.height + 'px';

  // Render 16:9 board frames (visible in browse mode)
  for (const b of P.boards) {
    const boardEl = document.createElement('div');
    boardEl.className = 'board-frame';
    boardEl.dataset.board = b.id;
    Object.assign(boardEl.style, {
      left: b.x + 'px',
      top: b.y + 'px',
      width: b.width + 'px',
      height: b.height + 'px'
    });
    const label = document.createElement('div');
    label.className = 'board-frame-label';
    label.textContent = b.name || b.id;
    boardEl.append(label);
    world.append(boardEl);
  }

  // Render semantic components inside their boards
  const elements = new Map();
  for (const c of P.components) {
    const el = document.createElement('section');
    el.className = 'component';
    el.dataset.component = c.id;
    const board = P.boards.find(b => b.id === c.board_id);
    Object.assign(el.style, {
      left: (board.x + c.bounds.x) + 'px',
      top: (board.y + c.bounds.y) + 'px',
      width: c.bounds.width + 'px',
      height: c.bounds.height + 'px'
    });
    el.innerHTML = FishingDiagrams.html[c.id] || '';
    world.append(el);
    elements.set(c.id, el);
  }

  window.CanvasScene = { elements, render: t => draw(t + lead) };
  const captions = window.CanvasSubtitles = CanvasSubtitleTrack.create({
    stage,
    timeline: FINAL_TIMELINE,
    output: P.output,
    config: P.subtitle_settings,
    isBrowsing: () => mode === 'browse',
    requestRender: () => draw(time)
  });

  function smallAmount(t) {
    let value = 0;
    for (const [start, end] of P.presenter_layout.canvas_intervals) {
      if (t >= start && t < end + 0.34) {
        value = Math.max(value, smooth((t - start) / 0.38) * (1 - smooth((t - end) / 0.34)));
      }
    }
    return value;
  }

  function cameraAt(t) {
    if (segment && P.components.some(c => c.id === segment.target)) {
      const fitted = CanvasCamera.fit(CanvasCamera.bounds(P, segment.target), P.output, 0.08);
      fitted.scale *= 0.90;
      return { ...fitted, shot: { target: segment.target }, index: 0, u: 1 };
    }
    return CanvasCamera.at(P, t);
  }

  function applyAttention(t, cam, browsing) {
    const idx = cam.index ?? 0;
    const shot = cam.shot || P.shots[idx];
    const prior = P.shots[Math.max(0, idx - 1)];
    const u = browsing ? 1 : smooth(cam.u ?? 1);
    const targetId = shot?.target?.split('/')[0];
    const priorId = prior?.target?.split('/')[0];
    const targetComp = P.components.find(c => c.id === targetId);
    const activeBoard = targetComp?.board_id;
    const pixelScale = browsing ? 1 : Math.max(0.4, cam.scale || 1);

    for (const c of P.components) {
      const el = elements.get(c.id);
      if (browsing) {
        el.style.opacity = '1';
        el.style.filter = 'none';
        continue;
      }
      const weight = Math.min(1, (c.id === priorId ? 1 - u : 0) + (c.id === targetId ? u : 0));
      const sameBoard = c.board_id === activeBoard;
      const blur = ((sameBoard ? 4.4 : 6.2) / pixelScale) * (1 - weight);

      if (isLightTheme) {
        // Light paper theme: fade smoothly into paper instead of darkening into muddy gray!
        const baseOpacity = sameBoard ? 0.30 : 0.16;
        el.style.opacity = String(baseOpacity + (1 - baseOpacity) * weight);
        el.style.filter = weight > 0.995
          ? 'none'
          : `saturate(${(0.55 + 0.45 * weight).toFixed(3)}) blur(${blur.toFixed(2)}px)`;
      } else {
        const baseBright = sameBoard ? 0.36 : 0.22;
        el.style.opacity = '1';
        el.style.filter = weight > 0.995
          ? 'none'
          : `brightness(${(baseBright + (1 - baseBright) * weight).toFixed(3)}) blur(${blur.toFixed(2)}px)`;
      }
    }
  }

  function draw(presentationTime) {
    time = Math.max(0, Math.min(duration(), presentationTime));
    const t = bodyTime();
    const browsing = mode === 'browse';
    const small = smallAmount(t);
    const cam = browsing ? freeCamera : cameraAt(t);

    world.style.transform = CanvasCamera.matrix(cam, browsing ? viewport : P.output);
    const current = cam.shot?.target;

    // Smooth color transition for title & subtitles as presenter drops below the title zone
    const canvasMix = browsing ? 1 : smooth((small - 0.16) / 0.32);
    stage.style.setProperty('--canvas-mix', canvasMix.toFixed(4));
    stage.classList.toggle('canvas-active', canvasMix > 0.5);

    applyAttention(t, cam, browsing);

    const pin = P.presenter_layout.window;
    const w = mix(1080, pin.width, small);
    const h = mix(1920, pin.height, small);
    const x = mix(0, pin.x, small);
    const y = mix(0, pin.y, Math.pow(small, 0.68));
    const box = $('#presenter');
    Object.assign(box.style, {
      left: x + 'px',
      top: y + 'px',
      width: w + 'px',
      height: h + 'px',
      borderRadius: (small * pin.width / 2) + 'px',
      boxShadow: small > 0.85
        ? `0 0 0 3px ${P.theme.foreground}, 0 12px 28px rgba(48,45,40,${(0.22 * small).toFixed(3)})`
        : 'none'
    });
    const vw = mix(1200, 336, small);
    const vh = vw * 1920 / 1080;
    Object.assign(video.style, {
      width: vw + 'px',
      height: vh + 'px',
      left: mix(-60, -66, small) + 'px',
      top: mix(0, -132, small) + 'px'
    });

    $('#full-shade').style.opacity = String(1 - smooth(small / 0.65));
    $('#film-title').style.opacity = '1';
    $('#cover').style.display = (!browsing && coverEnabled && time < lead) ? 'flex' : 'none';

    FishingDiagrams.render(t, { all: browsing });
    window.CameraFlightGuide?.render(t, { browsing, cover: time < lead, small });

    captions.render(t);
    captions.root.style.display = (time < lead || browsing || captions.getMode() === 'off') ? 'none' : 'block';
    const line = FINAL_TIMELINE.lines.find(l => l.line_id === captions.root.dataset.lineId);
    const entry = line ? smooth((t - line.target_start_ms / 1000) / 0.16) : 1;
    captions.root.dataset.editorial = (P.subtitle_settings.strong_lines || []).includes(line?.line_id) ? 'strong' : 'normal';
    captions.root.querySelector('.canvas-caption-line').style.transform = `translateY(${(1 - entry) * 8}px)`;

    window.CaptionDirector?.render(t, { browsing, cover: time < lead });

    for (const el of stage.querySelectorAll('[id^="canvas-subtitles-"]')) {
      el.style.visibility = time < lead ? 'hidden' : 'visible';
    }

    if (!renderMode) {
      $('#seek').min = segment?.start || 0;
      $('#seek').max = segment?.end ?? duration();
      $('#seek').value = time;
      $('#time-label').textContent = segment
        ? (time - segment.start).toFixed(2) + ' / ' + (segment.end - segment.start).toFixed(2) + ' 秒'
        : time.toFixed(2) + ' / ' + duration().toFixed(2) + ' 秒';
      const activeChapter = P.chapters.filter(c => c.at <= t).at(-1);
      $('#current-chapter').textContent = segment ? '局部播放 · ' + segment.label : (activeChapter?.label || '');
      for (const b of document.querySelectorAll('.phases button')) {
        b.classList.toggle('current', Number(b.dataset.at) === activeChapter?.at);
      }
      $('#zoom-label').textContent = Math.round(cam.scale * 100) + '%';
      window.dispatchEvent(new CustomEvent('canvas-render', {
        detail: { time, bodyTime: t, mode: mode === 'browse' ? 'resource' : 'demo', playing, segment }
      }));
    }
    return { time, contentTime: t, small, sourceTime: video.currentTime, shot: current };
  }

  function pause() {
    playing = false;
    voice.pause();
    video.pause();
    cancelAnimationFrame(frame);
    $('#play').textContent = '播放';
    if (!renderMode) {
      window.dispatchEvent(new CustomEvent('canvas-render', {
        detail: { time, bodyTime: bodyTime(), mode: mode === 'browse' ? 'resource' : 'demo', playing, segment }
      }));
    }
  }

  async function mediaSeek(target) {
    const t = Math.max(0, Math.min(P.content_duration - 0.001, target));
    if (Math.abs(video.currentTime - t) < 0.018 && video.readyState >= 2) return;
    await new Promise((resolve, reject) => {
      const timeout = setTimeout(() => { cleanup(); reject(Error('人物源帧定位超时：' + t)); }, 9000);
      function cleanup() { clearTimeout(timeout); video.removeEventListener('seeked', done); video.removeEventListener('error', fail); }
      function done() { cleanup(); resolve(); }
      function fail() { cleanup(); reject(Error('人物素材加载失败')); }
      video.addEventListener('seeked', done, { once: true });
      video.addEventListener('error', fail, { once: true });
      video.currentTime = t;
    });
    if (video.requestVideoFrameCallback) {
      await new Promise(resolve => {
        const timer = setTimeout(resolve, 120);
        video.requestVideoFrameCallback(() => { clearTimeout(timer); resolve(); });
      });
    }
  }

  function setMode(next) {
    const changed = next !== mode;
    mode = next;
    document.body.classList.toggle('resource-mode', mode === 'browse');
    document.body.classList.toggle('demo-mode', mode === 'demo');
    resize();
    if (changed) window.dispatchEvent(new CustomEvent('canvas-mode-change', { detail: { mode: mode === 'browse' ? 'resource' : 'demo' } }));
  }

  async function position(target, { keepSegment = false } = {}) {
    pause();
    if (!keepSegment) segment = null;
    setMode('demo');
    time = Math.max(0, Math.min(duration(), target));
    await mediaSeek(bodyTime());
    voice.currentTime = time + audioOffset();
    return draw(time);
  }

  function seek(target, options) {
    seekQueue = seekQueue.catch(() => {}).then(() => position(target, options));
    return seekQueue;
  }

  window.END = duration();
  window.renderAt = target => seek(target);

  function tick() {
    if (!playing) return;
    draw(voice.currentTime - audioOffset());
    if (time >= lead && video.paused) video.play().catch(report);
    if (time >= lead && performance.now() - lastSync > 900 && Math.abs(video.currentTime - bodyTime()) > 0.14) {
      video.currentTime = bodyTime();
      lastSync = performance.now();
    }
    const end = segment?.end ?? duration();
    if (voice.ended || time >= end - 0.01) { pause(); draw(end); return; }
    frame = requestAnimationFrame(tick);
  }

  function report(e) { $('#review-status').textContent = e.message; console.error(e); }

  async function play() {
    if (playing) { pause(); return; }
    const end = segment?.end ?? duration(), start = segment?.start || 0;
    await seek(time >= end - 0.01 ? start : Math.max(start, time), { keepSegment: true });
    await voice.play();
    if (time >= lead) await video.play();
    playing = true;
    $('#play').textContent = '暂停';
    frame = requestAnimationFrame(tick);
  }

  function resize() {
    const work = $('.workspace');
    const w = renderMode ? P.output.width : work.clientWidth;
    const h = renderMode ? P.output.height : work.clientHeight;
    if (w <= 0 || h <= 0) return;
    viewport = mode === 'browse' && !renderMode ? { width: w, height: h } : { ...P.output };
    const scale = Math.min(w / viewport.width, h / viewport.height);
    Object.assign($('#screen').style, { width: w + 'px', height: h + 'px' });
    Object.assign(stage.style, {
      width: viewport.width + 'px',
      height: viewport.height + 'px',
      transform: `translate(${(w - viewport.width * scale) / 2}px,${(h - viewport.height * scale) / 2}px) scale(${scale})`
    });
  }

  function fitBrowse(target, padding = 0.06) { return CanvasCamera.fit(CanvasCamera.bounds(P, target), viewport, padding); }
  function browse() { pause(); segment = null; const entering = mode !== 'browse'; setMode('browse'); if (entering || !freeCamera) { browseTarget = 'overview'; freeCamera = fitBrowse('overview', 0.05); } draw(time); }
  function focus(id) { browse(); browseTarget = id; select(elements.has(id) ? id : ''); freeCamera = fitBrowse(id, id === 'overview' ? 0.05 : 0.08); draw(time); }
  function select(id) { if (id && !elements.has(id)) return; selected = id; for (const [key, el] of elements) el.classList.toggle('selected', key === id); window.dispatchEvent(new CustomEvent('canvas-selection', { detail: { id } })); }
  function setTool(next) { tool = next === 'pan' ? 'pan' : 'select'; document.body.classList.toggle('tool-pan', tool === 'pan'); window.dispatchEvent(new CustomEvent('canvas-tool-change', { detail: { tool } })); }

  async function preview(target) {
    const members = P.components.filter(c => c.id === target || c.board_id === target || target === 'overview');
    const ranges = members.map(c => c.preview_range).filter(Boolean);
    if (!ranges.length) return;
    pause();
    segment = {
      target,
      label: members.length === 1 ? members[0].content.title : P.boards.find(b => b.id === target)?.name || '完整项目',
      start: lead + Math.min(...ranges.map(r => r.start)),
      end: lead + Math.max(...ranges.map(r => r.end))
    };
    await seek(segment.start, { keepSegment: true });
    return play();
  }

  async function setCoverEnabled(enabled) {
    pause();
    const t = bodyTime();
    coverEnabled = !!enabled;
    lead = coverEnabled ? originalLead : 0;
    window.END = duration();
    segment = null;
    const result = await seek(t + lead);
    window.dispatchEvent(new CustomEvent('canvas-timing-change', { detail: { lead, audioOffset: audioOffset() } }));
    return result;
  }

  window.CanvasExplorer = {
    getMode: () => mode === 'browse' ? 'resource' : 'demo',
    getTime: () => time,
    getBodyTime: bodyTime,
    getView: () => ({ ...(mode === 'browse' ? freeCamera : cameraAt(bodyTime())) }),
    getSelected: () => selected,
    getTool: () => tool,
    getSegment: () => segment ? { ...segment } : null,
    getLead: () => lead,
    getAudioOffset: audioOffset,
    getCoverEnabled: () => coverEnabled,
    setCoverEnabled, pause, seek, focus, select, setTool, preview, play, browse,
    overview: () => focus('overview')
  };

  $('#play').onclick = () => play().catch(report);
  $('#replay').onclick = () => seek(segment?.start || 0, { keepSegment: true }).then(play).catch(report);
  $('#browse').onclick = browse;
  $('#overview').onclick = () => focus('overview');

  let requestedTime = null, uiSeeking = false;
  $('#seek').oninput = async () => {
    requestedTime = Number($('#seek').value);
    pause();
    if (uiSeeking) return;
    uiSeeking = true;
    try {
      while (requestedTime !== null) {
        const target = requestedTime;
        requestedTime = null;
        await seek(target, { keepSegment: true });
      }
    } catch (e) { report(e); } finally { uiSeeking = false; }
  };

  $('#subtitle-mode').onchange = () => window.CaptionDirector
    ? window.CaptionDirector.setMode($('#subtitle-mode').value).catch(report)
    : captions.setMode($('#subtitle-mode').value);

  $('#voice-only').onchange = async () => {
    if (window.CaptionDirector) return window.CaptionDirector.syncAudio({ resume: false }).catch(report);
    pause();
    const at = time;
    const loaded = new Promise(resolve => voice.addEventListener('loadedmetadata', resolve, { once: true }));
    voice.src = $('#voice-only').checked ? 'assets/preview-mix.m4a' : 'assets/preview-mix.m4a';
    await loaded;
    voice.currentTime = at + audioOffset();
  };

  for (const c of P.chapters) {
    const b = document.createElement('button');
    b.dataset.at = c.at;
    b.title = c.label;
    b.innerHTML = `<span>${c.at.toFixed(1)}s</span><b>${c.label}</b>`;
    b.onclick = () => seek(c.at + lead).catch(report);
    $('.phases').append(b);
  }

  function zoom(factor, point) {
    if (mode !== 'browse') browse();
    browseTarget = null;
    const old = freeCamera.scale;
    const next = Math.max(0.065, Math.min(6, old * factor));
    const p = point || { x: viewport.width / 2, y: viewport.height / 2 };
    freeCamera.cx += (p.x - viewport.width / 2) * (1 / old - 1 / next);
    freeCamera.cy += (p.y - viewport.height / 2) * (1 / old - 1 / next);
    freeCamera.scale = next;
    draw(time);
  }
  $('#zoom-in').onclick = () => zoom(1.3);
  $('#zoom-out').onclick = () => zoom(1 / 1.3);

  const screen = $('#screen');
  screen.addEventListener('pointerdown', e => {
    if (renderMode || ![0, 1].includes(e.button)) return;
    pause();
    const pan = tool === 'pan' || e.button === 1;
    if (pan && mode !== 'browse') browse();
    drag = { id: e.pointerId, x: e.clientX, y: e.clientY, camera: { ...(freeCamera || cameraAt(bodyTime())) }, target: e.target, moved: false, pan };
    screen.setPointerCapture(e.pointerId);
    if (pan) screen.classList.add('dragging');
  });
  screen.addEventListener('pointermove', e => {
    if (!drag || drag.id !== e.pointerId) return;
    const dx = e.clientX - drag.x, dy = e.clientY - drag.y;
    if (Math.hypot(dx, dy) > 6) drag.moved = true;
    if (!drag.pan) return;
    browseTarget = null;
    freeCamera = { ...drag.camera, cx: drag.camera.cx - dx / drag.camera.scale, cy: drag.camera.cy - dy / drag.camera.scale };
    draw(time);
  });
  function endDrag(e, cancelled = false) {
    if (!drag || drag.id !== e.pointerId) return;
    const previous = drag;
    drag = null;
    screen.classList.remove('dragging');
    lastTapTarget = !cancelled && !previous.pan && !previous.moved ? previous.target : null;
    if (lastTapTarget) {
      const el = lastTapTarget.closest('[data-component]');
      if (el) {
        select(el.dataset.component);
        window.dispatchEvent(new CustomEvent('canvas-review-request', { detail: { id: el.dataset.component, point: { x: e.clientX, y: e.clientY } } }));
      }
    }
  }
  screen.addEventListener('pointerup', e => endDrag(e));
  screen.addEventListener('pointercancel', e => endDrag(e, true));
  screen.addEventListener('lostpointercapture', e => endDrag(e, true));
  screen.addEventListener('wheel', e => {
    if (renderMode) return;
    e.preventDefault();
    if (mode !== 'browse') browse();
    const r = screen.getBoundingClientRect();
    zoom(Math.exp(-e.deltaY * 0.0013), { x: e.clientX - r.left, y: e.clientY - r.top });
  }, { passive: false });
  screen.addEventListener('dblclick', e => {
    if (renderMode) return;
    const el = e.target.closest('[data-component]') || lastTapTarget?.closest('[data-component]');
    if (el) focus(el.dataset.component);
  });

  const isEditing = e => e.target.closest('input,textarea,select,[contenteditable="true"],[role="dialog"]');
  document.addEventListener('keydown', e => {
    if (renderMode || isEditing(e)) return;
    if (e.code === 'Space') { e.preventDefault(); spaceDown = true; setTool('pan'); }
    else if (e.key.toLowerCase() === 'f') { e.preventDefault(); focus('overview'); }
  });
  document.addEventListener('keyup', e => { if (e.code === 'Space' && spaceDown) { e.preventDefault(); spaceDown = false; setTool('select'); } });
  window.addEventListener('blur', () => { spaceDown = false; setTool('select'); if (drag) endDrag({ pointerId: drag.id }, true); });
  voice.addEventListener('ended', () => { pause(); draw(segment?.end ?? duration()); });
  window.addEventListener('resize', () => { resize(); if (mode === 'browse' && browseTarget) freeCamera = fitBrowse(browseTarget, browseTarget === 'overview' ? 0.05 : 0.08); draw(time); });

  const loaded = el => el.readyState >= 2 ? Promise.resolve() : new Promise((resolve, reject) => {
    el.addEventListener('loadeddata', resolve, { once: true });
    el.addEventListener('error', () => reject(Error('媒体加载失败：' + el.src)), { once: true });
  });
  window.READY = Promise.all([loaded(video), loaded(voice), document.fonts.ready]).then(() => { setMode('demo'); return seek(0); });
  window.PREVIEW_STATE = () => ({
    time, bodyTime: bodyTime(), lead, audioOffset: audioOffset(), mode, playing, segment,
    viewport: { ...viewport }, videoTime: video.currentTime, audioTime: voice.currentTime,
    videoReady: video.readyState, audioReady: voice.readyState
  });
})();
